import { all } from 'redux-saga/effects';
import authSaga from './auth/saga';
import LayoutSaga from './layout/saga';
import { watchFetchProfileData } from './user/sagas';


export default function* rootSaga(getState) {
    yield all([
        authSaga(),
        LayoutSaga(),
        watchFetchProfileData(),
    ]);
}
