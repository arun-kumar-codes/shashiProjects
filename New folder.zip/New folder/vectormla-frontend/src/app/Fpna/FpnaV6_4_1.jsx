import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Divider, Grid, CircularProgress } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolioFPNA,
	downloadFPNATemplate,
	deletePortfolio,
	updatePortfolio,
	getScenarioFPNADetails,
	getPortfolioScenarios,
	getCalcStatus,
	runCalculate,
	downloadDataFile,
	downloadFpnaCustomReports,
	getSubPortofolios,
	getSegment,
	getPdfUrl
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import FundingRequests from '../components/portfolio/FundingRequests';
import Chart from 'app/components/Chart/Chart';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import {
	GET_FPNA6_TABLES_CLEAN,
	GET_CHARTS6_CLEAN,
	TASK_PROGRESS_FPNA6,
	STOP_FPNA6_TIMER
} from '../store/types/fpna.type';
import { dynamicHeaders } from './liabilityTableFileds';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import {
	requiredTablesFpnaV6_3_1,
	tableDataFpnaV6_3_1,
	tableDataFpnaV6_4_1
} from './fpna6Assets';
import PDFViewer from '../helpers/PDFViewer';
import { API } from '../../config/EnvironmentConfig';
import FpnaCreditFacility from './FpnaCreditFacility';
import NumberOfLoans from 'app/components/portfolio/NumberOfLoans';
import { DummyDataForTable } from './tableDummyData';
import DummyWAchartData from './dummyWAchartData';
import { numberOfLoanValues } from 'app/helpers/static';
import dummyWAannualRatechartData from './dummyWAannualRatechartData';
import { log } from 'async';

const FpnaV6_4_1 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios6,
		tables6,
		status6,
		scenarios6,
		staus6ScenarioID,
		subPortofolio6
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);
	// state to check first time status if success
	const [timerStarted, setTimerStarted] = useState(false);
	const [chartVisible, setChartVisible] = useState(false);
	const [chartsData, setChartsData] = useState([]);
	// const pdfUrlDaily = `${API}/cfm6/report_files/?file=bb_report_pdf`;
	const [pdfUrlBbReport, setPdfUrlBbReport] = useState('');
	const [pdfUrlMonthlyReport, setPdfUrlMonthlyReport] = useState('');
	const [pdfUrlRequestAdvance, setPdfUrlRequestAdvance] = useState('');
	const [dummyData, setDummyData] = useState(DummyDataForTable);
	const [waChartData, setWaChart] = useState(DummyWAchartData);
	const [waAnnualRateChartData, setWaAnnualRateChartData] = useState(
		dummyWAannualRatechartData
	);

	useEffect(() => {
		getPdfUrl('6', 'bb_report_pdf', setPdfUrlBbReport);
		getPdfUrl('6', 'monthly_report_pdf', setPdfUrlMonthlyReport);
		getPdfUrl('6', 'request_for_advance_pdf', setPdfUrlRequestAdvance);
	}, []);

	useEffect(() => {
		let tempChart = [];
		const chart = [];
		let tempChart2 = [];
		const chart2 = [];
		if (waChartData) {
			waChartData['Date'].forEach((val1, i) => {
				let tempObj = { Date: val1 };

				for (let key in waChartData) {
					if (key !== 'Date') {
						tempObj[key] = waChartData[key][i];
					}
				}

				tempChart.push(tempObj);
			});
		}
		chart.push(tempChart);

		if (waAnnualRateChartData) {
			waAnnualRateChartData['Date'].forEach((val1, i) => {
				let tempObj2 = { Date: val1 };

				for (let key in waAnnualRateChartData) {
					if (key !== 'Date') {
						tempObj2[key] = waAnnualRateChartData[key][i];
					}
				}

				tempChart2.push(tempObj2);
			});
		}

		chart2.push(tempChart2);

		let updatedCharts = [
			{
				ch: chart
			},
			{
				ch: chart2
			}
		];
		setChartsData(updatedCharts);
	}, [chartVisible]);

	useEffect(() => {
		if (!portfolios6 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		else setSelectedPortfolio(portfolios6?.[0]);
		if (staus6ScenarioID) {
			setRunningTaskId();
			stopTimerFunction();
			dispatch(stopTimer('cfm6', 'STOPPED', () => setTimerStarted(false)));
		}
	}, [portfolios6]);

	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		if (Object.keys(tables6 || {}).length > 0)
			fetchScenariosDetails(Object.keys(tables6));
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
		// for charts data
	}, [selectedScenario]);

	const dispatchClean = (/*unmount*/ callBack) => {
		dispatch({
			type: GET_FPNA6_TABLES_CLEAN
			// payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS6_CLEAN });
		stopTimerFunction();
		dispatch(
			stopTimer('cfm6', 'change', () => {
				setTimerStarted(false);
				callBack && callBack();
			})
		);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (selectedScenario[0] && status6 === 'SUCCESS') {
			fetchScenariosDetails();
			setTimerStarted(false);
		}
		selectedScenario[0] &&
			(status6 === 'STOPPED' ||
				status6 === 'FAILURE' ||
				status6 === 'stopped') &&
			calculateStatus(selectedScenario[0]?.id, true);
	}, [status6]);

	const fetchSubPorofolios = () => {
		dispatch(
			getSubPortofolios(
				'6',
				selectedScenario[0]?.id,
				(scenriosSubPortofolios) => {
					setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
					scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
				}
			)
		);
	};

	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('6', supPorofolioId));
	};

	const fetchScenarioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getScenarioFPNADetails('6', selectedScenario[0]?.id, type, (data) => {
				if (type === 'default-vintage') {
					const finalObject = {};
					Object.keys(data?.vintage_df?.category).forEach((item) => {
						finalObject[item] = data?.vintage_df?.category[item];
					});
				}
			})
		);
	};

	const fetchScenariosDetails = async (openedTables) => {
		const fetchPromises = (openedTables || requiredTablesFpnaV6_3_1).map(
			(table) => fetchScenarioDetails(selectedScenario[0]?.id, table + '/')
		);
		// this line is to wait for all the promises to resolve
		await Promise.all(fetchPromises);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('6', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};
	const uploadFunction = (formData) => {
		dispatchClean(() => {
			dispatch(
				updatePortfolio(
					'6',
					selectedPortfolio?.id,
					formData,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchScenarios(selectedPortfolio?.id, 'create');
					},
					'fpna6'
				)
			);
			dispatch({
				type: TASK_PROGRESS_FPNA6,
				payload: '0.0 %'
			});
		});
	};
	const setDataFunction = (val) => {
		setDataType(val);
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
		if (tables6) fetchScenarioDetails(selectedScenario[0]?.id, val);
	};
	const updateFunction = (name) => {
		dispatchClean(() =>
			dispatch(
				updatePortfolio('6', selectedPortfolio?.id, { name }, () => {
					fetchPortfolio();
				})
			)
		);
	};
	const createFunction = (name, file) => {
		dispatchClean(() =>
			dispatch(
				createPortfolioFPNA(
					'6',
					name,
					user?.company_id,
					file,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchPortfolio('create');
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: '0.0 %'
						});
					},
					'fpna6'
				)
			)
		);
	};
	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('6', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, create);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, create) => {
		dispatch(
			getPortfolioScenarios('6', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm6', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const calculateStatus = (supPorofolioId, checkInStart) => {
		getCalcStatus(
			'cfm6/portfolio',
			selectedSubPorofolio[0]?.id || selectedScenario?.[0]?.id,
			(res) => {
				if (checkInStart && res?.task_state === 'SUCCESS') {
					setTimerStarted(false);
					return;
				} else {
					dispatch(startTimer('cfm6', supPorofolioId, ''));
					setRunningTaskId(selectedPortfolio?.id);
					setTimerStarted(true);
					if (res.task_state !== 'SUCCESS' && res.task_state !== 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: res.task_progress
						});
					}
					if (res.task_state === 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: 'Failed'
						});
						dispatch(
							killTaskFunc('cfm6', selectedPortfolio?.id, () => {
								deleteFunction();
								setRunningTaskId();
								stopTimerFunction();
								dispatch(
									stopTimer('cfm6', 'STOPPED', () => setTimerStarted(false))
								);
							})
						);
					}
				}
			}
		);
	};
	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('6', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};
	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA6_TIMER,
			payload: { status6: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog, callBack) => {
		let id = selectedPortfolio?.id;
		if (('' + status6)?.toLowerCase() === 'pending') {
			let modelName = 'cfm6';
			dispatch(
				killTaskFunc(modelName, id, () => {
					deleteFunction();
					closeKillTaskDialog && closeKillTaskDialog();
					setRunningTaskId();
					stopTimerFunction();
					dispatch(
						stopTimer(modelName, 'STOPPED', () => {
							setTimerStarted(false);
							callBack && callBack();
						})
					);
				})
			);
		} else {
			setTimerStarted(false);
			callBack && callBack();
		}
	};
	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
	}, [collapsed]);
	const typeHeaders = (tableName, category) => {
		if (tableName) return dynamicHeaders(category);
		else return null;
	};

	if (
		!user?.allowed_pages?.includes(4) ||
		!user?.allowed_section4.includes(403)
	)
		return <div></div>;

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator,
		extraMultiSeparator
	) => {
		let finalTableName =
			tableName === 'specialtable2' ? 'assetamort_table' : tableName;
		const fetchData = () => {};
		const handleStatusChange = (value, colIndex, index) => {
			const newData = { ...tableData };
			newData[tableName]['data'][colIndex][index] = value;
			setDummyData(newData);
		};
		return (
			<div>
				<MainTable
					statusScenarioId={staus6ScenarioID}
					status={('' + status6).toLowerCase()}
					header={tableData && tableData[finalTableName]?.columns}
					data={tableData && tableData[finalTableName]}
					attributes={
						tableData &&
						tableData[finalTableName]?.data &&
						Object.keys(tableData[finalTableName]?.columns)
					}
					tableData={tableData}
					multiSeparator={multiSeparator}
					extraMultiSeparator={extraMultiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableDataName={finalTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					collapsed={collapsed}
					separator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								multiSeparator ? 'category' : 'category2'
							]
					)}
					nestedSeparator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							!multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								!multiSeparator ? 'category' : 'category2'
							]
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model="6"
					id={selectedScenario[0]?.id}
					modelName="fpna6-4-1"
					onLeft={true}
					fetchData={fetchData}
					handleStatusChange={handleStatusChange}
				/>
			</div>
		);
	};

	const renderTables = () => {
		return tableDataFpnaV6_4_1.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				dummyData,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};
	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<FpnaCreditFacility model={'fpna6-4-1'} />
						<div
							style={{ marginTop: '55px', marginBottom: 80, marginLeft: -20 }}
						>
							<NumberOfLoans data={numberOfLoanValues('securitization')} />
						</div>
						{/* <Portfolio
							dispatchClean={() => dispatchClean()}
							model={'fpna6-4-1'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							timerStarted={timerStarted}
							loading={('' + status6).toLowerCase() === 'pending'}
							key={1006}
							portfolioList={portfolios6 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios6.filter((item) => item.id == val)[0]
								);
							}}
							// create={(name, file) => createFunction(name, file)}
							// update={(name) => updateFunction(name)}
							// deleteObj={() => deleteFunction()}
							upload={(formData) => uploadFunction(formData)}
							downloadFile={() => {
								dispatch(downloadDataFile('6', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('6'));
							}}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios6?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => setSelectedScenario([item])}
							setData={(val) => setDataFunction(val)}
							downloadCustomReports={(type) => {
								dispatch(
									downloadFpnaCustomReports('6', selectedScenario[0]?.id, type)
								);
							}}
							collapsed={collapsed}
							runCalculateFunction={runCalculateFunction}
							selectedData={dataType}
							seconds={0}
							status={status6}
							minutes={0}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/> */}
						<>{renderTables()}</>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						{/*{pdfUrl && <PDFViewer pdfUrl={pdfUrl} pdfName="BB Report" />}
						<PDFViewer
							pdfUrl={pdfUrlMonthly}
							pdfName={'Borrowing Base Monthly'}
						/>
						<PDFViewer
							pdfUrl={pdfUrlRequestAdvance}
							pdfName={'Borrowing Base Advance'}
						/>*/}
						<div>
							<FundingRequests />
							<PDFViewer
								displayOnlyName
								pdfUrl={pdfUrlBbReport}
								pdfName="Borrowing Base Report"
							/>
							<PDFViewer
								displayOnlyName
								pdfUrl={pdfUrlMonthlyReport}
								pdfName="Monthly Report"
							/>
							<PDFViewer
								displayOnlyName
								pdfUrl={pdfUrlRequestAdvance}
								pdfName="Request for Advance"
							/>
						</div>

						<Grid
							className={classes.appContentContainer}
							direction="column"
							container
							style={{ marginTop: '30px' }}
						>
							<div
								className={classes.contentHeaderContainer}
								onClick={() => setChartVisible(!chartVisible)}
							>
								<p className={classes.contentHeader}>{'WA Chart'}</p>
							</div>
						</Grid>

						{/* todo: create seperate component */}

						<Grid style={{ display: 'flex', flexFlow: 'wrap' }}>
							{chartVisible && (
								<Grid
									item
									xs={12}
									sm={12}
									md={6}
									style={{ marginTop: '20px', height: '300px' }}
								>
									{chartsData.length && (
										<Chart
											dataT={chartsData?.[0]?.ch}
											nameLegend={`The WA Original Term`}
											sizeLegend="14px"
											dataX="Date"
											tickCount={6}
											xDistance={100}
											noCharts={Object.keys(waChartData || {}).filter(
												(key) => key !== 'Date'
											)}
										/>
									)}
								</Grid>
							)}

							{chartVisible && (
								<Grid
									item
									xs={12}
									sm={12}
									md={6}
									style={{ marginTop: '20px', height: '300px' }}
								>
									{chartsData.length && (
										<Chart
											dataT={chartsData?.[1]?.ch}
											nameLegend={`The WA Annual % Rate`}
											sizeLegend="14px"
											dataX="Date"
											tickCount={7}
											xDistance={100}
											noCharts={Object.keys(waAnnualRateChartData || {}).filter(
												(key) => key !== 'Date'
											)}
										/>
									)}
								</Grid>
							)}
						</Grid>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default FpnaV6_4_1;
