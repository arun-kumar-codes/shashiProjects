import React from 'react'
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import PartnerNetwork from './PartnerNetwork/PartnerNetwork';
import DataRequest from './DataRequests/DataRequest';
import { Stack } from '@mui/material';
// import { Card, Nav } from 'react-bootstrap'


function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Stack mt={'10px'} >
          {children}
        </Stack>
      )}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const Sustainability = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
      <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'white', borderRadius: "10px" }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example" sx={{ paddingLeft: "10px" }} >
          <Tab sx={{ fontWeight: "600" }} label="Partner Network" {...a11yProps(0)} />
          <Tab sx={{ fontWeight: "600" }} label="Data Requests" {...a11yProps(1)} />
          </Tabs>
        </Box>
        <CustomTabPanel value={value} index={0}>
          <PartnerNetwork />
        </CustomTabPanel>
        <CustomTabPanel value={value} index={1}>
          <DataRequest />
        </CustomTabPanel>
    </Box>
  )
}

export default Sustainability
