import * as React from 'react';
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { Stack } from "@mui/material";
import InsightCard from "./InsightCard";
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component="div"

      role="tabpanel"
      hidden={value !== index}
      id={`action-tabpanel-${index}`}
      aria-labelledby={`action-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `action-tab-${index}`,
    'aria-controls': `action-tabpanel-${index}`,
  };
}



export default function InsightCardsTable() {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleChangeIndex = (index) => {
    setValue(index);
  };


  return (
    <Stack
      sx={{
        bgcolor: 'background.paper',
        width: "100%",
        position: 'relative',
        minHeight: 200,
        borderRadius: "20px",
        boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
      }}
    >
      <AppBar position="static" color="default">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          textColor="primary"
          variant="fullWidth"
          aria-label="action tabs example"
        >
          <Tab sx={{
            fontWeight: "600",
          }} label="New Insights " {...a11yProps(0)} />
          <Tab sx={{ fontWeight: "600" }} label="In Review" {...a11yProps(1)} />
          <Tab sx={{ fontWeight: "600" }} label="Resolved" {...a11yProps(2)} />
        </Tabs>
      </AppBar>
      <SwipeableViews
        axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
        index={value}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={value} index={0} dir={theme.direction}>
          <Stack direction={'row'} sx={{ padding: "20px 10px", justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
          </Stack>
        </TabPanel>
        <TabPanel value={value} index={1} dir={theme.direction}>
          <Stack direction={'row'} sx={{ padding: "20px 10px", justifyContent: { lg: 'space-between', md: 'center' }, flexWrap: 'wrap', gap: 2, alignItems: 'center' }}>
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
          </Stack>
        </TabPanel>
        <TabPanel value={value} index={2} dir={theme.direction}>
          <Stack direction={'row'} sx={{ padding: "20px 10px", justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
            <InsightCard />
          </Stack>
        </TabPanel>
      </SwipeableViews>
    </Stack>
  );
}

