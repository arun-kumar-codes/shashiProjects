import { Outlet} from "react-router-dom"
import SideBar from "../../components/sideBar/SideBar"
import Footer from "../../components/footer/Footer"
import { Box, Stack } from "@mui/material"

const Main = () => {
  return (
    <Box>
      <SideBar SideBarpages={<Stack  spacing={2}>
        <div>
          <Outlet />
        </div>
        <Footer />
      </Stack>} />

    </Box>
  )
}

export default Main
