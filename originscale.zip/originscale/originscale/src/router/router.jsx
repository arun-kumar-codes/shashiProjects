import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import Home from "../pages/Home/Home";
import Sell from "../pages/Sell/Sell";
import Main from "../pages/mainAi/Main";
import Insights from "../pages/AI/Insights/Insights";
import InventoryVisibility from "../pages/AI/InventoryVisibility/InventoryVisibility";
import NetworkMap from "../pages/AI/NetworkMap/NetworkMap";
import NTierVisibility from "../pages/AI/n-tier_visibility/NTierVisibility";
import DataLake from "../pages/AI/data_lake/DataLake";
import Sustainability from "../pages/AI/sustainability/Sustainability";
import DemandPlaning from "../pages/AI/demand_planing/DemandPlaning";
import WorkOrderInsigates from "../pages/AI/work_order_insigates/WorkOrderInsigates";
import MainHome from "../pages/AI/MainHome/MainHome";
import SupplyPlaning from "../pages/AI/supply_planing/SupplyPlaning";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { path: "", element: <Home /> },
      { path: "sell", element: <Sell /> },
      {
        path: "ai",
        element: <Main />,
        children: [
          { path: "", element: <MainHome /> },
          { path: "insights", element: <Insights /> },
          { path: "inventory_visibility", element: <InventoryVisibility /> },
          { path: "network_map", element: <NetworkMap /> },
          { path: "n-tier_visibility", element: <NTierVisibility /> },
          { path: "data_lake", element: <DataLake /> },
          { path: "sustainability", element: <Sustainability /> },
          { path: "supply_planing", element: <SupplyPlaning /> },
          { path: "demand_planing", element: <DemandPlaning /> },
          {
            path: "work_order_insigates",
            element: <WorkOrderInsigates />,
          },
        ],
      },
    ],
  },
]);
