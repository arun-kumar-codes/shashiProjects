import React from "react";
import Button from "components/CustomButton/CustomButton.jsx";
import StatusUtil from "../../common/util/statusUtil";
import * as _ from 'lodash';
import * as purchaseOrderConstant from './purchaseOrderConstant';
import { FormControl, InputGroup } from "react-bootstrap";
import SuggestionUtil from "../../common/util/suggestionUtil";
import CommonUtil from "../../common/util/commonUtil";
import * as stockAdjustmentConstant from '../../stockAdjustment/constant/stockAdjustmentConstant';
import * as commonConstant from "../../common/constant/commonConstant";
import * as statusConstant from "../../common/constant/statusConstant";
import PurchaseOrderUtil from "../views/PurchaseOrderUtil";
import Datetime from "react-datetime";
import isAuthorized from "auth-plugin";
import Select from "react-select";
import currencyIcon from '../../common/util/currencyIcon';
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox';
import { countryList } from "../../common/constant/countryConstant";
import CustomRadio from "../../../components/CustomRadio/CustomRadio";
import moment from "moment";
import { OverlayTrigger, Tooltip } from "react-bootstrap";

export const CREATE_PURCHASE_ORDER_PAGE_LIST = (that) => ({
  attributeObj: {
    purchaseOrderId: "",
    supplierId: "",
    supplierName: "",
    facilityId: "",
    locationName: "",
    createdDate: CommonUtil.getTodaysDate(),
    requestedDeliveryDate: CommonUtil.getTodaysDate(),
    receivedDate: "",
    invoiceDate: CommonUtil.getTodaysDate(),
    status: statusConstant.NEW_STATUS,
    itemList: [],
    ingredients: [],
    paymentStatus: statusConstant.PENDING_STATUS,
    paymentDetailsList: [],
    totalPaidAmount: 0,
    documentList: [],
  },
  attributeList: [
    {
      name: "purchaseOrderId",
      type: "UNIQUE_CODE",
      label: "Purchase Order Number",
      prefix: "PO",
      required: false,
      inputType: "label",
      fieldWidth: 3,
      createModeRemoveFlag: true,
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "invoiceNumber",
      type: "TEXTBOX",
      label: "Invoice Number",
      prefix: "",
      required: false,
      inputType: "label",
      fieldWidth: 3,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      numberOfRow: 0,
      maxLength: 30,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "supplierId",
      type: "DROPDOWN",
      label: "Supplier",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "disabled",
      viewMode: "disabled",
      customAttribute: false,
      isDropdownCall: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      MsgText: "Search Supplier",
      MsgTextHref: "#",
      linkOnClickFun: that.searchSupplier,
    },
    {
      name: "shipLocationName",
      type: "DROPDOWN",
      label: "Ship From",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "facilityId",
      type: "DROPDOWN",
      label: "Ship To",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    // {
    //   name: "createdDate",
    //   type: "DATE",
    //   label: "Created Date",
    //   required: true,
    //   fieldWidth: 3,
    //   inputType: "date",
    //   cloneModeRemoveFlag: true,
    //   createModeShowFlag: true,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: true,
    //   viewModeShowFlag: true,
    //   backDateNotAllowed: true,
    //   createMode: "disabled",
    //   cloneMode: "disabled",
    //   editMode: "disabled",
    //   viewMode: "disabled",
    //   placeholder: "",
    //   numberOfRow: 0,
    //   mandatoryMsgText: "Field can not be empty.",
    // },
    // {
    //   name: "requestedDeliveryDate",
    //   type: "DATE",
    //   label: "Requested Delivery Date",
    //   required: true,
    //   fieldWidth: 3,
    //   inputType: "date",
    //   cloneModeRemoveFlag: true,
    //   createModeShowFlag: true,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: true,
    //   viewModeShowFlag: true,
    //   backDateNotAllowed: false,
    //   createMode: "enable",
    //   cloneMode: "enable",
    //   editMode: "enable",
    //   viewMode: "disabled",
    //   placeholder: "",
    //   numberOfRow: 0,
    //   mandatoryMsgText: "Field can not be empty.",
    // },
    {
      name: "invoiceDate",
      type: "DATE",
      label: "Invoice Date",
      required: false,
      fieldWidth: 3,
      inputType: "date",
      cloneModeRemoveFlag: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      backDateNotAllowed: false,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "receivedDate",
      type: "DATE",
      label: "Date Received",
      required: false,
      fieldWidth: 3,
      inputType: "date",
      cloneModeRemoveFlag: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      backDateNotAllowed: false,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "shippingMethod",
      type: "DROPDOWN",
      label: "Shipping Method",
      required: false,
      fieldWidth: 3,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: false,
      viewModeShowFlag: false,
      numberOfRow: 0,
      dataDictionaryFlag: true,
      dataDictionaryId: 'shippingMethod',
    },
    {
      name: "incoterms",
      type: "DROPDOWN",
      label: "Incoterms",
      required: false,
      fieldWidth: 3,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: false,
      viewModeShowFlag: false,
      numberOfRow: 0,
      dataDictionaryFlag: true,
      dataDictionaryId: 'incoterms',
    },
    {
      name: "reference",
      type: "TEXTBOX",
      label: "References",
      required: false,
      fieldWidth: 3,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      numberOfRow: 0,
      maxLength: 32,
      minLength: 1,
    },
    {
      name: "status",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      name: "totalValue",
      type: "TEMP",
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      name: "version",
      type: "TEMP",
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
    {
      name: "itemList",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "ingredients",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "createdDate",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    // {
    //   name: "termsCondition",
    //   type: "TEMP",
    //   createModeShowFlag: true,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: true,
    // },
    {
      name: "paymentStatus",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
    {
      name: "documentList",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
    {
      name: "expenseList",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    }
  ],
  // termsAttributeList: [
  //   {
  //     name: "termsCondition",
  //     type: "DROPDOWN",
  //     label: "Terms & Conditions",
  //     required: false,
  //     fieldWidth: 12,
  //     createMode: 'enable',
  //     cloneMode: 'enable',
  //     editMode: 'enable',
  //     viewMode: 'disabled',
  //     createModeShowFlag: true,
  //     cloneModeShowFlag: true,
  //     editModeShowFlag: true,
  //     viewModeShowFlag: true,
  //     numberOfRow: 0,
  //     dataDictionaryFlag: true,
  //     isTermConditionFlag: true,
  //     dataDictionaryId: 'termsCondition',
  //   },
  // ],
});

export const PAYMENT_PROCESS_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Payment Date",
        id: "receivedDate",
        name: "receivedDate",
        accessor: "receivedDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"receivedDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: CommonUtil.isNotNull(original.purchaseOrderId) || CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }}
              name={'receivedDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "receivedDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Paid Amount",
        id: "receivedAmount",
        accessor: "receivedAmount",
        name: "receivedAmount",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isZero = CommonUtil.getFloatValue(value, true) == 0 || !value
          return (
                 <InputGroup
                  className={that.state.submitted && isZero ? 'required-error' : ''}>
                  <FormControl id={'receivedAmount' + '_' + index}
                      min={0}
                      data-type={'number'}
                      onPaste={(e) => { e.preventDefault(); return false }}
                      name={'receivedAmount'} onChange={that.handleTableTextBoxChange}
                      disabled={CommonUtil.isNotNull(original.purchaseOrderId) || CommonUtil.isViewMode(that.props.actionMode)}
                      value={value}
                      onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                      onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                      maxLength={10}
                      minLength={1} />
              </InputGroup>
          )
      }
      },
      {
        Header: "Payment Mode",
        id: "paymentMode",
        accessor: "paymentMode",
        name: "paymentMode",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: false,
        style: {
          flex: "0 0 150px",
        },
        dataDictionaryId: 'paymentMode',
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={'paymentMode' + '_' + index}
              name={"paymentMode" + '_' + index}
              onChange={that.handleTableDropDownChange}

              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList &&
                that.props.dataDictionaryList.filter((d) => d.dataType === 'paymentModeList')}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isNotNull(original.purchaseOrderId) || CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.paymentMode)} />
          )
        },
      },
      {
        Header: "Deposit Date",
        id: "depositeDate",
        name: "depositeDate",
        accessor: "depositeDate",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"depositeDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: CommonUtil.isNotNull(original.purchaseOrderId) || CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }}
              name={'depositeDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "depositeDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Description",
        id: "description",
        name: "description",
        accessor: "description",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"description" + "_" + index}
                name={"description"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isNotNull(original.purchaseOrderId) || CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value && value != "undefined" ? value : ''}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "actions",
        name: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              {!CommonUtil.isNotNull(original.purchaseOrderId) && <Button bsStyle="default" simple icon>
                <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}>
                  <i title="view" id={original.purchaseOrderId + "_" + index + "_" + original.ruleCode}
                    className="fa fa-trash"
                    onClick={(e) => that.handleTableRemove(e)}
                  />
                </div>
              </Button>}
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST = (that) => {
  return {
    tableData: [],
    tableColumnList: [
      {
        Header: "Product",
        id: "productId",
        name: "productId",
        accessor: "productId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 250px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let isDelivered = CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? true : false;
          return (
            <div title={(original.isIngredient ? "ING-" : "PRO-") + original.productId ? original.productId + "|" + original.productName : ''}>
              {original.productId ? ((original.isIngredient ? "ING-" : "PRO-") + original.productId + " | " + original.productName) : ''}
            </div>
          )
        },
      },
      {
        Header: "Quantity",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup
              className={original.productId && (that.state.submitted && !value ? 'required-error' : '')}>
              <FormControl
                id={"quantity" + "_" + index}
                name={"quantity"}
                data-type={'number'}
                onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isReceivedAllStatus ||
                  CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                value={value ? CommonUtil.getFloatValue(value, true) : ''}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { that.pressEnter(e) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Received Qty",
        id: "receivedQuantity",
        accessor: "receivedQuantity",
        name: "receivedQuantity",
        required: false,
        inputType: "float",
        disableSortBy: true,
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedFlag = PurchaseOrderUtil.isReceivedStatus(tempValue);
          return (
            <div className={CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? 'field-data' : 'field-data'}
              id={original.productId + '_' + index}
              name={'receivedQuantity'}>
              {CommonUtil.getFloatValue(original.receivedQuantity)}
              <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM))}</span>
            </div>
          )
        }
      },
      {
        Header: "Rate",
        id: "price",
        accessor: "price",
        name: "price",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Rate" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Rate";
          const { value } = cell;
          const { index, original } = cell.row;
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          const isZero = original.lop ? (CommonUtil.getFloatValue(original.lop, true) != 0) ? false : true :true;
          const rateDifference = CommonUtil.getFloatValue(original.lop, true) != CommonUtil.getFloatValue(original.price, true) ? true : false;
          const isEqual =  CommonUtil.getFloatValue(original.lop, true) == CommonUtil.getFloatValue(original.price, true) ? true : false;
          return (
            (rateDifference && !isZero) ?
              <OverlayTrigger
                placement="top"
                overlay={
                  <Tooltip id="difference" className='difference-tooltip'>
                    {rateDifference ? "Rate has been changed from last order price." : ""}
                  </Tooltip>
                }
              >
                <InputGroup
                  className={original.productId && rateDifference ? 'difference' : ''}>
                  <FormControl
                    id={'price' + '_' + index}
                    data-type={'number'}
                    onPaste={(e) => { e.preventDefault(); return false }}
                    name={'price'}
                    min={0}
                    onChange={that.handleTableTextBoxChange}
                    disabled={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                    value={value}
                    onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                    onKeyDown={(e) => { that.pressEnter(e) }}
                    maxLength={10}
                    minLength={1} />
                </InputGroup>
              </OverlayTrigger>
              :
              <InputGroup
                className={original.productId && ((that.state.submitted && !CommonUtil.isNotNull(value)) ? 'required-error' : '')}>
                <FormControl
                  id={'price' + '_' + index}
                  data-type={'number'}
                  onPaste={(e) => { e.preventDefault(); return false }}
                  name={'price'}
                  min={0}
                  onChange={that.handleTableTextBoxChange}
                  disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                  value={value}
                  onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                  onKeyDown={(e) => { that.pressEnter(e) }}
                  maxLength={10}
                  minLength={1} />
              </InputGroup>
          )
        }
      },
      {
        Header: "LOP",
        id: "lop",
        accessor: "lop",
        name: "lop",
        required: false,
        inputType: "number",
        type:"TEMP",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("LOP" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "LOP";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div id={'lop' + '_' + index} name={'lop'}>
              {original.lop ? CommonUtil.getFloatValue(original.lop, true) : 0}
            </div>
          )
        }
      },
      {
        Header: "Amount",
        id: "totalPrice",
        name: "totalPrice",
        accessor: "totalPrice",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amount" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amount";
          const { value } = cell;
          const { index, original } = cell.row;
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup
              className={original.productId && (that.state.submitted && !CommonUtil.isNotNull(value) ? 'required-error' : '')}>
              <FormControl
                id={"totalPrice" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"totalPrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      // {
      //   Header: "Excise Tax(%)",
      //   id: "taxValue",
      //   accessor: "taxValue",
      //   name: "taxValue",
      //   inputType: "float",
      //   required: true,
      //   style: {
      //     flex: "0 0 90px",
      //   },
      //   disableSortBy: true,
      //   isZeroAllowed: true,
      //   disableFilters: true,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   dataDictionaryFlag: true,
      //   dataDictionaryId: 'taxList',
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     return (
      //       <Select
      //         className={that.state.submitted &&
      //           CommonUtil.isNullValue(value) ? 'required-error' : ''}
      //         id={'taxValue' + '_' + index}
      //         name={"taxValue" + '_' + index}
      //         onChange={that.handleTableDropDownChange}
      //         options={that.props.dataDictionaryList &&
      //           that.props.dataDictionaryList.dataDictionaryList &&
      //           that.props.dataDictionaryList.dataDictionaryList.taxList}
      //         classNamePrefix="react-select"
      //         isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
      //         value={{ "label": original.taxValue }} />
      //     )
      //   },
      // },
      {
        id: "taxValue",
        name: "taxValue",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
      },
      {
        id: "brand",
        name: "brand",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        Header: "Volume",
        id: "totalVolume",
        accessor: "totalVolume",
        name: "totalVolume",
        required: false,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div id={'volume' + '_' + index} name={'volume'} className="field-data">
              {CommonUtil.getFloatValue(original.totalVolume, true)}
              <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, (original.volumeUnitId || original.volumeUnit)))}</span>
            </div>
          )
        }
      },

      {
        Header: "Order Status",
        id: "orderStatus",
        accessor: "orderStatus",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          value = PurchaseOrderUtil.getIngredientStatus(original);
          return (
            <div className={`full-td`}
              id={original.productId + "_" + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      // {
      //   Header: "Document",
      //   id: "document",
      //   accessor: "document",
      //   createModeShowFlag: false,
      //   cloneModeShowFlag: false,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   disableSortBy: true,
      //   disableFilters: true,
      //   style: {
      //     flex: "0 0 80px",
      //   },
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     let documentCount = PurchaseOrderUtil.getDocumentCount(original.documentList) +
      //       CommonUtil.isNaNValue(parseInt(original.documentCount));
      //     documentCount = CommonUtil.isNaNValue(documentCount);
      //     return (
      //       <a className={documentCount > 0 ? `link` : ''}
      //         id={original.productId + "_" + that.props.purchaseOrderId + "_" + index}
      //         onClick={(e) => documentCount > 0 ? PurchaseOrderUtil.handleTableUploadButtonClick(e, that) : null}>
      //         {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
      //       </a>
      //     )
      //   }
      // },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 50px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          var tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
          var selectedListCount = PurchaseOrderUtil.getSelectedListCount(that.state.itemList);
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <div className="actions-left">
              {/* {selectedListCount > 1 ? */}
              <Button bsStyle="default" simple icon>
                {tempStatus == statusConstant.COMPLETED_STATUS ?
                  <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i title="Completed"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-thumbs-up" /></div>
                  : tempStatus == statusConstant.PARTIAL_RECEIVED ?
                    <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i title="Receive"
                      id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                      className="fa fa-truck"
                      onClick={(e) => PurchaseOrderUtil.handleTableReceiveStockButtonClick(e, that)} /></div>
                    : tempStatus == statusConstant.NEW_STATUS ?
                      <div className={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? 'circle disabled' : 'circle'}><i title="remove"
                        id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                        className="fa fa-trash"
                        onClick={(e) => that.handleDeleteRowPopup(e)} /></div>
                      : null}

                {tempStatus !== statusConstant.COMPLETED_STATUS && isAuthorized("productVariations") && <div className={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? 'circle disabled' : 'circle'}><i title="Add Variations" id={"variant" + '_' + index} className="fa fa-plus" onClick={(e) => that.addVariantsModel(e, original.productId)} /></div>}

              </Button>
              {/* : null} */}
            </div>
          );
        },
      },
      {
        id: "productName",
        name: "productName",
        name: "productName",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "receivingQuantity",
        name: "receivingQuantity",
        name: "receivingQuantity",
        inputType: "float",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "productUOM",
        name: "productUOM",
        name: "productUOM",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnitId",
        name: "volumeUnitId",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "category",
        name: "category",
        name: "category",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volume",
        name: "volume",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "documentList",
        name: "documentList",
        name: "documentList",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "invoiceNumber",
        name: "invoiceNumber",
        name: "invoiceNumber",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "transportDetail",
        name: "transportDetail",
        name: "transportDetail",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "isIngredient",
        name: "isIngredient",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 10000,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const CREATE_PURCHASE_ORDER_INGREDIENT_TABLE_LIST = (that) => {
  return {
    tableData: [],
    tableColumnList: [
      {
        Header: "Ingredient",
        id: "ingredientId",
        name: "ingredientId",
        accessor: "ingredientId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 250px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let isDelivered = CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? true : false;
          return (
            <div className="ellipsis" title={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}>
              {original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}
            </div>
          )
        },
      },
      {
        Header: "Quantity",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup
              className={original.ingredientId && (that.state.submitted && !value ? 'required-error' : '')}>
              <FormControl
                id={"quantity" + "_" + index}
                name={"quantity"}
                data-type={'number'}
                onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isReceivedAllStatus ||
                  CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                value={value ? CommonUtil.getFloatValue(value, true) : ''}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { that.pressEnter(e) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Received Qty",
        id: "receivedQuantity",
        accessor: "receivedQuantity",
        name: "receivedQuantity",
        required: false,
        inputType: "float",
        disableSortBy: true,
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedFlag = PurchaseOrderUtil.isReceivedStatus(tempValue);
          return (
            <div className={CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? 'field-data' : 'field-data'}
              id={original.ingredientId + '_' + index}
              name={'receivedQuantity'}>
              {CommonUtil.getFloatValue(original.receivedQuantity)}
              <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM))}</span>
            </div>
          )
        }
      },
      // {
      //   Header: "Pack/ Volume",
      //   id: "packORVolume",
      //   accessor: "packORVolume",
      //   name: "packORVolume",
      //   required: false,
      //   inputType: "float",
      //   disableSortBy: true,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   disableFilters: true,
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     return (
      //       <div className={'full-width field-data'}
      //         id={original.ingredientId + '_' + index}
      //         name={'packORVolume'}
      //         >
      //         {CommonUtil.getFloatValue(original.packORVolume)}
      //         <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.packORVolumeUnit))}</span>
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Rate",
        id: "price",
        accessor: "price",
        name: "price",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Rate" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Rate";
          const { value } = cell;
          const { index, original } = cell.row;
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup className={original.ingredientId && (that.state.submitted && !CommonUtil.isNotNull(value) ? 'required-error' : '')}>
              <FormControl
                id={"price" + "_" + index}
                data-type={'number'}
                onPaste={(e) => { e.preventDefault(); return false }}
                name={"price"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { that.pressEnter(e) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      {
        Header: "Amount",
        id: "totalPrice",
        name: "totalPrice",
        accessor: "totalPrice",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amount" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amount";
          const { value } = cell;
          const { index, original } = cell.row;
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup
              className={original.ingredientId && (that.state.submitted && !CommonUtil.isNotNull(value) ? 'required-error' : '')}>
              <FormControl
                id={"totalPrice" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"totalPrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      // {
      //   Header: "Excise Tax(%)",
      //   id: "taxValue",
      //   accessor: "taxValue",
      //   name: "taxValue",
      //   inputType: "float",
      //   required: true,
      //   style: {
      //     flex: "0 0 90px",
      //   },
      //   disableSortBy: true,
      //   isZeroAllowed: true,
      //   disableFilters: true,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   dataDictionaryFlag: true,
      //   dataDictionaryId: 'taxList',
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     return (
      //       <Select
      //         className={that.state.submitted &&
      //           CommonUtil.isNullValue(value) ? 'required-error' : ''}
      //         id={'taxValue' + '_' + index}
      //         name={"taxValue" + '_' + index}
      //         onChange={that.handleTableDropDownChange}
      //         options={that.props.dataDictionaryList &&
      //           that.props.dataDictionaryList.dataDictionaryList &&
      //           that.props.dataDictionaryList.dataDictionaryList.taxList}
      //         classNamePrefix="react-select"
      //         isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
      //         value={{ "label": original.taxValue }} />
      //     )
      //   },
      // },
      {
        id: "taxValue",
        name: "taxValue",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
      },
      {
        id: "brand",
        name: "brand",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      // {
      //   Header: "Volume",
      //   id: "totalVolume",
      //   accessor: "totalVolume",
      //   name: "totalVolume",
      //   required: false,
      //   type: "text",
      //   disableSortBy: true,
      //   disableFilters: true,
      //   createModeShowFlag: false,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     return (
      //       <div id={'totalVolume' + '_' + index} name={'totalVolume'}>
      //         {CommonUtil.getFloatValue(original.totalVolume, true) + "  " +
      //           CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM))}
      //       </div>
      //     )
      //   }
      // },

      {
        Header: "Order Status",
        id: "orderStatus",
        accessor: "orderStatus",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          value = PurchaseOrderUtil.getIngredientStatus(original);
          return (
            <div className={`full-td`}
              id={original.productId + "_" + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      // {
      //   Header: "Document",
      //   id: "document",
      //   accessor: "document",
      //   createModeShowFlag: false,
      //   cloneModeShowFlag: false,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   disableSortBy: true,
      //   disableFilters: true,
      //   style: {
      //     flex: "0 0 80px",
      //   },
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     let documentCount = PurchaseOrderUtil.getDocumentCount(original.documentList) +
      //       CommonUtil.isNaNValue(parseInt(original.documentCount));
      //     documentCount = CommonUtil.isNaNValue(documentCount);
      //     return (
      //       <a className={documentCount > 0 ? `link` : ''}
      //         id={original.productId + "_" + that.props.purchaseOrderId + "_" + index}
      //         onClick={(e) => documentCount > 0 ? PurchaseOrderUtil.handleTableUploadButtonClick(e, that) : null}>
      //         {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
      //       </a>
      //     )
      //   }
      // },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 50px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          var tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
          var selectedListCount = PurchaseOrderUtil.getSelectedListCount(that.state.itemList);
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <div className="actions-left">
              {/* {selectedListCount > 1 ? */}
              <Button bsStyle="default" simple icon>
                {tempStatus == statusConstant.COMPLETED_STATUS ?
                  <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i title="Completed"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-thumbs-up" /></div>
                  : tempStatus == statusConstant.PARTIAL_RECEIVED ?
                    <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i title="Receive"
                      id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                      className="fa fa-truck"
                      onClick={(e) => PurchaseOrderUtil.handleTableReceiveStockButtonClick(e, that)} /></div>
                    : tempStatus == statusConstant.NEW_STATUS ?
                      <div className={CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? 'circle disabled' : 'circle'}><i title="remove"
                        id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                        className="fa fa-trash"
                        onClick={(e) => that.handleDeleteRowPopup(e)} /></div>
                      : null}


              </Button>
              {/* : null} */}
            </div>
          );
        },
      },
      {
        id: "ingredientName",
        name: "ingredientName",
        name: "ingredientName",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "receivingQuantity",
        name: "receivingQuantity",
        name: "receivingQuantity",
        inputType: "float",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "ingredientUOM",
        name: "ingredientUOM",
        name: "ingredientUOM",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "category",
        name: "category",
        name: "category",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnitId",
        name: "volumeUnitId",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volume",
        name: "volume",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "documentList",
        name: "documentList",
        name: "documentList",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "invoiceNumber",
        name: "invoiceNumber",
        name: "invoiceNumber",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "transportDetail",
        name: "transportDetail",
        name: "transportDetail",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 10000,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const CREATE_PURCHASE_ORDER_PRODUCT_RECEIVE_TABLE_LIST = (that) => {
  return {
    tableData: [
      {
        product: "",
        quantity: "",
        price: "",
        taxValue: "",
        totalPrice: "",
        productUOM: "",
        category: "",
      },
    ],
    tableColumnList: [
      {
        Header: "Product",
        id: "productId",
        name: "productId",
        accessor: "productId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 250px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let isDelivered = CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? true : false;
          return (
            <div title={(original.isIngredient ? "ING-" : "PRO-") + original.productId ? original.productId + "|" + original.productName : ''}>
              {original.productId ? ((original.isIngredient ? "ING-" : "PRO-") + original.productId + " | " + original.productName) : ''}
            </div>
          )
        },
      },
      {
        Header: "Ordered Qty",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl
                id={"quantity" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"quantity"}
                disabled={isReceivedAllStatus ||
                  CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                onChange={that.handleTableTextBoxChange}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1}
              />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Received Qty",
        id: "receivedQuantity",
        accessor: "receivedQuantity",
        name: "receivedQuantity",
        required: false,
        inputType: "float",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedFlag = PurchaseOrderUtil.isReceivedStatus(tempValue);
          return (
            <div className={CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? 'field-data' : 'field-data'}
              id={original.productId + '_' + index}
              name={'receivedQuantity'}>
              {CommonUtil.getFloatValue(original.receivedQuantity)}
              <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM))}</span>
            </div>
          )
        }
      },
      {
        Header: "Rate",
        id: "price",
        accessor: "price",
        name: "price",
        required: false,
        type: "TEMP",
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Rate" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Rate";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div style={{ padding: '0 6px'}}>{value}</div>
          )
        }
      },
      {
        Header: "Amount",
        id: "totalPrice",
        name: "totalPrice",
        accessor: "totalPrice",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amount" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amount";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div style={{ padding: '0 6px'}}>{value}</div>
          )
        },
      },
      {
        Header: "Left Qty",
        id: "leftQuantity",
        accessor: "leftQuantity",
        name: "leftQuantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"leftQuantity" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"leftQuantity"}
                onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={CommonUtil.getFloatValue(PurchaseOrderUtil.getLeftQuantity(original), 2)}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Receiving Qty",
        id: "receivingQuantity",
        accessor: "receivingQuantity",
        name: "receivingQuantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          let tempStatus = that.state.attributeObj.status;
          let fullFilledQty = CommonUtil.getFloatValue(original.receivedQuantity, true) >= CommonUtil.getFloatValue(original.quantity, true) ? true : false;
          return (
            <InputGroup className={that.state.submitted && !CommonUtil.isNotNull(value) ? 'required-error' : ''}>
              <FormControl
                id={"receivingQuantity" + "_" + index}
                name={"receivingQuantity"}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isReceivedAllStatus || tempStatus == statusConstant.COMPLETED_STATUS ||
                  CommonUtil.isViewMode(that.props.actionMode) || fullFilledQty ? true : false}
                value={(CommonUtil.isViewMode(that.props.actionMode) && tempStatus == statusConstant.COMPLETED_STATUS) ? 0 : value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Volume",
        id: "totalVolume",
        accessor: "totalVolume",
        name: "totalVolume",
        required: false,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: false,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div id={'volume' + '_' + index} name={'volume'} className="field-data">
              {CommonUtil.getFloatValue(original.totalVolume, true)}
              <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, (original.volumeUnitId || original.volumeUnit)))}</span>
            </div>
          )
        }
      },
      {
        Header: "Order Status",
        id: "orderStatus",
        accessor: "orderStatus",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        disableSortBy: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          value = PurchaseOrderUtil.getIngredientStatus(original);
          return (
            <div className={`full-td`}
              id={original.productId + "_" + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      // {
      //   Header: "Document",
      //   id: "document",
      //   accessor: "document",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: false,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   disableSortBy: true,
      //   disableFilters: true,
      //   style: {
      //     flex: "0 0 110px",
      //   },
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     let documentCount = PurchaseOrderUtil.getDocumentCount(original.documentList) +
      //       CommonUtil.isNaNValue(parseInt(original.documentCount));
      //     documentCount = CommonUtil.isNaNValue(documentCount);
      //     return (
      //       <a className={documentCount > 0 ? `link` : ''}
      //         id={original.productId + "_" + that.props.purchaseOrderId + "_" + index}
      //         onClick={(e) => documentCount > 0 ? PurchaseOrderUtil.handleTableUploadButtonClick(e, that) : null}>
      //         {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
      //       </a>
      //     )
      //   }
      // },
      // {
      //   Header: "Action",
      //   id: "action",
      //   accessor: "action",
      //   className: "action justify-content-center",
      //   style: {
      //     flex: "0 0 60px",
      //   },
      //   disableSortBy: true,
      //   disableFilters: true,
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
      //     let receivingQuantity = false; //CommonUtil.getFloatValue(original.receivingQuantity);
      //     return (
      //       <div className="actions-left">
      //         <Button bsStyle="default" simple icon>
      //           {tempStatus == statusConstant.COMPLETED_STATUS ?
      //             <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i title="All Received"
      //               id={original.productId + "_" + index}
      //               className="fa fa-thumbs-up"
      //             /></div>
      //             :
      //             receivingQuantity > 0 ?
      //               <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i
      //                 title="upload"
      //                 id={original.productId + "_" + index}
      //                 className="fa fa-upload"
      //                 onClick={(e) => PurchaseOrderUtil.handleTableUploadButtonClick(e, that)}
      //               /></div>: null}
      //         </Button>
      //       </div>
      //     );
      //   },
      // },
      {
        id: "productName",
        name: "productName",
        name: "productName",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnitId",
        name: "volumeUnitId",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      // {
      //   id: "volume",
      //   name: "volume",
      //   type: "TEMP",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      // },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "productUOM",
        name: "productUOM",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "isIngredient",
        name: "isIngredient",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 10000,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const CREATE_PURCHASE_ORDER_INGREDIENT_RECEIVE_TABLE_LIST = (that) => {
  return {
    tableData: [
      {
        product: "",
        quantity: "",
        price: "",
        taxValue: "",
        totalPrice: "",
        ingredientUOM: "",
        category: "",
      },
    ],
    tableColumnList: [
      {
        Header: "Ingredient",
        id: "ingredientId",
        name: "ingredientId",
        accessor: "ingredientId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 250px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let isDelivered = CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? true : false;
          return (
            <div className="ellipsis" title={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}>
              {original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}
            </div>
          )
        },
      },
      {
        Header: "Ordered Qty",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          const isPaymentPending = CommonUtil.isNullValue(that.state.attributeObj.totalPaidAmount) || that.state.attributeObj.totalPaidAmount == 0 ? true : false
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl
                id={"quantity" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"quantity"}
                disabled={isReceivedAllStatus ||
                  CommonUtil.isViewMode(that.props.actionMode) || !isPaymentPending ? true : false}
                onChange={that.handleTableTextBoxChange}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1}
              />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Received Qty",
        id: "receivedQuantity",
        accessor: "receivedQuantity",
        name: "receivedQuantity",
        required: false,
        inputType: "float",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedFlag = PurchaseOrderUtil.isReceivedStatus(tempValue);
          return (
            <div className={CommonUtil.getFloatValue(original.receivedQuantity) > 0 ? 'field-data' : 'field-data'}
              id={original.ingredientId + '_' + index}
              name={'receivedQuantity'}>
              {CommonUtil.getFloatValue(original.receivedQuantity)}
              <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM))}</span>
            </div>
          )
        }
      },
      // {
      //   Header: "Pack/ Volume",
      //   id: "packORVolume",
      //   accessor: "packORVolume",
      //   name: "packORVolume",
      //   required: false,
      //   inputType: "float",
      //   disableSortBy: true,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   disableFilters: true,
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     return (
      //       <div className={'full-width field-data'}
      //         id={original.ingredientId + '_' + index}
      //         name={'packORVolume'}
      //         >
      //         {CommonUtil.getFloatValue(original.packORVolume)}
      //         <span>{CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.packORVolumeUnit))}</span>
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Left Qty",
        id: "leftQuantity",
        accessor: "leftQuantity",
        name: "leftQuantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"leftQuantity" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"leftQuantity"}
                onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={CommonUtil.getFloatValue(PurchaseOrderUtil.getLeftQuantity(original), 2)}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Receiving Qty",
        id: "receivingQuantity",
        accessor: "receivingQuantity",
        name: "receivingQuantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          let tempStatus = that.state.attributeObj.status;
          let fullFilledQty = CommonUtil.getFloatValue(original.receivedQuantity, true) >= CommonUtil.getFloatValue(original.quantity, true) ? true : false;
          return (
            <InputGroup className={that.state.submitted && !CommonUtil.isNotNull(value) ? 'required-error' : ''}>
              <FormControl
                id={"receivingQuantity" + "_" + index}
                name={"receivingQuantity"}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isReceivedAllStatus || tempStatus == statusConstant.COMPLETED_STATUS ||
                  CommonUtil.isViewMode(that.props.actionMode) || fullFilledQty ? true : false}
                value={(CommonUtil.isViewMode(that.props.actionMode) && tempStatus == statusConstant.COMPLETED_STATUS) ? 0 : value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM)}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      // {
      //   Header: "Volume",
      //   id: "volume",
      //   accessor: "volume",
      //   name: "volume",
      //   required: false,
      //   type: "text",
      //   disableSortBy: true,
      //   disableFilters: true,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     return (
      //       <div id={'volume' + '_' + index} name={'volume'}>

      //         {CommonUtil.getFloatValue(original.volume, true) + "  " +
      //           CommonUtil.initializeValue(CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM))}
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Order Status",
        id: "orderStatus",
        accessor: "orderStatus",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        disableSortBy: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          value = PurchaseOrderUtil.getIngredientStatus(original);
          return (
            <div className={`full-td`}
              id={original.productId + "_" + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      // {
      //   Header: "Document",
      //   id: "document",
      //   accessor: "document",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: false,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   disableSortBy: true,
      //   disableFilters: true,
      //   style: {
      //     flex: "0 0 110px",
      //   },
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     let documentCount = PurchaseOrderUtil.getDocumentCount(original.documentList) +
      //       CommonUtil.isNaNValue(parseInt(original.documentCount));
      //     documentCount = CommonUtil.isNaNValue(documentCount);
      //     return (
      //       <a className={documentCount > 0 ? `link` : ''}
      //         id={original.ingredientId + "_" + that.props.purchaseOrderId + "_" + index}
      //         onClick={(e) => documentCount > 0 ? PurchaseOrderUtil.handleTableUploadButtonClick(e, that) : null}>
      //         {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
      //       </a>
      //     )
      //   }
      // },
      // {
      //   Header: "Action",
      //   id: "action",
      //   accessor: "action",
      //   className: "action justify-content-center",
      //   style: {
      //     flex: "0 0 60px",
      //   },
      //   disableSortBy: true,
      //   disableFilters: true,
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
      //     let receivingQuantity = false; //CommonUtil.getFloatValue(original.receivingQuantity);
      //     return (
      //       <div className="actions-left">
      //         <Button bsStyle="default" simple icon>
      //           {tempStatus == statusConstant.COMPLETED_STATUS ?
      //             <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i title="All Received"
      //               id={original.productId + "_" + index}
      //               className="fa fa-thumbs-up"
      //             /></div>
      //             :
      //             receivingQuantity > 0 ?
      //               <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}><i
      //                 title="upload"
      //                 id={original.productId + "_" + index}
      //                 className="fa fa-upload"
      //                 onClick={(e) => PurchaseOrderUtil.handleTableUploadButtonClick(e, that)}
      //               /></div> : null}
      //         </Button>
      //       </div>
      //     );
      //   },
      // },
      {
        id: "ingredientName",
        name: "ingredientName",
        name: "ingredientName",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnitId",
        name: "volumeUnitId",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      // {
      //   id: "volume",
      //   name: "volume",
      //   type: "TEMP",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      // },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "ingredientUOM",
        name: "ingredientUOM",
        name: "ingredientUOM",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 10000,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const PURCHASE_ORDER_STOCK_VIEW_MODAL_TABLE_LIST = (that) => {
  return {
    tableData: [
    ],
    tableColumnList: [
      {
        Header: "Received Date",
        id: "createddate",
        name: "createddate",
        accessor: "createddate",
        required: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        inputType: "text",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            CommonUtil.getCurrentZoneFormatDate(value)
          )
        }
      },
      {
        Header: "Batch",
        id: "uti",
        accessor: "uti",
        name: "uti",
        required: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <FormControl id={"uti" + "_" + index} name={"uti"}
              onChange={that.handleTableTextBoxChange}
              disabled={true}
              value={value} />
          );
        },
      },
      {
        Header: "Quantity",
        id: "receivedstock",
        accessor: "receivedstock",
        name: "receivedstock",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl id={"receivedstock" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={"receivedstock"}
                disabled={true} value={value} />
              <InputGroup.Addon> {that.state.entityUOM} </InputGroup.Addon>
            </InputGroup>
          );
        },
      }

    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const PURCHASE_ORDER_DOCUMENT_UPLOAD_MODAL_LIST = (that) => ({
  attributeObj: {
    utiCode: "",
    invoiceNumber: "",
    transportDetail: "",
  },
  attributeList: [
    {
      name: "utiCode",
      type: "DROPDOWN",
      label: "Select UTI Number",
      required: true,
      fieldWidth: 8,
      customAttribute: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "invoiceNumber",
      type: "TEXTBOX",
      label: "Invoice Number",
      required: false,
      inputType: "text",
      fieldWidth: 6,
      customAttribute: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "transportDetail",
      type: "TEXTBOX",
      label: "Transport Detail",
      required: false,
      inputType: "text",
      fieldWidth: 6,
      customAttribute: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
  ],
});

export const PURCHASE_ORDER_DOCUMENT_UPLOAD_MODAL_TABLE_LIST = (that) => {
  return {
    tableData: [
    ],
    tableColumnList: [
      {
        Header: "Document Type",
        id: "documentType",
        accessor: "documentType",
        name: "documentType",
        inputType: "float",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: true,
        dataDictionaryId: 'documentTypeList',
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select id={'documentType' + '_' + index}
              className={!value ? 'required-error' : ''}
              name={"documentType" + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList.documentTypeList}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={{ "label": original.documentType }} />
          )
        },
      },
      {
        Header: "Name",
        id: "documentName",
        name: "documentName",
        accessor: "documentName",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup className={(!value || value.length < 3) ? 'required-error' : ''}>
              <FormControl
                id={"documentName" + "_" + index}
                name={"documentName"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
      {
        Header: "Expiry Date",
        id: "documentExpiryDate",
        name: "documentExpiryDate",
        accessor: "documentExpiryDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              id={"documentExpiryDate" + '_' + index}
              timeFormat={false}
              isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }}
              name={'documentExpiryDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "documentExpiryDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "QC Type",
        id: "qcType",
        accessor: "qcType",
        name: "qcType",
        inputType: "float",
        required: false,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: true,
        dataDictionaryId: 'qcType',
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select id={'qcType' + '_' + index}
              name={"qcType" + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList.qcTypeList}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={{ "label": original.qcType }} />
          )
        },
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 90px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle nocircle">
                  {<a href={original.documentURL} download="click to download">
                    <img title="document" src={CommonUtil.getDocumentIcon(original.fileType)} alt="Document" />
                  </a>
                  }
                </div>
                <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}>
                  {<i title="remove"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-trash"
                    onClick={(e) => that.handleTableRemove(e)} />
                  }
                </div>
              </Button>
            </div>
          );
        },
      },

    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const MANAGE_OPEN_PURCHASE_ORDER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order#",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
        isQBOAttribute: false,
        style: {
          flex: "0 0 100px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div>
              {"PO-" + value}
            </div>
          );
        },
      },
      {
        Header: "Invoice",
        id: "invoiceNumber",
        accessor: "invoiceNumber",
        isQBOAttribute: false,
        disableSortBy: true,
        style: {
          flex: "0 0 120px",
        },
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        isQBOAttribute: false,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let supplierName;
          if (that.props.supplierList && that.props.supplierList) {
            let tempSupplierObj = CommonUtil.getFilteredObjFromArray(that.props.supplierList,
              'supplierId', original.supplierId);
            supplierName = CommonUtil.isNotNull(tempSupplierObj) ? tempSupplierObj.supplierName : null;
          }
          return (
            <div>
              {"SUP-" + original.supplierId + " | " + original.supplierName}
            </div>
          );
        },
      },
      {
        Header: "Value",
        id: "totalValue",
        accessor: "totalValue",
        isQBOAttribute: false,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Value" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Value";
          var value = cell.value ? cell.value : 0.00;
          return (
            currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, CommonUtil.getFloatValue(value, true))
          )
        }
      },
      // {
      //   Header: "ETA",
      //   id: "requestedDeliveryDate",
      //   accessor: "requestedDeliveryDate",
      //   isQBOAttribute: false,
      //   style: {
      //     flex: "0 0 80px",
      //   },
      //   disableSortBy: true,
      // },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value),
              borderRadius: '5px'
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Bills Status",
        id: "billStatus",
        accessor: "billStatus",
        isQBOAttribute: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let qboBillStatus = PurchaseOrderUtil.getQBOBillStatus(original.billingSourceName);
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + original.billingSourceId}
              style={{
                backgroundColor: StatusUtil.getStatusColor(qboBillStatus),
                borderRadius: '5px'
              }}
              onClick={(e) => that.getQBOBillDetails(e)}>
              {StatusUtil.getStatusLabel(qboBillStatus)}
            </div>
          )
        }
      },
      {
        Header: "Payment Status",
        id: "paymentStatus",
        accessor: "paymentStatus",
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          let paymentStatus = CommonUtil.getFloatValue(original.totalPaidAmount, 2) == 0 ? statusConstant.PENDING_STATUS : CommonUtil.getFloatValue(original.totalValue, 2) == CommonUtil.getFloatValue(original.totalPaidAmount, 2) ? statusConstant.PAID_STATUS : statusConstant.PARTIALLY_PAID_STATUS;
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + commonConstant.MENU_ACTION_MODE
                + '_' + purchaseOrderConstant.VIEW_PAYMENT_DETAILS + '_' + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(paymentStatus),
                borderRadius: '5px',
                pointerEvents: isAuthorized("paymentPurchaseOrder") ? "auto" : "none",
                cursor: isAuthorized("paymentPurchaseOrder") ? "pointer" : "no-drop",
              }}
              onClick={(e) => isAuthorized("paymentPurchaseOrder") && that.handleMenuPopupAction(e)}>
              {StatusUtil.getStatusLabel(paymentStatus)}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "actions",
        isQBOAttribute: false,
        className: "action justify-content-center",
        style: {
          flex: "0 0 90px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="edit" id={original.purchaseOrderId + "_" +
                      commonConstant.EDIT_ACTION_MODE + "_" + index}
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                {isAuthorized("viewPurchaseOrder") &&
                  <div className="circle">
                    <i title="view" id={original.purchaseOrderId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                      className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="send receipt" id={original.purchaseOrderId + "_" + commonConstant.SEND_RECEIEPT + '_' + index}
                      className="fa fa-envelope-o" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_COMPLETED_PURCHASE_ORDER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order#",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
        isQBOAttribute: false,
        style: {
          flex: "0 0 100px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div>
              {"PO-" + value}
            </div>
          );
        },
      },
      {
        Header: "Invoice",
        id: "invoiceNumber",
        accessor: "invoiceNumber",
        isQBOAttribute: false,
        disableSortBy: true,
        style: {
          flex: "0 0 120px",
        }
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let supplierName = null;
          if (that.props.supplierList && that.props.supplierList) {
            let tempSupplierObj = CommonUtil.getFilteredObjFromArray(that.props.supplierList,
              'supplierId', original.supplierId);
            supplierName = CommonUtil.isNotNull(tempSupplierObj) ? tempSupplierObj.supplierName : null;
          }
          return (
            <div>
              {"SUP-" + original.supplierId + " | " + original.supplierName}
            </div>
          );
        },
      },
      {
        Header: "Value",
        id: "totalValue",
        accessor: "totalValue",
        isQBOAttribute: false,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Value" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Value";
          var value = cell.value ? cell.value : 0.00;
          return (
            currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, value)
          )
        }
      },
      // {
      //   Header: "ETA",
      //   id: "requestedDeliveryDate",
      //   accessor: "requestedDeliveryDate",
      //   isQBOAttribute: false,
      //   style: {
      //     flex: "0 0 80px",
      //   },
      //   disableSortBy: true,
      // },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        isQBOAttribute: false,
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value),
              borderRadius: '5px'
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Bills Status",
        id: "billStatus",
        accessor: "billStatus",
        isQBOAttribute: true,
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let qboBillStatus = PurchaseOrderUtil.getQBOBillStatus(original.billingSourceName);
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + original.billingSourceId}
              style={{
                backgroundColor: StatusUtil.getStatusColor(qboBillStatus),
                borderRadius: '5px'
              }}
              onClick={(e) => that.getQBOBillDetails(e)}>
              {StatusUtil.getStatusLabel(qboBillStatus)}
            </div>
          )
        }
      },
      {
        Header: "Payment Status",
        id: "paymentStatus",
        accessor: "paymentStatus",
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          let paymentStatus = CommonUtil.getFloatValue(original.totalPaidAmount, 2) == 0 ? statusConstant.PENDING_STATUS : CommonUtil.getFloatValue(original.totalValue, 2) == CommonUtil.getFloatValue(original.totalPaidAmount, 2) ? statusConstant.PAID_STATUS : statusConstant.PARTIALLY_PAID_STATUS;
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + commonConstant.MENU_ACTION_MODE
                + '_' + purchaseOrderConstant.VIEW_PAYMENT_DETAILS + '_' + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(paymentStatus),
                borderRadius: '5px',
                pointerEvents: isAuthorized("paymentPurchaseOrder") ? "auto" : "none",
                cursor: isAuthorized("paymentPurchaseOrder") ? "pointer" : "no-drop",
              }}
              onClick={(e) => isAuthorized("paymentPurchaseOrder") && that.getTdProps(e)}>
              {StatusUtil.getStatusLabel(paymentStatus)}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "action",
        isQBOAttribute: false,
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle">
                  <i title="view" id={original.purchaseOrderId + "_" + commonConstant.VIEW_ACTION_MODE +
                    "_" + index}
                    className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                </div>

                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="Credit Note"
                      id={"PO-" + original.purchaseOrderId + '_' + commonConstant.MENU_ACTION_MODE + "_" +
                        stockAdjustmentConstant.PO_RETURN_STATUS + "_" + index}
                      className="fa fa-money" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }

                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="Amend Status"
                      id={original.purchaseOrderId + '_' + commonConstant.MENU_ACTION_MODE + "_" +
                        statusConstant.UPDATE_STATUS + "_" + index}
                      className="fa fa-reply" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="send receipt" id={original.purchaseOrderId + "_" + commonConstant.SEND_RECEIEPT + '_' + index}
                      className="fa fa-envelope-o" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_DRAFT_PURCHASE_ORDER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Product",
        id: "productId",
        accessor: "productId",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempUniqueObj = null;
          let isProFlag = CommonUtil.getModuleNameFromCode(original.productId);
          let productName = null;
          if (isProFlag && that.props.productList && that.props.productList) {
            tempUniqueObj = CommonUtil.getFilteredObjFromArray(that.props.productList,
              'productId', original.productId);
            productName = CommonUtil.isNotNull(tempUniqueObj) ? tempUniqueObj.productName : null;
          } else if (that.props.ingredientList && that.props.ingredientList) {
            tempUniqueObj = CommonUtil.getFilteredObjFromArray(that.props.ingredientList &&
              that.props.ingredientList, 'ingredientId', original.productId);
            productName = CommonUtil.isNotNull(tempUniqueObj) ? tempUniqueObj.ingredientName : null;
          }
          return (
            <div>
              {original.productId + " | " + productName}
            </div>
          );
        },
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let supplierId, supplierName;
          if (that.props.supplierList && that.props.supplierList) {
            supplierId = original.orderRequest ? original.orderRequest.supplierId : null;
            let tempSupplierObj = CommonUtil.getFilteredObjFromArray(that.props.supplierList,
              'supplierId', supplierId);
            supplierName = CommonUtil.isNotNull(tempSupplierObj) ? tempSupplierObj.supplierName : null;
          }
          return (
            <div>
              {supplierId + " | " + supplierName}
            </div>
          );
        },
      },
      {
        Header: "Facility",
        id: "facilityName",
        accessor: "facilityName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let facilityName;
          if (that.props.facilityList && that.props.facilityList) {
            let tempFacilityObj = CommonUtil.getFilteredObjFromArray(that.props.facilityList,
              'facilityId', original.facilityId);
            facilityName = CommonUtil.isNotNull(tempFacilityObj) ? tempFacilityObj.facilityName : null;
          }
          return (
            <div>
              {original.facilityId + " | " + facilityName}
            </div>
          );
        },
      },
      {
        Header: "Quantity",
        id: "orderQuantity",
        accessor: "orderQuantity",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let value = original.orderRequest && original.orderRequest.itemList &&
            original.orderRequest.itemList[0].quantity;
          let productUOM = original.orderRequest && original.orderRequest.itemList &&
            original.orderRequest.itemList[0].productUOM;
          return (
            value + " " + productUOM
          )
        }
      },
      {
        Header: "Total Cost",
        id: "totalValue",
        accessor: "totalValue",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Total Cost" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Cost";
          const { index, original } = cell.row;
          let totalValue = original.orderRequest ? original.orderRequest.totalValue : 0;
          return (
            currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, CommonUtil.getFloatValue(totalValue, true))
          )
        }
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(statusConstant.DRAFT_STATUS),
              borderRadius: '5px'
            }}
              id={original.productId + "_" + "status" + "_" + index + "_" + original.draftCode}>
              {StatusUtil.getStatusLabel(statusConstant.DRAFT_STATUS)}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle">
                  <i title="Confirm" id={original.productId + "_" + "confirm" +
                    "_" + index + "_" + original.draftCode}
                    className="fa fa-check" onClick={(e) => that.handleConfirmDraftAction(e, that)} />
                </div>
                <div className="circle">
                  <i title="Delete" id={original.productId + "_" + commonConstant.DELETE_ACTION_MODE +
                    "_" + index + "_" + original.draftCode}
                    className="fa fa-trash" onClick={(e) => PurchaseOrderUtil.handleDeleteDraftPopup(e, that)} />
                </div>
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: '',
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Purchase Order/Product",
      },
    ],
  }
};

export const HEADER_STATUS_LIST = [
  {
    statusKey: statusConstant.NEW_STATUS,
  },
  {
    statusKey: statusConstant.PARTIAL_RECEIVED,
  },
  {
    statusKey: statusConstant.COMPLETED_STATUS,
  },
];

export const MANAGE_HEADER_STATUS_LIST = [
  {
    statusKey: statusConstant.ALL_STATUS
  },
  {
    statusKey: statusConstant.NEW_STATUS,
  },
  {
    statusKey: statusConstant.PARTIAL_RECEIVED,
  },
  {
    statusKey: statusConstant.OVERDUE_STATUS
  }
]
export const CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST = (that) => {
  return {
    tableData: [],
    tableColumnList: [
      {
        Header: "Account",
        id: "accountId",
        name: "accountId",
        accessor: "accountId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        dataDictionaryFlag: true,
        dataDictionaryId: 'accountList',
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-width" title={original.accountId}>
              <Select
                className={that.state.submitted &&
                  CommonUtil.isNullValue(value) ? 'required-error' : ''}
                id={'accountId' + '_' + index}
                name={"accountId" + '_' + index}
                onChange={that.handleTableDropDownChange}
                options={that.props.dataDictionaryList &&
                  that.props.dataDictionaryList &&
                  that.props.dataDictionaryList.filter((d) => d.dataType === 'accountList')}
                classNamePrefix="react-select"
                isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.accountId)} />
            </div>
          );
        },
      },
      {
        Header: "Description",
        id: "descriptionId",
        name: "descriptionId",
        accessor: "descriptionId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        dataDictionaryFlag: true,
        dataDictionaryId: 'expenses',
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-width" title={original.descriptionId}>
              <Select
                className={that.state.submitted &&
                  CommonUtil.isNullValue(value) ? 'required-error' : ''}
                id={'descriptionId' + '_' + index}
                name={"descriptionId" + '_' + index}
                onChange={that.handleTableDropDownChange}
                options={that.props.dataDictionaryList &&
                  that.props.dataDictionaryList &&
                  that.props.dataDictionaryList.filter((d) => d.dataType === 'expenses')}
                classNamePrefix="react-select"
                isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.descriptionId)} />
            </div>
          );
        },
      },
      {
        Header: "Mode",
        id: "paymentModeId",
        name: "paymentModeId",
        accessor: "paymentModeId",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        dataDictionaryFlag: true,
        dataDictionaryId: 'paymentModeList',
        style: {
          flex: "0 0 150px",
        },
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted &&
                CommonUtil.isNullValue(value) ? 'required-error' : ''}
              id={'paymentModeId' + '_' + index}
              name={"paymentModeId" + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList &&
                that.props.dataDictionaryList.filter((d) => d.dataType === 'paymentModeList')}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.paymentModeId)} />
          );
        },
      },
      {
        Header: "Date",
        id: "expenseDate",
        name: "expenseDate",
        accessor: "expenseDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"expenseDate" + '_' + index}
              timeFormat={false}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }}
              name={'expenseDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "expenseDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Amount",
        id: "amount",
        accessor: "amount",
        name: "amount",
        required: false,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amount" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amount";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"amount" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"amount"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 80px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              {!CommonUtil.isViewMode(that.props.actionMode) && <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}>
                <i title="remove"
                  id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                  className="fa fa-trash"
                  onClick={(e) => that.handleDeleteRowPopup(e)} />
              </div>}
            </div>
          );
        },
      },
      {
        id: "version",
        name: "version",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "expenseId",
        name: "expenseId",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },

    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "",
        id: "actions",
        accessor: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox inline
                number={original.productId + "_" + commonConstant.CREATE_ACTION_MODE + '_' + index}
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)} />
            </div>
          )
        }
      },
      {
        Header: "Product Code",
        id: "productId",
        accessor: "productId",
        style: {
          flex: "0 0 140px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>{original.isIngredient ? "ING-" : "PRO-"}{value}</>
          )
        }
      },
      {
        Header: "Product Name",
        id: "productName",
        accessor: "productName"
      },
      // {
      //   Header: "Purchase Price",
      //   id: "purchasePrice",
      //   accessor: "purchasePrice",
      //   style: {
      //     flex: "0 0 140px",
      //   },
      // },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_MULTI_SELECTION_INGREDIENTS_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "",
        id: "actions",
        accessor: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox inline
                number={original.ingredientId + "_" + commonConstant.CREATE_ACTION_MODE + '_' + index}
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)} />
            </div>
          )
        }
      },
      {
        Header: "Ingredient Code",
        id: "ingredientId",
        accessor: "ingredientId",
        style: {
          flex: "0 0 140px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>INGR-{value}</>
          )
        }
      },
      {
        Header: "Ingredient Name",
        id: "ingredientName",
        accessor: "ingredientName"
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_SUPPLIER_SELECTION_PRODUCTS_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "",
        id: "actions",
        accessor: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomRadio key={index}
                name={original.supplierId}
                number={original.supplierId}
                value={original.supplierId}
                checked={that.state.selectedSupplier == original.supplierId}
                onChange={(e) => that.handleRadioButtonsChange(e, that)} />
            </div>
          )
        }
      },
      {
        Header: "Supplier Code",
        id: "supplierId",
        accessor: "supplierId",
        style: {
          flex: "0 0 140px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>SUP-{value}</>
          )
        }
      },
      {
        Header: "Name",
        id: "supplierName",
        accessor: "supplierName"
      },
      {
        Header: "Email",
        id: "email",
        accessor: "email"
      },
      {
        Header: "Phone",
        id: "phoneNumber",
        accessor: "phoneNumber",
        style: {
          flex: '0 0 120px'
        },
      },
      {
        Header: "Location",
        id: "location",
        accessor: (values) => {
          if (values.locations) {
            var location = null;
            for (var i = 0; i < values.locations.length; i++) {
              if (values.locations[i].isDefault) {
                location = values.locations[i].city + "-" +
                  values.locations[i].country
                break;
              }
            }
            if (!location) {
              if (values.locations[0]) {
                location = values.locations[0].city + "-" +
                  values.locations[0].country;
              }
              else {
                location = "";
              }
            }
            return location;
          } else {
            return ''
          }
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const CREATE_PURCHASE_ORDER_SEND_RECEIPT_PAGE = (that) =>{
  return{
      attributeObj :[{
          supplierEmail : [],
          supplierPhone : [],
          source : '',
          countryCode: '+1'
      }],

      attributeList : [        
          {
              checkList: [
                  {
                    name: "email",
                    label: "Email",
                    value: "email",
                  }
                ],
                type : "CUSTOM_RADIO",
                name : "email",
          label: "Email",
          required: false,
          fieldWidth: 3,
          fieldWidthSmall: 4,
          createMode: "enable",
          cloneMode: "enable",
          editMode: "enable",
          viewMode: "disabled",
          createModeShowFlag: true,
          cloneModeShowFlag: true,
          editModeShowFlag: true,
          viewModeShowFlag: true,
          supplierfields: false,
          buyShowFlag: true,
          makeShowFlag: true,
          kittingShowFlag: true,
          numberOfRow: 0,
          mandatoryMsgText: "Field can not be empty.",
        },
         
          {
              name: "supplierEmail",
              type: "TEXT_LIST",
              label: "Email",
              required: false,
              fieldWidth: 9,
              numberOfRow: 0,
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              createMode: 'enable',
              cloneMode: 'enable',
              editMode: 'enable',
              viewMode: 'disabled',
              //mandatoryMsgText: "Email is required.",
              emailMsgText: "Invalid email format.",
              customEmailMessage: "Customer Email already exist."
          }, 
          {
              checkList: [
                  {
                    name: "phone",
                    label: "Phone Number",
                    value: "phone",
                  },
                ],
          type : "CUSTOM_RADIO",
          name : "phone",
          label: "Phone Number",
          required: false,
          fieldWidth: 3,
          fieldWidthSmall: 4,
          createMode: "enable",
          cloneMode: "enable",
          editMode: "enable",
          viewMode: "disabled",
          createModeShowFlag: true,
          cloneModeShowFlag: true,
          editModeShowFlag: true,
          viewModeShowFlag: true,
          supplierfields: false,
          buyShowFlag: true,
          makeShowFlag: true,
          kittingShowFlag: true,
          numberOfRow: 0,
          mandatoryMsgText: "Field can not be empty.",
        },
        {
          name: "countryCode",
          type: "DROPDOWN",
          label: "Country Code ",
          required: false,
          fieldWidth: 2,
          numberOfRow: 0,
          minValue: 0,
          createModeShowFlag: true,
          cloneModeShowFlag: true,
          editModeShowFlag: true,
          viewModeShowFlag: true,
          createMode: 'enable',
          cloneMode: 'enable',
          editMode: 'enable',
          viewMode: 'disabled',
          options: _.map(countryList, country => ({ label: `${country.code} (${country.dial_code})`, value: `${country.dial_code}` }))
      },
          {
              name: "supplierPhone",
              type: "TEXT_LIST",
              label: "Phone Number",
             // inputType: "phone",
              required: false,
              fieldWidth: 7,
              numberOfRow: 0,
              minValue: 0,
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              createMode: 'enable',
              cloneMode: 'enable',
              editMode: 'enable',
              viewMode: 'disabled',
               //mandatoryMsgText: "Field can not be empty.",
              // phoneMsgText: "Please enter valid phone number.",
          },
      ]
  }
};