export const MANAGE_PURCHASE_ORDER_HEADER_TITLE = "Purchase Order";
export const CREATE_PURCHASE_HEADER_TITLE = "Create Purchase Order";
export const EDIT_PURCHASE_HEADER_TITLE = "Edit Purchase Order";
export const VIEW_PURCHASE_HEADER_TITLE = "View Purchase Order";
export const VIEW_PAYMENT_DETAILS = "viewPayment";
export const MODULE_NAME = "Purchase Order";
export const CREATE_PURCHASE_ORDER = "createPurchaseOrder";
export const CREATE_PURCHASE_ORDER_PAGE_URL = "/admin/create-purchase-order";
export const MANAGE_PURCHASE_ORDER_PAGE_URL = "/admin/manage-purchase-order";
export const MANAGE_DOCUMENT_PAGE_URL = "/admin/manage-documents";
export const SEND_RECEIPT = "sendReceipt";

export const AMEND_STATUS_ERROR_MSG = "Are you sure, you want to amend order Status! ";

export const POS_BASE_URL = process.env.REACT_APP_POS_API_BASE_URL;
export const IS_QBO = process.env.REACT_APP_QBO_ACTIVE;
export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_PURCHASE_ORDER_LIST_URL = `${BASE_URL}/purchaseorder`;
export const GET_PURCHASE_ORDER_STOCK_LIST_URL = `${BASE_URL}/purchaseorder/stocks/`;
export const GET_PURCHASE_ORDER_DETAILS_URL = `${BASE_URL}/purchaseorder/`;
export const SET_CREATE_PURCHASE_ORDER_DETAILS_URL = `${BASE_URL}/purchaseorder/`;
export const SET_UPDATE_PURCHASE_ORDER_DETAILS_URL = `${BASE_URL}/purchaseorder/`;
export const SET_UPDATE_PURCHASE_ORDER_PAYMENT_URL = `${BASE_URL}/purchaseorder/updatepayment`;
export const SET_UPDATE_PURCHASE_ORDER_STATUS_URL = `${BASE_URL}/purchaseorder/`;
export const SET_UPDATE_PURCHASE_ORDER_AMEND_STATUS_URL = `${BASE_URL}/purchaseorder/amendStatus/`;
export const DOWNLOAD_XLS_FILE_URL = `${BASE_URL}/purchaseorder/downloadxls`;
export const DOWNLOAD_INVOICE_URL = `${BASE_URL}/purchaseorder/downloadInvoice/`;
export const VALID_RECEIVABLE_PAYABLE_AMOUNT = "Please enter amount!";
export const VALID_ACCOUNT_DESCRIPTION_COMBINATION = "Expense account and description already exist.";
export const SEND_RECEIPT_OVER_SMS = `${POS_BASE_URL}/purchaseorder/notifications/sms/`;

export const GET_QBO_DETAILS_URL = `${BASE_URL}/qbo/checkQBOConnection`;
export const GET_QBO_BILL_DETAILS_URL = `${BASE_URL}/qbo/createQBOBill`;
export const GET_PURCHASE_ORDER_SEARCH_URL = BASE_URL + '/purchaseorder';
export const GET_PURCHASE_ORDER_PAYMENT_DETAILS_URL = `${BASE_URL}/purchaseorder/payments/`;

export const MANAGE_PAGE_TAB_LIST = [
    {
        key: "OPEN",
        title: "OPEN"
    },
    {
        key: "COMPLETED",
        title: "COMPLETED"
    },
    {
        key: "DRAFT",
        title: "DRAFT"
    },
];

export const MANAGE_PAGE_TAB_LIST_WITHOUT_DRAFT = [
    {
        key: "OPEN",
        title: "OPEN"
    },
    {
        key: "COMPLETED",
        title: "COMPLETED"
    },
]

