import axios from "../../../axios/axios";
import * as purchaseOrderActionTypes from "./purchaseOrderActionTypes";
import * as purchaseOrderConstant from "../constant/purchaseOrderConstant";
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: purchaseOrderActionTypes.SET_PURCHASE_ORDER_REDUCER_INIT_MODE,
      payload: null,
    });
  };
}

export function setPurchaseOrderDetails(purchaseOrderDetailsObj, actionMode, purchaseOrderId) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(purchaseOrderConstant.SET_CREATE_PURCHASE_ORDER_DETAILS_URL,
        purchaseOrderDetailsObj).then((response) => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch((error) => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(purchaseOrderConstant.SET_UPDATE_PURCHASE_ORDER_DETAILS_URL +
        purchaseOrderId, purchaseOrderDetailsObj).then((response) => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch((error) => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedPurchaseOrderCode(selectedPurchaseOrderCode) {
  return function (dispatch) {
    dispatch({
      type: purchaseOrderActionTypes.SET_SELECTED_PURCHASE_ORDER_CODE,
      payload: selectedPurchaseOrderCode,
    });
  };
}

export function getPurchaseOrderList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.GET_PURCHASE_ORDER_LIST_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: purchaseOrderActionTypes.GET_PURCHASE_ORDER_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getReceivedStockList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.GET_PURCHASE_ORDER_STOCK_LIST_URL +
      params.purchaseOrderId + "/" + params.orderNumber).then((response) => {
        if (response.status == 200) {
          dispatch({
            type: purchaseOrderActionTypes.GET_PURCHASE_ORDER_STOCK_LIST,
            payload: response.data,
          });
        }
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
      });
  };
}

export function getPurchaseOrderDetails(selectedPurchaseOrderCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.GET_PURCHASE_ORDER_DETAILS_URL +
      selectedPurchaseOrderCode).then((response) => {
        if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
          dispatch({
            type: purchaseOrderActionTypes.GET_PURCHASE_ORDER_DETAILS,
            payload: response.data[0],
          });
        }
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
      });
  };
}

export function getQBODetails() {
  return function (dispatch) {
    // this code will activate the qbo
    console.info("-----------------------------" + purchaseOrderConstant.BASE_URL);
    console.info("-----------------------------" + purchaseOrderConstant.IS_QBO);
    if (purchaseOrderConstant.IS_QBO) {
      dispatch(beginAjaxCall());
      axios.get(purchaseOrderConstant.GET_QBO_DETAILS_URL).then((response) => {
        if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
          dispatch({
            type: purchaseOrderActionTypes.GET_QBO_DETAILS,
            payload: response.data,
          });
        }
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
      });
    }
    // this code will activate the qbo
  };
}

export function getQBOBillDetails(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.GET_QBO_BILL_DETAILS_URL, { params: params }).then((response) => {
      if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
        dispatch({
          type: purchaseOrderActionTypes.GET_QBO_BILL_DETAILS,
          payload: response.data,
        });
      }
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}

export function updatePurchaseOrderAmendStatus(purchaseOrderId, obj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(purchaseOrderConstant.SET_UPDATE_PURCHASE_ORDER_AMEND_STATUS_URL + purchaseOrderId, obj).then((response) => {
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}

export function updatePurchaseOrderDeleteStatus(purchaseOrderDetailsObj, purchaseOrderId) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(purchaseOrderConstant.SET_UPDATE_PURCHASE_ORDER_STATUS_URL +
      purchaseOrderId, purchaseOrderDetailsObj).then((response) => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      })
      .catch((error) => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  };
}

export function downLoadXLSFile(selectedTab, params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.DOWNLOAD_XLS_FILE_URL, { params }).then((response) => {
      if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
        CommonUtil.getXlsResponseDownloadFile(response.data, selectedTab+"_PURCHASE_ORDERS.xlsx");
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function downloadInvoice(id, key) {
  return function (dispatch) {
    let downloadURL = '';
    downloadURL = `${purchaseOrderConstant.DOWNLOAD_INVOICE_URL}${id}?downloadType=${key}`

    dispatch(beginAjaxCall());
    axios.get(downloadURL).then((response) => {
      if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
        CommonUtil.downloadPdf(response.data.Location, response.data.key, CommonUtil.saveAs);
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getPurchaseOrderSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.GET_PURCHASE_ORDER_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: purchaseOrderActionTypes.GET_PURCHASE_ORDER_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function updatePurchaseOrderPayment(paymentRequestObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(purchaseOrderConstant.SET_UPDATE_PURCHASE_ORDER_PAYMENT_URL, paymentRequestObj).then(response => {
      if (response.status == 200) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getPurchaseOrderPaymentDetails(selectedSaleOrderCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(purchaseOrderConstant.GET_PURCHASE_ORDER_PAYMENT_DETAILS_URL + selectedSaleOrderCode).then(response => {
      if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
        dispatch({
          type: purchaseOrderActionTypes.GET_PURCHASE_ORDER_PAYMENT_DETAILS,
          payload: response.data[0]
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function sendReceiptOverSms(selectedPurchaseOrderCode,tempObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(purchaseOrderConstant.SEND_RECEIPT_OVER_SMS + selectedPurchaseOrderCode,tempObj).then(response => {
      if (response.status == 200) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}


export function sendReceiptOverEmail(id, email) {
  return function (dispatch) {
    let downloadURL = '';
    downloadURL = `${purchaseOrderConstant.DOWNLOAD_INVOICE_URL}${id}?email=${email}`
    dispatch(beginAjaxCall());
    axios.get(downloadURL).then((response) => {
      if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}