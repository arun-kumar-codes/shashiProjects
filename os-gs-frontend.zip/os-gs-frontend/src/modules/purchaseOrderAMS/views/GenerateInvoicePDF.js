import React, { Component } from "react";
import { connect } from "react-redux";
import { PDFDownloadLink } from "@react-pdf/renderer";
import PurchaseOrderInvoice from "./PurchaseOrderInvoice";
import CommonUtil from "../../common/util/commonUtil";
import { getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getSupplierDetails } from "../../supplierManagement/actions/supplierActions";

class GenerateInvoicePDF extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      show: false,
      supplierObj: null,
      facilityObj: null
    };
  }

  updateSupplierDetails = () => {
    this.setState({ supplierObj: this.props.supplierDetails });
    this.onDownLoadClick();
  }

  updateFacilityDetails = async () => {
    this.setState({ facilityObj: this.props.facilityDetails });
    const { attributeObj } = this.props;
    const orgInformation = CommonUtil.getOrgInformation(this.props.dataDictionaryList, attributeObj.facilityId);
    const imageUrl = await CommonUtil.getImageBlobFromUrl(orgInformation.logoURL);
    await this.setState({ show: true, imageUrl: imageUrl, orgInformation: orgInformation });
    this.onDownLoadClick();
  }

  componentDidMount = async () => {
    const { attributeObj } = this.props;
    if (this.props.isDownLoadPdf) {
      this.props.getSupplierDetails(attributeObj.supplierId);
      this.props.getFacilityDetails(attributeObj.facilityId);
    }
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.supplierDetails != null && prevProps.supplierDetails != this.props.supplierDetails) {
      this.updateSupplierDetails();
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      this.updateFacilityDetails();
    }
  }

  onDownLoadClick = () => {
    const { supplierDetails, facilityDetails } = this.props;
    if (this.props.isDownLoadPdf && supplierDetails && facilityDetails) {
      setTimeout(() => {
        this.refs.current.click();
        this.props.pdfDownload();
      }, 3000);
    }
  }

  render() {
    const { show, facilityObj, supplierObj, orgInformation } = this.state;
    return (
      (show && supplierObj && facilityObj ?
        <PDFDownloadLink
          document={<PurchaseOrderInvoice
            attributeObj={this.props.attributeObj}
            facilityObj={facilityObj}
            supplierObj={supplierObj}
            stateGST={this.props.stateGST}
            centralGST={this.props.centralGST}
            userProfile={this.props.userProfile}
            currencyCode={this.props.currencyCode}
            orgInformation={orgInformation}
            companyImage={this.state.imageUrl}
          />}
          fileName={this.props.attributeObj.purchaseOrderId}
          style={{ color: "#1E1E1E" }}
          children={<div ref="current"></div>}>
        </PDFDownloadLink>
        : null

      )
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    actionMode: state.app.actionMode,
    currencyCode: state.dataDictionary.currencyCode,
    stateGST: state.dataDictionary.stateGST,
    centralGST: state.dataDictionary.centralGST,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    userProfile: state.user.userProfile,
    attributeObj: state.purchaseOrder.purchaseOrderDetails,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    supplierList: state.supplier.supplierList,
    supplierDetails: state.supplier.supplierDetails,
    facilityDetails: state.facility.facilityDetails,
    facilityList: state.facility.facilityList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  getFacilityDetails: (id) => dispatch(getFacilityDetails(id)),
  getSupplierDetails: (id) => dispatch(getSupplierDetails(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(GenerateInvoicePDF);