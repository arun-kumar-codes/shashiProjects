import React, { Component } from "react";
import { Grid, Row, Col, FormControl } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import Select from "react-select";
import { getProductList, getProductSearchList, getProductDetailList, getMappedProductList } from '../../productManagement/actions/productActions';
import PaginationUtil from "../../common/util/paginationUtil";
import Datetime from "react-datetime";
import moment from "moment";
var Modal = require('react-bootstrap-modal')

class MultipleSelectionModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataList: [],
      params: null,
      brand: '',
      brandName: '',
      categoryName: '',
      category: '',
      brandSearch: '',
      brandList: [],
      categoryList: [],
      searchInput: "",
      selectedFilter: "",
      additionalParams: null,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      allList: [{ label: 'All', value: '' }],
      isAllChecked: false,
      customError: false,
      autoSave: false,
      closePopUp: true,
      fromDate: '',
      toDate: '',
      searchProducts: false,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true });
    await this.setSelectedTabDetails();
  };

  setSelectedTabDetails = async () => {
    const managePageList = pagePropertyListConstant.MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST(this);
    const { search, brand, fromDate, toDate, category } = this.state;
    var additionalParams = {};
    additionalParams["isDropdown"] = true;
    additionalParams["clientSource"] = 'taxes';
    if(CommonUtil.isNotNull(category)) additionalParams["categoryId"] = category;
    if(CommonUtil.isNotNull(search)) additionalParams["search"] = search;
    if(CommonUtil.isNotNull(brand)) additionalParams["brand"] = brand;
    if(CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(toDate)) additionalParams["fromDate"] = fromDate;
    if(CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(toDate)) additionalParams["toDate"] = toDate;
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      attributeObj: searchAttributeList.attributeObj,
      additionalParams: additionalParams,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      brandList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'brandList')],
      categoryList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'categoryList')],
    });
    await this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  makeCustomAPICall(tempParamas) {
    const { showVariant, selectedProduct } = this.props;
    this.setState({isAllChecked: false});
    if(showVariant && selectedProduct) {
      this.props.getMappedProductList(selectedProduct);
    } else if (this.state.searchProducts) {
      this.props.getProductList(tempParamas);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList(this.props.productList);
    }
    if(this.props.mappedProductList != null && prevProps.mappedProductList != this.props.mappedProductList) {
      this.updateProductDropDownList(this.props.mappedProductList);
    }
    if (this.props.productDetailList != null && prevProps.productDetailList != this.props.productDetailList) {
      let tempList = this.props.productDetailList;
      tempList.map((item) => {
        item.price = item.purchasePrice;
      })
      this.props.getProductSelectionDetails(tempList, this.state.closePopUp);
      this.state.closePopUp && this.setState({ openModal: false });
    }
  }

  updateProductDropDownList = async (productList) => {
    let list = productList;
    let parentProduct = list.filter(item => !item.parentProductId)
    if(parentProduct && parentProduct.length > 0) {
      await this.setState({ productId: parentProduct[0].productId, productName: parentProduct[0].productName })
    }
    list = await list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    await this.setState({ tableDataList: [] })
    await this.setState({ tableDataList: list })
  }

  closeModal = (event) => {
    this.props.getProductSelectionDetails(null, true);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave = async (event) => {
    const { tableDataList } = this.state;
    let tempList = [];
    tempList = tableDataList && tableDataList.filter((item) => item.isChecked == true).map((item) => {
      return item.productId
    })
    if(tempList && tempList.length > 0) {
      await this.setState({ submitted: true, autoSave: false, alert: null, closePopUp: true });
      await this.props.getProductDetailList(tempList, this.props.supplierId, this.props.facilityId)
    }
  }  

  handlePopupContinue = async (event) => {
    const { tableDataList } = this.state;
    let tempList = [];
    tempList = tableDataList && tableDataList.filter((item) => item.isChecked == true).map((item) => {
      return item.productId
    })
    if(tempList && tempList.length > 0) {
      await this.setState({ submitted: true, autoSave: false, alert: null, closePopUp: false });
      await this.props.getProductDetailList(tempList, this.props.supplierId, this.props.facilityId)
      await this.makeCustomAPICall(PaginationUtil.getPaginationParams(this.state.currentPage - 1, null, this, true))
    } else {
      this.setState({ submitted: true, autoSave: false, alert: null });
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null, currentPage: this.state.pageNumber });
  }

  handlebrandDropdownChange = async (tempObj) => {
    await this.setState({
      brand: tempObj.value, brandName: tempObj.label,
    });
  }

  handlecategoryDropdownChange = async (tempObj) => {
    await this.setState({
      category: tempObj.value, categoryName: tempObj.label,
    });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      // this.globalSearch();
    });
  }

  globalSearch = async () => {
    let { searchInput } = this.state;
    let list = this.props.productList
    list = await list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    let filteredData = list.filter((value) => {
      return (
        String(value.productId).includes(searchInput) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productSKU.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    await this.setState({ tableDataList: [] });
    await this.setState({ tableDataList: filteredData });
  };

  advanceSearch = async () => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ search: this.state.searchInput.trim(), searchProducts: true  });
    this.setSelectedTabDetails();
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleRemoveFilter = async (event) => {
    this.setState({ search: null, searchInput: "", brand: null, brandName: "", category: null, categoryName: "", fromDate : "", toDate: "", searchProducts: false, tableDataList: [] });
  }

  handleCheckBoxChange = async (event) => {
    const { id, checked } = event.target;
    var tempId = id.split("_");
    const { tableDataList } = this.state;
    tableDataList.map((item) => {
      if(item.productId == tempId[0]) {
        item.isChecked = checked;
      }
    })
    await this.setState({
      autoSave: true,
      tableDataList: tableDataList
    })
  }

  handleAllCheckboxChange = async (event) => {
    const { checked } = event.target;
    const { tableDataList } = this.state;
    tableDataList.map((item, index) => {
      item.isChecked = checked;
    })
    await this.setState({
      autoSave: true,
      isAllChecked : checked,
      tableDataList: tableDataList
    })
  }

  handleDateChange(event, eventId) {
    var name = eventId.split('_')[0];
    this.setState({
      [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : ''
    })
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, search, customError, brand, category, fromDate, toDate, searchProducts} = this.state;
    const { showVariant } = this.props;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.closeModal} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          {this.state.alert}
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                {showVariant ? <div className="model-heading">Variations | PRO-{this.state.productId} | {this.state.productName}</div> :
                <div className="model-heading">Add Multiple Products</div>}
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            {!showVariant && <Row className="header-section" style={{marginBottom: '30px'}}>
                              <Col md={12}>
                                <Row>
                                  <Col md={3}>
                                    <Select
                                      classNamePrefix="react-select"
                                      name="category"
                                      onChange={(value) => this.handlecategoryDropdownChange(value)}
                                      value={{ "label": this.state.categoryName ? this.state.categoryName : 'Select Category' }}
                                      options={[...this.state.allList, ...this.state.categoryList]}
                                      placeholder="Select Category"
                                    />
                                  </Col>
                                  <Col md={3}>
                                    <Select
                                      classNamePrefix="react-select"
                                      name="brand"
                                      onChange={(value) => this.handlebrandDropdownChange(value)}
                                      value={{ "label": this.state.brandName ? this.state.brandName : 'Select Brand' }}
                                      options={[...this.state.allList, ...this.state.brandList]}
                                      placeholder="Select Brand"
                                    />
                                  </Col>
                                  <Col md={6}>
                                    <div className="right-section multi-selection ">
                                      <div className="search-section advance" style={{width: '100%'}}>
                                        <form onSubmit={this.handleSubmit}>
                                        <i className="fa fa-search"></i>
                                        <FormControl type="text" name="searchInput" placeholder="Search by Product Code/Name/SKU"
                                          value={this.state.searchInput} onChange={this.handleChange} />
                                        </form>
                                      </div>
                                    </div>
                                  </Col>
                                </Row>
                                <Row style={{marginTop: "20px", display: 'flex', alignItems: 'center'}}>
                                  <Col md={3}>
                                    <Datetime
                                      id="fromDate"
                                      timeFormat={false}
                                      closeOnSelect={true}
                                      isValidDate={''}
                                      inputProps={{
                                        readOnly: true,
                                        placeholder: "From Date",
                                        disabled: false,
                                        title: CommonUtil.getFormattedDate(this.state.fromDate)
                                      }}
                                      name="fromDate"
                                      onChange={(moment) => this.handleDateChange(moment, 'fromDate')}
                                      dateFormat="MM-DD-YYYY"
                                      value={moment(this.state.fromDate)}
                                    />
                                  </Col>
                                  <Col md={3}>
                                    <Datetime
                                      id="toDate"
                                      timeFormat={false}
                                      closeOnSelect={true}
                                      isValidDate={''}
                                      inputProps={{
                                        readOnly: true,
                                        placeholder: "To Date",
                                        disabled: false,
                                        title: CommonUtil.getFormattedDate(this.state.toDate)
                                      }}
                                      name="toDate"
                                      onChange={(moment) => this.handleDateChange(moment, 'toDate')}
                                      dateFormat="MM-DD-YYYY"
                                      value={moment(this.state.toDate)}
                                    />
                                  </Col>
                                  <Col md={6} style={{ display: 'flex'}}><Button className="btn-save btn-fill" onClick={this.advanceSearch} style={{marginLeft : 0}}>Search</Button>
                                  {searchProducts ? <Button className="btn-cancel" onClick={this.handleRemoveFilter}>Reset</Button> : null}
                                  </Col>
                                </Row>
                              </Col>
                            </Row>}
                            {customError && <Row><Col md={12}><p className="text-danger">Product limit of 500 has reached in the order.</p></Col></Row>}
                            {tableColumnList != null ? (
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                  <Table className={"table-box-height"} 
                                    columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                    showCheck={true}
                                  />
                                ) : null}
                              </Row>
                            ) : null}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>Add Product</Button>
                              </div>
                              :
                              <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                            }
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    productList: state.product.productList,
    productDetailList: state.product.productDetailList,
    mappedProductList: state.product.mappedProductList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getProductList: (id) => dispatch(getProductList(id)),
  getProductDetailList: (list, supplierId, facilityId) => dispatch(getProductDetailList(list, facilityId,null,null,supplierId)),
  getProductSearchList: params => dispatch(getProductSearchList(params)),
  getMappedProductList: (id) => dispatch(getMappedProductList(id)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MultipleSelectionModal);
