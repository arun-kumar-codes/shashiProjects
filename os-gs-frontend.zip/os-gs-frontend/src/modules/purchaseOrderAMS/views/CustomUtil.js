import CommonUtil from '../../common/util/commonUtil';
import PurchaseOrderUtil from './PurchaseOrderUtil';

const CustomUtil = {
    handleCustomDropDownCall: async function (event, obj, that, isTableAttribute) {
        let key = isTableAttribute ? obj : obj.name;
        if (key == 'supplierId') {
            that.props.getSupplierDetails(event.value);
            CommonUtil.handleDropDownChange(event, obj, that);
        } else if (key == 'facilityId') {
            that.props.getFacilityDetails(event.value);
            CommonUtil.handleDropDownChange(event, obj, that);
        } else if (key == 'productId') {
            that.props.getProductDetails(event[0].productId, { supplierId: that.state.attributeObj.supplierId, facilityId: that.state.attributeObj.facilityId });
        } else if (key == 'ingredientId') {
            that.props.getIngredientDetails(event[0].ingredientId);
        }
    },
    updateCustomApiData: async function (attributeName, that) {
        const { attributeObj } = that.state;
        const { actionMode } = that.props;
        if (attributeName == 'supplierId') {
            if (CommonUtil.isCreateOrCloneMode(actionMode)) {
                attributeObj.shipLocationName = '';
            }
            that.setState({ attributeObj: { ...attributeObj } });
            PurchaseOrderUtil.updateShippingLocationList(that);
        } else if (attributeName == 'productId') {
            await PurchaseOrderUtil.setDefaultRowData("itemList", that);
            await PurchaseOrderUtil.handleTableCalculation("itemList", that);
        } else if (attributeName == 'ingredientId') {
            await PurchaseOrderUtil.setDefaultRowData("ingredients", that);
            await PurchaseOrderUtil.handleTableCalculation("ingredients", that);
        }
    },
    handleAPIResponse: function (that, prevProps, prevState) {
        if (that.props.attributeObj != null && prevProps.attributeObj != that.props.attributeObj) {
            if (CommonUtil.isCloneMode(that.props.actionMode)) {
                that.updateCloneData(that.props.attributeObj);
            } else {
                that.updateApiData(that.props.attributeObj);
            }
        }
        if (that.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != that.props.ajaxCallStatus) {
            that.handleAjaxResponse();
        }
        if (that.props.ingredientList != null && prevProps.ingredientList != that.props.ingredientList) {
            that.updateIngredientDropDownList();
        }
        if (that.props.productDetails != null && prevProps.productDetails != that.props.productDetails) {
            CustomUtil.updateCustomApiData('productId', that);
        }
        if (that.props.ingredientDetails != null && prevProps.ingredientDetails != that.props.ingredientDetails) {
            CustomUtil.updateCustomApiData('ingredientId', that);
        }
        if (that.props.supplierDetails != null && prevProps.supplierDetails != that.props.supplierDetails) {
            CustomUtil.updateCustomApiData('supplierId', that);
        }
        if (that.props.supplierList != null && prevProps.supplierList != that.props.supplierList) {
            that.updateSupplierDropDownList();
        }
        if (that.props.productList != null && prevProps.productList != that.props.productList) {
            that.updateProductDropDownList();
        }
        if (that.props.facilityList != null && prevProps.facilityList != that.props.facilityList) {
            that.updateFacilityDropDownList();
        }
        if (that.state.attributeObj && that.state.attributeObj.supplierId && prevState.attributeObj
            && that.state.attributeObj.supplierId != prevState.attributeObj.supplierId) {
            that.mergeProductIngredientList(that.state.attributeObj.supplierId);
        }
        if (that.props.qboDetail != null && prevProps.qboDetail != that.props.qboDetail) {
            that.handleQBODetails();
        }
        if (that.props.qboBillDetail != null && prevProps.qboBillDetail != that.props.qboBillDetail) {
            that.handleQBOBillDetails();
        }
        if (prevProps.location && prevProps.location.key !== that.props.location.key) {
            if (!CommonUtil.isCreateMode(that.props.actionMode)) {
                that.props.getPurchaseOrderDetails(that.props.purchaseOrderId);
            } else {
                that.createNew();
            }
        }
    }
};

export default CustomUtil;