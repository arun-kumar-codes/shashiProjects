import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { Redirect } from "react-router-dom";
import { getPurchaseOrderPaymentDetails, updatePurchaseOrderPayment } from "../actions/purchaseOrderActions";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import * as commonConstant from "../../common/constant/commonConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import ValidationUtil from "../../common/util/validationUtil";
import PopularTableUtil from '../../common/util/popularTableUtil';
import { setActionMode } from "../../../actions/appActions";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import currencyIcon from '../../common/util/currencyIcon';
var Modal = require('react-bootstrap-modal')

class PaymentProcessModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: {},
      submitted: false,
      customErrorFlag: false,
      redirect: false,
      redirectUrl: null,
      alert: null,
      tableDataKey: "tableDataList",
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    const managePageList = pagePropertyListConstant.PAYMENT_PROCESS_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    });
    this.props.getPurchaseOrderPaymentDetails(this.props.purchaseOrderId);
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
  }

  updateApiData(attributeObj) {
    this.setState({
      attributeObj: {
        ...attributeObj
      },
      totalPaidAmount: attributeObj.paymentDetailsList.length > 0 ? this.getTotalReceivedAmount(attributeObj.paymentDetailsList) : 0,
      tableDataList: attributeObj.paymentDetailsList.length > 0 ? [...attributeObj.paymentDetailsList] : [{}]
    });
  }

  getTotalReceivedAmount = (paymentDetailsList) => {
    let totalPaidAmount = 0;
    if (CommonUtil.isNotNull(paymentDetailsList) && paymentDetailsList.length > 0) {
      for (let i = 0; i < paymentDetailsList.length; i++) {
        totalPaidAmount = CommonUtil.getTotalValue(totalPaidAmount, paymentDetailsList[i].receivedAmount);
      }
    }
    return totalPaidAmount;
  }

  handleTableTextBoxChange = (event) => {
    this.setState({ customErrorFlag: false });
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  handleTableSwitchChange = (event, state) => {
    PopularTableUtil.handleTableSwitchChange(event, state, this, this.getSelectedTablekey());
  }

  handleTableRemove = (event) => {
    PopularTableUtil.handleTableRemove(event, this, this.getSelectedTablekey());
  };

  handleTableDateChange = (event, eventId) => {
    PopularTableUtil.handleTableDateChange(event, eventId, this, this.getSelectedTablekey());
  };

  handleTableAddRow = (event) => {
    PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
  }

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.setState({ openModal: false, submitted: false });
      this.setState({ alert: null });
      this.props.setAjaxCallStatus(null);
      this.props.getPaymentModalDetails(true);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
    }
  };

  handleSave = async (event) => {
    this.setState({ submitted: true });
    const { tableDataList, attributeObj } = this.state;
    let tempObj = {};
    tempObj.paymentDetailsList = [...tableDataList];

    let totalPaidAmount = this.getTotalReceivedAmount(tempObj.paymentDetailsList);
    if (CommonUtil.getFloatValue(totalPaidAmount, true) > CommonUtil.getFloatValue(attributeObj.totalValue, true)) {
      this.setState({ customErrorFlag: true });
      return true;
    }
    tempObj.paymentDetailsList = tempObj.paymentDetailsList.filter(item => !item.purchaseOrderId)
    tempObj.paymentDetailsList = ValidationUtil.removeAttributeFromArrayList(tempObj.paymentDetailsList,
      pagePropertyListConstant.PAYMENT_PROCESS_PAGE_LIST(this).tableColumnList,
      commonConstant.EDIT_ACTION_MODE);

    if (!ValidationUtil.validateArrayListRequestObj(tempObj.paymentDetailsList,
      pagePropertyListConstant.PAYMENT_PROCESS_PAGE_LIST(this).tableColumnList)) {
      return false;
    }
    
    let temp = true;
    if (tempObj.paymentDetailsList && tempObj.paymentDetailsList.length > 0) {
      tempObj.paymentDetailsList.map(x => {
        if(CommonUtil.getFloatValue(x.receivedAmount, true) == 0) {
          temp = false;
        }
      })
    }
    if(temp) {
      tempObj.facilityId = this.props.facilityId;
      tempObj.purchaseOrderId = this.props.purchaseOrderId;
      await this.props.updatePurchaseOrderPayment(tempObj);
      await this.props.getPaymentModalDetails(true);
      await this.setState({ openModal: false });
    }
  }

  handlePopupCancel() {
    this.props.getPaymentModalDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { submitted, tableColumnList, tableConfig, tableDataList, attributeObj } = this.state;
    const currencyCode = this.props.currencyCode;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Process Payment</div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div className="automation">
                            <Row>
                              <Col md={3} className="automation-details">
                                <div className="heading">Order Number</div>
                                <div className="value">PO-{this.props.purchaseOrderId}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Total Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,attributeObj.totalValue)}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Paid Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,CommonUtil.getFloatValue(this.state.totalPaidAmount))}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Pending Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,CommonUtil.getFloatValue(attributeObj.totalValue) -
                                  CommonUtil.getFloatValue(this.state.totalPaidAmount))}</div>
                                {this.state.customErrorFlag && (
                                  <small className="text-danger">
                                    Paid amount is higher than pending amount.
                              </small>
                                )}
                              </Col>
                            </Row>
                            {tableColumnList != null ?
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) ?
                                  <>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />

                                  </>
                                  : null}
                                <Col md={12}>
                                  <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                    <i className=" fa fa-plus" />
                                    Add row
                                  </div>
                                </Col>
                              </Row>
                              : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <div>
                            <Button className="btn-cancel" onClick={this.handlePopupCancel}>Cancel</Button>
                            <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    attributeObj: state.purchaseOrder.purchaseOrderPaymentDetails,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
  };
}

const mapDispatchToProps = (dispatch) => ({
  updatePurchaseOrderPayment: (purchaseOrderDetailsObj) => dispatch(updatePurchaseOrderPayment(purchaseOrderDetailsObj)),
  getPurchaseOrderPaymentDetails: (selectedPurchaseOrderCode) => dispatch(getPurchaseOrderPaymentDetails(selectedPurchaseOrderCode)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(PaymentProcessModal);
