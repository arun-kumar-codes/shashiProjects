import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import DragDrop from "../../../components/DragDrop/DragDrop.jsx";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import ValidationUtil from '../../common/util/validationUtil';
import { Redirect } from "react-router-dom";
import * as statusConstant from '../../common/constant/statusConstant';
const Modal = require('react-bootstrap-modal')

class DocumentPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
    };
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.getDocumentDetails = this.getDocumentDetails.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true, attributeObj: this.props.documentList });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleSave(event) {
    this.setState({ submitted: true });
    const { attributeObj } = this.state;
    let tempObj = {};
    tempObj.documentList = this.state.attributeObj.documentList;
    if (CommonUtil.isNotNull(tempObj.documentList) && tempObj.documentList.length > 0) {
      let openFlag = false;
      for (var i=0; i<tempObj.documentList.length; i++) {
        if(CommonUtil.isNotNull(tempObj.documentList[i].documentType) && CommonUtil.isNotNull(tempObj.documentList[i].documentName) && tempObj.documentList[i].documentName.length > 2) {
          openFlag = true;
        } else {
          openFlag = false;
        }  
      }
      if (openFlag == true) {
        this.setState({ openModal: false, });
        this.props.getUploadDocumentDetailsNew(tempObj);
      } else {
        this.setState({ openModal: true, });
      }
    } else {
      this.setState({ openModal: false, });
      this.props.getUploadDocumentDetailsNew(tempObj);
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel = (event) => {
    this.props.getUploadDocumentDetailsNew(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  getDocumentDetails(documentList) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        documentList: [...documentList]
      }
    })
  }

  render() {
    const { attributeObj } = this.state;
    const actionMode = this.props.actionMode;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Upload documentList</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <Card
                      plain
                      title=""
                      content={
                        <DragDrop
                          minSize={0}
                          maxSize={5000000}
                          multiple={false}
                          disabled={(CommonUtil.isViewMode(this.props.actionMode) ||  this.props.status == statusConstant.COMPLETED_STATUS)  ? true : false}
                          errormsg="File size exceed max size limit of 5 MB."
                          typeerror="File type is not accepted"
                          getdocumentdetails={this.getDocumentDetails}
                          files={attributeObj != null && attributeObj.documentList != null && attributeObj.documentList.length > 0 ?
                            attributeObj.documentList : null}
                          fileNamePrefix={attributeObj != null && attributeObj.supplierId}
                          moduleName="saleOrder"
                        />
                      }
                      ftTextRight
                      legend={
                        CommonUtil.isViewMode(this.props.actionMode) ?
                          <div>
                            <Button className="btn-cancel" onClick={this.handlePopupCancel}>
                              Cancel
                              </Button>
                          </div>
                          : <div>
                            <Button className="btn-cancel" onClick={this.handlePopupCancel}>
                              Cancel
                              </Button>

                            <Button className="btn-save btn-fill btn-wd" onClick={this.handleSave}>
                              Save
                              </Button>
                          </div>
                      }
                    />
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(DocumentPopup);
