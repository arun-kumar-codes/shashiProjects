import React, { Component } from "react";
import { Grid, Row, Col, Nav, NavDropdown, MenuItem, FormGroup, ControlLabel, Tabs, Tab } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import {
  setPurchaseOrderDetails,
  getPurchaseOrderDetails,
  updatePurchaseOrderDeleteStatus,
  setReducerInitMode,
  getQBODetails,
  getQBOBillDetails,
  downloadInvoice
} from "../actions/purchaseOrderActions";
import { setActionMode } from "../../../actions/appActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as purchaseOrderConstant from "../constant/purchaseOrderConstant";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { getIngredientList, getIngredientDetails } from "../../ingredientManagement/actions/ingredientActions";
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getSupplierList, getSupplierDetails } from "../../supplierManagement/actions/supplierActions";
import { getProductList, getProductDetails } from '../../productManagement/actions/productActions';
import ValidationUtil from "../../common/util/validationUtil";
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil";
import PopupUtil from "../../common/util/popupUtil";
import LabelUtil from "modules/common/util/labelUtil";
import StockViewModal from "./StockViewModal";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DateUtil from "../../common/util/dateUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import StatusUtil from "../../common/util/statusUtil";
import * as commonConstant from "../../common/constant/commonConstant";
import * as statusConstant from "../../common/constant/statusConstant";
import PurchaseOrderUtil from '../views/PurchaseOrderUtil';
import isAuthorized from "auth-plugin";
import source from "assets/img/source-page-icon.svg";
import _ from 'lodash';
import DocumentUploadModal from "./DocumentUploadModal";
import DocumentUploadModalNew from "./DocumentUploadModalNew";
import mixpanel from "../../analytics/mixpanel/mixpael";
import GenerateInvoicePDF from "./GenerateInvoicePDF";
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import currencyIcon from '../../common/util/currencyIcon';
import CustomUtil from "./CustomUtil";
import MultipleSelectionModal from './MultipleSelectionModal';
import SupplierSelectionModal from './SupplierSelectionModal';
import SuggestionUtil from '../../common/util/suggestionUtil';
import check from "assets/img/check.svg";
import documentmangment from "assets/img/Document-Mangment-1.svg";
import NavigationPrompt from "react-router-navigation-prompt";
import SweetAlert from "react-bootstrap-sweetalert";
import { getUserProfile } from "../../userManagement/actions/userActions";

class CreatePurchaseOrder extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      productId: null,
      openDocumentModal: false,
      openDocumentModalNew: false,
      openStockModal: false,
      isTaxValidationDone: false,
      itemList: [],
      submitted: false,
      isDownLoadPdf: false,
      alert: null,
      qboBillAction: null,
      qboDetail: null,
      qboBillDetail: null,
      receivedStatusFlag: false,
      expenseList: [],
      ingredients: [],
      selectedTab: "PRODUCTDETAILS",
      productTableKey: "itemList",
      expensesTableKey: "expenseList",
      ingredientTableKey: "ingredients",
      multipleSelectionModal: false,
      supplierSelectionModal: false,
      showVariant: false,
      selectedProduct: null,
      selectedIngredient: null,
      selelctedValue: '',
      showSuggestionInput: true,
      expenseValidationError: false,
      productValidationError: false,
      qualityValidationError: false,
      qualityIngValidationError: false,
      formDirty: false,
      isPaymentPending: true,
    };
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Create purchase order loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getPurchaseOrderDetails(this.props.purchaseOrderId);
      }
    } else {
      CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_PURCHASE_ORDER_PAGE_URL, this);
    }
    this.props.getUserProfile();
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({ searchInput: searchInput ? searchInput : '' })
    this.props.getDataDictionaryDetails();
    this.props.getProductList({ isDropdown: true });
    // this.props.getIngredientList({ isDropdown: true });
    this.props.getSupplierList({ isDropdown: true });
    this.props.getFacilityList({ isDropdown: true });
    this.setSelectedTableDetails(this.state.receivedStatusFlag);

    const commonAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_PAGE_LIST(this);
    await this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      termsAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.termsAttributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  };

  setSelectedTableDetails = async (receivedStatusFlag) => {
    let tableAttributeList = [], tableColumnList = [];
    const { attributeObj, selectedTab } = this.state;
    if (attributeObj && selectedTab == "EXPENSESDETAILS") {
      tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this);
    } else if (attributeObj && selectedTab == "INGREDIENTDETAILS") {
      if (receivedStatusFlag) {
        tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_INGREDIENT_RECEIVE_TABLE_LIST(this);
      } else {
        tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_INGREDIENT_TABLE_LIST(this);
      }
    } else {
      if (receivedStatusFlag) {
        tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_RECEIVE_TABLE_LIST(this);
      } else {
        tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this);
      }
    }
    const tempList = [...Array(0)].map(() => ({}))
    await this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.tableColumnList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
      receivedStatusFlag: receivedStatusFlag,
      dictionaryData: this.props.dataDictionaryList
    });

    if (((this.props.userProfile && this.props.userProfile.metadata) ? (this.props.userProfile.metadata.isLopPurchase ? this.props.userProfile.metadata.isLopPurchase : false) : false)) {
      let tempList = this.state.tableColumnList && this.state.tableColumnList.map(item => {
        if (item.id == "lop") {
          item.type = "text"
        }
        return item;
      })
      await this.setState({ tableColumnList: tempList });
    }

    if (attributeObj && attributeObj.status == statusConstant.COMPLETED_STATUS && CommonUtil.isViewMode(this.props.actionMode)) {
      let tempList = this.state.tableColumnList && this.state.tableColumnList.map(item => {
        if(item.id == "leftQuantity" || item.id == "receivingQuantity") {
          item.type = "TEMP"
        }
        if(item.id == "price" || item.id == "totalPrice") {
          item.type = "text"
        }
        return item;
      })
      await this.setState({ tableColumnList : tempList})
    }
  };

  getSelectedTablekey = (selectedTab) => {
    if (this.state.selectedTab == 'PRODUCTDETAILS' || selectedTab == 'PRODUCTDETAILS') {
      return this.state.productTableKey;
    } else if (this.state.selectedTab == 'EXPENSESDETAILS' || selectedTab == 'EXPENSESDETAILS') {
      return this.state.expensesTableKey;
    } else if (this.state.selectedTab == 'INGREDIENTDETAILS' || selectedTab == 'INGREDIENTDETAILS') {
      return this.state.ingredientTableKey;
    }
  }

  getProductSelectionDetails = async (list, closePopUp) => {
    if (list && list.length > 0) {
      list.sort((a, b) => a.productId > b.productId);
      const { itemList } = this.state;
      list.map((x) => {
        x.quantity = 1;
        x.price = (CommonUtil.isNullValue(x.lop) || x.lop == 0) ? x.purchasePrice : x.lop;
        x.volumeUnitId = x.volumeUnitId ? x.volumeUnitId : x.volumeUnit;
        return x
      })
      itemList.map((x) => {
        list.map((y) => {
          y.volumeUnitId = y.volumeUnitId ? y.volumeUnitId : y.volumeUnit;

          if(x.productId == y.productId) {
            x.quantity = Number(x.quantity) + 1 ;
            y["dup"]=1;
          }
        })
      })
      const tempList = [...list, ...itemList];
      const uniqueList = tempList.filter(item => !item.hasOwnProperty('dup'));
      await this.setState({ itemList: [] })
      await this.setState({ itemList: uniqueList.filter((x) => CommonUtil.isNotNull(x)) })
    }
    await PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this)
    if(closePopUp) {
      this.props.getProductList({ isDropdown: true });
      this.setState({ multipleSelectionModal: false, showVariant: false, selectedProduct: null, selectedIngredient: null });
    }
  }

  getIngredientSelectionDetails = async (list) => {
    if (list && list.length > 0) {
      list.sort((a, b) => a.ingredientId > b.ingredientId);
      const { ingredients } = this.state;
      // let selectedLenght = ingredients.length;
      // if (selectedLenght >= 100) {
      //   await this.setState({ customError: true, showSuggestionInput: true });
      // } else {
        list.map((x) => {
          x.quantity = 1;
          // x.volumeUnitId = x.volumeUnitId ? x.volumeUnitId : x.volumeUnit;
          return x
        });
        ingredients.map((x) => {
          list.map((y) => {
            // y.volumeUnitId = y.volumeUnitId ? y.volumeUnitId : y.volumeUnit;

            if(x.ingredientId == y.ingredientId) {
              x.quantity = Number(x.quantity) + 1 ;
              y["dup"]=1;
            }
          });
        })
        const tempList = [...list, ...ingredients];
        const uniqueList = tempList.filter(item => !item.hasOwnProperty('dup'));
        await this.setState({ ingredients: [] })
        await this.setState({ ingredients: uniqueList.filter((x) => CommonUtil.isNotNull(x)) })
      // }
    }
    await PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this)
    this.props.getIngredientList({ isDropdown: true });
    this.setState({ multipleSelectionModal: false, showVariant: false, selectedProduct: null, selectedIngredient: null });
  }

  handleMultipleSelection = (event, isProduct) => {
    if (isProduct) {
      this.setState({ multipleSelectionModal: true, showVariant: false, selectedProduct: null, selectedIngredient: null, isIngredient: false });
    } else {
      this.setState({ multipleSelectionModal: true, showVariant: false, selectedProduct: null, selectedIngredient: null, isIngredient: true });
    }
  }

  handleTableTextBoxChange = async (event) => {
    var id = event.target.id.split('_')[0];
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
     this.setState({ fieldName: id, formDirty: true })
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  handleTableDropDownChange = (event, obj) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  handleTableDateChange = (event, eventId) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableDateChange(event, eventId, this, this.getSelectedTablekey());
  }

  handleTableSuggestionChange = async (event, eventId, searchOptions) => {
    this.setState({ formDirty: true })
    let key = "productId";
    let { itemList } = this.state;
    if (event != null && event.length > 0) {
      await this.setState({ showSuggestionInput: false })
      const alreadyExist = itemList.some(product => product.productId === event[0].productId)
      if (alreadyExist) {
        itemList.map((item, index) => {
          if (item.productId == event[0].productId) {
            item.quantity = Number(item.quantity) + 1
          }
        })
        await this.setState({ itemList: [] })
        await this.setState({ itemList: itemList })
        await PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
        await this.setState({ showSuggestionInput: true })
      } else {
        PopularTableUtil.handleTableSuggestionChangeAMS(event, eventId, searchOptions,
          this, this.getSelectedTablekey(), "purchaseOrder");
        CustomUtil.handleCustomDropDownCall(event, key, this, true);
        await this.setState({ customError: false, showSuggestionInput: true })
      }
      document.getElementById("quantity_0").focus();
    }
  }

  handleIngredientTableSuggestionChange = async (event, eventId, searchOptions) => {
    this.setState({ formDirty: true })
    let key = "ingredientId";
    let { ingredients } = this.state;
    if (event != null && event.length > 0) {
      await this.setState({ showSuggestionInput: false })
      const alreadyExist = ingredients.some(ingredient => ingredient.ingredientId === event[0].ingredientId)
      if (alreadyExist) {
        ingredients.map((item, index) => {
          if (item.ingredientId == event[0].ingredientId) {
            item.quantity = Number(item.quantity) + 1
          }
        })
        await this.setState({ ingredients: [] })
        await this.setState({ ingredients: ingredients })
        await PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
        await this.setState({ showSuggestionInput: true })
      } else {
        PopularTableUtil.handleTableSuggestionChangeAMS(event, eventId, searchOptions,
          this, this.getSelectedTablekey(), "purchaseOrderIngredient");
        CustomUtil.handleCustomDropDownCall(event, key, this, true);
        await this.setState({ showSuggestionInput: true })
      }
      document.getElementById("quantity_0").focus();
    }
  }

  pressEnter = async (e) => {
    if (!e) e = window.event;
    if (e.keyCode == '13') {
      await this.setState({ showSuggestionInput: false })
      await this.setState({ showSuggestionInput: true })
    } else {
      CommonUtil.maxLengthCheck(e, 10)
    }
  }

  handleCustomDropDownCall = async (event, obj) => {
    await this.setState({ formDirty: true })
    CustomUtil.handleCustomDropDownCall(event, obj, this);
  };


  handleDeleteRowPopup = (event) => {
    this.setState({ eventId: event.target.id, formDirty: true });
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleTableRemove = async (event) => {
    this.setState({ alert: null, formDirty: true });
    let tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, this.getSelectedTablekey(), true);
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  };

  handleTableAddRow = (event) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
    // if (this.state.itemList.length < this.state.productIngredientOptions.length) {
    // }
  };

  handleTableButtonMenuAction = (event) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };


  getUploadDocumentDetailsNew = (uploadDocumentObj) => {
    this.setState({ openDocumentModalNew: false, selectedProductCode: null, formDirty: true });
    if (uploadDocumentObj != null && uploadDocumentObj.documentList &&
      uploadDocumentObj.documentList.length >= 0) {
      PurchaseOrderUtil.handleUploadDocumentDetailsNew({ ...uploadDocumentObj }, this);
    }
  }

  componentDidUpdate(prevProps, prevState) {
    CustomUtil.handleAPIResponse(this, prevProps, prevState);
  }

  handleQBODetails = async () => {
    await this.setState({ qboDetail: this.props.qboDetail });
  }

  handleQBOBillDetails = () => {
    this.setState({ qboBillDetail: this.props.qboBillDetail });
    if (this.state.qboBillAction == 'create') {
      const { limit, currentPage } = this.state;
      this.props.getPurchaseOrderDetails(this.state.attributeObj.purchaseOrderId);
    } else if (this.state.qboBillAction == 'view') {
      if (CommonUtil.isNotNull(this.props.qboBillDetail.qboURL)) {
        window.open(this.props.qboBillDetail.qboURL);
      }
    }
  }

  getQBOBillDetails = (e) => {
    if (PurchaseOrderUtil.isInActiveQBOAccount(this)) {
      PurchaseOrderUtil.QBOInActivePopup(this);
      return
    }
    let eventId = e.target.id.split("_");
    let qboParams = {};
    qboParams.purchaseorderCode = eventId[0];
    if (CommonUtil.isNullValue(eventId[1])) {
      qboParams.action = 'create';
      this.setState({ qboBillAction: 'create' });
    } else {
      qboParams.action = 'view';
      this.setState({ qboBillAction: 'view' });
      qboParams.sourceId = eventId[1];
    }
    this.props.getQBOBillDetails(qboParams);
  };

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  updateIngredientDropDownList = () => {
    this.setState({ ingredientList: this.props.ingredientList });
    // this.mergeProductIngredientList();
  }

  updateProductDropDownList = () => {
    this.setState({ productList: this.props.productList });
    // this.mergeProductIngredientList();
  }

  mergeProductIngredientList = async () => {
    const { itemList } = this.state;
    let activeProductList = [];
    this.props.productList && Array.prototype.push.apply(activeProductList, this.props.productList);
    const tempList = CommonUtil.isNotNull(itemList) ? itemList : [...Array(0)].map(() => ({}))
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      await this.setState({ itemList: [...tempList] });
    }
    await this.setState({ productIngredientOptions: [...activeProductList] })
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  updateFacilityDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-");
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'facilityId')
    })
  }

  updateSupplierDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.supplierList, 'supplierId', 'supplierName', null, false, "SUP-");
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'supplierId')
    })
  }

  handleSave(event) {
    this.setState({ submitted: true, qboBillAction: null, qualityValidationError: false, qualityIngValidationError: false, formDirty: false });
    const { attributeObj } = this.state;
    var tempObj = _.cloneDeep(attributeObj);
    const purchaseOrderId = attributeObj.purchaseOrderId;
    tempObj.totalValue = this.state.grandTotal;

    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj, this.state.attributeList,
      this.props.actionMode);
    tempObj.itemList = [];
    tempObj.itemList = [...this.state.itemList].filter((item, index) => item.productId).map(({ lop, ...rest }) => ({ ...rest, exciseTax: "0.00" }));

    // tempObj.itemList = ValidationUtil.removeAttributeFromArrayList(tempObj.itemList,
    //   pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this).tableColumnList,
    //   commonConstant.CREATE_ACTION_MODE);
    tempObj.expenseList = [...this.state.expenseList];
    tempObj.requestedDeliveryDate = CommonUtil.getTodaysDate();
    tempObj.ingredients = [...this.state.ingredients].filter((item, index) => item.ingredientId);
    // tempObj.ingredients = ValidationUtil.removeAttributeFromArrayList(tempObj.ingredients,
    //   pagePropertyListConstant.CREATE_PURCHASE_ORDER_INGREDIENT_TABLE_LIST(this).tableColumnList,
    //   commonConstant.CREATE_ACTION_MODE);
    const tableColumnList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this).tableColumnList;
    tempObj.expenseList = ValidationUtil.removeAttributeFromArrayList(tempObj.expenseList, tableColumnList,
      this.props.actionMode);
    this.isValidRequestObj(tempObj)
    PurchaseOrderUtil.isValidExpenseRequestObj(this, tempObj, tableColumnList)
    if (this.isValidRequestObj(tempObj) && PurchaseOrderUtil.isValidExpenseRequestObj(this, tempObj, tableColumnList)) {
      delete tempObj.purchaseOrderId;
      this.props.setPurchaseOrderDetails(tempObj, this.props.actionMode, purchaseOrderId);
    }
  }

  isValidRequestObj = (tempObj) => {
    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }
    if (tempObj.itemList.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.itemList,
        pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this).tableColumnList)) {
        this.setState({ productValidationError: true })
        return false;
      } else {
        this.setState({ productValidationError: false })
      }
      // if (this.state.receivedStatusFlag && !PurchaseOrderUtil.checkReceivedQuantityValidation(tempObj.itemList)) {
      //   if (tempObj.status != statusConstant.COMPLETED_STATUS) {
      //     return false;
      //   }
      // }
    }
    if (tempObj.status == statusConstant.PARTIAL_RECEIVED && this.state.receivedStatusFlag) {
      if (tempObj.itemList.length > 0 && !PurchaseOrderUtil.isValidOrderedQty(tempObj.itemList)) {
        this.setState({ qualityValidationError: true })
        return false;
      }
      if (tempObj.ingredients.length > 0 && !PurchaseOrderUtil.isValidOrderedQty(tempObj.ingredients)) {
        this.setState({ qualityIngValidationError: true })
        return false;
      }
    }
    if (CommonUtil.isCreateMode(this.props.actionMode)) {
      if (!this.state.isTaxValidationDone && !PurchaseOrderUtil.checkTaxValidation(tempObj.itemList)) {
        PurchaseOrderUtil.handleTaxValidation(this);
        return false;
      }
    }
    if (tempObj.expenseList.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.expenseList,
        pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this).tableColumnList)) {
        return false;
      }
    }
    if (tempObj.ingredients.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.ingredients,
        pagePropertyListConstant.CREATE_PURCHASE_ORDER_INGREDIENT_TABLE_LIST(this).tableColumnList)) {
        return false;
      }
    }
    return true;
  }

  handleHeaderIconClick = (e, action) => {
    switch (action) {
      case commonConstant.PRINT_ACTION:
        this.printPurchaseOrder();
        break;
      case commonConstant.CLONE_ACTION:
        this.clonePurchaseOrder();
        this.setSelectedTableDetails(this.state.receivedStatusFlag)
        break;
      case commonConstant.TRASH_ACTION:
        this.deletePurchaseOrder();
        break;
      // case commonConstant.DOWNLOAD_ACTION_MODE:
      //   this.downloadPurchaseOrder();
      //   break;
      default:
        console.log("Invalid header action");
    }
  };

  downloadPurchaseOrder = (e, invoiceDate, invoiceName) => {
    if (!CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      // this.setState({ isDownLoadPdf: true });
      this.props.downloadInvoice(this.state.attributeObj.purchaseOrderId, invoiceDate)
    }
  }

  pdfDownload = () => {
    this.setState({ isDownLoadPdf: false });
  }

  printPurchaseOrder = (params) => {
    // TODO
  };

  clonePurchaseOrder = (params) => {
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    this.props.setActionMode(commonConstant.CLONE_ACTION_MODE);
    this.props.getPurchaseOrderDetails(this.state.attributeObj.purchaseOrderId);
  };

  deletePurchaseOrder = (params) => {
    if (!CommonUtil.isEditMode(this.props.actionMode)) {
      return;
    }
    if (this.state.attributeObj.status !== statusConstant.NEW_STATUS) {
      return;
    }
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleStatusAction;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeletPopUpConfig(
      popupActionButton, purchaseOrderConstant.MODULE_NAME);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  };

  handleStatusAction = (status) => {
    let tempObj = {};
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updatePurchaseOrderDeleteStatus(tempObj, this.state.attributeObj.purchaseOrderId);
  };

  handleTaxConfirmation = async () => {
    await this.setState({ isTaxValidationDone: true, alert: null });
    this.handleSave();
  };

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      } else {
        if (CommonUtil.isNullValue(this.state.attributeObj.billingSourceName)) {
          if (this.state.qboBillAction == 'create') {
            this.props.handleClick(CommonUtil.prepareBillCreatedSuccessPopUpConfig());
            return
          } else {
            this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
          }
        } else {
          if (this.state.qboBillAction == 'view') {
            return
          } else {
            this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
          }
        }
      }
      let params = null;
      if (this.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
        params = "COMPLETED";
      }
      let location = this.state.attributeObj.facilityId;
      setTimeout(CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_PURCHASE_ORDER_PAGE_URL, this, params, location), 0);
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      let errorMessage = this.props.ajaxCallStatus.data &&
        this.props.ajaxCallStatus.data.response &&
        this.props.ajaxCallStatus.data.response.data;
      if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "411") {
        PurchaseOrderUtil.QBOSupplierNotExitPopup(this);
      } else {
        PopupUtil.popupErrorResponse(this);
      }
      await this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = null;
    this.setState({ formDirty: false })
    if (this.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
      params = "COMPLETED";
    }
    let location = this.state.attributeObj.facilityId;
    CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_PURCHASE_ORDER_PAGE_URL, this, params, location);
  }

  async updateApiData(attributeObj) {
    await this.setState({
      attributeObj: {
        ...attributeObj,
        purchaseOrderId: CommonUtil.isCloneMode(this.props.actionMode)
          ? "" : `${attributeObj.purchaseOrderId}`,
      },
      itemList: [...attributeObj.itemList],
      ingredients: [...attributeObj.ingredients],
      expenseList: !CommonUtil.isNullArray(attributeObj.expenseList) ? [...attributeObj.expenseList] : [],
      receivedStatusFlag: attributeObj.status == statusConstant.NEW_STATUS ? false : true,
      isPaymentPending: CommonUtil.isNullValue(attributeObj.totalPaidAmount) || attributeObj.totalPaidAmount == 0 ? true : false
    });
    this.setSelectedTableDetails(attributeObj.status == statusConstant.NEW_STATUS ? false : true)
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  updateCloneData = async (attributeObj) => {
    let tempObj = attributeObj;
    tempObj.status = statusConstant.NEW_STATUS;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj, this.state.attributeList, this.props.actionMode);
    tempObj.createdDate = CommonUtil.getTodaysDate();
    tempObj.itemList = ValidationUtil.removeAttributeFromArrayList(tempObj.itemList,
      pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this).tableColumnList,
      commonConstant.CLONE_ACTION_MODE);
    tempObj.expenseList = tempObj.expenseList ? ValidationUtil.removeAttributeFromArrayList(tempObj.expenseList,
      pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this).tableColumnList,
      commonConstant.CLONE_ACTION_MODE) : [];
    tempObj.documentList = [];
    await this.setState({
      attributeObj: {
        ...tempObj,
        purchaseOrderId: CommonUtil.isCloneMode(this.props.actionMode) ? "" : tempObj.purchaseOrderId,
      },
      itemList: [...tempObj.itemList],
      ingredients: [...tempObj.ingredients],
      expenseList: [...tempObj.expenseList],
      isDownLoadPdf: false,
      receivedStatusFlag: false,
    });
    this.setSelectedTableDetails(false)
    this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  };

  createNew = async () => {
    const tempList = [...Array(0)].map(() => ({}))
    let tempObj = [];
    tempObj.status = statusConstant.NEW_STATUS;
    tempObj.createdDate = CommonUtil.getTodaysDate();
    tempObj.itemList = [];
    tempObj.expenseList = [];
    tempObj.documentList = [];
    await this.setState({
      attributeObj: {
        ...tempObj,
        purchaseOrderId: "",
      },
      itemList: [...tempList],
      expenseList: [...tempObj.expenseList],
    });
    // await this.handleTableAddRow();
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  };

  handleTabClick = async (label, event) => {
    let selectedTabKey = label.toUpperCase();
    await this.setState({ selectedTab: selectedTabKey })
    this.setSelectedTableDetails(this.state.receivedStatusFlag);
  }

  handleDocumentPopup = async (e) => {
    await this.setState({ openDocumentModalNew: true, });
  };

  addVariantsModel = async (e, selectedProduct) => {
    await this.setState({ multipleSelectionModal: true, showVariant: true, selectedProduct: selectedProduct, selectedIngredient: null });
  }

  searchSupplier = async () => {
    if (CommonUtil.isCreateMode(this.props.actionMode)) {
      await this.setState({ supplierSelectionModal: true, formDirty: false})
    }
  }

  getSupplierSelectionDetails = async (selectedSupplier) => {
    this.setState({ showCheckout: true })
    const { attributeObj } = this.state;
    if (selectedSupplier) {
      await this.setState({
        attributeObj: {
          ...attributeObj,
          supplierId: Number(selectedSupplier)
        },
      });
      await this.props.getSupplierDetails(selectedSupplier);
    }
    await this.setState({
      multipleSelectionModal: false, showVariant: false, selectedProduct: null, supplierSelectionModal: false, selectedIngredient: null
    });
    await this.props.getSupplierList({ isDropdown: true });
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList, tableConfig, totalUnits, grandTotal, subTotalWithoutTax, termsAttributeList, imageUrl, totalExpenses, showSuggestionInput, isPaymentPending } = this.state;
    const tableDataList = this.state[this.getSelectedTablekey()];
    const actionMode = this.props.actionMode;
    const currencyCode = this.props.currencyCode;
    let selectedListCount = PurchaseOrderUtil.getSelectedListCount(this.state.itemList) + PurchaseOrderUtil.getSelectedListCount(this.state.ingredients);
    return (
      <div className="main-content create-page">
        <NavigationPrompt when={this.state.formDirty}>
          {({ onConfirm, onCancel }) => (
            <React.Fragment>
              <SweetAlert
                showCancel
                warning
                customClass="popup-header"
                style={{ display: "block", marginTop: "-150px" }}
                title={"All changes will be lost. Do you want to continue?"}
                text={"All changes will be lost. Do you want to continue?"}
                confirmBtnText={'Confirm'}
                cancelBtnText={'Cancel'}
                onConfirm={onConfirm}
                onCancel={onCancel}
                btnSize="sm"
                cancelBtnCssClass="btn-cancel"
                confirmBtnCssClass="btn-save btn-fill"
                focusConfirmBtn={false}
                focusCancelBtn={true}
                closeOnCancel={true}
                closeOnConfirm={true}
                showConfirm={true}
              >
              </SweetAlert>
            </React.Fragment>
          )}
        </NavigationPrompt>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params, location: this.state.location, searchInput: this.state.searchInput }}></Redirect> : null
        }
        {this.state.alert}

        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={source} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    purchaseOrderConstant.EDIT_PURCHASE_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      purchaseOrderConstant.VIEW_PURCHASE_HEADER_TITLE
                      : purchaseOrderConstant.CREATE_PURCHASE_HEADER_TITLE}
                </div>
              </Col>

              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {isAuthorized("createPurchaseOrderActions") &&
                    <div className="page-action-buttons">
                      <div className={`btn-fill btn-wd btn btn-default progress-button ${!CommonUtil.isEditMode(actionMode) ? 'disabled' : ''}`}
                        style={{
                          backgroundColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status),
                          borderColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status)
                        }}>
                        <div className="items">{StatusUtil.getStatusLabel(attributeObj && attributeObj.status)}
                        </div>
                        {!CommonUtil.isViewMode(this.props.actionMode) && !CommonUtil.isCreateOrCloneMode(this.props.actionMode) ?
                          <div className="items">
                            <Nav pullRight>
                              <NavDropdown id={'status'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
                                {pagePropertyListConstant.HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                                  <MenuItem key={index} name="status" id={tempAttributeListObj.statusKey}
                                    onClick={(e) => PurchaseOrderUtil.handleButtonStatusChange(e, this)}
                                    disabled={false}>
                                    <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
                                    {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                                  </MenuItem>
                                ))}
                              </NavDropdown>
                            </Nav>
                          </div>
                          : null}
                      </div>
                      {(CommonUtil.isEditMode(actionMode) || CommonUtil.isViewMode(actionMode)) && attributeObj && this.props.qboDetail && this.props.qboDetail.qboStatus != "NA" ?
                        <div className='btn-fill btn-wd btn progress-button qbo'
                          onClick={(e) => this.getQBOBillDetails(e)}
                          id={attributeObj.purchaseOrderId + "_" + attributeObj.billingSourceId}
                          style={{
                            backgroundColor: StatusUtil.getStatusColor(PurchaseOrderUtil.getQBOBillStatus(attributeObj.billingSourceName)),
                            borderColor: StatusUtil.getStatusColor(PurchaseOrderUtil.getQBOBillStatus(attributeObj.billingSourceName))
                          }}>
                          {StatusUtil.getStatusLabel(PurchaseOrderUtil.getQBOBillStatus(attributeObj && attributeObj.billingSourceName))}
                        </div>
                        : null}

                      {!CommonUtil.isCreateOrCloneMode(actionMode) ?
                        <img src={documentmangment} alt="" className={CommonUtil.isViewMode(actionMode) ? 'fa disabled' : 'fa'} title="Documents" onClick={(e) => this.handleDocumentPopup(e)} />
                        : null}

                      {this.state.isDownLoadPdf == true ? <GenerateInvoicePDF isDownLoadPdf={true} imageUrl={imageUrl} pdfDownload={this.pdfDownload} /> : null}
                      {/* <i className="fa fa-download invoice-download" title={"Download"} onClick={(e) => this.handleHeaderIconClick(e, commonConstant.DOWNLOAD_ACTION_MODE)} ></i> */}

                      <div className="items">
                        <Nav pullRight>
                          <NavDropdown id={'pdfdownload'} title={<i className="fa fa-download invoice-download" title={"Download"} />} noCaret>
                            <MenuItem name="pdfdownload" id="FULLINVOICE"
                              onClick={(e) => this.downloadPurchaseOrder(e, "FULLINVOICE", this.props.purchaseOrderId)}
                              disabled={false}> Invoice
                                          </MenuItem>
                            <MenuItem name="pdfdownload" id="PACKINGSLIP"
                              onClick={(e) => this.downloadPurchaseOrder(e, "PICKUP", "Pick List-" + this.props.purchaseOrderId)}
                              disabled={false}> Pick List
                                          </MenuItem>
                          </NavDropdown>
                        </Nav>
                      </div>

                      <i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-copy' : 'fa fa-copy disabled'} title={"Clone"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.CLONE_ACTION)} ></i>
                      {isAuthorized("deletePurchaseOrder") && <i className={(CommonUtil.isEditMode(actionMode) && StatusUtil.getStatusLabel(attributeObj && attributeObj.status) === 'New') ? 'fa fa-trash' : 'fa fa-trash disabled'} title={"Trash"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.TRASH_ACTION)} ></i>}
                    </div>
                  }
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave} disabled={selectedListCount > 0 ? false : true}>Save</Button>
                    </div>
                    :
                    !this.props.insideInventory && <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                          tempAttributeListObj.type == "FIXED" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            LabelUtil.fixedAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                            : tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : null))
                        }
                      </Row>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <Tabs id="create-sale-tabs" className="table-tabs-without-border" activeKey={this.state.selectedTab} onSelect={this.handleTabClick}>
                      {this.state.qualityValidationError &&
                        <Row><Col md={12} style={{ marginTop: '10px' }}>
                          <small className="text-danger">Products Quanity should be greater than equal to receiving Quantity.</small>
                        </Col></Row>}
                      {this.state.qualityIngValidationError &&
                        <Row><Col md={12} style={{ marginTop: '10px' }}>
                          <small className="text-danger">Ingredients Quanity should be greater than equal to receiving Quantity.</small>
                        </Col></Row>}
                      <Tab eventKey={'PRODUCTDETAILS'} title="PRODUCT DETAILS">
                        {this.state.expenseValidationError == true &&
                          <Col md={12}>
                            <small className="text-danger">Please check mandatory fields in Expense Details tab.</small>
                          </Col>}
                        {showSuggestionInput && isPaymentPending && CommonUtil.isNotNull(attributeObj) && CommonUtil.isNotNull(attributeObj.supplierId) && CommonUtil.isNotNull(attributeObj.facilityId) && attributeObj.status === statusConstant.NEW_STATUS && !CommonUtil.isViewMode(this.props.actionMode) ?
                          <Row>
                            <Col md={4}>
                              <div className="suggestion-box">
                                <i className="fa fa-search"></i>
                                <SuggestionUtil
                                  searchOptionList={["productId", "productName", "productSKU"]}
                                  id={'productId'}
                                  options={this.state.productList}
                                  selectedListKeys={['productId', 'productSKU']}
                                  selectedAttributeList={this.state.products}
                                  placeholder="Search by Product Code/Name/SKU"
                                  disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                  value={this.state.selelctedValue}
                                  selectedValue={this.state.selelctedValue}
                                  resetOnSelection={true}
                                  reSelect={true}
                                  onChange={(e) => this.handleTableSuggestionChange(e, 'productId',
                                    ["productId", "productName"])}
                                  handleSuggestionChange={this.handleTableSuggestionChange}
                                />
                              </div>
                            </Col>
                          </Row>
                          : null}
                        {tableColumnList != null ?
                          <Row>
                            {(tableDataList != null && tableDataList.length > 0) ? (
                              <Table className={"table-box-height"} 
                                columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                            ) : null}

                            <div className="add-new-section">
                              <Col md={6}>
                                <Row>
                                  <Col md={12}>
                                    {isPaymentPending && CommonUtil.isNotNull(attributeObj) && CommonUtil.isNotNull(attributeObj.supplierId) && CommonUtil.isNotNull(attributeObj.facilityId) && attributeObj.status === statusConstant.NEW_STATUS &&
                                      !CommonUtil.isViewMode(this.props.actionMode) ?
                                      <div className="add-row-button" onClick={(e) => this.handleMultipleSelection(e, true)}>
                                        <i className=" fa fa-plus" />
                                        Add multiple products
                                      </div>
                                      : null}
                                  </Col>
                                  <Col md={6} className="tcs">
                                    <Row>
                                      {termsAttributeList != null && termsAttributeList.map((tempAttributeListObj, index) => (
                                        DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      ))}
                                    </Row>
                                  </Col>
                                </Row>
                              </Col>
                              <Col md={6}>
                                <ul className="total-section">
                                  <li>
                                    <Col md={6} className="total-section-field-title"> Total Units </Col>
                                    <Col md={6} className="total-section-field-value">
                                      {totalUnits}
                                    </Col>
                                  </li>
                                  <li>
                                    <Col md={6} className="total-section-field-title">
                                      Subtotal
                                  </Col>
                                    {subTotalWithoutTax ? (
                                      <Col md={6} className="total-section-field-value">
                                        {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, subTotalWithoutTax)}
                                      </Col>
                                    ) : null}
                                  </li>

                                  <li>
                                    <Col md={6} className="total-section-field-title">
                                      Total Expense
                                  </Col>
                                    <Col md={6} className="total-section-field-value">
                                      {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalExpenses)}
                                    </Col>
                                  </li>


                                  <li>
                                    <Col md={6} className="total-section-field-title">
                                      <b>Final Total</b>
                                    </Col>
                                    {grandTotal ? (
                                      <Col md={6} className="total-section-field-value">
                                        <b>{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, grandTotal)}</b>
                                      </Col>
                                    ) : null}
                                  </li>
                                </ul>
                              </Col>
                            </div>
                          </Row>
                          : null}
                      </Tab>
                      {/* {isAuthorized("ingTabPurchaseOrder") &&
                        <Tab eventKey={'INGREDIENTDETAILS'} title="INGREDIENT DETAILS">
                          {this.state.expenseValidationError == true &&
                            <Col md={12}>
                              <small className="text-danger">Please check mandatory fields in Expense Details tab.</small>
                            </Col>}
                          {showSuggestionInput && isPaymentPending && CommonUtil.isNotNull(attributeObj) && attributeObj.status === statusConstant.NEW_STATUS && !CommonUtil.isViewMode(this.props.actionMode) ?
                            <Row>
                              <Col md={4}>
                                <div className="suggestion-box">
                                  <i className="fa fa-search"></i>
                                  <SuggestionUtil
                                    searchOptionList={["ingredientId", "ingredientName", "ingredientSKU"]}
                                    id={'ingredientId'}
                                    options={this.state.ingredientList}
                                    selectedListKeys={['ingredientId', 'ingredientSKU']}
                                    selectedAttributeList={this.state.ingredients}
                                    placeholder="Search by Ingredient Code/Name/SKU"
                                    disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                    value={this.state.selelctedValue}
                                    selectedValue={this.state.selelctedValue}
                                    resetOnSelection={true}
                                    reSelect={true}
                                    onChange={(e) => this.handleIngredientTableSuggestionChange(e, 'ingredientId',
                                      ["ingredientId", "ingredientName"])}
                                    handleSuggestionChange={this.handleIngredientTableSuggestionChange}
                                  />
                                </div>
                              </Col>
                            </Row>
                            : null}
                          {tableColumnList != null ?
                            <Row>
                              {(tableDataList != null && tableDataList.length > 0) ? (
                                <Table
                                  columns={tableColumnList}
                                  data={tableDataList}
                                  config={tableConfig}
                                  getRowProps={this.getTdProps}
                                  that={this}
                                />
                              ) : null}

                              <div className="add-new-section">
                                <Col md={6}>
                                  <Row>
                                    <Col md={12}>
                                    {isPaymentPending && attributeObj && attributeObj.status === statusConstant.NEW_STATUS &&
                                      !CommonUtil.isViewMode(this.props.actionMode) ?
                                      <div className="add-row-button" onClick={(e) => this.handleMultipleSelection(e, false)}>
                                        <i className=" fa fa-plus" />
                                        Add multiple Ingredients
                                      </div>
                                      : null}
                                  </Col>
                                  </Row>
                                </Col>
                                <Col md={6}>
                                  <ul className="total-section">
                                    <li>
                                      <Col md={6} className="total-section-field-title"> Total Units </Col>
                                      <Col md={6} className="total-section-field-value">
                                        {totalUnits}
                                      </Col>
                                    </li>
                                    <li>
                                      <Col md={6} className="total-section-field-title">
                                        Subtotal
                                  </Col>
                                      {subTotalWithoutTax ? (
                                        <Col md={6} className="total-section-field-value">
                                          {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, subTotalWithoutTax)}
                                        </Col>
                                      ) : null}
                                    </li>

                                    <li>
                                      <Col md={6} className="total-section-field-title">
                                        Total Expense
                                  </Col>
                                      <Col md={6} className="total-section-field-value">
                                        {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalExpenses)}
                                      </Col>
                                    </li>


                                    <li>
                                      <Col md={6} className="total-section-field-title">
                                        <b>Final Total</b>
                                      </Col>
                                      {grandTotal ? (
                                        <Col md={6} className="total-section-field-value">
                                          <b>{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, grandTotal)}</b>
                                        </Col>
                                      ) : null}
                                    </li>
                                  </ul>
                                </Col>
                              </div>
                            </Row>
                            : null}
                        </Tab>
                      } */}
                      {(CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditMode(actionMode) || CommonUtil.isViewMode(actionMode)) &&
                        <Tab eventKey={'EXPENSESDETAILS'} title="EXPENSE DETAILS">
                          {this.state.productValidationError == true &&
                            <Col md={12}>
                              <small className="text-danger">Please check mandatory fields in Products tab.</small>
                            </Col>}
                          {tableColumnList != null ? (
                            <Row>
                              <Table
                                columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              <div className="add-new-section">
                                <Col md={6}>
                                  <Row>
                                    <Col md={12}>
                                      {!CommonUtil.isViewMode(actionMode) &&
                                        <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                          <i className=" fa fa-plus" />
                                          Add Row
                                        </div>
                                      }
                                    </Col>
                                  </Row>
                                </Col>
                                <Col md={6}>
                                  <ul className="total-section">
                                    <li>
                                      <Col md={6} className="total-section-field-title">
                                        <b>Total Expense</b>
                                      </Col>
                                      {totalExpenses ? (
                                        <Col md={6} className="total-section-field-value">
                                          <b>{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalExpenses)}</b>
                                        </Col>
                                      ) : null}
                                    </li>
                                  </ul>
                                </Col>
                              </div>
                            </Row>
                          ) : null}
                        </Tab>
                      }
                      {this.state.openDocumentModalNew == true ?
                        <DocumentUploadModalNew
                          documentList={this.state.attributeObj}
                          actionmode={actionMode}
                          status={attributeObj.status}
                          getUploadDocumentDetailsNew={this.getUploadDocumentDetailsNew}>
                        </DocumentUploadModalNew>
                        : null}
                      {this.state.multipleSelectionModal == true ?
                        <MultipleSelectionModal
                          saleOrderId={this.props.saleOrderId}
                          getProductSelectionDetails={this.getProductSelectionDetails}
                          getIngredientSelectionDetails={this.getIngredientSelectionDetails}
                          showVariant={this.state.showVariant}
                          selectedProduct={this.state.selectedProduct}
                          isIngredient={this.state.isIngredient}
                          selectedIngredient={this.state.selectedIngredient}       
                          supplierId={this.state.attributeObj.supplierId}                   
                          facilityId={this.state.attributeObj.facilityId}                  
                          >
                        </MultipleSelectionModal>
                        : null}
                      {this.state.supplierSelectionModal == true ?
                        <SupplierSelectionModal
                          getSupplierSelectionDetails={this.getSupplierSelectionDetails}>
                        </SupplierSelectionModal>
                        : null}
                    </Tabs>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave} disabled={selectedListCount > 0 ? false : true} >Save</Button>
                        </div>
                        :
                        !this.props.insideInventory && <Button className="btn-cancel" onClick={this.handlePopupContinue} disabled={selectedListCount > 0 ? false : true}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.purchaseOrder.purchaseOrderDetails,
    purchaseOrderId: state.purchaseOrder.selectedPurchaseOrderCode,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    productList: state.product.productList,
    supplierList: state.supplier.supplierList,
    ingredientList: state.ingredient.ingredientList,
    facilityList: state.facility.facilityList,
    currencyCode: state.dataDictionary.currencyCode,
    stateGST: state.dataDictionary.stateGST,
    centralGST: state.dataDictionary.centralGST,
    qboDetail: state.purchaseOrder.qboDetail,
    qboBillDetail: state.purchaseOrder.qboBillDetail,
    productDetails: state.product.productDetails,
    ingredientDetails: state.ingredient.ingredientDetails,
    facilityDetails: state.facility.facilityDetails,
    supplierDetails: state.supplier.supplierDetails,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setPurchaseOrderDetails: (purchaseOrderDetailsObj, actionMode, purchaseOrderId) => dispatch(setPurchaseOrderDetails(purchaseOrderDetailsObj, actionMode, purchaseOrderId)),
  getPurchaseOrderDetails: (selectedPurchaseOrderCode) => dispatch(getPurchaseOrderDetails(selectedPurchaseOrderCode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  updatePurchaseOrderDeleteStatus: (purchaseOrderDetails, purchaseOrderId) => dispatch(updatePurchaseOrderDeleteStatus(purchaseOrderDetails, purchaseOrderId)),
  setReducerInitMode: (init) => dispatch(setReducerInitMode(init)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getFacilityDetails: (id) => dispatch(getFacilityDetails(id)),
  getProductDetails: (id,supplierId) => dispatch(getProductDetails(id,supplierId)),
  getIngredientDetails: (id) => dispatch(getIngredientDetails(id)),
  getSupplierDetails: (id) => dispatch(getSupplierDetails(id)),
  getQBODetails: (id) => dispatch(getQBODetails(id)),
  getQBOBillDetails: (id) => dispatch(getQBOBillDetails(id)),
  downloadInvoice: (id, downloadType) => dispatch(downloadInvoice(id, downloadType)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});
export default connect(mapStateToProps, mapDispatchToProps)(CreatePurchaseOrder);
