import React, { Component } from "react";
import { Page, Text, View, Document, StyleSheet, Image } from "@react-pdf/renderer";
import CommonUtil from "../../common/util/commonUtil";
import currencyIcon from '../../common/util/currencyIcon';


class PurchaseOrderInvoice extends Component {

    constructor(props) {
        super(props);
        this.state = {
            attributeObj: null,
            totalUnits: 0,
            subTotalWithoutTax: 0,
            stateTaxTotal: 0,
            centralTaxTotal: 0,
            taxTotal: 0,
            grandTotal: 0,
        };
    }

    componentDidMount = async () => {
        if (CommonUtil.isNotNull(this.props.attributeObj)) {
            this.setState({ attributeObj: this.props.attributeObj });
            await this.getTotalOrderDetails(this.props.attributeObj);
        }
    };

    getTotalOrderDetails = async (attributeObj) => {
        let attributeDataList = attributeObj.itemList;
        let totalUnits = 0, subTotalWithoutTax = 0, taxTotal = 0, grandTotal = 0,
            stateTaxTotal = 0, centralTaxTotal = 0, totalReceivable = 0;

        let expenseList = attributeObj.expenseList;
        for (let i = 0; i < expenseList.length; i++) {
            let tempReceivable = 0;
            tempReceivable = CommonUtil.getFloatValue(expenseList[i].expenseAmount);
            totalReceivable = CommonUtil.getTotalValue(totalReceivable, tempReceivable);
        }
        let totalExpenses = CommonUtil.getFloatValue(totalReceivable, true);


        for (let i = 0; i < attributeDataList.length; i++) {
            let tempPrice = 0, tempQuantity = 0, tempTaxCode = 0;
            tempPrice = CommonUtil.getFloatValue(attributeDataList[i].totalPrice);
            tempQuantity = CommonUtil.getFloatValue(attributeDataList[i].quantity);
            tempTaxCode = CommonUtil.getFloatValue(attributeDataList[i].taxValue);
            totalUnits = CommonUtil.getTotalValue(totalUnits, tempQuantity);
            subTotalWithoutTax = CommonUtil.getTotalValue(subTotalWithoutTax, tempPrice);
            taxTotal = parseFloat(taxTotal + parseFloat((tempPrice / 100) * tempTaxCode));
        }
        stateTaxTotal = parseFloat((taxTotal / 100) * CommonUtil.getFloatValue(this.props.stateGST));
        centralTaxTotal = parseFloat((taxTotal / 100) * CommonUtil.getFloatValue(this.props.centralGST));
        stateTaxTotal = CommonUtil.isNaNValue(parseFloat(stateTaxTotal).toFixed(2));
        centralTaxTotal = CommonUtil.isNaNValue(parseFloat(centralTaxTotal).toFixed(2));
        grandTotal = CommonUtil.getTotalValue(subTotalWithoutTax, taxTotal, true);
        taxTotal = CommonUtil.getFloatValue(taxTotal, true);
        subTotalWithoutTax = CommonUtil.getFloatValue(subTotalWithoutTax, true);
        grandTotal = CommonUtil.getFloatValue(grandTotal) + CommonUtil.getFloatValue(totalExpenses);

        this.setState({
            totalUnits: totalUnits,
            subTotalWithoutTax: subTotalWithoutTax,
            taxTotal: taxTotal,
            stateTaxTotal: stateTaxTotal,
            centralTaxTotal: centralTaxTotal,
            grandTotal: grandTotal,
            totalExpenses: totalExpenses
        });
    }

    render() {
        const { attributeObj, totalUnits, subTotalWithoutTax, grandTotal,
            totalExpenses } = this.state;
        const { supplierObj, facilityObj, orgInformation, companyImage } = this.props;

        return (
            attributeObj !== null ?
                <Document>
                    <Page size="A4" style={styles.page}>

                        <View style={styles.header}>
                            <View style={styles.headersection}>
                                <View style={{ flexDirection: 'row' }}>
                                    {companyImage ?
                                        <View style={{ flexDirection: 'row' }}>
                                            <Image
                                                style={styles.image}
                                                src={companyImage}
                                            />
                                        </View>
                                        : null}
                                </View>
                                <View>
                                    <View style={styles.details}>
                                        {orgInformation && orgInformation.contactPerson ?
                                            <Text style={{ fontWeight: "bold" }}>{`${orgInformation.contactPerson}`}</Text>
                                            : null}
                                        {orgInformation && orgInformation.location ?
                                            <View style={styles.comapnyaddress}>
                                                <Text>{`${orgInformation.addressLine1.trim()}`}
                                                    {orgInformation.addressLine2 ? (", " + orgInformation.addressLine2.trim()) : null}
                                                </Text>
                                                <Text>{`${orgInformation.location.city.trim()}, ${orgInformation.location.state.trim()},`} {`${orgInformation.location.country.trim()}, ${orgInformation.location.zipcode.trim()}`} </Text>
                                                {/*<Text>{`${orgInformation.contactPerson}`}</Text>*/}
                                                <Text>{`${orgInformation.email.trim()}`} {`${orgInformation.phone.trim()}`}</Text>
                                            </View>
                                            : null}
                                    </View>
                                </View>
                            </View>
                            <View style={styles.topcorner}>
                                <Text style={styles.title}>Purchase Order</Text>
                                <View style={styles.date}>
                                    <Text>Date: {attributeObj.createdDate}</Text>
                                </View>
                                <View style={styles.date}>
                                    <Text>PO Number: {attributeObj.purchaseOrderId}</Text>
                                </View>
                                <View style={styles.date}>
                                    <Text>Due Date: {attributeObj.requestedDeliveryDate}</Text>
                                </View>
                            </View >
                        </View>

                        <View style={styles.addressConatiner}>
                            <View style={styles.addressDetails}>
                                <Text style={styles.heading}>Vendor</Text>
                                {supplierObj != null ?
                                    <View style={styles.details}>
                                        <Text>{`${supplierObj.supplierName.trim()}`}</Text>
                                        {/* <Text>{supplierObj.locations[0].locationName}</Text> */}
                                        <Text>{`${supplierObj.locations[0].address.trim()}, ${supplierObj.locations[0].city.trim()}, ${supplierObj.locations[0].state.trim()},`} </Text>
                                        <Text>{`${supplierObj.locations[0].country.trim()}, ${supplierObj.locations[0].zipcode.trim()}`} </Text>
                                    </View>
                                    : null}
                            </View>

                            <View style={styles.secondaddressDetails}>
                                <Text style={styles.heading}>Ship To</Text>
                                {facilityObj != null ?
                                    <View style={styles.details}>
                                        <Text>{facilityObj.facilityName.trim()}</Text>
                                        {/* <>{facilityObj.locations[0].locationName}</Text> */}
                                        <Text>{`${facilityObj.locations[0].address.trim()}, ${facilityObj.locations[0].city.trim()}, ${facilityObj.locations[0].state.trim()},`} </Text>
                                        <Text>{`${facilityObj.locations[0].country.trim()}, ${facilityObj.locations[0].zipcode.trim()}`} </Text>
                                    </View>
                                    : null}
                            </View>
                        </View>

                        <View style={styles.tableContainer}>
                            <View style={styles.container}>
                                <Text style={styles.description}>Item Desc</Text>
                                <Text style={styles.qty}>Quantity</Text>
                                <Text style={styles.qty}>Price ({this.props.currencyCode !== 'INR' ? currencyIcon.getCurrencyIcon(this.props.currencyCode) : 'Rs'})</Text>
                                <Text style={styles.lastqty}>Total ({this.props.currencyCode !== 'INR' ? currencyIcon.getCurrencyIcon(this.props.currencyCode) : 'Rs'})</Text>
                            </View>
                            {attributeObj.itemList.map((item, index) =>
                                <View style={styles.row} key={index} wrap={false}>
                                    <Text style={styles.description}>{`${item.productId}|${item.productName}`}</Text>
                                    <Text style={styles.qty}>{`${item.quantity} ${item.productUOM}`}</Text>
                                    <Text style={styles.qty}>{`${currencyIcon.getCurrencyDecimalFormat(this.props.currencyCode, item.price)}`}</Text>
                                    <Text style={styles.lastqty}>{`${currencyIcon.getCurrencyDecimalFormat(this.props.currencyCode, item.totalPrice)}`}</Text>
                                </View>
                            )}
                        </View>

                        <View style={styles.finaldetailsection} wrap={false}>
                            <View style={styles.totalsection}>
                                <View style={styles.finalvaluesection}>
                                    <Text style={styles.text}>Total Units: </Text>
                                    <Text style={styles.value}>{`${CommonUtil.getFloatValue(totalUnits)}`}</Text>
                                </View>
                                <View style={styles.finalvaluesection}>
                                    <Text style={styles.text}>Subtotal: </Text>
                                    <Text style={styles.value}>{`${this.props.currencyCode !== 'INR' ? currencyIcon.getCurrencyIcon(this.props.currencyCode) : 'Rs'} ${currencyIcon.getCurrencyDecimalFormat(this.props.currencyCode, CommonUtil.getFloatValue(subTotalWithoutTax))}`}</Text>
                                </View>
                                <View style={styles.finalvaluesection}>
                                    <Text style={styles.text}>Total Expense: </Text>
                                    <Text style={styles.value}>{`${this.props.currencyCode !== 'INR' ? currencyIcon.getCurrencyIcon(this.props.currencyCode) : 'Rs'} ${currencyIcon.getCurrencyDecimalFormat(this.props.currencyCode, CommonUtil.getFloatValue(totalExpenses))}`}</Text>
                                </View>
                                <View style={styles.finalvaluesection}>
                                    <Text style={styles.lasttext}>Final Total: </Text>
                                    <Text style={styles.lastvalue}>{`${this.props.currencyCode !== 'INR' ? currencyIcon.getCurrencyIcon(this.props.currencyCode) : 'Rs'} ${currencyIcon.getCurrencyDecimalFormat(this.props.currencyCode, CommonUtil.getFloatValue(grandTotal))}`}</Text>
                                </View>
                                {attributeObj.paymentStatus == "paid" && <View style={styles.paymentstatus}>
                                    <Text>({attributeObj.paymentStatus})</Text>
                                </View>}
                            </View>
                        </View>
                        {attributeObj.termsCondition ?
                            <View>
                                <View>
                                    <Text style={styles.tcstitle}>Terms & Conditions</Text>
                                </View>
                                <View>
                                    <Text style={{ fontSize: 7 }}>{attributeObj.termsCondition}</Text>
                                </View>
                            </View>
                            : null}


                    </Page>
                </Document>
                : null
        );
    }
}

export default PurchaseOrderInvoice;

const borderColor = '#00000';
const tableRowsCount = 11;
const styles = StyleSheet.create({
    page: {
        fontFamily: 'Helvetica',
        fontSize: 9,
        paddingTop: 30,
        paddingLeft: 30,
        paddingRight: 30,
        paddingBottom: 80,
        flexDirection: 'column',
        lineHeight: 1.5,
    },
    logo: {
        width: 120,
        height: 40,
        marginLeft: 2,
    },
    headersection: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
    },
    comapnyaddress: {
        fontSize: 6,
    },
    header: {
        flexDirection: 'row',
        marginBottom: 20,
    },
    topcorner: {
        flex: 1,
        justifyContent: 'flex-start',
    },
    addressConatiner: {
        flexDirection: 'row',
        marginBottom: 20,
        paddingLeft: 15,
        paddingRight: 15,
    },
    addressDetails: {
        marginRight: 30,
        flex: 1,
    },
    secondaddressDetails: {
        marginLeft: 30,
        flex: 1,
    },
    title: {
        color: "#7e7d7c",
        fontSize: 20,
        marginBottom: 5,
        textAlign: 'right',
    },
    date: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        marginBottom: 2,
    },
    heading: {
        backgroundColor: '#a5a5a5',
        paddingTop: 5,
        paddingLeft: 5,
        marginTop: 5,
    },
    details: {
        flexDirection: 'column',
        paddingLeft: 5,
        marginTop: 5,
    },
    image: {
        width: 100,
    },
    tableContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 20,
        borderWidth: 0,
        borderColor: borderColor,
    },
    container: {
        flexDirection: 'row',
        backgroundColor: '#a5a5a5',
        alignItems: 'center',
        justifyContent: 'center',
        alignContent: 'center',
        textAlign: 'center',
        fontWeight: "600",
    },
    row: {
        flexDirection: 'row',
        borderTopColor: borderColor,
        borderTopWidth: 0,
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        alignContent: 'center',
    },
    description: {
        width: '68%',
        borderRightColor: borderColor,
        borderRightWidth: 0,
        alignItems: 'flex-start',
        paddingTop: 5,
        paddingBottom: 5,
        paddingLeft: 10,
        lineHeight: 1,
        height: '100%',
        flexDirection: 'row',
        flexWrap: 'wrap',
        textAlign: 'left',
    },
    qty: {
        width: '10%',
        borderRightColor: borderColor,
        borderRightWidth: 0,
        alignItems: 'center',
        paddingTop: 5,
        paddingBottom: 5,
        paddingRight: 10,
        lineHeight: 1,
        height: '100%',
        flexDirection: 'row',
        flexWrap: 'wrap',
        textAlign: 'right',
    },
    lastqty: {
        width: '12%',
        borderRightColor: borderColor,
        borderRightWidth: 0,
        alignItems: 'center',
        paddingTop: 5,
        paddingBottom: 5,
        paddingRight: 10,
        lineHeight: 1,
        height: '100%',
        flexDirection: 'row',
        flexWrap: 'wrap',
        textAlign: 'right',
    },
    shippingmethod: {
        width: '20%',
        borderRightColor: borderColor,
        borderRightWidth: 1,
        alignItems: 'center',
        paddingTop: 5,
        paddingBottom: 5,
        lineHeight: 1.5,
        height: '100%',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    lastshippingmethod: {
        width: '20%',
        alignItems: 'center',
        paddingTop: 5,
        paddingBottom: 5,
        lineHeight: 1.5,
        height: '100%',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    finaldetailsection: {
        justifyContent: 'flex-end',
        flexDirection: 'row',
        marginTop: 20,
    },
    totalsection: {
        width: '50%',
        borderColor: '#f3f3f3',
        backgroundColor: '#f3f3f3',
        borderWidth: 1,
        borderRadius: 10,
        padding: 10,
    },
    finalvaluesection: {
        flexDirection: 'row',
        textAlign: 'left',
    },
    text: {
        backgroundColor: '#f3f3f3',
        borderBottomWidth: 1,
        borderBottomColor: '#707070',
        flex: 1,
        padding: 7,
    },
    lasttext: {
        backgroundColor: '#f3f3f3',
        fontWeight: "900",
        flex: 1,
        padding: 7,
    },
    value: {
        backgroundColor: '#f3f3f3',
        borderBottomWidth: 1,
        borderBottomColor: '#707070',
        flex: 1,
        marrginLeft: 5,
        padding: 7,
        textAlign: 'right',
    },
    lastvalue: {
        backgroundColor: '#f3f3f3',
        fontWeight: "900",
        flex: 1,
        marrginLeft: 5,
        padding: 7,
        textAlign: 'right',
    },
    signature: {
        borderTopWidth: 1,
        borderColor: borderColor,
        flexDirection: 'row',
        paddingLeft: 5,
        paddingRight: 5,
        paddingTop: 0,
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        height: 50,
    },
    sign: {
        width: '80%',
        borderRightWidth: 1,
        borderColor: borderColor,
    },
    signdate: {
        paddingLeft: 5,
    },
    tcstitle: {
        fontSize: 8,
        textDecoration: 'underline',
        lineHeight: 1.5,
        marginTop: '60px',
    },
    paymentstatus: {
        textTransform: 'uppercase',
        fontSize: 9,
        color: 'green',
        fontWeight: 600,
        paddingLeft: 7,
    }
});

