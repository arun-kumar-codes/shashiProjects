import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getSaleChannelCostList } from '../../saleOrder/actions/saleOrderActions';
import { getUserProfile , setProfileDashboardDetails } from '../../userManagement/actions/userActions';
import { ResponsiveFunnel } from '@nivo/funnel'
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import CommonUtil from '../../common/util/commonUtil';
import * as dashboardConstant from '../constant/dashboardConstant';
import currencyIcon from '../../common/util/currencyIcon';
import moment from "moment";

class SalesFunnel extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: '30D',
      categorySelect: null,
      fromDate: null,
      toDate: null,
      customDate: false,
      allList: [{ label: 'All', value: 'All' }],
    };
  }

  componentDidMount = () => {
    this.getTileDate();  
  }

  getTileDate = () => {
    let userProfile = this.props.userProfile;
    if (userProfile.dashboard != null && userProfile.dashboard.length > 0 && CommonUtil.isNotNull(userProfile.dashboard[0].salesByChannelCost)) {
      if (this.props.userProfile.dashboard[0].salesByChannelCost.customDate == true) {
        this.setState({duration: this.props.userProfile.dashboard[0].salesByChannelCost.duration, fromDate: this.props.userProfile.dashboard[0].salesByChannelCost.fromDate, toDate: this.props.userProfile.dashboard[0].salesByChannelCost.toDate, categorySelect: this.props.userProfile.dashboard[0].salesByChannelCost.category, customDate: this.props.userProfile.dashboard[0].salesByChannelCost.customDate});
      } else {
        this.setState({duration: this.props.userProfile.dashboard[0].salesByChannelCost.duration, categorySelect: this.props.userProfile.dashboard[0].salesByChannelCost.category});
      }
      this.props.getSaleChannelCostList(this.props.userProfile.dashboard[0].salesByChannelCost);
    } else {
      this.props.getSaleChannelCostList({ duration: '30D' });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.saleChannelCost != null && prevProps.saleChannelCost != this.props.saleChannelCost) {
      this.setState({ saleChannelCost: this.props.saleChannelCost });
    }
    // if (this.props.userProfile != null && prevProps.userProfile != this.props.userProfile) {
    //   this.getTileDate();
    // }
  }

  getTotalSaleCount = () => {
    var saleOrderTotalCount = 0;
    if (this.state.saleChannelCost != null) {
      for (var i = 0; i < this.state.saleChannelCost.length; i++) {
        saleOrderTotalCount = saleOrderTotalCount +
          CommonUtil.isNaNValue(parseInt(this.state.saleChannelCost[i].value));
      }
    }
    return saleOrderTotalCount;
  }

  handleApiCall = () => {
    this.props.getSaleChannelCostList(this.getSelectedRequestParams());
    this.refs.overlay.hide();

  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
    this.setState({
      categorySelect: null,
      fromDate: null,
      toDate: null,
      customDate: false,
    })
  }

  getSelectedRequestParams = () => {
    var tempParamas = {};
    const { duration, categorySelect, fromDate, toDate, customDate } = this.state;
    if (customDate) {
      tempParamas.customDate = customDate;
      tempParamas.duration = null;
      tempParamas.fromDate = fromDate ? fromDate : '';
      tempParamas.toDate = toDate ? toDate : '';
    }
    else {
      tempParamas.duration = duration ? duration : "30D";
      tempParamas.customDate = false;
      tempParamas.fromDate = '';
      tempParamas.toDate = '';
    }
    if (categorySelect) {
      tempParamas.category = categorySelect ? categorySelect : '';
    }
    let obj = {};
    let salesByChannelObj = {};
    salesByChannelObj.salesByChannelCost = tempParamas;
    var dashboardObj = [];
    dashboardObj.push(salesByChannelObj);
    obj.dashboard = dashboardObj;
    this.props.setProfileDashboardDetails(obj);
    return tempParamas;
    //return tempParamas;
  }

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate,
      duration: '',
    }));
  };

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options, customDate: false })
  }

  handleDropDownChange = (event, obj) => {
    this.setState({ 'categorySelect': event.value });
  }

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  getTotalSaleCost = () => {
    var saleChannelTotalCost = 0;
    if (this.state.saleChannelCost != null) {
      for (var i = 0; i < this.state.saleChannelCost.length; i++) {
        saleChannelTotalCost = saleChannelTotalCost +
          CommonUtil.getFloatValue(this.state.saleChannelCost[i].value);
      }
    }
    return saleChannelTotalCost.toFixed();
  }

  render() {
    const { duration, customDate } = this.state;
    const saleChannelCost = [
      {
        "id": "orders",
        "value": 38214,
        "label": "Orders Placed",
        "percentage": "100%",
        "color": "#A5A6FE"
      },
      {
        "id": "shopping",
        "value": 50401,
        "label": "Shopping Carts",
        "percentage": "100%",
        "color": "#FEBC0C"
      },
      {
        "id": "sessions",
        "value": 82746,
        "label": "Sessions",
        "percentage": "100%",
        "color":"#45C79D"
      },
    ];
    saleChannelCost.sort(function(a, b){return b.value - a.value});
    let salesChannelCostData = [];
    if (saleChannelCost.length > 0) {
      salesChannelCostData = saleChannelCost.map((item, index) => {
        return {
          ...item,
          value: parseFloat(item.value).toFixed(),
        }
      })
    }

    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <p>Date</p>
                <div className="date-buttons">
                  <Button className={duration == "7D" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '7D')}>Last 7 Days</Button>
                  <Button className={duration == "30D" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '30D')}>Last 30 Days</Button>
                  <Button className={customDate ? 'active' : ''} bsSize="xs" onClick={this.openCustomDateHander}>Custom Date</Button>
                </div>
                {this.state.customDate && (
                  <div className="custom-date">
                    <FormGroup>
                      <ControlLabel> Custom Date </ControlLabel>
                      <Datetime id="startdate" inputProps={{ readOnly: true, placeholder: "From" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.fromDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'fromDate')} />
                      <Datetime id="enddate" inputProps={{ readOnly: true, placeholder: "To" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.toDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'toDate')} />
                    </FormGroup>
                  </div>
                )}
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
           </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
           </Button>
            </div>
          }
        />
      </Popover>
    );

    return (
      <Col md={6} sm={12}>
        <Card
          title="Sales Funnel"
          content={
            <div className="graph" style={{display: 'flex', flexDirection: "column"}}>
              <ResponsiveFunnel
                height={130}
                data={salesChannelCostData}
                margin={{ top: 0, right: 100, bottom: 10, left: 100 }}
                shapeBlending={1}
                spacing={6}
                borderWidth={0}
                enableLabel={true}
                labelColor="#ffffff"
                borderOpacity={0}
                colors={salesChannelCostData.map((item) => item.color)}
                enableBeforeSeparators={false}
                beforeSeparatorLength={50}
                beforeSeparatorOffset={20}
                enableAfterSeparators={false}
                afterSeparatorLength={50}
                afterSeparatorOffset={20}
                currentPartSizeExtension={10}
                currentBorderWidth={10}
                motionConfig="gentle"
              />
              <ul className="funnel-legends">
                {salesChannelCostData.map((item) => 
                  <li><span style={{backgroundColor: item.color, height: '10px', width: '10px', marginRight: '10px', borderRadius: '5px'}}></span><div>{item.label}</div><div>{item.value}</div><div>{item.percentage}</div></li>
                )}
              </ul>
              {/*<div className="overlay-section">
                <OverlayTrigger ref="overlay" trigger="click" rootClose placement="left" overlay={popover}>
                  <i className="fa fa-ellipsis-v" />
                </OverlayTrigger>
              </div>*/}
            </div>
          }
        />
      </Col>);
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    saleChannelCost: state.saleOrder.saleChannelCost,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getSaleChannelCostList: selectedParams => dispatch(getSaleChannelCostList(selectedParams)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProfileDashboardDetails: (dataDictionaryDetailsObj) => dispatch(setProfileDashboardDetails(dataDictionaryDetailsObj)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SalesFunnel);
