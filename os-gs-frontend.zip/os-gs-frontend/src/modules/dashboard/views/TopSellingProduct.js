import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getUserProfile , setProfileDashboardDetails } from '../../userManagement/actions/userActions';
import { getTopProductList } from '../../saleOrder/actions/saleOrderActions';
import { ResponsiveBar } from '@nivo/bar';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { JS } from "aws-amplify";
import moment from "moment";

class TopSellingProduct extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: '30D',
      categorySelect: null,
      fromDate: null,
      toDate: null,
      customDate: false,
      allList: [{ label: 'All', value: 'All' }]
    };
  }

  componentDidMount = () => {
    this.getTileDate();  
  }

  getTileDate = () => {
    let userProfile = this.props.userProfile;
    if (userProfile.dashboard != null && userProfile.dashboard.length > 0 && CommonUtil.isNotNull(userProfile.dashboard[0].topSellingProducts)) {
      if (this.props.userProfile.dashboard[0].topSellingProducts.customDate == true) {
        this.setState({duration: this.props.userProfile.dashboard[0].topSellingProducts.duration, fromDate: this.props.userProfile.dashboard[0].topSellingProducts.fromDate, toDate: this.props.userProfile.dashboard[0].topSellingProducts.toDate, categorySelect: this.props.userProfile.dashboard[0].topSellingProducts.category, customDate: this.props.userProfile.dashboard[0].topSellingProducts.customDate});
      } else {
        this.setState({duration: this.props.userProfile.dashboard[0].topSellingProducts.duration, categorySelect: this.props.userProfile.dashboard[0].topSellingProducts.category});
      }
      this.props.getTopProductList(this.props.userProfile.dashboard[0].topSellingProducts);
    } else {
      this.props.getTopProductList({ duration: '30D' });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.topProductList != null && prevProps.topProductList != this.props.topProductList) {
      this.setState({ topProductList: this.props.topProductList });
    }
    if (this.props.userProfile != null && prevProps.userProfile != this.props.userProfile) {
      this.getTileDate();
    }
  }

  getTotalSaleCount = () => {
    var saleOrderTotalCount = 0;
    if (this.state.topProductList != null) {
      for (var i = 0; i < this.state.topProductList.length; i++) {
        saleOrderTotalCount = saleOrderTotalCount +
          CommonUtil.getFloatValue(this.state.topProductList[i].quantity);
      }
    }
    return saleOrderTotalCount;
  }

  handleApiCall = () => {
    this.props.getTopProductList(this.getSelectedRequestParams());
    this.refs.overlay.hide();

  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
    this.setState({
      categorySelect: null,
      fromDate: null,
      toDate: null,
      customDate: false,
    })
  }

  getSelectedRequestParams = () => {
    var tempParamas = {};
    const { duration, categorySelect, fromDate, toDate, customDate } = this.state;
    if (customDate) {
      tempParamas.customDate = customDate;
      tempParamas.duration = null;
      tempParamas.fromDate = fromDate ? fromDate : '';
      tempParamas.toDate = toDate ? toDate : '';
    }
    else {
      tempParamas.duration = duration ? duration : "30D";
      tempParamas.customDate = false;
      tempParamas.fromDate = '';
      tempParamas.toDate = '';
    }
    if (categorySelect) {
      tempParamas.category = categorySelect ? categorySelect : '';
    }
    let obj = {};
    let topSellObj = {};
    topSellObj.topSellingProducts = tempParamas;
    var dashboardObj = [];
    dashboardObj.push(topSellObj);
    obj.dashboard = dashboardObj;
    //localStorage.setItem('topSellingProducts', JSON.stringify(tempParamas));
    this.props.setProfileDashboardDetails(obj);
    return tempParamas;
  }

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate,
      duration: '',
    }));
  };

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options, customDate: false })
  }

  handleDropDownChange = (event, obj) => {
    this.setState({ 'categorySelect': event.value });
  }

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  render() {
    const { topProductList, duration, customDate } = this.state;
    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <p>Date</p>
                <div className="date-buttons">
                  <Button className={duration == "7D" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '7D')}>Last 7 Days</Button>
                  <Button className={duration == "30D" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '30D')}>Last 30 Days</Button>
                  <Button className={customDate ? 'active' : ''} bsSize="xs" onClick={this.openCustomDateHander}>Custom Date</Button>
                </div>
                {this.state.customDate && (
                  <div className="custom-date">
                    <FormGroup>
                      <ControlLabel> Custom Date </ControlLabel>
                      <Datetime id="startdate" inputProps={{ readOnly: true, placeholder: "From" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.fromDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'fromDate')} />
                      <Datetime id="enddate" inputProps={{ readOnly: true, placeholder: "To" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.toDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'toDate')} />
                    </FormGroup>
                  </div>
                )}
                <FormGroup>
                  <ControlLabel>
                    Category
                  </ControlLabel>
                  <Select classNamePrefix="react-select"
                    name="categorySelect"
                    value={{ "label": this.state.categorySelect }}
                    onChange={this.handleDropDownChange}
                    options={this.props.dataDictionaryList != null &&
                      this.props.dataDictionaryList.dataDictionaryList != null &&
                      [...this.state.allList, ...this.props.dataDictionaryList.dataDictionaryList.categoryList]}
                    placeholder="Select Category" />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );

    const CustomBarComponent = (props) => {
      const {
        x, y, width, height, color, borderColor, data, showTooltip, hideTooltip,
      } = props;

      return (
        <g transform={`translate(${x},${isNaN(y) ? 0 : y})`}
          onMouseEnter={(event) => {
            showTooltip(<tooltip className="bar-tooltip">
              <div style={{ color, borderColor, backgroundColor: "#fff" }}>
                {data && <p>{data.indexValue}</p>}
              </div>
            </tooltip>, event);
          }}
          onMouseLeave={(event) => {
            hideTooltip();
          }}
        >
          <rect width={25} height={isNaN(height) ? 0 : height} fill={color} x={(width / 2) - 12.5} />
          <text
            x={(width / 2)}
            y={isNaN(height) ? 0 : (height / 2)}
            textAnchor="middle"
            dominantBaseline="central"
            fill="black"
            style={{
                fontWeight: 400,
                fontSize: 10,
            }}
          >
            <tspan y={-6}>{data.value > 0 ? data.value : ''}</tspan>
          </text>
        </g>
      );
    };

    return (
      <Col md={6} sm={6}>
        <Card
          title="Top Selling Products"
          category={"Total count : " + this.getTotalSaleCount()}
          content={
            <div className="graph">
              <ResponsiveBar
                data={topProductList != null ? topProductList : []}
                keys={['quantity']}
                indexBy="productName"
                margin={{ top: 10, right: 10, bottom: 50, left: 40 }}
                padding={0.3}
                innerPadding={1}
                groupMode="grouped"
                colors={["#FF7D1A"]}
                minValue="auto"
                maxValue="auto"
                axisTop={null}
                axisRight={null}
                axisBottom={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: -20,
                  legend: '',
                  legendPosition: 'middle',
                  legendOffset: 28,
                }}
                axisLeft={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: '',
                  legendPosition: 'middle',
                  legendOffset: -30,
                  tickValues: 7
                }}
                theme={{
                  fontSize: 8,
                  axis: {
                    "domain": {
                      "line": {
                        "stroke": "#9AC7D7",
                        "strokeWidth": 1
                      }
                    },
                  },
                }}
                barComponent={CustomBarComponent}
                enableGridY={false}
                labelSkipWidth={0}
                labelSkipHeight={0}
                isInteractive={true}
                animate={false}
              />
              <div className="overlay-section">
                <OverlayTrigger ref="overlay" trigger="click" rootClose placement="left" overlay={popover}>
                  <i className="fa fa-ellipsis-v" />
                </OverlayTrigger>
              </div>
            </div>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    topProductList: state.saleOrder.topProductList,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getTopProductList: selectedParams => dispatch(getTopProductList(selectedParams)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProfileDashboardDetails: (dataDictionaryDetailsObj) => dispatch(setProfileDashboardDetails(dataDictionaryDetailsObj)),
});

export default connect(mapStateToProps, mapDispatchToProps)(TopSellingProduct);
