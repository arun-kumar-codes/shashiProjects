import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getUserProfile , setProfileDashboardDetails } from '../../userManagement/actions/userActions';
import { getMfgOTIFList } from '../../manufacturingOrder/actions/mfgOrderActions';
import { ResponsiveBar } from '@nivo/bar';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import moment from "moment";

class MfgOTIF extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: '5W',
      categorySelect: null,
      location: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
      mfgOrderTotalCount: null,
      mfgOTIFTotalAvg: null,
      allList: [{ label: 'All', value: 'All' }]
    };
  }

  componentDidMount = () => {
    this.getTileDate();  
    // if (CommonUtil.isNullValue(this.props.facilityList)) {
    //   this.props.getFacilityList();
    // }
  }

  getTileDate = () => {
    let userProfile = this.props.userProfile;
    if (userProfile.dashboard != null && userProfile.dashboard.length > 0 && CommonUtil.isNotNull(userProfile.dashboard[0].MfgOtif)) {
      this.setState({duration: this.props.userProfile.dashboard[0].MfgOtif.duration, location: this.props.userProfile.dashboard[0].MfgOtif.location, locationName: this.props.userProfile.dashboard[0].MfgOtif.locationName});
      this.props.getMfgOTIFList(this.props.userProfile.dashboard[0].MfgOtif);
    } else {
      this.props.getMfgOTIFList({ duration: '5W' });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.mfgOTIFList != null && prevProps.mfgOTIFList != this.props.mfgOTIFList) {
      this.setState({ mfgOTIFList: this.props.mfgOTIFList });
      this.getTotalMFGCount(this.props.mfgOTIFList);
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.handleFacilityDropDown();
    }
    if (this.props.userProfile != null && prevProps.userProfile != this.props.userProfile) {
      this.getTileDate();
    }
  }

  handleDropDownChange = (event, obj) => {
    this.setState({ 'location': event.value, 'locationName': event.label });
  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
    this.setState({
      location: null,
      locationName: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
    })
  }

  handleApiCall = () => {
    this.props.getMfgOTIFList(this.getSelectedRequestParams());
    this.refs.overlay.hide();
  }

  getSelectedRequestParams = () => {
    var tempParamas = {};
    const { duration, location, locationName, fromDate, toDate, customDate } = this.state;
    if (customDate) {
      tempParamas.fromDate = fromDate ? fromDate : '';
      tempParamas.toDate = toDate ? toDate : '';
    } else {
      tempParamas.duration = duration ? duration : "5W";
    }
    if (location) {
      tempParamas.location = location ? location : '';
      tempParamas.locationName = locationName ? locationName : '';
    }
  //  localStorage.setItem('MfgOtif', JSON.stringify(tempParamas));
  let obj = {};
    let mfgOtifObj = {};
    mfgOtifObj.MfgOtif = tempParamas;
    var dashboardObj = [];
    dashboardObj.push(mfgOtifObj);
    obj.dashboard = dashboardObj;
    this.props.setProfileDashboardDetails(obj);
    return tempParamas;
  }

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate
    }));
  };

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options })
  }

  handleFacilityDropDown = (event, obj) => {
    this.setState({
      facilityList: CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
        this.props.facilityList.Items), 'facilityId', 'facilityName')
    })
  }

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  getTotalMFGCount = (mfgOTIFList) => {
    var mfgOrderTotalCount = 0;
    var mfgOTIFTotalAvg = 0;
    if (mfgOTIFList != null) {
      for (var i = 0; i < mfgOTIFList.length; i++) {
        if (mfgOTIFList[i].totalAvg != null) {
          mfgOrderTotalCount = mfgOrderTotalCount + 1;
        }
        mfgOTIFTotalAvg = mfgOTIFTotalAvg +
          CommonUtil.isNaNValue(parseInt(mfgOTIFList[i].totalAvg));
      }
    }
    var avg = mfgOTIFTotalAvg / mfgOrderTotalCount;
    this.setState({ mfgOTIFTotalAvg: CommonUtil.isNaNValue(parseFloat(avg).toFixed()) });
  }

  render() {
    const { mfgOTIFList, duration } = this.state;
    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <p>Date</p>
                <div className="date-buttons">
                  <Button className={duration == "5W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '5W')}>Last 5 Week</Button>
                  <Button className={duration == "7W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '7W')}>Last 7 Week</Button>
                  <Button className={duration == "10W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '10W')}>Last 10 Week</Button>
                </div>
                {this.state.customDate && (
                  <div className="custom-date">
                    <FormGroup>
                      <ControlLabel> Custom Date </ControlLabel>
                      <Datetime id="startdate" inputProps={{ readOnly: true, placeholder: "From" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.fromDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'fromDate')} />
                      <Datetime id="enddate" inputProps={{ readOnly: true, placeholder: "To" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.toDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'toDate')} />
                    </FormGroup>
                  </div>
                )}
                <FormGroup>
                  <ControlLabel>
                    Location
                  </ControlLabel>
                  <Select classNamePrefix="react-select"
                    name="categorySelect"
                    value={{ "label": this.state.locationName }}
                    onChange={this.handleDropDownChange}
                    options={this.state.facilityList != null ?
                      [...this.state.allList, ...this.state.facilityList] : []}
                    placeholder="Select Location" />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );

    return (
      <Col md={4} sm={6}>
        <Card
          title="Manufacturing OTIF"
          category={"Average : " + (this.state.mfgOTIFTotalAvg != null ? this.state.mfgOTIFTotalAvg : 0)}
          content={
            <div className="graph">
              <ResponsiveBar
                data={mfgOTIFList != null ? mfgOTIFList : []}
                keys={['totalAvg']}
                indexBy="week"
                margin={{ top: 10, right: 10, bottom: 50, left: 40 }}
                padding={0.3}
                innerPadding={1}
                groupMode="grouped"
                colors={["#0086C0"]}
                minValue="auto"
                maxValue="auto"
                axisTop={null}
                axisRight={null}
                axisBottom={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Week Number',
                  legendPosition: 'middle',
                  legendOffset: 28
                }}
                axisLeft={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: '% Age of on time delivery',
                  legendPosition: 'middle',
                  legendOffset: -30,
                  tickValues: 7
                }}
                theme={{
                  fontSize: 8,
                  axis: {
                    "legend": {
                      "text": {
                        "fill": "#4988A6"
                      }
                    },
                    "domain": {
                      "line": {
                        "stroke": "#9AC7D7",
                        "strokeWidth": 1
                      }
                    },
                  },
                }}
                barComponent={props => (
                  <g transform={`translate(${props.x},${isNaN(props.y) ? 0 : props.y})`}>
                    <rect width={25} height={(isNaN(props.height) || props.height < 0) ? 0 : props.height} fill={props.color} x={(props.width / 2) - 12.5} />
                    <text
                      x={(props.width / 2)}
                      y={(isNaN(props.height) || props.height < 0) ? 0 : (props.height / 2)}
                      textAnchor="middle"
                      dominantBaseline="central"
                      fill="black"
                      style={{
                          fontWeight: 400,
                          fontSize: 10,
                      }}
                    >
                      <tspan y={-6}>{props.data.value > 0 ? props.data.value : ''}</tspan>
                    </text>
                  </g>
                )}
                gridYValues={[0, 20, 40, 60, 80, 100]}
                enableGridY={false}
                labelSkipWidth={0}
                labelSkipHeight={0}
                isInteractive={false}
                animate={false}
              />
              <div className="overlay-section">
                <OverlayTrigger ref="overlay" trigger="click" rootClose placement="left" overlay={popover}>
                  <i className="fa fa-ellipsis-v" />
                </OverlayTrigger>
              </div>
            </div>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    facilityList: state.facility.facilityList,
    mfgOTIFList: state.mfgOrder.mfgOTIFList,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getMfgOTIFList: selectedParams => dispatch(getMfgOTIFList(selectedParams)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProfileDashboardDetails: (dataDictionaryDetailsObj) => dispatch(setProfileDashboardDetails(dataDictionaryDetailsObj)),
});

export default connect(mapStateToProps, mapDispatchToProps)(MfgOTIF);
