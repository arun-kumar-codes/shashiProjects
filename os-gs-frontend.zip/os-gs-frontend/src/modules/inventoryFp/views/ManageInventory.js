import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, Tabs, Tab, FormGroup } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import * as inventoryConstant from '../constant/inventoryConstant';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import Select from "react-select";
import { getInventoryList, downLoadXLSFile, getInventorySearchList } from "../actions/inventoryActions";
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getProductList } from '../../productManagement/actions/productActions';
import * as commonConstant from '../../common/constant/commonConstant';
import { setActionMode } from "../../../actions/appActions";
import DetailModal from "./DetailModal.js";
import { getUserProfile } from "../../userManagement/actions/userActions";
import inventory from "assets/img/inventory-page-icon.svg";
import pin from "assets/img/pin.svg";
import download from "assets/img/download.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import isAuthorized from "auth-plugin";
import check from "assets/img/check.svg";
import brandicon from "assets/img/brand-icon.png";

class ManageInventory extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      inventoryCode: null,
      status: null,
      key: 1,
      location: 'all',
      selectedTab: "PRODUCT",
      additionalParams: null,
      openModal: false,
      uniqueCode: null,
      facilityList: [],
      allList: [{ label: 'All', value: 'all' }],
      search: null,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      fileUrl: '#',
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.getCompleteDetails = this.getCompleteDetails.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  componentDidMount = async () => {
    mixpanel.track("Manage Inventory loaded");
    let params = CommonUtil.getAdditonalPathParams(this);
    let location = CommonUtil.getAdditonalPathLocation(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getFacilityList();
    this.props.getProductList({});
    const { selectedTab } = this.state;
    if (CommonUtil.isNotNull(location)) {
      await this.props.getFacilityDetails(location);
    }
    if (params == "PRODUCT") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("PRODUCT");
      const { location, history } = this.props;
      history.replace();
    } else {
      await this.setSelectedTabDetails(selectedTab);
    }
  }

  setSelectedTabDetails = async (selectedTab) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    const managePageList = pagePropertyListConstant["MANAGE_" + selectedTab + "_INVENTORY_PAGE_LIST"](this);
    let additionalParams = { gross: selectedTab.toLowerCase() };
    additionalParams["location"] = this.state.location;
    const { search, brand } = this.state;
    if (search) {
      additionalParams["search"] = search;
    }
    if (brand) {
      additionalParams["brand"] = brand;
    }
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      searchInput: "",
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
      selectedTab: selectedTab,
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this));
  }

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim(),location: 'all', locationName: 'All',brand: ''  });
      this.setSelectedTabDetails(this.state.selectedTab);
      this.setState({ menuOpen: false, status: null });
    }
  }

  advanceBrand = async (event) => {
    console.log(event);
    PaginationUtil.initPaginationParams(this);
    await this.setState({ brand: event, location: 'all', locationName: 'All', search: '' });
    this.setSelectedTabDetails(this.state.selectedTab);
    this.setState({ menuOpen: false, status: null });
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleTabClick = async (label, event) => {
    PaginationUtil.initPaginationParams(this);
    var selectedTabKey = label.toUpperCase();
    await this.setState({
      tableDataList: [], nextClick: false,
      previousClick: false, nextClickDisable: true, previousClickDisable: true,
      pageSize: 1, currentPage: 1, lastEvaluatedKeyArray: [],
      search: null, searchInput: ""
    });
    this.setSelectedTabDetails(selectedTabKey);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.inventoryList != this.props.inventoryList && this.props.inventoryList != null) {
      PaginationUtil.handlePagination(this.props.inventoryList, this);
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      let tempObj = {};
      tempObj.value = this.props.facilityDetails.facilityId; tempObj.label = this.props.facilityDetails.facilityId + " | " + this.props.facilityDetails.facilityName;
      this.handleLocationDropdownChange(tempObj);
    }
    if (this.props.location.state != null && prevProps.location.key !== this.props.location.key) {
      this.setSelectedTabDetails(this.props.location.state)
      this.props.getFacilityDetails(this.props.location.location);
    }
  }

  updateFacilityDropDownList = () => {
    this.setState({
      facilityList: CommonUtil.getOptionsFromList(
        this.props.facilityList.Items, 'facilityId', 'facilityName')
    })
  }

  updateProductDropDownList = () => {
    this.setState({ productList: this.props.productList });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    const { searchInput, selectedTab } = this.state;
    if (searchInput) {
      if (selectedTab === "PRODUCT") {
        const filteredData = this.props.inventoryList.Items.filter((value) => {
          return (
            value.productName.toLowerCase().includes(searchInput.toLowerCase()) ||
            value.stockId.toLowerCase().includes(searchInput.toLowerCase())
          );
        });
        this.setState({ tableDataList: filteredData })
      } else if (selectedTab === "LOT") {
        const filteredData = this.props.inventoryList.Items.filter((value) => value.lotNumber && value.lotNumber.toLowerCase().includes(searchInput.toLowerCase()));
        this.setState({ tableDataList: filteredData })
      }
    } else {
      this.setState({ tableDataList: this.props.inventoryList.Items });
    }

  }

  handleFIlter = async (event) => {
    this.state.location = event;
    this.setState({ location: event });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ location: tempObj.value, locationName: tempObj.label });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handleExportFileDownLoad = () => {
    this.props.downLoadXLSFile({ "tab": this.state.selectedTab.toLowerCase() });
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == inventoryConstant.STOCK_TRANSFER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(inventoryConstant.STOCK_TRANSFER_PAGE_URL, this);
    }

    if (tempId[2] == inventoryConstant.STOCK_ADJUSTMENT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(inventoryConstant.STOCK_ADJUSTMENT_PAGE_URL, this);
    }

    if (tempId[2] == inventoryConstant.STOCK_KIT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(inventoryConstant.STOCK_KIT_PAGE_URL, this);
    }
  }

  makeCustomAPICall = (tempParamas) => {
    if (CommonUtil.isNotNull(tempParamas.search) ||CommonUtil.isNotNull(tempParamas.brand)) {
      this.props.getInventorySearchList(tempParamas);
    } else {
      this.props.getInventoryList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (tempId != null && tempId[1] == inventoryConstant.MENU_ACTION_MODE) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  getCompleteDetails = (completeDetails) => {
    this.setState({ openModal: false });
  }

  handleModalopenButtonClick = (event, that) => {
    var tempId = event.target && event.target.id.split("_");
    this.setState({ openModal: true, uniqueCode: tempId[0], stockType: tempId[2] });
  }

  openModalWindow = (stockId, stockType) => {
    this.setState({ openModal: true, uniqueCode: stockId, stockType: stockType });
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      await this.setState({ search: null, status: null, lastEvaluatedKeyArray: [], searchInput: "", brand: "" });
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, fileUrl, selectedTab, search, brand } = this.state;
    const searchInputPlaceHolder = selectedTab === "PRODUCT" ? "Search By Code/Name" : "Search By Lot Number";
    const brandList = this.props.dataDictionaryList ? this.props.dataDictionaryList.dataDictionaryList.brandList : [];
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={inventory} alt="" className="page-icon" />
                  {inventoryConstant.MANAGE_INVENTORY_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder={searchInputPlaceHolder}
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {selectedTab !== "PRODUCT" ?
                  <Nav pullRight>
                    <NavDropdown title={<div className="filter"><img src={brandicon} alt="" style={{width:'20px'}}/></div>}
                      noCaret id="status-filter"  onSelect={this.advanceBrand} className="filter-status">
                        {brandList.map((tempAttributeListObj, index) => (
                        <MenuItem key={index} eventKey={tempAttributeListObj.label}>
                          {(tempAttributeListObj.label)}
                        </MenuItem>
                      ))}
                    </NavDropdown>
                  </Nav>:null
                  }
                  <div className="btn-fill btn-wd btn btn-default create-options create-dropdown" >
                    <div className="items">
                      <Nav pullRight>
                        <NavDropdown id="create-stock" title={<div>{" "}<i className="fa fa-ellipsis-v" />{" "}</div>}
                          noCaret >
                          {isAuthorized("createStockTransfer") &&
                            <MenuItem id={"inventoryCode" + "_" + inventoryConstant.MENU_ACTION_MODE +
                              "_" + inventoryConstant.STOCK_TRANSFER}
                              onClick={this.handleMenuPopupAction.bind(this)}>
                              Stock Transfer
                            </MenuItem>
                          }
                        </NavDropdown>
                      </Nav>
                    </div>
                  </div>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {(search  || brand) ?
                      <div className="showfilter">
                        Search / Filter by:
                        {(search || brand) ?
                          <div className="filtertag">{search ? search : brand} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    <Tabs id="inventory-tabs" className="table-tabs-without-border" onSelect={this.handleTabClick}>
                      <Tab eventKey={'Product'} title="PRODUCTS">
                        {tableColumnList != null ?
                          <Row className="stockTable">
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                          </Row>
                          : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                        <FormGroup className="location-dropdown">
                          <div className="export-btn" onClick={this.handleExportFileDownLoad}>
                            <a href={fileUrl} ref="downloadxlsx" download style={{ display: 'none' }}></a>
                            <img src={download} alt="" /> Export
                          </div>
                          <div className="location-control">
                            <img src={pin} alt="" />
                            <div title={this.state.locationName} >
                              <Select
                                classNamePrefix="react-select"
                                name="location"
                                placeholder="Location"
                                value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                                onChange={(value) => this.handleLocationDropdownChange(value)}
                                options={[...this.state.allList, ...this.state.facilityList]} />
                            </div>
                          </div>
                        </FormGroup>
                      </Tab>
                      <Tab eventKey={'LOT'} title="LOT/PALLET">
                        {tableColumnList != null ?
                          <Row className="stockTable">
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                          </Row>
                          : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>
                        }
                        <FormGroup className="location-dropdown">
                          <div className="export-btn" onClick={this.handleExportFileDownLoad}>
                            <a href={fileUrl} ref="downloadxlsx" download style={{ display: 'none' }}></a>
                            <img src={download} alt="" /> Export
                          </div>
                          <div className="location-control">
                            <img src={pin} alt="" />
                            <div title={this.state.locationName} >
                              <Select
                                classNamePrefix="react-select"
                                name="location"
                                placeholder="Location"
                                value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                                onChange={(value) => this.handleLocationDropdownChange(value)}
                                options={[...this.state.allList, ...this.state.facilityList]} />
                            </div>
                          </div>
                        </FormGroup>
                      </Tab>

                    </Tabs>
                    {this.state.openModal == true ?
                      <DetailModal
                        attributeObj={this.state.attributeObj}
                        uniqueCode={this.state.uniqueCode}
                        location={this.state.location}
                        stockType={this.state.stockType}
                        getCompleteDetails={this.getCompleteDetails}
                      >
                      </DetailModal>
                      : null}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    inventoryList: state.inventory.inventoryList,
    facilityList: state.facility.facilityList,
    productList: state.product.productList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    userProfile: state.user.userProfile,
    facilityDetails: state.facility.facilityDetails,
    inventorySearchList: state.inventory.inventorySearchList,
    currencyCode: state.dataDictionary.currencyCode,
  };
}

const mapDispatchToProps = dispatch => ({
  getInventoryList: params => dispatch(getInventoryList(params)),
  getInventorySearchList: params => dispatch(getInventorySearchList(params)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  downLoadXLSFile: (params) => dispatch(downLoadXLSFile(params)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getFacilityDetails: selectedFacilityCode => dispatch(getFacilityDetails(selectedFacilityCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageInventory);
