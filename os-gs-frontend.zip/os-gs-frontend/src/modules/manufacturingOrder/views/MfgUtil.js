import * as statusConstant from '../../common/constant/statusConstant';
import CommonUtil from '../../common/util/commonUtil';
import * as mfgOrderConstant from '../../manufacturingOrder/constant/mfgOrderConstant';
import PopupUtil from '../../common/util/popupUtil';
import * as _ from "lodash";
const MfgUtil = {
    handleButtonStatusChange: function (event, that) {
        const { name, id } = event.target;
        if (CommonUtil.isCreateOrCloneMode(that.props.actionMode)) {
            return;
        } else if (id == statusConstant.COMPLETED_STATUS) {
            // this.handleSubButtonStatusChange(that, id);
            const { itemList } = that.state;
            for (var j = 0; j < that.props.attributeObj.itemList.length; j++) {
                itemList[j].issueQuantity = itemList[j].totalQuantity;
            }
            that.setState({ itemList: [...itemList] });
        } else if (id == statusConstant.NEW_STATUS && !this.isValidNotStartedStatusChange(that)) {
            return;
        } else if (id == statusConstant.IN_PROGRESS_STATUS || id == statusConstant.BLOCKED_STATUS) {
            if (!this.isValidInProgressStatusChange(that)) {
                return;
            }
        }
        CommonUtil.handleButtonStatusChange(event, that);
    },
    doneStatusPopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareDoneStatusPopUpConfig(popupActionButton, mfgOrderConstant.MODULE_NAME);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    alteastAddOneRowPopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.withOutRowValidationPopUpConfig(popupActionButton,
            mfgOrderConstant.ING_OPT_VALIDATION_MSG);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    checkIngredientPurchasePrice: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.withOutRowValidationPopUpConfig(popupActionButton,
            mfgOrderConstant.ING_PRICE_VALIDATION_MSG);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    checkValidIngredientStatus: function (arrayList, that) {
        const { inactiveIngredientList } = that.props;
        let tempInactiveIngList = [];
        if (inactiveIngredientList && inactiveIngredientList.length > 0) {
            for (let i = 0; i < arrayList.length; i++) {
                let filteredList = inactiveIngredientList.filter(function (tempObj) {
                    return tempObj.productId == arrayList[i].productId;
                });
                if (filteredList.length > 0) {
                    tempInactiveIngList.push(filteredList[0].productId);
                }
            }
            if (tempInactiveIngList && tempInactiveIngList.length > 0) {
                this.inActivePopup(that, tempInactiveIngList);
                return false;
            }
        }
        return true;
    },
    inActivePopup: function (that, tempInactiveIngList) {
        let popupActionButton = {};
        popupActionButton.onConfirmClick = that.handleInactiveIngConfirmation;
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton,
            mfgOrderConstant.INVACTIVE_ING_MSG.replace("ING-LIST", tempInactiveIngList.toString()), true);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    updateLocationResorceList: function (that, value) {
        let selectedData = CommonUtil.getFilteredObjFromArray(
            that.props.facilityList, 'facilityId', value);
        that.setState({
            attributeList: CommonUtil.setDropDownOptionsInAttribute(that.state.attributeList,
                CommonUtil.getOptionsFromList(selectedData.resources, 'resourceCode',
                    'resourceName'), 'locationResource')
        });
    },
    handleDeleteDraftPopup(event, that) {
        that.setState({ draftId: event.target.id });
        let popupActionButton = {};
        popupActionButton.onConfirmClick = that.handleDeleteDraftAction;
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    handleSubButtonStatusChange: function (that, orderStatus) {
        const operationsList = [...that.state.operationsList];
        if (CommonUtil.isNotNull(operationsList)) {
            for (var j = 0; j < operationsList.length; j++) {
                if (operationsList[j].status !== statusConstant.COMPLETED_STATUS) {
                    operationsList[j].status = orderStatus;
                }
            }
        }
        that.setState({ operationsList: operationsList });
    },
    handleOperationStatusChange: function (event, processKey, that) {
        if (CommonUtil.isCreateOrCloneMode(that.props.actionMode)) {
            return;
        }
        const { name, id } = event.target;
        var statusKey = id.split("_")[0];
        if (CommonUtil.isBothEqual(statusKey, statusConstant.COMPLETED_STATUS)) {
            that.setState({ openModal: true, processKey: processKey });
        }
        const { attributeObj } = that.state;
        attributeObj.status = statusConstant.IN_PROGRESS_STATUS;
        that.setState({ attributeObj: attributeObj });
    },
    isValidDoneStatusChange: function (that) {
        let isValidDoneStatus = true;
        if (CommonUtil.isNotNull(that.state.itemList) && that.state.itemList.length > 0) {
            for (let i = 0; i < that.state.itemList.length; i++) {
                let tempValue = this.getLeftQuantity(that.state.itemList[i]);
                if (tempValue > 0) {
                    isValidDoneStatus = false;
                    break;
                }
            }
        }
        else {
            isValidDoneStatus = false;
        }
        return isValidDoneStatus;
    },
    isValidNotStartedStatusChange: function (that) {
        let ingredientList = that.state.itemList && that.state.itemList.filter(value => {
            return (value.issueQuantity > 0 || value.materialStatus == true)
        });
        if (CommonUtil.isNotNull(ingredientList) && ingredientList.length > 0) {
            return false;
        }
        let operationList = that.state.operationsList && that.state.operationsList.filter(value => {
            return (value.status !== statusConstant.NEW_STATUS)
        });
        if (CommonUtil.isNotNull(operationList) && operationList.length > 0) {
            return false;
        }
        return true;
    },
    isValidInProgressStatusChange: function (that) {
        let ingredientList = that.state.itemList && that.state.itemList.filter(value => {
            return (value.issueQuantity > 0 || value.issuedQuantity > 0)
        });
        if (CommonUtil.isNotNull(ingredientList) && ingredientList.length > 0) {
            return false;
        }
        return true;
    },
    getLeftQuantity: function (tempObj) {
        return CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempObj.totalQuantity) -
            CommonUtil.getFloatValue(tempObj.issuedQuantity) -
            CommonUtil.getFloatValue(tempObj.issueQuantity), 2);
    },
    handleTableDocumentClick: function (event, that, documentCount) {
        event.preventDefault();
        if (CommonUtil.getFloatValue(documentCount) == 0) {
            return;
        }
        var eventId = event.target && event.target.id.split("_");
        var params = {}
        params.uniqueCode = eventId[0];
        params.orderCode = eventId[1];
        CommonUtil.handlePageRedirection(mfgOrderConstant.MANAGE_DOCUMENT_PAGE_URL, that, params);
    },
    handleTableUploadButtonClick: function (event, that) {
        let processKey = event.target && event.target.id.split("_")[0];
        that.setState({ openModal: true, processKey: processKey });
    },
    getDocumentCount: function (documentList) {
        if (documentList != null) {
            return documentList.length;
        }
        return 0;
    },
    handleUploadDocumentDetails: function (uploadDocumentObj, that) {
        let { attributeObj } = that.state;
        attributeObj.documentList = uploadDocumentObj.documentList;
        that.setState({ attributeObj: attributeObj });
    },
    isDoneStatus: function (that) {
        if (that.state && that.state.attributeObj && that.state.attributeObj.status) {
            return that.state.attributeObj.status == statusConstant.COMPLETED_STATUS ? true : false;
        }
        return false;
    },
    handleOperationQCDetails: function (operationQCList, that) {
        const { operationsList } = that.state;
        for (var j = 0; j < that.state.operationsList.length; j++) {
            if (CommonUtil.isBothEqual(operationQCList.operationId, operationsList[j].operationId)) {
                operationsList[j].documentList = operationQCList.documentList;
            }
        }
        that.setState({ operationsList: [...operationsList] })
    },
    getSelectedOperationDetails: function (operationsList, processKey) {
        let selectedEntityObj = "";
        let attributeDataList = [...operationsList];
        attributeDataList && attributeDataList.filter((value) => {
            if ((value.operationId && String(value.operationId).toLowerCase().indexOf(processKey &&
                String(processKey).toLowerCase()) !== -1)) {
                selectedEntityObj = value;
            }
        });
        return selectedEntityObj
    },
    getSelectedIngredientDetails: function (itemList, productId) {
        let selectedEntityObj = "";
        let attributeDataList = [...itemList];
        attributeDataList && attributeDataList.filter((value) => {
            if ((value.productId && String(value.productId).toLowerCase().indexOf(productId &&
                String(productId).toLowerCase()) !== -1)) {
                selectedEntityObj = value;
            }
        });
        return selectedEntityObj
    },
    handleSelectedIngDetails: function (tempObj, that) {
        const { itemList } = that.state;
        for (var j = 0; j < that.state.itemList.length; j++) {
            if (CommonUtil.isBothEqual(tempObj.productId, itemList[j].productId)) {
                let oldSelectedIngList = [];
                oldSelectedIngList = that.props.attributeObj.itemList[j].selectedIngList ?
                    that.props.attributeObj.itemList[j].selectedIngList : [];
                itemList[j].issueQuantity = this.getSelectedIngTotal([...tempObj.selectedIngList]);
                itemList[j].selectedIngList = [...tempObj.selectedIngList, ...oldSelectedIngList];
            }
        }
        that.setState({ itemList: [...itemList] })
    },
    updateDragDropPriority: function (that, updatedTableDataList, facilityId) {
        let selectedPriorityObj = CommonUtil.getFilteredObjFromArray(
            that.props.mfgOrderPriorityDetails.priorityList, 'location', facilityId);
        let mfgList = JSON.parse(JSON.stringify(selectedPriorityObj.mfgList));
        const { mfgOrderPriorityDetails } = that.props;
        if (!CommonUtil.isNullArray(mfgList)) {
            let page = that.state.currentPage;
            let limit = that.state.tableConfig.defaultPageSize;
            let pageIndex = parseInt(page) - 1;
            pageIndex = pageIndex * limit;

            for (let i = 0; i < updatedTableDataList.length; i++) {
                for (let j = 0; j < mfgList.length; j++) {
                    if (mfgList[j].orderCode == updatedTableDataList[i].mfgOrderId) {
                        mfgList[j].priority = pageIndex + i + 1;
                        break;
                    }
                }
            }
        }
        for (let i = 0; i < mfgOrderPriorityDetails.priorityList.length; i++) {
            if (mfgOrderPriorityDetails.priorityList[i].location == facilityId) {
                mfgOrderPriorityDetails.priorityList[i].mfgList = mfgList;
            }
        }
        return mfgOrderPriorityDetails.priorityList;
    },
    updateSelectedIngDetails: async function (that, selectedIngredientCode) {
        const { itemList } = that.state;
        for (let j = 0; j < that.state.itemList.length; j++) {
            if (CommonUtil.isBothEqual(that.state.itemList[j].productId, selectedIngredientCode)) {
                itemList[j].selectedIngList = [];
                itemList[j].issueQuantity = 0;
                let selectedIngObj = CommonUtil.getFilteredObjFromArray(that.props.attributeObj.itemList,
                    'productId', selectedIngredientCode);
                itemList[j].selectedIngList = selectedIngObj.selectedIngList ?
                    selectedIngObj.selectedIngList : [];
            }
        }
        await that.setState({ itemList: [...itemList] })
    },
    getSelectedIngTotal: function (selectedIngList) {
        var tempTotalQuantity = 0;
        for (var i = 0; i < selectedIngList.length; i++) {
            tempTotalQuantity = CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempTotalQuantity) +
                CommonUtil.getFloatValue(selectedIngList[i].selectedQuantity), 2);
        }
        return tempTotalQuantity;
    },
    getSelectedListCount: function (arrayList) {
        if (arrayList != null && arrayList.length > 0) {
            return arrayList.length;
        }
        return 0;
    },
    // isNewIngRowAdded: function (that, productId, productId) {
    //     if (CommonUtil.isNotNull(productId)) {
    //         let tempArrayList = that.props.productList && that.props.productList;
    //         if (CommonUtil.isNotNull(tempArrayList)) {
    //             let tempFilteredArrayList = tempArrayList.filter(value => {
    //                 return (value.productId == productId)
    //             })
    //             let tempIngFilteredArrayList = tempFilteredArrayList &&
    //                 tempFilteredArrayList.filter(value => {
    //                     return (value.productId == productId)
    //                 })
    //             if (tempIngFilteredArrayList) {
    //                 return false;
    //             }
    //         }
    //     }
    //     return true;
    // },

    isNewOptRowAdded: function (that, productId, operationId) {
        if (CommonUtil.isNotNull(productId)) {
            let tempArrayList = that.props.productList && that.props.productList;
            if (CommonUtil.isNotNull(tempArrayList)) {
                let tempFilteredArrayList = tempArrayList.filter(value => {
                    return (value.productId == productId)
                })
                let tempIngFilteredArrayList = tempFilteredArrayList && tempFilteredArrayList[0] && tempFilteredArrayList[0].operationsList &&
                    tempFilteredArrayList[0].operationsList.length > 0 && tempFilteredArrayList[0].operationsList.filter(value => {
                        return (value.operationId == operationId)
                    })
                if (tempIngFilteredArrayList && tempIngFilteredArrayList[0]) {
                    return false;
                }
            }
        }
        return true;
    },
    validateSelectedQuantity: function (tempObj) {
        var tempValue = 0;
        var tempSelectedQuantity = CommonUtil.getFloatValue(tempObj.selectedQuantity, 2);
        var tempReceivedQuantity = CommonUtil.getFloatValue(tempObj.remainingstock, 2);
        if (tempReceivedQuantity > tempSelectedQuantity) {
            tempValue = tempSelectedQuantity;
        }
        else {
            tempValue = tempReceivedQuantity < 0 ? 0 : tempReceivedQuantity;
        }
        return tempValue;
    },
    getAvailabilityStatus: function (status) {
        var statusSequence = 0;
        switch (status) {
            case statusConstant.IN_STOCK_STATUS:
                statusSequence = 1;
                break;
            case statusConstant.NOT_AVAILABLE_STATUS:
                statusSequence = 0;
                break;
            default:
                statusSequence = 0;
        }
        return statusSequence;
    },
    getMaterialStatus: function (tempIngObj) {
        if (CommonUtil.isNotNull(tempIngObj)) {
            let issueQuantity = CommonUtil.getFloatValue(tempIngObj.issueQuantity, 2);
            return issueQuantity > 0 || tempIngObj.materialStatus ? true : false;
        }
        return false;
    },
    getLeastOrderStockStatus: function (that, mfgOrderId, facilityId) {
        const { mfgOrderPriorityDetails } = that.state;
        if (CommonUtil.isNotNull(mfgOrderPriorityDetails)) {
            let selectedPriorityObj = CommonUtil.getFilteredObjFromArray(
                mfgOrderPriorityDetails.priorityList, 'location', facilityId);
            let tempPriorityObj = selectedPriorityObj && selectedPriorityObj.mfgList.filter(value => {
                return (value.orderCode == mfgOrderId)
            });
            return tempPriorityObj && tempPriorityObj[0] && tempPriorityObj[0].availability;
        }
        return null;
    },
    getIngredientOrderStockStatus: function (that, productId, facilityId) {
        if (CommonUtil.isCreateOrCloneMode(that.props.actionMode)) {
            return null;
        }
        if (CommonUtil.isViewMode(that.props.actionMode)) {
            return statusConstant.IN_STOCK_STATUS;
        }
        const { mfgOrderPriorityDetails } = that.state;
        if (CommonUtil.isNotNull(mfgOrderPriorityDetails)) {
            let selectedPriorityObj = CommonUtil.getFilteredObjFromArray(
                mfgOrderPriorityDetails.priorityList, 'location', facilityId);

            let tempPriorityObj = selectedPriorityObj && selectedPriorityObj.mfgList.filter(value => {
                return (value.orderCode == that.props.selectedMfgOrderCode)
            });
            if (productId && tempPriorityObj) {
                let tempIngPriorityObj = tempPriorityObj && tempPriorityObj[0].itemList.filter(value => {
                    return (value.productId == productId)
                });
                return tempIngPriorityObj && tempIngPriorityObj[0] && tempIngPriorityObj[0].availability;
            }
        }
    },
    getOrderPriority: function (that, mfgOrderId, facilityId) {
        const { mfgOrderPriorityDetails } = that.state;
        if (CommonUtil.isNotNull(mfgOrderPriorityDetails)) {
            let selectedPriorityObj = CommonUtil.getFilteredObjFromArray(
                mfgOrderPriorityDetails.priorityList, 'location', facilityId);
            let tempPriorityObj = selectedPriorityObj && selectedPriorityObj.mfgList.filter(value => {
                return (value.orderCode == mfgOrderId)
            });
            return tempPriorityObj && tempPriorityObj[0] && tempPriorityObj[0].priority;
        }
        return null;
    },
    updateTableDataList: function (that) {
        let tableDataList = that.state.tableDataList;
        for (let i = 0; i < tableDataList.length; i++) {
            tableDataList[i].priority = this.getOrderPriority(that, tableDataList[i].mfgOrderId, that.state.location);
        }
        return tableDataList;
    },
    setPriorityStatus: function (that) {
        const { ingredientGrossList, mfgOrderPriorityDetails } = that.state;

        if (!CommonUtil.isNullArray(ingredientGrossList) && !CommonUtil.isNullArray(mfgOrderPriorityDetails)) {
            let tempIngredientGrossList = JSON.parse(JSON.stringify(ingredientGrossList));
            let tempMfgOrderPriorityDetails = { ...mfgOrderPriorityDetails };

            for (let k = 0; k < tempMfgOrderPriorityDetails.priorityList.length; k++) {
                let mfgList = JSON.parse(JSON.stringify(tempMfgOrderPriorityDetails.priorityList[k].mfgList));
                mfgList = _.sortBy(mfgList, 'priority');
                let facilityId = tempMfgOrderPriorityDetails.priorityList[k].location;

                if (!CommonUtil.isNullArray(mfgList)) {
                    for (let i = 0; i < mfgList.length; i++) {
                        let stockStatus = 1;
                        if (CommonUtil.isNotNull(mfgList[i].itemList)) {
                            for (let j = 0; j < mfgList[i].itemList.length; j++) {
                                let tempIngObj = tempIngredientGrossList && tempIngredientGrossList.filter(value => {
                                    return (value.location == mfgList[i].location &&
                                        value.productId == mfgList[i].itemList[j].productId)
                                });
                                if (CommonUtil.isNullValue(tempIngObj) || tempIngObj.length == 0) {
                                    return;
                                }
                                let tempIndex = tempIngredientGrossList.findIndex(value => value.productId
                                    == mfgList[i].itemList[j].productId &&
                                    value.location == mfgList[i].location);

                                let tempQuantity = CommonUtil.getFloatValue(CommonUtil.getFloatValue(mfgList[i].itemList[j].quantity) -
                                    CommonUtil.getFloatValue(mfgList[i].itemList[j].issuedQuantity), 2);
                                let tempStock = CommonUtil.getFloatValue(tempIngObj[0].stock, 2);

                                if (tempQuantity <= tempStock) {
                                    tempIngredientGrossList[tempIndex].stock = tempStock - tempQuantity;
                                    mfgList[i].itemList[j].availability = statusConstant.IN_STOCK_STATUS;
                                }
                                else {
                                    mfgList[i].itemList[j].availability = statusConstant.NOT_AVAILABLE_STATUS;
                                }
                                let currentStatus = this.getAvailabilityStatus(mfgList[i].itemList[j].availability);
                                if (stockStatus > currentStatus) {
                                    stockStatus = currentStatus;
                                }
                            }
                            if (stockStatus) {
                                mfgList[i].availability = statusConstant.IN_STOCK_STATUS;
                            } else {
                                mfgList[i].availability = statusConstant.NOT_AVAILABLE_STATUS;
                            }
                        }
                    }
                    for (let i = 0; i < tempMfgOrderPriorityDetails.priorityList.length; i++) {
                        if (tempMfgOrderPriorityDetails.priorityList[i].location == facilityId) {
                            tempMfgOrderPriorityDetails.priorityList[i].mfgList = mfgList;
                        }
                    }
                }
            }
            that.setState({ mfgOrderPriorityDetails: tempMfgOrderPriorityDetails })
        }
    },
}

export default MfgUtil;