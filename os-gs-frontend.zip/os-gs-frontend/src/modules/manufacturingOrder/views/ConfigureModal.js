import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import DragDrop from "../../../components/DragDrop/DragDrop.jsx";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import CheckBoxUtil from '../../common/util/checkBoxUtil';
import PopupUtil from "../../common/util/popupUtil";
import MfgUtil from "./MfgUtil.js";
var Modal = require('react-bootstrap-modal')

class ConfigureModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataKey: "tableDataList",
      tableDataList: [],
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    const commonAttributeList = pagePropertyListConstant.CREATE_CONFIGURE_DEADLINE;
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  closeModal = (event) => {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    this.props.getCompleteDetails(true);
    this.setState({ submitted: true, openModal: false });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }


  render() {
    const { attributeList, attributeObj, submitted } = this.state;
    console.log(attributeList, attributeObj)
    return (
      <div>
        <Modal show={this.state.openModal}
          onHide={this.closeModal} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Manufacturing Configrution</div>
              <div className="subsection">
                <div className="model-subheading"></div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12} className="config-deadline">
                    <Card
                      plain
                      content={
                        <Row>
                          {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                            tempAttributeListObj.type == "CHECKBOX" ?
                              <div className="product-checkbox check">
                                {CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)}
                              </div>

                              : tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)

                                : tempAttributeListObj.type == "DROPDOWN" ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this)

                                  : null))
                          }
                      </Row>
                      }
                    />
                  </Col>
                </Row>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        ftTextRight
                        legend={
                          CommonUtil.isViewMode(this.props.actionMode) ?
                            <div>
                              <Button className="btn-cancel" onClick={this.closeModal}>
                                Reset
                              </Button>
                            </div>
                          : <div>
                              <Button className="btn-cancel" onClick={this.closeModal}>
                                Reset
                              </Button>

                              <Button className="btn-save btn-fill btn-wd" onClick={this.handleSave}>
                                Configure
                              </Button>
                            </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>

              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ConfigureModal);
