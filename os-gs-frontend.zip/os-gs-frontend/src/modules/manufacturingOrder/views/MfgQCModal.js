import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import DragDrop from "../../../components/DragDrop/DragDrop.jsx";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil.js";
import PopupUtil from "../../common/util/popupUtil";
import MfgUtil from "./MfgUtil.js";
var Modal = require('react-bootstrap-modal')

class MfgQCModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataKey: "tableDataList",
      tableDataList: [],
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  handleTableDateChange = (event, eventId) => {
    PopularTableUtil.handleTableDateChange(event, eventId, this, this.getSelectedTablekey());
  };

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleTableButtonMenuAction = (event) => {
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };

  componentDidMount = () => {
    this.setState({ openModal: true });
    this.setSelectedTableDetails(this.state.selectedTab);
  };

  setSelectedTableDetails = (selectedTab) => {
    var selectedOperationDetails = MfgUtil.getSelectedOperationDetails(
      [...this.props.attributeObj.operationsList], this.props.processKey)

    let tableDataList = this.state.tableDataList;
    tableDataList.documentList = selectedOperationDetails.documentList;
    const tableAttributeList = pagePropertyListConstant.CREATE_MFG_DOCUMENT_MODAL_TABLE_LIST;
    this.setState({
      tableDataList: tableDataList,
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  closeModal = (event) => {
    this.props.getOperationQCDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    this.setState({ submitted: true });
    var tempObj = {}
    tempObj.process = this.props.processKey;
    tempObj.documentList = this.state.attributeObj && this.state.attributeObj.documentList ?
    this.state.attributeObj.documentList : null;
    if (CommonUtil.isNotNull(tempObj.documentList) && tempObj.documentList.length > 0) {
      let openFlag = false;
      for (var i=0; i<tempObj.documentList.length; i++) {
        if(CommonUtil.isNotNull(tempObj.documentList[i].documentType) && CommonUtil.isNotNull(tempObj.documentList[i].documentName) && tempObj.documentList[i].documentName.length > 2) {
          openFlag = true;
        } else {
          openFlag = false;
        }  
      }
      if (openFlag == true) {
        this.setState({ openModal: false, });
        this.props.getOperationQCDetails(tempObj);
      } else {
        this.setState({ openModal: true, });
      }
    } else {
      this.setState({ openModal: false, });
      this.props.getOperationQCDetails(tempObj);
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getOperationQCDetails(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  getDocumentDetails = (documentList) => {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        documentList: [...documentList]
      }
    })
  }

  render() {
    const { tableColumnList, tableDataList, attributeObj } = this.state;
    const actionMode = this.props.actionMode;
    return (
      <div>
        <Modal show={this.state.openModal}
          onHide={this.closeModal} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Upload QC & Process documentList</div>
              <div className="subsection">
                <div className="model-subheading"></div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <Card
                      plain
                      title="documentList"
                      content={
                        <DragDrop
                          minSize={0}
                          maxSize={5000000}
                          multiple={false}
                          disabled={CommonUtil.isViewMode(actionMode) ? true : false}
                          errormsg="File size exceed max size limit of 5 MB."
                          typeerror="File type is not accepted"
                          attributeList={tableColumnList}
                          getdocumentdetails={this.getDocumentDetails}
                          files={tableDataList != null && tableDataList.documentList &&
                            tableDataList.documentList.length > 0 ?
                            tableDataList.documentList : null}
                          fileNamePrefix={attributeObj != null && attributeObj.facilityId}
                          moduleName="manufacturingOrder"
                        />
                      }
                    />
                  </Col>
                </Row>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        ftTextRight
                        legend={
                          CommonUtil.isViewMode(this.props.actionMode) ?
                            <div>
                              <Button className="btn-cancel" onClick={this.closeModal}>
                                Cancel
                              </Button>
                            </div>
                          : <div>
                              <Button className="btn-cancel" onClick={this.closeModal}>
                                Cancel
                              </Button>

                              <Button className="btn-save btn-fill btn-wd" onClick={this.handleSave}>
                                Save
                              </Button>
                            </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>

              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MfgQCModal);
