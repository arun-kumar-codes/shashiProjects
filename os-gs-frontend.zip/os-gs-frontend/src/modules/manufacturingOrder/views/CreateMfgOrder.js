import React, { Component } from "react";
import { Grid, Row, Col, Nav, NavDropdown, MenuItem, Tabs, Tab } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import {
  setMfgOrderDetails, getMfgOrderDetails, setReducerInitMode,
  updateMfgOrderDeleteStatus, getPriorityDetails, getMFGBatchDetails, downloadInvoice
} from "../actions/mfgOrderActions";
import { getProductList, getProductDetails, getProductGrossList, getProductDetailList } from '../../productManagement/actions/productActions';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as mfgOrderConstant from '../constant/mfgOrderConstant';
import { getIngredientList, getInactiveIngredientList, getIngredientDetails } from "../../ingredientManagement/actions/ingredientActions";
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import { getOperationDetails, getOperationList } from "../../operation/actions/operationActions";
import { setActionMode } from "../../../actions/appActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopularTableUtil from '../../common/util/popularTableUtil';
import PopupUtil from '../../common/util/popupUtil';
import LabelUtil from "modules/common/util/labelUtil";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DateUtil from '../../common/util/dateUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import MfgUtil from './MfgUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import MfgQCModal from "./MfgQCModal.js";
import IngSelectModal from "./IngSelectModal.js";
import isAuthorized from "auth-plugin";
import make from "assets/img/make-page-icon.svg";
import StockViewModal from "./StockViewModal.js";
import mixpanel from "../../analytics/mixpanel/mixpael";
import currencyIcon from '../../common/util/currencyIcon';
import _, { at } from 'lodash';
import moment from "moment";
import documentmangment from "assets/img/Document-Mangment-1.svg";
import DocumentUploadModal from './DocumentUploadModal';
import NavigationPrompt from "react-router-navigation-prompt";
import SweetAlert from "react-bootstrap-sweetalert";

class CreateMfgOrder extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      openModal: false,
      isInactiveIngValidationDone: false,
      openIngSelectModal: false,
      selectedIngredientCode: null,
      ingredientGrossList: [],
      mfgOrderPriorityDetails: null,
      customErrorFlag: false,
      openStockViewModal: false,
      saveBtnDisable: false,
      alert: null,

      itemList: [],
      operationsList: [],
      operationQCList: [],
      selectedTab: "INGREDIENT",
      ingredientTableKey: "itemList",
      operationTableKey: "operationsList",
      openDocumentModal: false,
      formDirty: false,
    };
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Create Mfg order loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getMfgOrderDetails(this.props.selectedMfgOrderCode);
      }
    } else {
      CommonUtil.handlePageRedirection(mfgOrderConstant.MANAGE_MFG_ORDER_PAGE_LIST, this);
    }
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({searchInput : searchInput ? searchInput : ''})
    // this.props.getInactiveIngredientList({ status: 'inactive' });
    // this.props.getOperationDetails();
    this.props.getIngredientList({ isDropdown: true, isIngredient: true });
    this.props.getOperationList();
    this.props.getProductList({ isDropdown: true, source: 'make' });
    this.props.getFacilityList({ isDropdown: true, source: 'make' });
    // this.props.getProductGrossList({ isDropdown: true });
    // this.props.getPriorityDetails();
    this.setSelectedTableDetails(this.state.selectedTab);
    const commonAttributeList = pagePropertyListConstant.CREATE_MFG_ORDER_PAGE_LIST(this);
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj
    });
  }

  setSelectedTableDetails = async (selectedTab) => {
    const tableAttributeList = pagePropertyListConstant["CREATE_MFG_" +
      selectedTab.toUpperCase() + "_TABLE_LIST"](this);
    let tableColumnList = [];
    if (CommonUtil.isViewMode(this.props.actionMode)) {
      tableColumnList = CommonUtil.removeObjFromArray(tableAttributeList.tableColumnList, 'name', 'availability');
    } else {
      tableColumnList = tableAttributeList.tableColumnList;
    }

    await this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.attributeList, this.props.dataDictionaryList),
      tableColumnList: tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    })
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  getSelectedTablekey = (selectedTab) => {
    if (this.state.selectedTab == 'INGREDIENT' || selectedTab == 'INGREDIENT') {
      return this.state.ingredientTableKey;
    }
    if (this.state.selectedTab == 'OPERATION' || selectedTab == 'OPERATION') {
      return this.state.operationTableKey;
    }
  }

  handleTableViewStockClick = (event) => {
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    let ingredientId = event.target && event.target.id.split("_")[1];
    this.setState({ openStockViewModal: true, selectedIngredientCode: ingredientId });
  }

  getStockViewDetails = () => {
    this.setState({ openStockViewModal: false });
  }

  handleCustomTextBoxChange = async (event) => {
    const { name, value } = event.target;
    this.setState({  formDirty: true });
    if (name == 'productQuantity') {
      await CommonUtil.handleNumberChange(event, this);
      await this.handleTableCalculation(this.getSelectedTablekey());
      // await this.handleTableCalculation(this.state.operationTableKey);
    }
  }

  handleCustomBlurChange = (event) => {
    this.setState({  formDirty: true });
    CommonUtil.handleTextBoxBlur(event, this);
    CommonUtil.handleTextBoxChange(event, this);
    this.setState({ customErrorFlag: false });
    const { name, value } = event.target;
    const { attributeObj } = this.state;
    if (name == 'productBatch' && CommonUtil.isNotNull(value)) {
      this.props.getMFGBatchDetails(value.toUpperCase());
    }
  }

  handleCustomDropDownChange = async (event, obj) => {
    this.setState({  formDirty: true });
    const { attributeObj } = this.state;
    if (obj.name == 'product') {
      await this.setState({
        attributeObj: {
          ...attributeObj,
          [obj.name]: event.value,
        },
      })
      await this.props.getProductDetails(event.value);
    }
    if (obj.name == 'mfgLocation') {
      await this.setState({
        attributeObj: {
          ...attributeObj,
          locationResource: null
        }
      })
      CommonUtil.handleDropDownChange(event, obj, this);
      MfgUtil.updateLocationResorceList(this, event.value);
    }
  }

  handleUpdateIngredientOperationList = async () => {
    let selectedData = this.props.productDetails;
    let operationsList = selectedData.operations && selectedData.operations.length > 0 && selectedData.operations.map((x) => {
      let temp = {
        "id": x.id,
        "operationId": x.operationId,
        "operationName": x.operationName,
        "timePerUnit": x.duration,
        "costPerUnit": x.cost,
        "status": 'new'
      }
      return temp;
    });

    let tempList = [];
    tempList = selectedData.ingredients && selectedData.ingredients.length > 0 && selectedData.ingredients.map((item) => {
      return item.ingredientId
    })
    if(tempList && tempList.length > 0) {
      await this.props.getProductDetailList(tempList, this.state.attributeObj.facilityId || this.state.attributeObj.mfgLocation )
    }
    let ingredients = selectedData.ingredients && selectedData.ingredients.length > 0 && selectedData.ingredients.map((x) => {
      let temp = {
        "id": x.id,
        "ingredientId": x.ingredientId,
        "ingredientName": x.ingredientName,
        "ingredientUOM": x.ingredientUOM,
        "qtyPerUnit": x.quantity,
        // "pricePerUnit": x.usgCostPerUnit,
        "pricePerUnit": x.purchasePrice,
        "status": 'new',
        "issueQuantity": 0,
        // "usgPackSizeQty": x.usgPackSizeQty,  
        // "usgUOM": x.usgUOM,  
        // "usgCostPerUnit": x.usgCostPerUnit
      }
      return temp;
    })
    const { attributeObj } = this.state;
    await this.setState({
      attributeObj: {
        ...attributeObj,
        productUOM: selectedData.productUOM
      },
      ingredients: ingredients ? [...ingredients] : [],
      operationsList: operationsList ? [...operationsList] : []
    })
    await this.setSelectedTableDetails(this.state.selectedTab);
    await this.handleTableCalculation(this.getSelectedTablekey());
    // await this.handleTableCalculation(this.state.operationTableKey);
  }

  handleTabClick = (label, event) => {
    var selectedTabKey = label.toUpperCase();
    this.setState({
      selectedTab: label.toUpperCase(),
    }, function () {
      this.setSelectedTableDetails(selectedTabKey);
    })
  }

  getOperationQCDetails = (operationQCList) => {
    this.setState({ openModal: false, processKey: null });
    if (operationQCList != null && operationQCList.documentList &&
      operationQCList.documentList.length >= 0) {
      MfgUtil.handleOperationQCDetails(operationQCList, this);
    }
  }

  getSelectedIngList = (tempObj) => {
    this.setState({ openIngSelectModal: false, selectedIngredientCode: null });
    if (tempObj != null && tempObj.selectedIngList && tempObj.selectedIngList.length > 0) {
      MfgUtil.handleSelectedIngDetails(tempObj, this);
    }
  }

  handleTableSuggestionChange = async (event, eventId, searchOptions, shouldNewRowAdded) => {
    this.setState({  formDirty: true });
    await PopularTableUtil.handleTableSuggestionChange(event, eventId, searchOptions,
      this, this.getSelectedTablekey());
    var id = parseInt(eventId.split('_')[1]);
    if (event && event.length > 0 && this.state.selectedTab == 'INGREDIENT') {
      await this.props.getIngredientDetails(event[0].productId, { facilityId: this.state.attributeObj.facilityId ||this.state.attributeObj.mfgLocation  });
    }
    else {
      await this.setOperationDefaultRowData(id, this.getSelectedTablekey());
    }
    await this.handleTableCalculation(this.getSelectedTablekey(), shouldNewRowAdded);
  }

  handleTableTextBoxChange = async (event) => {
    this.setState({  formDirty: true });
    await PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleTableSwitchChange = async (event, state) => {
    this.setState({  formDirty: true });
    await PopularTableUtil.handleTableSwitchChange(event, state, this, this.getSelectedTablekey());
    if (state === true) {
      const { attributeObj } = this.state;
      if (attributeObj.status == statusConstant.NEW_STATUS) {
        attributeObj.status = statusConstant.IN_PROGRESS_STATUS;
        this.setState({ attributeObj: attributeObj });
      }
    }
  }

  handleTableLinkClick = async (event) => {
    this.setState({ formDirty: true })
    event.preventDefault();
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    var tempId = event.target.id.split("_");
    await MfgUtil.updateSelectedIngDetails(this, tempId[1]);
    this.setState({ openIngSelectModal: true, selectedIngredientCode: tempId[1] });
  }

  handleTableDropDownChange = async (event, obj) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleDeleteRowPopup = (event) => {
    this.setState({ eventId: event.target.id,formDirty: true });
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleTableRemove = async (event) => {
    this.setState({ alert: null,formDirty: true  });
    let tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, this.getSelectedTablekey(), true);
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  setIngredientDefaultRowData = async (tableDataKeyName) => {
    let attributeDataList = [...this.state[tableDataKeyName]];
    const { ingredientDetails } = this.props;
    let i = attributeDataList.findIndex(value => value.productId == ingredientDetails.productId);
    attributeDataList[i].ingredientId = ingredientDetails.productId;
    attributeDataList[i].ingredientUOM = ingredientDetails.productUOM;
    attributeDataList[i].pricePerUnit = ingredientDetails.purchasePrice;
    // attributeDataList[i].pricePerUnit = ingredientDetails.usgCostPerUnit;
    attributeDataList[i].ingredientName = ingredientDetails.productName;
    attributeDataList[i].qtyPerUnit = ingredientDetails.quantity;
    attributeDataList[i].issueQuantity = 0;
    attributeDataList[i].status = "new";
    attributeDataList[i].totalCosts = ingredientDetails.pricePerUnit;
    attributeDataList[i].stock = ingredientDetails.stock == 0 ? ingredientDetails.orderstock : ingredientDetails.stock;

    // attributeDataList[i].usgPackSizeQty = ingredientDetails.usgPackSizeQty;
    // attributeDataList[i].usgUOM = ingredientDetails.usgUOM;
    // attributeDataList[i].usgCostPerUnit = ingredientDetails.usgCostPerUnit;

    await this.setState({ [tableDataKeyName]: attributeDataList });
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleTableButtonMenuAction = (event, operationKey) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
    MfgUtil.handleOperationStatusChange(event, operationKey, this);
  }

  handleTableCalculation = async (tableDataKeyName, shouldNewRowAdded) => {
    await this.handleIngredientTableCalulation("itemList");
    await this.handleOperationTableCalulation("operationsList");
    // if (CommonUtil.isBothEqual(tableDataKeyName, 'itemList')) {
    // }
    // if (CommonUtil.isBothEqual(tableDataKeyName, 'operationsList')) {
    // }
    if (shouldNewRowAdded) {
      this.handleTableAddRow();
    }
  }

  handleIngredientTableCalulation = async (tableDataKeyName) => {
    const { attributeObj } = this.state;
    var attributeDataList = [...this.state[tableDataKeyName]];
    var tempQuantity = 0, tempPrice = 0, totalIngredientValue = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      tempQuantity = 0; tempPrice = 0;
      tempQuantity = this.state[tableDataKeyName][i].qtyPerUnit;
      tempPrice = this.state[tableDataKeyName][i].pricePerUnit;
      // tempPrice = this.state[tableDataKeyName][i].usgCostPerUnit;
      tempQuantity = CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempQuantity) *
        CommonUtil.getFloatValue(attributeObj.productQuantity), 2);
      tempPrice = CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempPrice) * CommonUtil.getFloatValue(tempQuantity), 2);
      attributeDataList[i].totalQuantity = tempQuantity;
      attributeDataList[i].issueQuantity = this.state.attributeObj.status == statusConstant.COMPLETED_STATUS ? tempQuantity : 0;
      // attributeDataList[i].totalPurchasePrice = CommonUtil.getFloatValue(tempPrice, 2);
      attributeDataList[i].totalCosts = CommonUtil.getFloatValue(tempPrice, 2);
      totalIngredientValue = CommonUtil.getFloatValue(CommonUtil.getTotalValue(totalIngredientValue, tempPrice, true), 2);
    }
    await this.setState({ [tableDataKeyName]: attributeDataList, totalIngredientValue: totalIngredientValue });
  }

  setOperationDefaultRowData = async (id, tableDataKeyName) => {
    var selectedData = '';
    var attributeDataList = [...this.state[tableDataKeyName]];
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (id == i) {
        this.props && this.props.operationList && this.props.operationList.filter(value => {
          if (value.operationId && String(value.operationId).toLowerCase().indexOf(
            attributeDataList[i].operationId &&
            String(attributeDataList[i].operationId).toLowerCase()) !== -1) {
            selectedData = value;
          }
        });
        if (selectedData && selectedData !== null) {
          attributeDataList[i].operationName = selectedData.operationName;
          attributeDataList[i].timePerUnit = selectedData.duration;
          attributeDataList[i].costPerUnit = selectedData.cost;
          attributeDataList[i].totalProductionTime = selectedData.duration;
          attributeDataList[i].totalCosts = selectedData.cost;
          attributeDataList[i].status = "new";
        }
      }
    }
    this.setState({ [tableDataKeyName]: attributeDataList });
  }

  handleOperationTableCalulation = async (tableDataKeyName) => {
    const { attributeObj } = this.state;
    var attributeDataList = [...this.state[tableDataKeyName]];
    var tempProductionTime = 0, tempPrice = 0, totalOperationValue = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      tempProductionTime = 0; tempPrice = 0;
      tempProductionTime = this.state[tableDataKeyName][i].timePerUnit;
      tempPrice = this.state[tableDataKeyName][i].costPerUnit;
      tempProductionTime = CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempProductionTime) *
        CommonUtil.getFloatValue(attributeObj.productQuantity), 2);
      tempPrice = CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempPrice) *
        CommonUtil.getFloatValue(tempProductionTime), 2);

      attributeDataList[i].totalProductionTime = tempProductionTime;
      attributeDataList[i].totalCosts = CommonUtil.getFloatValue(tempPrice, 2);
      totalOperationValue = CommonUtil.getFloatValue(CommonUtil.getTotalValue(totalOperationValue, tempPrice, true), 2);
    }
    await this.setState({ [tableDataKeyName]: attributeDataList, totalOperationValue: totalOperationValue });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      if (CommonUtil.isCloneMode(this.props.actionMode)) {
        this.updateCloneData(this.props.attributeObj);
      } else {
        this.updateApiData(this.props.attributeObj);
      }
    }
    if (this.props.operationList != null && prevProps.operationList != this.props.operationList) {
      this.updateOperationDropDownList();
    }
    if (this.props.mfgBatchDetail != null && prevProps.mfgBatchDetail != this.props.mfgBatchDetail) {
      this.handleMfgBatchDetails();
    }
    if (this.props.ingredientList != null && prevProps.ingredientList != this.props.ingredientList) {
      this.updateIngredientDropDownList();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productGrossList != null && prevProps.productGrossList != this.props.productGrossList) {
      this.handleIngredientGrossList();
    }
    if (prevProps.mfgOrderPriorityDetails != this.props.mfgOrderPriorityDetails && this.props.mfgOrderPriorityDetails != null) {
      this.handlePriorityList();
    }
    if (this.props.productDetails != null && prevProps.productDetails != this.props.productDetails) {
      this.handleUpdateIngredientOperationList();
    }
    if (this.props.ingredientDetails != null && prevProps.ingredientDetails != this.props.ingredientDetails) {
      this.setIngredientDefaultRowData(this.getSelectedTablekey());
    }
    if (prevProps.location && prevProps.location.key !== this.props.location.key) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getMfgOrderDetails(this.props.selectedMfgOrderCode);
      } else {
        this.createNew();
      }
    }
    if (this.props.productDetailList != null && prevProps.productDetailList != this.props.productDetailList) {
      let tempList = this.props.productDetailList;
      this.getProductSelectionDetails(tempList);
    }
  }

  getProductSelectionDetails = async (list) => {
    const { ingredients } = this.state;
    if (list && list.length > 0) {
      list.sort((a, b) => a.productId > b.productId);
      let tempList = list.map((x) => {
        let temp = {
          "ingredientId": x.productId,
          "ingredientUOM": x.productUOM,
          "pricePerUnit": x.purchasePrice,
          "ingredientName": x.productName,
          "qtyPerUnit": x.quantity,
          "issueQuantity": 0,
          "status": "new",
          "totalCosts": x.pricePerUnit,
          "stock": x.stock == 0 ? x.orderstock : x.stock,
        };
        return temp
      })
      tempList.map(x => {
        ingredients.map(y => {
          if(x.ingredientId === y.ingredientId) {
            x.qtyPerUnit = y.qtyPerUnit
          }
        })
      })
      this.setState({ itemList: [] })
      this.setState({ itemList: tempList })
    }
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleTableAddRow = (event) => {
    this.setState({ formDirty: true })
    PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
  }

  handlePriorityList = async () => {
    await this.setState({ mfgOrderPriorityDetails: this.props.mfgOrderPriorityDetails });
    this.handlePriorityDetails();
  }

  handleIngredientGrossList = async () => {
    await this.setState({ ingredientGrossList: this.props.productGrossList });
    this.handlePriorityDetails();
  }

  handlePriorityDetails = () => {
    if (CommonUtil.isNotNull(this.props.productGrossList) && CommonUtil.isNotNull(this.props.mfgOrderPriorityDetails)) {
      MfgUtil.setPriorityStatus(this);
    }
  }

  handleInactiveIngConfirmation = async () => {
    await this.setState({ isInactiveIngValidationDone: true });
    this.handleSave();
  }

  handleSave = async (event) => {
    if (this.state.saveBtnDisable) {
      return;
    }
    await this.setState({ submitted: true, saveBtnDisable: true, formDirty: false });
    const { attributeObj } = this.state;
    var tempObj = _.cloneDeep(attributeObj);
    const mfgOrderId = attributeObj.mfgOrderId ? attributeObj.mfgOrderId : "";
    delete tempObj.mfgOrderId;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, this.props.actionMode);
    tempObj.productBatch = tempObj.productBatch.toUpperCase();
    tempObj.itemList = this.state.itemList;
    tempObj.operationsList = this.state.operationsList;
    tempObj.totalIngredientValue = this.state.totalIngredientValue;
    tempObj.totalOperationValue = this.state.totalOperationValue;
    tempObj.productId = attributeObj.product;
    tempObj.facilityId = attributeObj.mfgLocation;
    tempObj.totalValue = CommonUtil.getFloatValue((this.state.totalOperationValue + this.state.totalIngredientValue), true)

    if (tempObj.itemList.length > 0) {
      tempObj.itemList.map((item) => {
        if (item.pricePerUnit == 0) {
        // if (item.usgCostPerUnit == 0) {
          this.setState({ customErrorFlag: true });
          MfgUtil.checkIngredientPurchasePrice(this);
          return false;
        } else {
          this.setState({ customErrorFlag: false });
        }
      });
    }

    if (this.isValidRequestObj(tempObj) && !this.state.customErrorFlag) {
      delete tempObj.product;
      delete tempObj.mfgLocation;
      this.props.setMfgOrderDetails(tempObj, this.props.actionMode, mfgOrderId);
    } else {
      await this.setState({ saveBtnDisable: false });
    }
  }

  isValidRequestObj = (tempObj) => {
    if (tempObj.status == statusConstant.COMPLETED_STATUS) {
      if (!MfgUtil.isValidDoneStatusChange(this)) {
        MfgUtil.doneStatusPopup(this);
        return false;
      }
    }
    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }
    if (tempObj.itemList.length == 0 || tempObj.operationsList.length == 0) {
      MfgUtil.alteastAddOneRowPopup(this);
      return false;
    }
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      if (!this.state.isInactiveIngValidationDone && !MfgUtil.checkValidIngredientStatus(tempObj.itemList, this)) {
        return false;
      }
    }
    let tempSelectedStockColumnList = pagePropertyListConstant.CREATE_MFG_ING_SELECT_MODAL_TABLE_LIST(this).tableColumnList;
    if (tempObj.itemList && CommonUtil.isNotNull(tempObj.itemList)) {
      for (let i = 0; i < tempObj.itemList.length; i++) {
        tempObj.itemList[i].materialStatus = MfgUtil.getMaterialStatus(tempObj.itemList[i]);
        if (CommonUtil.isNotNull(tempObj.itemList[i].selectedIngList)) {
          tempObj.itemList[i].selectedIngList = ValidationUtil.removeAttributeFromArrayList(tempObj.itemList[i].selectedIngList,
            tempSelectedStockColumnList, this.props.actionMode);
        }
      }
    }

    let tableIngColumnList = pagePropertyListConstant.CREATE_MFG_INGREDIENT_TABLE_LIST(this).tableColumnList;
    tempObj.itemList = ValidationUtil.removeAttributeFromArrayList(tempObj.itemList, tableIngColumnList, this.props.actionMode);
    if (!ValidationUtil.validateArrayListRequestObj(tempObj.itemList, tableIngColumnList)) {
      return false;
    }

    let tableOptColumnList = pagePropertyListConstant.CREATE_MFG_OPERATION_TABLE_LIST(this).tableColumnList;
    if (!ValidationUtil.validateArrayListRequestObj(tempObj.operationsList, tableOptColumnList)) {
      return false;
    }
    return true;
  }

  handleTableMenuPopupAction = (event) => {
    CommonUtil.overlay(event);
    var tempId = event.target.id.split("_");
    let location = this.state.attributeObj.mfgLocation;
    if (tempId[2] == mfgOrderConstant.CREATE_PO) {
      CommonUtil.handlePageRedirection(mfgOrderConstant.CREATE_PO_ORDER_PAGE_URL, this, null, location);
    }
    if (tempId[2] == mfgOrderConstant.CREATE_MO) {
      CommonUtil.handlePageRedirection(mfgOrderConstant.CREATE_MO_ORDER_PAGE_URL, this, null, location);
    }
  }

  handleHeaderIconClick = (e, action) => {
    switch (action) {
      case commonConstant.PRINT_ACTION:
        this.printMfgOrder();
        break;
      case commonConstant.CLONE_ACTION:
        this.cloneMfgOrder()
        break;
      case commonConstant.TRASH_ACTION:
        this.deleteMfgOrder();
        break;
      default:
        console.log('Invalid header action')
    }
  }

  printMfgOrder = (params) => {
    // TODO
  }

  cloneMfgOrder = (params) => {
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    this.props.getProductList({ isDropdown: true, source: 'make' });
    this.props.getIngredientList({ isDropdown: true, isIngredient: true });
    this.props.setActionMode(commonConstant.CLONE_ACTION_MODE);
    this.props.getMfgOrderDetails(this.state.attributeObj.mfgOrderId);
  }

  deleteMfgOrder = (params) => {
    if (!CommonUtil.isEditMode(this.props.actionMode)) {
      return;
    }
    if (this.state.attributeObj.status == statusConstant.NEW_STATUS) {
      var popupActionButton = {};
      popupActionButton.onConfirmClick = this.handleStatusAction;
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeletPopUpConfig(popupActionButton, mfgOrderConstant.MODULE_NAME);
      this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }
  }

  handleStatusAction = (status) => {
    var tempObj = {};
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updateMfgOrderDeleteStatus(tempObj, this.state.attributeObj.mfgOrderId);
  }


  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      let params = null;
      if (this.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
        params = "COMPLETED";
      }
      let location = this.state.attributeObj.mfgLocation;
      setTimeout(CommonUtil.handlePageRedirection(mfgOrderConstant.MANAGE_MFG_ORDER_PAGE_LIST, this, params, location), 0);
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      let errorMessage = this.props.ajaxCallStatus.data && this.props.ajaxCallStatus.data.response;
      if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "409") {
        this.setState({ customErrorFlag: true });
      } else if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "422") {
        PopupUtil.stockNotAvailablePopup(this);
      } else {
        PopupUtil.popupErrorResponse(this);
      }
      this.props.setAjaxCallStatus(null);
      this.setState({ saveBtnDisable: false });
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = null;
    this.setState({ formDirty: false })
    if (this.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
      params = "COMPLETED";
    }
    let location = this.state.attributeObj.mfgLocation;
    CommonUtil.handlePageRedirection(mfgOrderConstant.MANAGE_MFG_ORDER_PAGE_LIST, this, params, location);
  }

  async updateApiData(attributeObj) {
    await this.setState({
      attributeObj: {
        ...attributeObj,
        mfgOrderId: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.mfgOrderId,
        product: attributeObj.product ? attributeObj.product : attributeObj.productId,
        mfgLocation: attributeObj.mfgLocation ? attributeObj.mfgLocation : attributeObj.facilityId,
        status: attributeObj.status ? attributeObj.status : "new"
        // createdDate: moment(new Date(attributeObj.createdDate).toLocaleDateString('en-US')).format('MM-DD-YYYY')
      },
      totalIngredientValue: attributeObj.totalIngredientValue,
      totalOperationValue: attributeObj.totalOperationValue,
      itemList: attributeObj.itemList ? [...attributeObj.itemList] : [],
      operationsList: attributeObj.operationsList ? [...attributeObj.operationsList] : [],
    });
    this.isProductActive();
    await this.handleTableCalculation(this.getSelectedTablekey());
    // await this.handleTableCalculation(this.state.operationTableKey);
    let { attributeList } = this.state;
    if (CommonUtil.isNotNull(attributeObj)) {
      attributeList = attributeList.map((item) => {
        if (CommonUtil.isBothEqual(attributeObj.productBatch, attributeObj.utiNumber)) {
          if (item.name == "productBatch" || item.name == "locationResource") {
            item.editMode = 'enable';
          }
        }
        return item;
      });
    }
    await this.setState({ attributeList: attributeList });
  }

  updateCloneData = async (attributeObj) => {
    let tempObj = attributeObj;
    tempObj.status = statusConstant.NEW_STATUS;
    // tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj, this.state.attributeList, this.props.actionMode);
    // tempObj.createdDate = CommonUtil.getTodaysDate();
    tempObj.itemList = ValidationUtil.removeAttributeFromArrayList(tempObj.itemList,
      pagePropertyListConstant.CREATE_MFG_INGREDIENT_TABLE_LIST(this).tableColumnList,
      commonConstant.CLONE_ACTION_MODE);
    tempObj.operationsList = ValidationUtil.removeAttributeFromArrayList(tempObj.operationsList,
      pagePropertyListConstant.CREATE_MFG_OPERATION_TABLE_LIST(this).tableColumnList,
      commonConstant.CLONE_ACTION_MODE);
    await this.setState({
      attributeObj: {
        ...tempObj,
        // mfgOrderId: CommonUtil.isCloneMode(this.props.actionMode) ? "" : tempObj.mfgOrderId,
        productBatch: CommonUtil.isCloneMode(this.props.actionMode) ? "" : tempObj.productBatch,
        product: tempObj.productId,
        mfgLocation: tempObj.facilityId,
        status: "new"
      },
      itemList: [...tempObj.itemList],
      operationsList: [...tempObj.operationsList],
    });
    MfgUtil.updateLocationResorceList(this, tempObj.facilityId);
    this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    this.handleTableCalculation(this.getSelectedTablekey());
  };

  createNew = async () => {
    let tempObj = [];
    tempObj.status = statusConstant.NEW_STATUS;
    // tempObj.createdDate = CommonUtil.getTodaysDate();
    tempObj.itemList = [];
    tempObj.operationsList = [{}];
    await this.setState({
      attributeObj: {
        ...tempObj,
        mfgOrderId: "",
        productBatch: "",
      },
      itemList: [...tempObj.itemList],
      operationsList: [...tempObj.operationsList],
    });
    await this.setSelectedTableDetails("INGREDIENT");
    await this.handleTableAddRow();
    this.handleTableCalculation(this.getSelectedTablekey());
  };

  updateOperationDropDownList = () => {
    this.setState({ operationList: this.props.operationList })
  }

  handleMfgBatchDetails = () => {
    if (CommonUtil.isNotNull(this.props.mfgBatchDetail)) {
      this.setState({ customErrorFlag: true });
    }
  }

  updateIngredientDropDownList = () => {
    this.setState({ ingredientList: this.props.ingredientList })
  }

  updateProductDropDownList = () => {
    this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList,
        CommonUtil.getOptionsFromList(this.props.productList, 'productId',
          'productName', null, false, "PRO-"), 'product'),
    })
    this.isProductActive();
  }

  isProductActive = () => {
    if (!CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      if (CommonUtil.isNotNull(this.props.productList) && CommonUtil.isNotNull(this.props.attributeObj)) {
        let isProductAvailable = CommonUtil.getFilteredObjFromArray(this.props.productList,
          'productId', this.props.attributeObj.productId);
        if (CommonUtil.isNullValue(isProductAvailable)) {
          this.props.getProductList({ "status": 'inactive' });
        }
      }
    }
  }

  updateFacilityDropDownList = () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-");
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'mfgLocation')
    })
  }

  handleDocumentPopup = async (e) => {
    await this.setState({ openDocumentModal: true, });
  };

  getUploadDocumentDetails = (uploadDocumentObj) => {
    this.setState({ openDocumentModal: false, selectedProductCode: null });
    if (uploadDocumentObj != null && uploadDocumentObj.documentList &&
      uploadDocumentObj.documentList.length >= 0) {
      MfgUtil.handleUploadDocumentDetails({ ...uploadDocumentObj }, this);
    }
  }

  downloadMakeOrder = (e, invoiceDate) => {
    if (!CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      this.props.downloadInvoice(this.state.attributeObj.mfgOrderId, invoiceDate)
    }
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList, tableConfig,
      mfgOrderPriorityDetails, ingredientGrossList, totalOperationValue, totalIngredientValue,
      customErrorFlag } = this.state;
    const tableDataList = this.state[this.getSelectedTablekey()];
    const actionMode = this.props.actionMode;
    const currencyCode = this.props.currencyCode;
    return (
      <div className="main-content create-page">
        <NavigationPrompt when={this.state.formDirty}>
            {({ onConfirm, onCancel }) => (
                <React.Fragment>
                <SweetAlert
                    showCancel
                    warning
                    customClass="popup-header"
                    style={{ display: "block", marginTop: "-150px" }}
                    title={"All changes will be lost. Do you want to continue?"}
                    text={"All changes will be lost. Do you want to continue?"}
                    confirmBtnText={'Confirm'}
                    cancelBtnText={'Cancel'}
                    onConfirm={onConfirm}
                    onCancel={onCancel}
                    btnSize="sm"
                    cancelBtnCssClass="btn-cancel"
                    confirmBtnCssClass="btn-save btn-fill"
                    focusConfirmBtn={false}
                    focusCancelBtn={true}
                    closeOnCancel={true}
                    closeOnConfirm={true}
                    showConfirm={true}
                >
                </SweetAlert>
                </React.Fragment>
            )}
        </NavigationPrompt>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params, location: this.state.location, searchInput: this.state.searchInput }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={make} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    mfgOrderConstant.EDIT_MFG_ORDER_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      mfgOrderConstant.VIEW_MFG_ORDER_HEADER_TITLE
                      : mfgOrderConstant.CREATE_MFG_ORDER_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {isAuthorized("makeCreateActions") &&
                    <div className="page-action-buttons">
                      <div className={!CommonUtil.isViewMode(actionMode) ? 'btn-fill btn-wd btn progress-button' : 'btn-fill btn-wd btn progress-button disabled'}
                        style={{
                          backgroundColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status),
                          borderColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status)
                        }}>
                        <div className="items">{StatusUtil.getStatusLabel(attributeObj && attributeObj.status)}
                        </div>
                        {!CommonUtil.isViewMode(this.props.actionMode) && !CommonUtil.isCreateOrCloneMode(this.props.actionMode) ?
                          <div className="items">
                            <Nav pullRight>
                              <NavDropdown id={'status'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
                                {pagePropertyListConstant.HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                                  <MenuItem name="status" id={tempAttributeListObj.statusKey}
                                    onClick={(e) => MfgUtil.handleButtonStatusChange(e, this)}
                                    disabled={false}>
                                    <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
                                    {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                                  </MenuItem>
                                ))}
                              </NavDropdown>
                            </Nav>
                          </div>
                          : null}
                      </div>
                      {!CommonUtil.isCreateOrCloneMode(actionMode) ?
                        <img src={documentmangment} alt="" className={CommonUtil.isViewMode(actionMode) ? 'fa disabled' : 'fa'} title="Documents" onClick={(e) => this.handleDocumentPopup(e)} />
                        : null}

                      <div className="items">
                        <Nav pullRight>
                          <NavDropdown id={'pdfdownload'} title={<i className="fa fa-download invoice-download" title={"Download"} />} noCaret>
                            <MenuItem name="pdfdownload" id="PACKINGSLIP"
                              onClick={(e) => this.downloadMakeOrder(e, "TICKETINVOICE")}
                              disabled={false}> Order Ticket
                            </MenuItem>
                            <MenuItem name="pdfdownload" id="FULLINVOICE"
                              onClick={(e) => this.downloadMakeOrder(e, "FULLINVOICE")}
                              disabled={false}> Manufacturing Order
                            </MenuItem>
                          </NavDropdown>
                        </Nav>
                      </div>
                      {/*<i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-print' : 'fa fa-print disabled'} title={"Print"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.PRINT_ACTION)} ></i>*/}
                      <i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-copy' : 'fa fa-copy disabled'} title={"Clone"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.CLONE_ACTION)} ></i>
                      {isAuthorized("deleteMakeOrder") && <i className={(CommonUtil.isEditMode(actionMode) && StatusUtil.getStatusLabel(attributeObj && attributeObj.status) === 'New') ? 'fa fa-trash' : 'fa fa-trash disabled'} title={"Trash"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.TRASH_ACTION)} ></i>}
                    </div>
                  }
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button ref={this.savebtn} className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    !this.props.insideInventory && <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                          tempAttributeListObj.type == "FIXED" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            LabelUtil.fixedAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                            : tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                                  : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : null))
                        }
                      </Row>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Tabs activeKey={this.state.selectedTab} onSelect={this.handleTabClick} id="table-tab">
                        <Tab eventKey={'INGREDIENT'} title={mfgOrderConstant.INGREDIENT_TABLE_NAME}>
                          {tableDataList != null &&
                            <Row>
                              {tableColumnList != null && tableColumnList.length > 0 ?
                                <div>
                                  <Table columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                  <div className="add-new-section">
                                    <Col md={12}>
                                      {attributeObj && CommonUtil.isNotNull(attributeObj.product) && CommonUtil.isNotNull(attributeObj.mfgLocation) && (attributeObj.status == statusConstant.NEW_STATUS || attributeObj.status == statusConstant.IN_PROGRESS_STATUS) && !CommonUtil.isViewMode(this.props.actionMode) ?
                                        <div className="add-row-button" onClick={
                                          !CommonUtil.isViewMode(this.props.actionMode) ?
                                            (e) => this.handleTableAddRow(e) : null}>
                                          <i className=" fa fa-plus" />
                                          Add Row
                                        </div>
                                        : null}
                                    </Col>
                                  </div>
                                </div>
                                : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                            </Row>}
                        </Tab>
                        <Tab eventKey={'OPERATION'} title={mfgOrderConstant.OPERATION_TABLE_NAME}>
                          {tableDataList != null &&
                            <Row>
                              {tableColumnList != null && tableColumnList.length > 0 ?
                                <div>
                                  <Table columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                  <div className="add-new-section">
                                    <Col md={6}>
                                      {attributeObj && CommonUtil.isNotNull(attributeObj.product) && CommonUtil.isNotNull(attributeObj.mfgLocation) && (attributeObj.status == statusConstant.NEW_STATUS || attributeObj.status == statusConstant.IN_PROGRESS_STATUS) && !CommonUtil.isViewMode(this.props.actionMode) ?
                                        <div className="add-row-button" onClick={
                                          !CommonUtil.isViewMode(this.props.actionMode) ?
                                            (e) => this.handleTableAddRow(e) : null}>
                                          <i className=" fa fa-plus" />
                                          Add Row
                                        </div>
                                        : null}
                                    </Col>

                                  </div>
                                </div>
                                : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                            </Row>}
                        </Tab>
                      </Tabs>
                      <Row>
                        <Col md={6}>
                        </Col>
                        <Col md={6}>
                          <ul className="total-section">
                            <li>
                              <Col md={6} className="total-section-field-title"> Total Ingredient Cost </Col>
                              {totalIngredientValue ? (
                                <Col md={6} className="total-section-field-value">
                                  {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, CommonUtil.getFloatValue(totalIngredientValue, 2))}
                                </Col>
                              ) : null}
                            </li>
                            <li>
                              <Col md={6} className="total-section-field-title">
                                Total Operation Cost
                              </Col>
                              {totalOperationValue ? (
                                <Col md={6} className="total-section-field-value">
                                  {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, CommonUtil.getFloatValue(totalOperationValue, 2))}
                                </Col>
                              ) : null}
                            </li>
                            <li>
                              <Col md={6} className="total-section-field-title">
                                Total Cost
                              </Col>
                              {totalOperationValue && totalIngredientValue ? (
                                <Col md={6} className="total-section-field-value">
                                  {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, CommonUtil.getTotalValue(totalOperationValue, totalIngredientValue, true))}
                                </Col>
                              ) : null}
                            </li>
                          </ul>
                        </Col>
                      </Row>
                      {/* {this.state.openModal == true ?
                        <MfgQCModal
                          getOperationQCDetails={this.getOperationQCDetails}
                          attributeObj={this.state.attributeObj}
                          processKey={this.state.processKey}>
                        </MfgQCModal>
                        : null} */}

                      {/* {this.state.openIngSelectModal == true ?
                        <IngSelectModal
                          getSelectedIngList={this.getSelectedIngList}
                          ingredientId={this.state.selectedIngredientCode}
                          productId={this.state.attributeObj.productId}
                          facilityId={this.state.attributeObj.mfgLocation}
                          itemList={this.state.itemList}>
                        </IngSelectModal>
                        : null}

                      {this.state.openStockViewModal == true ?
                        <StockViewModal
                          attributeObj={this.props.attributeObj}
                          ingredientId={this.state.selectedIngredientCode}
                          getStockViewDetails={this.getStockViewDetails}>
                        </StockViewModal>
                        : null} */}
                      {this.state.openDocumentModal == true ?
                        <DocumentUploadModal
                          documentList={this.state.attributeObj}
                          actionmode={actionMode}
                          status={attributeObj.status}
                          getUploadDocumentDetails={this.getUploadDocumentDetails}>
                        </DocumentUploadModal>
                        : null}
                    </div>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button ref={this.savebtn} className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        !this.props.insideInventory && <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div >
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.mfgOrder.mfgOrderDetails,
    mfgBatchDetail: state.mfgOrder.mfgBatchDetail,
    selectedMfgOrderCode: state.mfgOrder.selectedMfgOrderCode,
    mfgOrderPriorityDetails: state.mfgOrder.mfgOrderPriorityDetails,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    currencyCode: state.dataDictionary.currencyCode,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    productList: state.product.productList,
    productGrossList: state.product.productGrossList,
    operationList: state.operation.operationList,
    operationDetails: state.operation.operationDetails,
    ingredientList: state.ingredient.ingredientList,
    inactiveIngredientList: state.ingredient.inactiveIngredientList,
    facilityList: state.facility.facilityList,
    actionMode: state.app.actionMode,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    productDetails: state.product.productDetails,
    ingredientDetails: state.ingredient.ingredientDetails,
    productDetailList: state.product.productDetailList,
  };
}

const mapDispatchToProps = dispatch => ({
  setMfgOrderDetails: (mfgOrderDetailsObj, actionMode, mfgOrderId) => dispatch(setMfgOrderDetails(mfgOrderDetailsObj, actionMode, mfgOrderId)),
  getMfgOrderDetails: selectedMfgOrderCode => dispatch(getMfgOrderDetails(selectedMfgOrderCode)),
  getMFGBatchDetails: selectedBatchCode => dispatch(getMFGBatchDetails(selectedBatchCode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getPriorityDetails: id => dispatch(getPriorityDetails(id)),
  updateMfgOrderDeleteStatus: (mfgOrderDetails, mfgOrderId) => dispatch(updateMfgOrderDeleteStatus(mfgOrderDetails, mfgOrderId)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getProductGrossList: (params) => dispatch(getProductGrossList(params)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  getInactiveIngredientList: (params) => dispatch(getInactiveIngredientList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  getOperationList: () => dispatch(getOperationList()),
  getOperationDetails: (params) => dispatch(getOperationDetails(params)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getProductDetails: (id) => dispatch(getProductDetails(id)),
  getIngredientDetails: (id, params) => dispatch(getIngredientDetails(id, params)),
  downloadInvoice: (id, downloadType) => dispatch(downloadInvoice(id, downloadType)),
  getProductDetailList: (list, facilityId) => dispatch(getProductDetailList(list, facilityId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateMfgOrder);
