import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, Tab, Tabs, FormGroup, Form } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as mfgOrderConstant from '../constant/mfgOrderConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import Select from "react-select";
import {
  setSelectedMfgOrderCode, getMfgOrderList, updateMfgOrderStatus, getMfgOrderSearchList,
  setIngredientStatusList, getPriorityDetails, updateMfgOrderPriority, downLoadXLSFile,
  getMfgOrderResourceViewData, getMfgOrderOrderViewData, editOperationStatus
} from "../actions/mfgOrderActions";
import { updateAutomationDraftStatus, getAutomationDraftOrderList } from "../../automation/actions/automationActions";
import { getProductGrossList } from "../../productManagement/actions/productActions";
import { getProductList } from '../../productManagement/actions/productActions';
import CommonUtil from '../../common/util/commonUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { setActionMode } from "../../../actions/appActions";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PopularTableUtil from '../../common/util/popularTableUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import PopupUtil from '../../common/util/popupUtil';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import StatusUtil from '../../common/util/statusUtil';
import filter from 'assets/img/filter.svg';
import pin from "assets/img/pin.svg";
import download from "assets/img/download.svg";
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import MfgUtil from "./MfgUtil";
import make from "assets/img/make-page-icon.svg";
import * as _ from "lodash";
import mixpanel from "../../analytics/mixpanel/mixpael";
import ConfigureModal from "./ConfigureModal.js";
import check from "assets/img/check.svg";

class ManageMfgOrder extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      mfgOrderId: null,
      defaultSelectedTab: "OPEN",
      selectedTab: "OPEN",
      mainSelectedTab: "ORDERSTATUS",
      ingredientGrossList: [],
      mfgOrderPriorityDetails: null,
      status: null,
      duration: null,
      facilityList: [],
      allList: [{ label: 'All', value: '' }],
      locationName: "",
      openModal: false,
      search: null,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      mfgOrdersResourceViewData: null,
      mfgOrdersOrderViewData: null,
      resourceDataList: [],
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.getCompleteDetails = this.getCompleteDetails.bind(this);
    this.openConfigureModal = this.openConfigureModal.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Manage Mfg order loaded");
    let params = CommonUtil.getAdditonalPathParams(this);
    let location = CommonUtil.getAdditonalPathLocation(this);
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getFacilityList({ isDropdown: true, source: 'make' });
    // this.props.getPriorityDetails();
    // this.props.getProductList();
    // this.props.getProductGrossList({ gross: 'ingredient' });
    const { selectedTab } = this.state;
    // if (CommonUtil.isNotNull(location)) {
    //   await this.props.getFacilityDetails(location);
    // }
    await this.setState({location : location ? location : '', searchInput : searchInput ? searchInput : '', search : searchInput ? searchInput : ''})
    if (params == "COMPLETED") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("COMPLETED");
      const { location, history } = this.props;
      history.replace();
    } else if (params == "DRAFT") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("DRAFT");
      const { location, history } = this.props;
      history.replace();
    } else {
      await this.setSelectedTabDetails(selectedTab);
    }
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  // closeSearchBox = () => {
  //   this.state.attributeObj.orderNumber = '';
  //   this.setState({ menuOpen: false });
  // }


  advanceSearch = async () => {
    if(CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails(this.state.selectedTab);
      this.setState({ menuOpen: false, status: null });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  setSelectedTabDetails = async (selectedTab) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    let managePageList = pagePropertyListConstant["MANAGE_MFG_" +
      selectedTab.toUpperCase() + "_ORDER_PAGE_LIST"](this);
    let additionalParams = { status: selectedTab.toLowerCase() };
    if (this.state.location && selectedTab == "OPEN") {
      managePageList = pagePropertyListConstant["MANAGE_MFG_OPEN_ORDER_PAGE_LIST"](this);
      if (isAuthorized("mgfDragStatus")) {
        managePageList.tableConfig.isDraggable = false;
      }
    }
    if (this.state.location) {
      additionalParams.location = this.state.location;
    }
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      selectedTab: selectedTab,
      // searchInput: "",
      lastEvaluatedKeyArray: [],
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
      additionalParams: additionalParams
    })
    this.state.location && this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this), selectedTab);
  }

  handleTabClick = (label, event) => {
    let selectedTabKey = label.toUpperCase();
    PaginationUtil.initPaginationParams(this);
    this.setSelectedTabDetails(selectedTabKey);
  }

  handleMainTabClick = (label, event) => {
    let mainSelectedTab = label.toUpperCase();
    PaginationUtil.initPaginationParams(this);
    this.setState({mainSelectedTab: mainSelectedTab});
    if (mainSelectedTab == "ORDERSTATUS") {
      this.setSelectedTabDetails("OPEN");
    } else if (mainSelectedTab == "RESOURCESCHEDULETASK") {
      this.setSelectedTabDetails("RESOURCEVIEW");
    }
  }

  componentDidUpdate(prevProps) {
    if (prevProps.mfgOrderList != this.props.mfgOrderList && this.props.mfgOrderList != null) {
      this.handleCustomPagination();
    }
    if (this.props.automationDraftList != null && prevProps.automationDraftList != this.props.automationDraftList) {
      this.handleCustomPagination();
    }
    if (prevProps.productGrossList != this.props.productGrossList && this.props.productGrossList != null) {
      this.handleIngredientGrossList();
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityLocationDropDownList();
    }
    if (this.props.mfgOrderPriorityDetails != null && prevProps.mfgOrderPriorityDetails != this.props.mfgOrderPriorityDetails) {
      this.handlePriorityList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      let tempObj = {};
      tempObj.value = this.props.facilityDetails.facilityId; tempObj.label = this.props.facilityDetails.facilityId + " | " + this.props.facilityDetails.facilityName;
      this.handleLocationDropdownChange(tempObj);
    }
    if (this.props.location.state != null && prevProps.location.key !== this.props.location.key) {
      this.setSelectedTabDetails(this.props.location.state)
      // this.props.getFacilityDetails(this.props.location.location);
    }

    if (this.props.mfgOrdersResourceViewData !== null && prevProps.mfgOrdersResourceViewData !== this.props.mfgOrdersResourceViewData) {
      this.setState({mfgOrdersResourceViewData: this.props.mfgOrdersResourceViewData});
    }

    if (this.props.mfgOrdersOrderViewData !== null && prevProps.mfgOrdersOrderViewData !== this.props.mfgOrdersOrderViewData) {
      this.setState({mfgOrdersOrderViewData: this.props.mfgOrdersOrderViewData});
    }

    if (this.props.operationOrderStatusChangeStatus !== null && prevProps.operationOrderStatusChangeStatus !== this.props.operationOrderStatusChangeStatus) {
      this.props.getMfgOrderResourceViewData("resources", this.getFaciltyCode(this.state.locationName));
    }
  }

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      PaginationUtil.initPaginationParams(this);
      this.setSelectedTabDetails(this.state.selectedTab);
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      await this.props.setAjaxCallStatus(null);
    }
  }

  handleCustomPagination = () => {
    if (this.state.selectedTab == "DRAFT" && CommonUtil.isNotNull(this.props.automationDraftList)) {
      PaginationUtil.handlePagination(this.props.automationDraftList, this);
    } else {
      this.handleTableDataList();
    }
  }

  handleConfirmDraftAction = (event) => {
    this.setState({ alert: null });
    let tempId = event.target.id.split("_");
    let tempDraftObj = {};
    tempDraftObj.uniqueCode = tempId[0];
    tempDraftObj.draftCode = tempId[3];
    tempDraftObj.isDeleted = false;
    tempDraftObj.isConfirmed = true;
    this.props.updateAutomationDraftStatus(tempDraftObj);
  };

  handleDeleteDraftAction = () => {
    this.setState({ alert: null });
    const { draftId } = this.state;
    let tempId = draftId.split("_");
    let tempDraftObj = {};
    tempDraftObj.uniqueCode = tempId[0];
    tempDraftObj.draftCode = tempId[3];
    tempDraftObj.isDeleted = true;
    tempDraftObj.isConfirmed = false;
    this.props.updateAutomationDraftStatus(tempDraftObj);
  };

  handlePriorityList = async () => {
    await this.setState({ mfgOrderPriorityDetails: this.props.mfgOrderPriorityDetails });
    this.handlePriorityDetails();
    this.handleTableDataList();
  }

  updateFacilityLocationDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
      this.props.facilityList), 'facilityId', 'facilityName', null, false, "FAC-")
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0))
    let { location } = this.state;
    let selectedLocation = [];
    if(location) {
      selectedLocation = tempList.filter(item => item.value == location)
    }
    await this.setState({
      facilityList: tempList,
      location: location ? selectedLocation[0].value : tempList[0].value,
      locationName: location ? selectedLocation[0].label : tempList[0].label
    })
    tempList && tempList.length > 0 && await this.setSelectedTabDetails(this.state.selectedTab)
  }

  handleIngredientGrossList = async () => {
    await this.setState({ ingredientGrossList: this.props.productGrossList });
    this.handlePriorityDetails();
  }

  handlePriorityDetails = () => {
    if (CommonUtil.isNotNull(this.props.productGrossList) && CommonUtil.isNotNull(this.props.mfgOrderPriorityDetails)) {
      MfgUtil.setPriorityStatus(this);
    }
  }

  handleTableDataList = async () => {
    // if (CommonUtil.isNotNull(this.props.mfgOrderList)) {
      await PaginationUtil.handlePagination(this.props.mfgOrderList, this);
      if (CommonUtil.isNotNull(this.state.location)) {
        let tempTableDataList = MfgUtil.updateTableDataList(this);
        tempTableDataList = _.sortBy(tempTableDataList, 'priority');
        this.setState({ tableDataList: tempTableDataList });
      }
      if (CommonUtil.isNotNull(this.state.selectedFilter)) {
        this.handleFIlter(this.state.selectedFilter);
      }
    // }
  }

  getUpdatedTableDataList = (updateFlag) => {
    if (updateFlag) {
      const { tableDataList } = this.state;
      let requestObj = {};
      let updatedPriorityList = MfgUtil.updateDragDropPriority(this, tableDataList, this.state.location);
      requestObj = {};
      requestObj.priority = true;
      requestObj.priorityList = updatedPriorityList;
      // this.props.updateMfgOrderPriority(requestObj);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({
      location: tempObj.value, locationName: tempObj.label,
      tableDataList: [], selectedFilter: null
    });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handleExportFileDownLoad = () => {
    this.props.downLoadXLSFile({ status: this.state.selectedTab.toLowerCase() });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.mfgOrderList.filter(value => {
      return (
        String(value.mfgOrderId).includes(searchInput) ||
        String(value.productId).includes(searchInput)
      )
    });
    this.setState({ tableDataList: filteredData });
  }

  getButtonStatusColor = (value) => {
    return PopularTableUtil.getButtonStatusColor(value, mfgOrderConstant);
  }

  handleFIlter = async (event) => {
    let status = CommonUtil.isNotNull(event) ? event.toLowerCase() : null;
    // if (CommonUtil.isNotNull(this.state.location)) {
    //   await this.setState({ location: null, locationName: null, tableDataList: [], selectedFilter: event, status: status });
    //   this.setSelectedTabDetails(this.state.selectedTab);
    // } else {
      let filteredData = this.props.mfgOrderList.filter((value) => {
        if (event == statusConstant.OVERDUE_STATUS) {
          return (CommonUtil.isDateExpired(value.eta) == true);
        } else if (event == statusConstant.ALL_STATUS) {
          return value;
        }  else if (event !== "") {
          return value.status.toLowerCase() == event.toLowerCase();
        }
        return value;
      });
      this.setState({ tableDataList: filteredData, selectedFilter: event, status: status });
    // }
  }

  handleEditClone = (id) => {
    let tempId = id.split("_");
    this.props.setSelectedMfgOrderCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    let filteredData = this.state.tableDataList.filter(value => {
      return (
        String(value.mfgOrderId).toLowerCase().includes(tempId[0].toLowerCase())
      );
    });
    this.props.setIngredientStatusList(filteredData[0].itemList);
    CommonUtil.handlePageRedirection(mfgOrderConstant.CREATE_MFG_ORDER_PAGE_URL, this);
  }

  handleMenuPopupAction = (event) => {
    let tempId = event.target.id.split("_");
    if (tempId[2] == mfgOrderConstant.CREATE_MFG_ORDER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(mfgOrderConstant.CREATE_MFG_ORDER_PAGE_URL, this);
    }
  }

  handlePopupCancel = () => {
    this.setState({ alert: null });
  }

  handleStatusAction(mfgOrderId, status) {
    let tempObj = {};
    let tempMfgOrderCode = mfgOrderId ? mfgOrderId : this.state.mfgOrderId;
    tempObj.status = status ? status : this.state.status;
    this.setState({ alert: null });
    this.props.updateMfgOrderStatus(tempObj, tempMfgOrderCode);
  }

  makeCustomAPICall(tempParamas, selectedTab) {
    if (selectedTab == "DRAFT") {
      tempParamas.moduleName = "MO";
      this.props.getAutomationDraftOrderList(tempParamas);
    } else if (selectedTab === "RESOURCEVIEW") {
      this.props.getMfgOrderResourceViewData(tempParamas);
    } else if (selectedTab === "ORDERVIEW") {
      this.props.getMfgOrderResourceViewData(tempParamas);
    } else {
      if (CommonUtil.isNotNull(tempParamas.search)) {
        this.props.getMfgOrderSearchList(tempParamas);
      } else {
        this.props.getMfgOrderList(tempParamas);
      }
    }
  }

  getFaciltyCode = (locationValue) => {
    const locationParts = locationValue.split("|");
    if (locationParts.length > 1) {
      return locationParts[0].trim();
    } else {
      return "";
    }
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  getCompleteDetails = (completeDetails) => {
    this.setState({ openModal: false });
  }

  openConfigureModal = () => {
    this.setState({ openModal: true });
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      await this.setState({ search: null, status: null, selectedFilter: null, searchInput: ""});
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
    if (tempId[1] === "status") {
      await this.setState({ status: null, lastEvaluatedKeyArray: [], selectedFilter: null});
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
  }


  prepareDataForResourceView = (rawResourceViewData) => {
    const finalResouceViewData = [];

    if (!rawResourceViewData) {
      return finalResouceViewData;
    }

    const resourceList = Object.keys(rawResourceViewData);
    for (let i = 0; i < resourceList.length; i++) {
      const resourceKey = resourceList[i];
      const resouceMfgOrders = rawResourceViewData[resourceKey];

      for (let j = 0; j < resouceMfgOrders.length; j++) {
        const mfgOrder = resouceMfgOrders[j];
        const commonMfgOrder = {
          resourceName: mfgOrder["resourceName"] || resourceKey,
          mfgOrderId: mfgOrder["mfgOrderId"],
          productId: mfgOrder["productId"],
          quantity: mfgOrder["quantity"],
          owner: mfgOrder["owner"],
          availableCapacity: mfgOrder["availableCapacity"],
          usedCapacity: mfgOrder["totalCapacity"] - mfgOrder["availableCapacity"]
        };

        const operations = mfgOrder["operations"];

        for (let k = 0; k < operations.length; k++) {
          const operation = operations[k];
          const finalResourceViewData = {
            ...commonMfgOrder,
            operationStatus: operation.status,
            scheduleTime: operation.totalDuration,
            operation: operation.operationId,
            processId: operation.processId
          }
          finalResouceViewData.push(finalResourceViewData);
        }
      }
    }
    return finalResouceViewData;
  }

  handleOperationStatusChange = (event, operationData) => {
    const { name, id } = event.target;
    const statusKey = id.split("_")[0];
    const updatedData = {...operationData, operationStatus: statusKey};
    this.props.editOperationStatus(updatedData);
  }

  prepareDataForOrderView = (rawResourceViewData) => {
    const finalResouceViewData = [];

    if (!rawResourceViewData) {
      return finalResouceViewData;
    }

    const mfgOrderCodeList = Object.keys(rawResourceViewData);
    for (let i = 0; i < mfgOrderCodeList.length; i++) {
      const mfgOrderId = mfgOrderCodeList[i];
      const resouceMfgOrders = rawResourceViewData[mfgOrderId];

      for (let j = 0; j < resouceMfgOrders.length; j++) {
        const mfgOrder = resouceMfgOrders[j];
        const commonMfgOrder = {
          resourceName: mfgOrder["resourceName"],
          mfgOrderId: mfgOrder["mfgOrderId"],
          productId: mfgOrder["productId"],
          quantity: mfgOrder["quantity"],
          owner: mfgOrder["owner"]
        };

        if ((typeof mfgOrder["availableCapacity"] === "number") && (typeof mfgOrder["totalCapacity"] === "number")) {
          commonMfgOrder["availableCapacity"] = mfgOrder["availableCapacity"];
          commonMfgOrder["usedCapacity"] = mfgOrder["totalCapacity"] - mfgOrder["availableCapacity"];
        }
        
        const operations = mfgOrder["operations"];

        for (let k = 0; k < operations.length; k++) {
          const operation = operations[k];
          const finalResourceViewData = {
            ...commonMfgOrder,
            operationStatus: operation.status,
            scheduleTime: operation.totalDuration,
            operation: operation.operationId
          }
          finalResouceViewData.push(finalResourceViewData);
        }
      }
    }
    return finalResouceViewData;
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, attributeList, attributeObj, submitted,
      selectedFilter, ingredientGrossList, mfgOrderPriorityDetails, search, status, mfgOrdersResourceViewData, mfgOrdersOrderViewData, selectedTab} = this.state;
    const MANAGE_PAGE_TAB_LIST = isAuthorized("draftTab") ? mfgOrderConstant.MANAGE_PAGE_TAB_LIST : mfgOrderConstant.MANAGE_PAGE_TAB_LIST_WITHOUT_DRAFT;
    const MANAGE_PAGE_RESOURCE_TAB_LIST = mfgOrderConstant.MANAGE_PAGE_RESOURCE_TAB_LIST;

    let resourceDataList = [];
    if (selectedTab === "RESOURCEVIEW") {
      resourceDataList = this.prepareDataForResourceView(mfgOrdersResourceViewData);
    } else if (selectedTab === "ORDERVIEW") {
      resourceDataList = this.prepareDataForOrderView(mfgOrdersResourceViewData);
    }

    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, searchInput: this.state.searchInput }}></Redirect>  : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={make} alt="" className="page-icon" />
                  {mfgOrderConstant.MANAGE_MFG_ORDER_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder="Search by Mfg Order/Product"
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? {cursor: 'default'} : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {/*<Nav pullRight className="advance-filter">
                    <NavDropdown title={<div className="filter"> <i className="fa fa-ellipsis-v"></i>  </div>}
                      noCaret id="search-filter" className="filter-search filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)
                                : null))
                            }
                          </Row>
                        </Form>
                      </MenuItem>
                      <div className="search-btns">
                        <Button className="btn-cancel" onClick={this.closeSearchBox}>
                          Cancel
                        </Button>
                        <Button className="btn-save btn-fill btn-wd" onClick={this.advanceSearch}>
                          Search
                        </Button>
                      </div>
                    </NavDropdown>
                  </Nav>*/}

                  {this.state.selectedTab === "OPEN" && (
                    <Nav pullRight>
                      <NavDropdown title={<div className="filter"><img src={filter} alt="" /></div>}
                        noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                        {pagePropertyListConstant.MANAGE_HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                          <MenuItem eventKey={tempAttributeListObj.statusKey} className={selectedFilter === tempAttributeListObj.statusKey ? "active" : null}>
                            {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                          </MenuItem>
                        ))}
                      </NavDropdown>
                    </Nav>
                  )}

                  {isAuthorized("createMakeOrder") &&
                    <Button id={"mfgOrderId" + "_" + commonConstant.MENU_ACTION_MODE + "_" + mfgOrderConstant.CREATE_MFG_ORDER}
                      fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                  </Button>
                  }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>

              <Card
                content={
                  <div>
                    {status || search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ? 
                            <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                          {status ? 
                            <div className="filtertag">{StatusUtil.getStatusLabel(status)} <i id="filter-status" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                      </div>
                    : null }
                    <Tabs id="manage-mfg-order-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-tabs">
                      {MANAGE_PAGE_TAB_LIST.map((tempTabObj, index) => (
                        <Tab eventKey={tempTabObj.key} title={tempTabObj.title}>
                          {tableColumnList != null ?
                            <Row>
                              {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                                <Table columns={tableColumnList}
                                  data={tableDataList}
                                  config={tableConfig}
                                  getUpdatedTableDataList={this.getUpdatedTableDataList}
                                  that={this}
                                />
                                : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                            </Row>
                            : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                        </Tab>
                      ))}
                      <FormGroup className="location-dropdown">
                        <div className="export-btn" onClick={this.handleExportFileDownLoad}>
                          <img src={download} alt="" /> Export
                        </div>
                        <div className="location-control">
                          <img src={pin} alt="" />
                          <Select
                            classNamePrefix="react-select"
                            name="location"
                            value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                            onChange={(value) => this.handleLocationDropdownChange(value)}
                            options={[...this.state.facilityList]}
                            placeholder="Select Location"
                          />
                        </div>
                        {/*{ (this.state.locationName != "All" && this.state.locationName != "Select Location") &&
                          <Button className="btn-save btn-fill" onClick={this.openConfigureModal}>
                            Configure deadline
                          </Button> 
                        }*/}
                      </FormGroup>
                    </Tabs>
                    {/* <Tabs id="manage-mfg-main-tabs" activeKey={this.state.mainSelectedTab} onSelect={this.handleMainTabClick} className="table-tabs">
                        <Tab eventKey="ORDERSTATUS" title="ORDER STATUS">
                        </Tab>
                        <Tab eventKey="RESOURCESCHEDULETASK" title="RESOURCE - SCHEDULE TASK">
                          <Tabs id="manage-mfg-resource-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-tabs">
                            {MANAGE_PAGE_RESOURCE_TAB_LIST.map((tempTabObj, index) => (
                              <Tab eventKey={tempTabObj.key} title={tempTabObj.title}>
                                {tableColumnList != null ?
                                  <Row>
                                    {resourceDataList != null && resourceDataList.length > 0  ?
                                      <Table columns={tableColumnList}
                                        data={resourceDataList}
                                        config={tableConfig}
                                        getUpdatedTableDataList={this.getUpdatedTableDataList}
                                        that={this}
                                      />
                                      : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                  </Row>
                                  : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                              </Tab>
                            ))}
                          </Tabs>
                        </Tab>
                    </Tabs> */}

                    {this.state.openModal == true ?
                      <ConfigureModal
                        getCompleteDetails={this.getCompleteDetails}>
                      </ConfigureModal>
                      : null}

                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    mfgOrderList: state.mfgOrder.mfgOrderList,
    operationOrderStatusChangeStatus: state.mfgOrder.operationOrderStatusChangeStatus,
    mfgOrdersResourceViewData: state.mfgOrder.mfgOrdersResourceViewData,
    mfgOrdersOrderViewData: state.mfgOrder.mfgOrdersOrderViewData,
    mfgOrderPriorityDetails: state.mfgOrder.mfgOrderPriorityDetails,
    automationDraftList: state.automation.automationDraftList,
    facilityList: state.facility.facilityList,
    productGrossList: state.product.productGrossList,
    productList: state.product.productList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    facilityDetails: state.facility.facilityDetails,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedMfgOrderCode: selectedMfgOrderCode => dispatch(setSelectedMfgOrderCode(selectedMfgOrderCode)),
  getMfgOrderList: id => dispatch(getMfgOrderList(id)),
  getMfgOrderSearchList: id => dispatch(getMfgOrderSearchList(id)),
  getPriorityDetails: id => dispatch(getPriorityDetails(id)),
  getProductGrossList: (params) => dispatch(getProductGrossList(params)),
  downLoadXLSFile: (id) => dispatch(downLoadXLSFile(id)),
  updateAutomationDraftStatus: (draftOrderDetails) => dispatch(updateAutomationDraftStatus(draftOrderDetails)),
  getAutomationDraftOrderList: (params) => dispatch(getAutomationDraftOrderList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  setIngredientStatusList: (params) => dispatch(setIngredientStatusList(params)),
  updateMfgOrderPriority: (priorityList) => dispatch(updateMfgOrderPriority(priorityList)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: mfgOrderActionMode => dispatch(setActionMode(mfgOrderActionMode)),
  updateMfgOrderStatus: (mfgOrderDetails, mfgOrderId) => dispatch(updateMfgOrderStatus(mfgOrderDetails, mfgOrderId)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getFacilityDetails: selectedFacilityCode => dispatch(getFacilityDetails(selectedFacilityCode)),
  getMfgOrderOrderViewData: () => dispatch(getMfgOrderOrderViewData()),
  getMfgOrderResourceViewData: (view, location) => dispatch(getMfgOrderResourceViewData(view, location)),
  editOperationStatus: (request) => dispatch(editOperationStatus(request)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageMfgOrder);
