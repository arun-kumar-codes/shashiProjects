import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { getReceivedStockList } from "../../saleOrder/actions/saleOrderActions";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as commonConstant from '../../common/constant/commonConstant';
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil.js";
import PopupUtil from "../../common/util/popupUtil";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import LabelUtil from "modules/common/util/labelUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import MfgUtil from "./MfgUtil.js";
var Modal = require('react-bootstrap-modal')

class IngSelectModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      selectedIngObj: null,
      submitted: false,
      customErrorFlag: false,
      alert: null,
      tableDataKey: "tableDataList",
      tableDataList: [],
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  handleTableTextBoxChange = async (event) => {
    await PopularTableUtil.handleStockModalTextBoxChange(event, this, this.getSelectedTablekey());
    this.handleTableCalculation();
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleTableCalculation = () => {
    const { attributeObj, selectedIngObj } = this.state;
    var tempValue = MfgUtil.getSelectedIngTotal(this.state.tableDataList);
    attributeObj.selectedQuantity = CommonUtil.getFloatValue(CommonUtil.getFloatValue(selectedIngObj.issueQuantity) +
      CommonUtil.getFloatValue(tempValue),2);
    attributeObj.pendingQuantity = CommonUtil.getFloatValue(CommonUtil.getFloatValue(attributeObj.totalQuantity) -
      CommonUtil.getFloatValue(attributeObj.selectedQuantity), 2);
    this.setState({ attributeObj: attributeObj });
  }

  handleTableButtonMenuAction = (event) => {
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };

  componentDidMount = () => {
    this.setState({ openModal: true });
    this.props.getReceivedStockList({ entityCode: this.props.ingredientId, facilityId: this.props.facilityId });
    const commonAttributeList = pagePropertyListConstant.CREATE_MFG_ING_SELECT_MODAL_LIST(this);
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: this.props.itemList
    });
    this.setSelectedTableDetails(this.state.selectedTab);
    this.setSelectedIngredientDetails();
  };

  setSelectedIngredientDetails = () => {
    var tempObj = {};
    tempObj = this.props.itemList;
    let filteredData = this.props.itemList.filter(value => {
      if (this.props.ingredientId !== '') {
        return (
          String(value.ingredientId).toLowerCase() == String(this.props.ingredientId).toLowerCase()
        );
      }
      return (value);
    });
    tempObj.productId = this.props.productId;
    tempObj.ingredientId = filteredData[0].ingredientId;
    tempObj.totalQuantity = CommonUtil.getFloatValue(filteredData[0].totalQuantity, 2);
    tempObj.selectedQuantity = CommonUtil.getFloatValue(filteredData[0].issueQuantity, 2);
    tempObj.pendingQuantity = CommonUtil.getFloatValue(CommonUtil.getFloatValue(tempObj.totalQuantity) -
      CommonUtil.getFloatValue(tempObj.selectedQuantity), 2);
    this.setState({ attributeObj: tempObj, selectedIngObj: filteredData[0] });
  }

  setSelectedTableDetails = (selectedTab) => {
    const tableAttributeList = pagePropertyListConstant.CREATE_MFG_ING_SELECT_MODAL_TABLE_LIST(this);
    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.attributeList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.receivedStockList != null && prevProps.receivedStockList != this.props.receivedStockList) {
      this.setState({ tableDataList: [...this.props.receivedStockList] });
    }
  }

  closeModal = (event) => {
    this.props.getSelectedIngList(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    var tempObj = {};
    const { attributeObj } = this.state;
    if (CommonUtil.getFloatValue(attributeObj.pendingQuantity) != 0) {
      this.setState({ submitted: true, customErrorFlag: true });
      return true;
    }
    tempObj.ingredientId = this.props.ingredientId;
    tempObj.selectedIngList = this.getSelectedIngQuantityList(this.state.tableDataList);
    this.props.getSelectedIngList(tempObj);
    this.setState({ openModal: false, submitted: false });
  }

  getSelectedIngQuantityList = (tableDataList) => {
    var tempSelectedIngList = [];
    if (tableDataList.length > 0) {
      for (var i = 0; i < tableDataList.length; i++) {
        if (CommonUtil.getFloatValue(tableDataList[i].selectedQuantity) > 0) {
          tempSelectedIngList.push({ ...tableDataList[i] })
        }
      }
    }
    return tempSelectedIngList;
  };

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getSelectedIngList(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList,
      tableConfig, tableDataList, customErrorFlag } = this.state;
    const actionMode = commonConstant.EDIT_ACTION_MODE;

    return (
      <div>
        <Modal show={this.state.openModal}
          onHide={this.closeModal} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Ingredient selection</div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={

                          <div>
                            <div>
                              <Row className="content-section">
                                {attributeList != null &&
                                  attributeList.map((tempAttributeListObj, index) =>

                                    tempAttributeListObj.type == "FIXED" &&
                                      tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                      LabelUtil.fixedAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                                      : tempAttributeListObj.type == "TEXTBOX" &&
                                        tempAttributeListObj[actionMode + "ShowFlag"] == true ?
                                        TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                        : tempAttributeListObj.type == "DROPDOWN" &&
                                          tempAttributeListObj[actionMode + "ShowFlag"] == true ?
                                          DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                          : null
                                  )}
                              </Row>
                            </div>

                          </div>

                        }
                      />
                    </form>
                  </Col>
                </Row>

                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            {tableDataList != null && (
                              <Row>
                                {tableColumnList != null &&
                                  tableColumnList.length > 0 ?
                                  <div>
                                    <Table
                                      columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                  </div>
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>
                            )}

                          </div>
                        }
                        ftTextRight
                        legend={
                          <div>
                            <Button className="btn-cancel" onClick={this.closeModal}>
                              Cancel
                             </Button>
                            <Button className="btn-save btn-fill btn-wd" onClick={this.handleSave}>
                              Save
                            </Button>
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    receivedStockList: state.saleOrder.saleOrderStockList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getReceivedStockList: (params) => dispatch(getReceivedStockList(params)),
});
export default connect(mapStateToProps, mapDispatchToProps)(IngSelectModal);
