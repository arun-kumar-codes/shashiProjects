import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import { FormControl, InputGroup } from "react-bootstrap";
import SuggestionUtil from '../../common/util/suggestionUtil';
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import CommonUtil from '../../common/util/commonUtil';
import MfgUtil from "../views/MfgUtil";
import Switch from "react-bootstrap-switch";
import isAuthorized from "auth-plugin";
import moment from "moment";

export const CREATE_MFG_ORDER_PAGE_LIST = (that) => {
    return {
        attributeObj: {
            product: '',
            mfgOrderId: '',
            // customer: '',
            // createdDate: CommonUtil.getTodaysDate(),
            eta: '',
            locationResource: '',
            mfgLocation: '',
            productBatch: '',
            productQuantity: '',
            salesOrder: '',
            utiNumber: '',
            status: statusConstant.NEW_STATUS,
            itemList: [],
            operationsList: [],
            documentList: [],
        },
        attributeList: [
            {
                name: "mfgOrderId",
                type: "UNIQUE_CODE",
                label: "Order #",
                prefix: "MFG",
                required: false,
                inputType: "label",
                fieldWidth: 2,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                createMode: 'disabled',
                cloneMode: 'disabled',
                editMode: 'disabled',
                viewMode: 'disabled',
                numberOfRow: 0,
                maxLength: 10,
                minLength: 10,
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "mfgLocation",
                type: "DROPDOWN",
                label: "Mfg Location",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 3,
                customAttribute: true,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'disabled',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                placeholder: "Select",
                numberOfRow: 0,
                maxLength: 8,
                minLength: 8,
                mandatoryMsgText: "Field can not be empty.",
                options: []
            },
            {
                name: "product",
                type: "DROPDOWN",
                label: "Product Code",
                required: true,
                inputType: "label",
                fieldWidth: 4,
                customAttribute: true,
                createModeRemoveFlag: false,
                cloneModeRemoveFlag: false,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'disabled',
                viewMode: 'disabled',
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                options: []
            },
            // {
            //     name: "utiNumber",
            //     type: "FIXED",
            //     label: "UTI #",
            //     required: false,
            //     inputType: "label",
            //     fieldWidth: 2,
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     createMode: 'enable',
            //     cloneMode: 'enable',
            //     editMode: 'enable',
            //     viewMode: 'disabled',
            //     numberOfRow: 0,
            //     maxLength: 10,
            //     minLength: 10,
            //     mandatoryMsgText: "Field can not be empty.",
            // },
            // {
            //     name: "saleOrderId",
            //     type: "FIXED",
            //     label: "Sales Order",
            //     required: false,
            //     fieldWidth: 2,
            //     inputType: "text",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     createMode: 'disabled',
            //     cloneMode: 'disabled',
            //     editMode: 'disabled',
            //     viewMode: 'disabled',
            //     placeholder: "",
            //     numberOfRow: 0,
            //     maxLength: 9,
            //     minLength: 9,
            //     mandatoryMsgText: "Field can not be empty.",
            // },
            // {
            //     name: "customer",
            //     type: "FIXED",
            //     label: "Customer",
            //     required: false,
            //     fieldWidth: 2,
            //     inputType: "text",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     createMode: 'enable',
            //     cloneMode: 'enable',
            //     editMode: 'enable',
            //     viewMode: 'disabled',
            //     placeholder: "",
            //     numberOfRow: 0,
            //     maxLength: 100,
            //     minLength: 3,
            //     mandatoryMsgText: "Field can not be empty.",
            // },
            {
                name: "productUOM",
                type: "DROPDOWN",
                label: "UoM",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: "disabled",
                cloneMode: "disabled",
                editMode: "disabled",
                viewMode: "disabled",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                placeholder: "Select",
                mandatoryMsgText: "Field can not be empty.",
                dataDictionaryFlag: true,
                dataDictionaryId: "unitofMesurementList",
                options: [],
            },
            {
                name: "productBatch",
                type: "TEXTBOX",
                label: "Product Batch",
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 3,
                inputType: "text",
                customBlurAttribute: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'disabled',
                viewMode: 'disabled',
                placeholder: "",
                numberOfRow: 0,
                maxLength: 25,
                minLength: 3,
                mandatoryMsgText: "Field can not be empty.",
                customMessage: "Batch already exist."
            },
            // {
            //     name: "createdDate",
            //     type: "DATE",
            //     label: "Created Date",
            //     required: true,
            //     fieldWidth: 3,
            //     fieldWidthSmall: 3,
            //     inputType: "date",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     createMode: 'disabled',
            //     cloneMode: 'disabled',
            //     editMode: 'disabled',
            //     viewMode: 'disabled',
            //     placeholder: "",
            //     numberOfRow: 0,
            //     mandatoryMsgText: "Field can not be empty.",
            // },
            {
                name: "productQuantity",
                type: "TEXTBOX",
                label: "Quantity",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 3,
                inputType: "number",
                pattern: "^[0-9]*$",
                minValue: 0,
                customAttribute: true,
                showUOM: false,
                uomName: "productUOM",
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                placeholder: "Select",
                numberOfRow: 0,
                maxLength: 10,
                minLength: 1,
                mandatoryMsgText: "Field can not be empty.",
            },
            // {
            //     name: "locationResource",
            //     type: "DROPDOWN",
            //     label: "Location Resource",
            //     required: false,
            //     fieldWidth: 2,
            //     fieldWidthSmall: 3,
            //     customAttribute: false,
            //     createMode: 'enable',
            //     cloneMode: 'enable',
            //     editMode: 'disabled',
            //     viewMode: 'disabled',
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     placeholder: "Select",
            //     numberOfRow: 0,
            //     maxLength: 36,
            //     minLength: 3,
            //     mandatoryMsgText: "Field can not be empty.",
            //     options: []
            // },
            {
                name: "eta",
                type: "DATE",
                label: "ETA",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 3,
                inputType: "date",
                backDateNotAllowed: true,
                cloneModeRemoveFlag: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                placeholder: "",
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "productUOM",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                name: "status",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                name: "version",
                type: "TEMP",
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
            },
            {
                name: "ingredients",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
            },
            {
                name: "operationsList",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
            },
            {
                name: "itemList",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
            },
            {
                name: "productId",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
            },
            {
                id: "documentList",
                name: "documentList",
                name: "documentList",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            }

        ],
    }
};

export const CREATE_MFG_INGREDIENT_TABLE_LIST = (that) => {
    return {
        tableData: [{
            ingredient: '',
            qtyPerUnit: '',
            ingredientUOM: '',
            pricePerUnit: '',
            usgCostPerUnit: null
        }],
        tableColumnList: [
            {
                Header: "Ingredient",
                id: "ingredientId",
                name: "ingredientId",
                accessor: "ingredientId",
                style: {
                    flex: '0 0 20%'
                },
                required: true,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-width"
                            title={original.ingredientId ? "ING-" + original.ingredientId + "|" + original.ingredientName : "" }
                        >
                            <SuggestionUtil
                                className={that.state.submitted && !value ? 'required-error' : ''}
                                searchOptionList={["productId", "productName", "productSKU"]}
                                id={'productId' + '_' + index}
                                options={that.state.ingredientList}
                                selectedListKeys={["productId", "productSKU"]}
                                selectedAttributeList={that.state.itemList}
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                setNoFocus={true}
                                reSelect={false}
                                placeholder=""
                                value={original.ingredientId ? "ING-" + original.ingredientId + "|" + original.ingredientName : ''}
                                selectedValue={original.ingredientId ? "ING-" + original.ingredientId + "|" + original.ingredientName : ''}
                                onChange={(e) => that.handleTableSuggestionChange(e, 'productId' + '_' + index,
                                    ["productId", "productName"])}
                                handleSuggestionChange={that.handleTableSuggestionChange}
                            />
                        </div>

                    )
                }
            },
            {
                Header: "Per Unit Qty",
                id: "qtyPerUnit",
                accessor: "qtyPerUnit",
                name: "qtyPerUnit",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup
                            className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'qtyPerUnit' + '_' + index}
                                name={'qtyPerUnit'}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                onChange={(e) => that.handleTableTextBoxChange(e)}
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.qtyPerUnit}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>
                                {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM)}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            // {
            //     Header: "Cost Per Unit ($)",
            //     id: "usgCostPerUnit",
            //     accessor: "usgCostPerUnit",
            //     name: "usgCostPerUnit",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     required: false,
            //     type: "text",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     className: "input-field",
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (
            //             <InputGroup>
            //                 <FormControl id={'usgCostPerUnit' + '_' + index} name={'usgCostPerUnit'}
            //                     onChange={that.handleTableTextBoxChange}
            //                     disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
            //                     min={0}
            //                     value={CommonUtil.getFloatValue(original.usgCostPerUnit)}
            //                     onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
            //                     onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
            //                     maxLength={10}
            //                     minLength={1} />
            //                 {/* <InputGroup.Addon>
            //                     {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon> */}
            //             </InputGroup>
            //         )
            //     }
            // },
            {
                Header: "Total Qty",
                id: "totalQuantity",
                accessor: "totalQuantity",
                name: "totalQuantity",
                required: false,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                    <InputGroup
                        className={that.state.submitted && !value ? 'required-error' : ''}>
                        <FormControl id={'totalQuantity' + '_' + index}
                            name={'totalQuantity'}
                            data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                            min={0}
                            // onChange={(e) => that.handleTableTextBoxChange(e)}
                            disabled={true}
                            value={CommonUtil.getFloatValue(original.totalQuantity, true)}
                            onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                            onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                            maxLength={10}
                            minLength={1} />
                        <InputGroup.Addon>
                            {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.ingredientUOM)}</InputGroup.Addon>
                    </InputGroup>
                        //  CommonUtil.initializeValue(original.ingredientUOM)
                    )
                }
            },
            {
                id: "issueQuantity",
                name: "issueQuantity",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            // {
            //     Header: "Issue Qty",
            //     id: "issueQuantity",
            //     accessor: "issueQuantity",
            //     name: "issueQuantity",
            //     required: false,
            //     type: "text",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     createModeShowFlag: false,
            //     cloneModeShowFlag: false,
            //     editModeShowFlag: false,
            //     viewModeShowFlag: false,
            //     className: "input-field",
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         // let leftQuantity = MfgUtil.getLeftQuantity(original);
            //         // let isDoneStatus = !CommonUtil.isViewMode(that.props.actionMode) && MfgUtil.isDoneStatus(that);
            //         let issueQuantity = CommonUtil.isViewMode(that.props.actionMode) ?
            //             CommonUtil.getFloatValue(original.issuedQuantity) :
            //             CommonUtil.getFloatValue(original.issueQuantity)
            //         // let orderStatus = MfgUtil.getIngredientOrderStockStatus(that, original.ingredientId,
            //         //     that.state.attributeObj.mfgLocation);
            //         // let isMaterialInStock = orderStatus == statusConstant.IN_STOCK_STATUS ? true : false;

            //         return (
            //             // <div className={that.state.submitted && leftQuantity > 0 &&
            //             //     isDoneStatus ? 'required-error link' :
            //             //     isDoneStatus ? 'link' :
            //             //         CommonUtil.isViewMode(that.props.actionMode) ? 'link' : ''}
            //             //     id={'issueQuantity' + "_" + original.ingredientId + '_' + index}
            //             //     name={'issueQuantity'}
            //             //     onClick={isDoneStatus && isMaterialInStock ?
            //             //         (e) => that.handleTableLinkClick(e, that) :
            //             //         CommonUtil.isViewMode(that.props.actionMode) ?
            //             //             (e) => that.handleTableViewStockClick(e, that) :
            //             //             null}>
            //             <div>
            //                 {CommonUtil.getFloatValue(issueQuantity)}
            //             </div>
            //         )
            //     }
            // },
            // {
            //     Header: "Amount ($)",
            //     id: "amount",
            //     accessor: "amount",
            //     name: "amount",
            //     required: false,
            //     type: "text",
            //     inputType: "number",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: false,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     className: "input-field",
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         let totalAmount = Number(original.totalQuantity) * Number(original.usgCostPerUnit);
            //         totalAmount = CommonUtil.getFloatValue(totalAmount, true);
  
            //         return (
            //             <InputGroup
            //                 className={that.state.submitted && !value ? 'required-error' : ''}>
            //                 <FormControl id={'amount' + '_' + index}
            //                     name={'amount'}
            //                     data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
            //                     min={0}
            //                     // onChange={(e) => that.handleTableTextBoxChange(e)}
            //                     disabled={true}
            //                     value={totalAmount}
            //                     onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
            //                     onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
            //                     maxLength={10}
            //                     minLength={1} />
            //                 {/* <InputGroup.Addon>
            //                     {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.usgUOM)}</InputGroup.Addon> */}
            //             </InputGroup>
            //         )
            //     }
            // },
            // {
            //     id: "pricePerUnit",
            //     name: "pricePerUnit",
            //     type: "TEMP",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            // },
            {
                Header: "Cost",
                id: "pricePerUnit",
                accessor: "pricePerUnit",
                name: "pricePerUnit",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                required: false,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup>
                            <FormControl id={'pricePerUnit' + '_' + index} name={'pricePerUnit'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                min={0}
                                value={CommonUtil.getFloatValue(original.pricePerUnit)}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Total Cost",
                id: "totalCosts",
                accessor: "totalCosts",
                name: "totalCosts",
                required: false,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup
                            className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'totalCosts' + '_' + index}
                                name={'totalCosts'}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                onChange={(e) => that.handleTableTextBoxChange(e)}
                                disabled={true}
                                value={original.totalCosts}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Availability",
                id: "availability",
                accessor: "availability",
                name: "availability",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: false,
                viewModeShowFlag: false,
                style: {
                    flex: '0 0 120px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;

                    original.stock =  original.stock || 1;
                    original.totalQuantity =  original.totalQuantity || 0;
                    original.issuedQuantity =  original.issuedQuantity || 0;

                    // const stockValue = CommonUtil.getFloatValue(Number(original.stock) * Number(original.usgPackSizeQty),2);
                    let orderStatus = CommonUtil.getFloatValue(original.stock, true) >= CommonUtil.getFloatValue(original.totalQuantity, true) - CommonUtil.getFloatValue(original.issuedQuantity, true) ? statusConstant.IN_STOCK_STATUS : statusConstant.NOT_AVAILABLE_STATUS;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(orderStatus)
                        }}>
                            {StatusUtil.getStatusLabel(orderStatus)}
                        </div>
                    )
                }
            },
            // {
            //     Header: "Material Status",
            //     id: "materialStatus",
            //     name: "materialStatus",
            //     accessor: "materialStatus",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: false,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     style: {
            //         flex: '0 0 120px'
            //     },
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         let tempValue = CommonUtil.getFloatValue(original.issueQuantity);
            //         let materialStatusFlag = tempValue > 0 ? true : original.materialStatus;
            //         let orderStatus = MfgUtil.getIngredientOrderStockStatus(that, original.ingredientId,
            //             that.state.attributeObj.mfgLocation);
            //         let isMaterialInStock = orderStatus == statusConstant.IN_STOCK_STATUS ? true : false;
            //         return (
            //             <Switch
            //                 id={'materialStatus' + '_' + index}
            //                 inverse={false}
            //                 value={materialStatusFlag}
            //                 disabled={!isMaterialInStock || CommonUtil.isCreateMode(that.props.actionMode) ||
            //                     CommonUtil.isViewMode(that.props.actionMode) ? true : false}
            //                 offColor={'primary'}
            //                 onColor={'success'}
            //                 onText="Issued" offText="Pending" defaultValue={false}
            //                 onChange={(el, state) => that.handleTableSwitchChange(el, state)}
            //             />
            //         )
            //     }
            // },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 60px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let tempValue = CommonUtil.getFloatValue(original.issueQuantity);
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon
                                disabled={(CommonUtil.isViewMode(that.props.actionMode) || that.state.attributeObj.status == statusConstant.COMPLETED_STATUS) ? true : false}>
                                <div className="circle">
                                    {/* {tempValue > 0 ?
                                        <i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-truck" />
                                        :
                                        isNewRowAdded ? */}
                                    <i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                        className="fa fa-trash" onClick={
                                            (!CommonUtil.isViewMode(that.props.actionMode) || that.state.attributeObj.status !== statusConstant.COMPLETED_STATUS) ?
                                                (e) => that.handleDeleteRowPopup(e) : null} />
                                    {/* : null
                                    } */}
                                </div>
                            </Button>
                        </div>
                    )
                }
            },
            {
                id: "ingredientUOM",
                name: "ingredientUOM",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                id: "ingredientName",
                name: "ingredientName",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                id: "status",
                name: "status",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            // {
            //     id: "documentList",
            //     name: "documentList",
            //     name: "documentList",
            //     type: "TEMP",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: false,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            // }

        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const MFG_ORDER_STOCK_VIEW_MODAL_TABLE_LIST = (that) => {
    return {
        tableData: [
        ],
        tableColumnList: [
            {
                Header: "Received Date",
                id: "createddate",
                name: "createddate",
                accessor: "createddate",
                required: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                inputType: "text",
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        CommonUtil.getCurrentZoneFormatDate(value)
                    )
                }
            },
            {
                Header: "Batch",
                id: "uti",
                accessor: "uti",
                name: "uti",
                required: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={"uti" + "_" + index} name={"uti"}
                            onChange={that.handleTableTextBoxChange}
                            disabled={true}
                            value={value} />
                    );
                },
            },
            {
                Header: "Quantity",
                id: "selectedQuantity",
                accessor: "selectedQuantity",
                name: "selectedQuantity",
                required: true,
                inputType: "number",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup>
                            <FormControl id={"selectedQuantity" + "_" + index}
                                data-type={'number'}
                                onPaste={(e) => { e.preventDefault(); return false }}
                                name={"selectedQuantity"}
                                disabled={true} value={value}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon> {that.state.entityUOM} </InputGroup.Addon>
                        </InputGroup>
                    );
                },
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};

export const CREATE_MFG_OPERATION_TABLE_LIST = (that) => {
    return {
        tableData: [],
        tableColumnList: [
            {
                Header: "Process",
                id: "operationId",
                name: "operationId",
                accessor: "operationId",
                required: true,
                type: "text",
                style: {
                    flex: '0 0 20%'
                },
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    // let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                    //     that.state.attributeObj.productId, original.operationId);
                    return (
                        <div className="full-width"
                            title={original.operationId ? original.operationId + "|" + original.operationName : ''}
                        >
                            <SuggestionUtil
                                className={that.state.submitted && !value ? 'required-error' : ''}
                                searchOptionList={["operationId", "operationName"]}
                                id={'operationId' + '_' + index}
                                options={that.state.operationList}
                                selectedListKeys={['operationId']}
                                selectedAttributeList={that.state.operationsList}
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                setNoFocus={true}
                                reSelect={false}
                                placeholder=""
                                value={original.operationId ? original.operationId + "|" + original.operationName : ''}
                                selectedValue={original.operationId ? original.operationId + "|" + original.operationName : ''}
                                onChange={(e) => that.handleTableSuggestionChange(e, 'operationId' + '_' + index,
                                    ["operationId", "operationName"])}
                                handleSuggestionChange={that.handleTableSuggestionChange}
                            />
                        </div>
                    )
                }
            },
            {
                Header: "Production Time/Unit",
                id: "timePerUnit",
                accessor: "timePerUnit",
                name: "timePerUnit",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    // let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                    //     that.state.attributeObj.productId, original.operationId);
                    return (
                        <InputGroup
                            className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'timePerUnit' + '_' + index}
                                name={'timePerUnit'}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                onChange={(e) => that.handleTableTextBoxChange(e)}
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.timePerUnit}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>hrs</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Total Production Time",
                id: "totalProductionTime",
                accessor: "totalProductionTime",
                name: "totalProductionTime",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup
                            className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'totalProductionTime' + '_' + index}
                                name={'totalProductionTime'}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                onChange={(e) => that.handleTableTextBoxChange(e)}
                                disabled={true}
                                value={original.totalProductionTime}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>hrs</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Cost/Unit",
                id: "costPerUnit",
                accessor: "costPerUnit",
                name: "costPerUnit",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    // let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                    //     that.state.attributeObj.productId, original.operationId);
                    return (
                        <InputGroup
                            className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'costPerUnit' + '_' + index}
                                name={'costPerUnit'}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                onChange={(e) => that.handleTableTextBoxChange(e)}
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.costPerUnit}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Total Cost",
                id: "totalCosts",
                accessor: "totalCosts",
                name: "totalCosts",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup
                            className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'totalCosts' + '_' + index}
                                name={'totalCosts'}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                onChange={(e) => that.handleTableTextBoxChange(e)}
                                disabled={true}
                                value={original.totalCosts}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            // {
            //     Header: "Status",
            //     id: "status",
            //     accessor: "status",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: false,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     style: {
            //         flex: '0 0 120px'
            //     },
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         var tempValue = !original.status ? statusConstant.NEW_STATUS : original.status;
            //         original.status = tempValue;
            //         return (
            //             <div className="full-td progress-button" style={{
            //                 backgroundColor: StatusUtil.getStatusColor(tempValue)
            //             }}>
            //                 <div className="items">{StatusUtil.getStatusLabel(tempValue)}</div>

            //                 <div className="items">
            //                     {!CommonUtil.isViewMode(that.props.actionMode) && !CommonUtil.isCreateOrCloneMode(that.props.actionMode) ?
            //                         <Nav pullRight>
            //                             <NavDropdown id={'status'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
            //                                 {OPERATION_STATUS_LIST.map((tempAttributeListObj, index1) => (
            //                                     <MenuItem name="status" id={tempAttributeListObj.statusKey + "_" + index}
            //                                         onClick={(e) => that.handleTableButtonMenuAction(e, original.operationId)}>
            //                                         <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
            //                                         {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
            //                                     </MenuItem>
            //                                 ))}
            //                             </NavDropdown>
            //                         </Nav>
            //                         : null}
            //                 </div>

            //             </div>
            //         )
            //     }
            // },
            // {
            //     Header: "Document",
            //     id: "document",
            //     accessor: "document",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: false,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            //     style: {
            //         flex: '0 0 120px'
            //     },
            //     Cell: ({ cell }) => {
            //         var value = cell.value;
            //         const { index, original } = cell.row;
            //         let documentCount = MfgUtil.getDocumentCount(original.documentList) +
            //             CommonUtil.isNaNValue(parseInt(original.documentCount));
            //         documentCount = CommonUtil.isNaNValue(documentCount);
            //         return (
            //             <a className={documentCount > 0 ? `link` : ''} id={original.operationId + "_" + that.props.selectedMfgOrderCode + "_" + index}
            //                 onClick={(e) => documentCount > 0 ? MfgUtil.handleTableUploadButtonClick(e, that) : null}>
            //                 {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
            //             </a>
            //         )
            //     }
            // },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                style: {
                    flex: '0 0 60px'
                },
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var tempStatus = original.status;
                    let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                        that.state.attributeObj.productId, original.operationId);
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle">
                                    {tempStatus == statusConstant.COMPLETED_STATUS ?
                                        <i title="Completed" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-thumbs-up" />
                                        :
                                        // isNewRowAdded ?
                                        <i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-trash" onClick={(e) => that.handleDeleteRowPopup(e)} />
                                        // : null
                                    }
                                </div>
                            </Button>
                        </div>
                    )
                }
            },
            {
                id: "documentList",
                name: "documentList",
                name: "documentList",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                id: "operationName",
                name: "operationName",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const CREATE_MFG_RESOURCE_VIEW_TABLE_LIST = (that) => {
    return {
        tableData: [],
        tableColumnList: [
            {
                Header: "Resource Name",
                id: "resourceName",
                style: {
                    flex: '0 0 60px'
                },
                accessor: "step",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var tempValue = index + 1;
                    return (
                        <div>{tempValue.toString().padStart(2, "0")} </div>
                    )
                }
            },
            {
                Header: "Operation",
                id: "operation",
                name: "operation",
                accessor: "operation",
                required: true,
                type: "text",
                style: {
                    flex: '0 0 35%'
                },
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    // let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                    //     that.state.attributeObj.productId, original.operationId);
                    return (
                        <FormControl id={'operation' + '_' + index}
                            name={'operation'}
                            onChange={(e) => that.handleTableTextBoxChange(e)}
                            disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={original.operation}
                        />
                    )
                }
            },
            {
                Header: "Order Details",
                id: "orderDetails",
                accessor: "orderDetails",
                name: "orderDetails",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={'orderDetails' + '_' + index}
                            name={'orderDetails'}
                            onChange={(e) => that.handleTableTextBoxChange(e)}
                            disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={original.orderDetails}
                        />
                    )
                }
            },
            {
                Header: "Product",
                id: "productName",
                accessor: "productName",
                name: "productName",
                required: true,
                type: "text",
                inputType: "number",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    // let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                    //     that.state.attributeObj.productId, original.operationId);
                    return (
                        <FormControl id={'productName' + '_' + index}
                            name={'productName'}
                            onChange={(e) => that.handleTableTextBoxChange(e)}
                            disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={original.productName}
                        />
                    )
                }
            },
            {
                Header: "Production Quantity",
                id: "productionQuantity",
                accessor: "productionQuantity",
                disableSortBy: true,
                disableFilters: true,
                createModeShowFlag: true,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var tempValue = !original.status ? statusConstant.NEW_STATUS : original.status;
                    original.status = tempValue;
                    return (
                        <div className="full-td progress-button" style={{
                            backgroundColor: StatusUtil.getStatusColor(tempValue)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(tempValue)}</div>

                            <div className="items">
                                {!CommonUtil.isViewMode(that.props.actionMode) && !CommonUtil.isCreateOrCloneMode(that.props.actionMode) ?
                                    <Nav pullRight>
                                        <NavDropdown id={'status'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
                                            {OPERATION_STATUS_LIST.map((tempAttributeListObj, index1) => (
                                                <MenuItem name="status" id={tempAttributeListObj.statusKey + "_" + index}
                                                    onClick={(e) => that.handleTableButtonMenuAction(e, original.operationId)}>
                                                    <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
                                                    {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                                                </MenuItem>
                                            ))}
                                        </NavDropdown>
                                    </Nav>
                                    : null}
                            </div>

                        </div>
                    )
                }
            },
            {
                Header: "Document",
                id: "document",
                accessor: "document",
                createModeShowFlag: true,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    let documentCount = MfgUtil.getDocumentCount(original.documentList) +
                        CommonUtil.isNaNValue(parseInt(original.documentCount));
                    documentCount = CommonUtil.isNaNValue(documentCount);
                    return (
                        <a className={documentCount > 0 ? `link` : ''} id={original.operationId + "_" + that.props.selectedMfgOrderCode + "_" + index}
                            onClick={(e) => documentCount > 0 ? MfgUtil.handleTableUploadButtonClick(e, that) : null}>
                            {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
                        </a>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                style: {
                    flex: '0 0 60px'
                },
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var tempStatus = original.status;
                    // let isNewRowAdded = MfgUtil.isNewOptRowAdded(that,
                    //     that.state.attributeObj.productId, original.operationId);
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle">
                                    {tempStatus == statusConstant.COMPLETED_STATUS ?
                                        <i title="Completed" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-thumbs-up" />
                                        :
                                        // isNewRowAdded ?
                                        <i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-trash" onClick={(e) => that.handleDeleteRowPopup(e)} />
                                        // : null
                                    }
                                </div>
                            </Button>
                        </div>
                    )
                }
            },
            {
                id: "documentList",
                name: "documentList",
                name: "documentList",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const CREATE_MFG_DOCUMENT_MODAL_TABLE_LIST =
{
    tableData: {
        documentId: '',
        documentType: '',
        documentName: '',
        documentExpiryDate: '',
        fileType: 'application/pdf',
        documentURL: ''
    },
    tableColumnList: [
        {
            title: "Document Type",
            name: "documentType",
            type: "DROPDOWN",
            dataDictionaryFlag: true,
            dataDictionaryId: 'documentTypeList',
            options: [],
            inputType: "text",
            createMode: 'enable',
            required: true,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            title: "QC Name/Number",
            name: "documentName",
            type: "TEXTBOX",
            inputType: "text",
            fieldWidth: 2,
            configurePipeLine: 'disabled',
            modifyPipeLine: 'disabled',
            clonePipeLine: 'disabled',
            createBatch: 'enable',
            modifyBatch: 'enable',
            maxLength: 55,
            minLength: 3,
            required: true,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            title: "Expiry Date",
            name: "documentExpiryDate",
            type: "TEXTBOX",
            fieldWidth: 2,
            inputType: "date",
            configurePipeLine: 'disabled',
            modifyPipeLine: 'disabled',
            clonePipeLine: 'disabled',
            createBatch: 'enable',
            modifyBatch: 'enable',
        },
        {
            title: "QC Type",
            name: "qcType",
            type: "DROPDOWN",
            dataDictionaryFlag: true,
            dataDictionaryId: 'qcTypeList',
            options: [],
            inputType: "text",
            createMode: 'enable'
        },
        {
            title: "",
            name: "action",
            type: "BUTTON",
            downloadIcon: true,
            removeIcon: true,
        },
        {
            name: "version",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: false,
        },
    ],
};

export const CREATE_MFG_ING_SELECT_MODAL_LIST = (that) => ({
    attributeObj: {},
    attributeList: [
        {
            name: "productId",
            type: "FIXED",
            label: "Product",
            required: false,
            inputType: "label",
            fieldWidth: 3,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "ingredientId",
            type: "FIXED",
            label: "Ingredient",
            required: false,
            inputType: "label",
            fieldWidth: 3,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "totalQuantity",
            type: "FIXED",
            label: "Required",
            required: false,
            inputType: "label",
            fieldWidth: 2,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "selectedQuantity",
            type: "FIXED",
            label: "Selected",
            required: false,
            inputType: "label",
            fieldWidth: 2,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            customMessage: "Please select required Quantity."
        },
        {
            name: "pendingQuantity",
            type: "FIXED",
            label: "Pending",
            required: false,
            inputType: "label",
            fieldWidth: 2,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
    ],
});

export const CREATE_MFG_ING_SELECT_MODAL_TABLE_LIST = (that) => {
    return {
        tableData: [],
        tableColumnList: [
            {
                Header: "Received Date",
                id: "createddate",
                name: "createddate",
                accessor: "createddate",
                required: true,
                style: {
                    flex: "0 0 150px"
                },
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        CommonUtil.getCurrentZoneFormatDate(value)
                    )
                },

            },
            {
                Header: "PO/MO Number",
                id: "ordernumber",
                accessor: "ordernumber",
                name: "ordernumber",
                required: true,
                style: {
                    flex: "0 0 110px"
                },
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={"ordernumber" + "_" + index} name={"ordernumber"}
                            onChange={that.handleTableTextBoxChange}
                            disabled={true}
                            value={value} />
                    );
                },
            },
            {
                Header: "Quantity",
                id: "remainingstock",
                accessor: "remainingstock",
                name: "remainingstock",
                required: true,
                inputType: "number",
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: false,
                viewModeShowFlag: false,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let remainingstockValue = CommonUtil.getFloatValue(value, 2)
                    return (
                        <InputGroup>
                            <FormControl id={"remainingstock" + "_" + index}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={"remainingstock"}
                                disabled={true} value={remainingstockValue}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon> {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)} </InputGroup.Addon>
                        </InputGroup>
                    );
                },
            },
            {
                Header: "Selected Qty",
                id: "selectedQuantity",
                accessor: "selectedQuantity",
                name: "selectedQuantity",
                required: true,
                inputType: "number",
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: false,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup>
                            <FormControl id={"selectedQuantity" + "_" + index}
                                onChange={that.handleTableTextBoxChange}
                                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                min={0}
                                name={"selectedQuantity"}
                                disabled={false} value={value}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon> {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM)} </InputGroup.Addon>
                        </InputGroup>
                    );
                },
            },
            {
                Header: "Batch",
                id: "batch",
                accessor: "batch",
                name: "batch",
                required: true,
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: false,
                viewModeShowFlag: false,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={"batch" + "_" + index} name={"batch"}
                            onChange={that.handleTableTextBoxChange}
                            disabled={true}
                            value={value} />
                    );
                },
            },
            {
                Header: "Blocked Stock",
                id: "blockedstock",
                accessor: "blockedstock",
                name: "blockedstock",
                required: false,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={"blockedstock" + "_" + index} name={"blockedstock"}
                            onChange={that.handleTableTextBoxChange}
                            disabled={true}
                            value={value} />
                    );
                },
            },
            {
                Header: "UTI #",
                id: "uti",
                accessor: "uti",
                name: "uti",
                required: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={"uti" + "_" + index} name={"uti"}
                            onChange={that.handleTableTextBoxChange}
                            disabled={true}
                            value={value} />
                    );
                },
            },
            {
                id: "pk",
                name: "pk",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                id: "sk",
                name: "sk",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};

export const MANAGE_MFG_OPEN_ORDER_PRIORITY_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Priority",
                id: "priority",
                style: {
                    flex: '0 0 60px'
                },
                accessor: "priority",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let tempPriority = MfgUtil.getOrderPriority(that,
                        original.mfgOrderId, original.mfgLocation);
                    return (
                        <div>{CommonUtil.getFloatValue(tempPriority)} </div>
                    )
                }
            },
            {
                Header: "Order",
                id: "mfgOrderId",
                accessor: "mfgOrderId",
            },
            {
                Header: "Product",
                id: "productName",
                accessor: "productName",
                style: {
                    flex: '0 0 15%'
                },
            },
            {
                Header: "Qty",
                style: {
                    flex: '0 0 60px'
                },
                id: "quantity",
                accessor: "quantity"
            },
            {
                Header: "Batch",
                id: "productBatch",
                accessor: "productBatch",
            },
            {
                Header: "Total Cost",
                id: "totalMfgCost",
                accessor: "totalMfgCost",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let totalMfgCost = CommonUtil.getFloatValue(original.totalIngredientValue) +
                        CommonUtil.getFloatValue(original.totalOperationValue);
                    return (
                        <div>{CommonUtil.getFloatValue(totalMfgCost, true)} {that.props.currencyCode} </div>
                    )
                }
            },
            {
                Header: "ETA",
                id: "eta",
                accessor: "eta"
            },
            {
                Header: "Ingredient",
                id: "availability",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let orderStatus = MfgUtil.getLeastOrderStockStatus(that, original.mfgOrderId,
                        original.mfgLocation);
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(orderStatus)
                        }}>
                            {StatusUtil.getStatusLabel(orderStatus)}
                        </div>
                    )
                }
            },
            {
                Header: "Process",
                id: "status",
                accessor: "status",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value),
                            borderRadius: '5px'
                        }}>
                            {StatusUtil.getStatusLabel(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 60px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                {isAuthorized("editMakeOrder") &&
                                    <div className="circle">
                                        <i title="edit" id={original.mfgOrderId + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }
                                {isAuthorized("viewMakeOrder") &&
                                    <div className="circle">
                                        <i title="view" id={original.mfgOrderId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                                            className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: true
        }
    }
};

export const MANAGE_MFG_OPEN_ORDER_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Order",
                id: "mfgOrderId",
                accessor: "mfgOrderId",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>MFG-{value}</>
                    )
                }
            },
            {
                Header: "Product",
                id: "productName",
                accessor: "productName",
                style: {
                    flex: '0 0 15%'
                },
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>PO-{value}</>
                    )
                }
            },
            {
                Header: "Qty",
                style: {
                    flex: '0 0 80px'
                },
                id: "productQuantity",
                accessor: "productQuantity"
            },
            {
                Header: "Batch",
                id: "productBatch",
                accessor: "productBatch",
            },
            {
                Header: "Total Cost",
                id: "totalValue",
                accessor: "totalValue",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    // let totalMfgCost = CommonUtil.getFloatValue(original.totalIngredientValue) +
                    //     CommonUtil.getFloatValue(original.totalOperationValue);
                    return (
                        <div>{CommonUtil.getFloatValue(value, true)} {that.props.currencyCode} </div>
                    )
                }
            },
            {
                Header: "ETA",
                id: "eta",
                accessor: "eta",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
                    )
                }
            },
            // {
            //     Header: "Ingredient",
            //     id: "availability",
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         let orderStatus = MfgUtil.getLeastOrderStockStatus(that, original.mfgOrderId,
            //             original.mfgLocation);
            //         return (
            //             <div className="full-td" style={{
            //                 backgroundColor: StatusUtil.getStatusColor(orderStatus)
            //             }}>
            //                 {StatusUtil.getStatusLabel(orderStatus)}
            //             </div>
            //         )
            //     }
            // },
            {
                Header: "Process",
                id: "status",
                accessor: "status",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value),
                            borderRadius: '5px'
                        }}>
                            {StatusUtil.getStatusLabel(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 60px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                {isAuthorized("editMakeOrder") &&
                                    <div className="circle">
                                        <i title="edit" id={original.mfgOrderId + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index}
                                            className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }
                                {isAuthorized("viewMakeOrder") &&
                                    <div className="circle">
                                        <i title="view" id={original.mfgOrderId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                                            className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_MFG_COMPLETED_ORDER_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Order",
                id: "mfgOrderId",
                accessor: "mfgOrderId",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>MFG-{value}</>
                    )
                }
            },
            {
                Header: "Product",
                id: "productName",
                accessor: "productName",
                style: {
                    flex: '0 0 20%'
                },
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>PO-{value}</>
                    )
                }
            },
            {
                Header: "Qty",
                style: {
                    flex: '0 0 60px'
                },
                id: "productQuantity",
                accessor: "productQuantity"
            },
            {
                Header: "Batch",
                id: "productBatch",
                accessor: "productBatch",
            },
            {
                Header: "Total Cost",
                id: "totalValue",
                accessor: "totalValue",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    // let totalValue = CommonUtil.getFloatValue(original.totalIngredientValue) +
                    //     CommonUtil.getFloatValue(original.totalOperationValue);
                    return (
                        <div>{CommonUtil.getFloatValue(original.totalValue, true)} {that.props.currencyCode} </div>
                    )
                }
            },
            {
                Header: "ETA",
                id: "eta",
                accessor: "eta",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
                    )
                }
            },
            {
                Header: "Process",
                id: "status",
                accessor: "status",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value),
                            borderRadius: '5px'
                        }}>
                            {StatusUtil.getStatusLabel(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 60px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                <div className="circle">
                                    <i title="view" id={original.mfgOrderId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                                        className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_MFG_RESOURCEVIEW_ORDER_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Resource Name",
                id: "resourceName",
                accessor: "resourceName",
            },
            {
                Header: "Operations",
                id: "operation",
                accessor: "operation",
                disableSortBy: true,
            },
            {
                Header: "MO - Detail",
                id: "mfgOrderId",
                accessor: "mfgOrderId",
                style: {
                    flex: '0 0 100px'
                },
                disableSortBy: true,
            },
            {
                Header: "Product",
                id: "productId",
                accessor: "productId",
                disableSortBy: true,
            },
            {
                Header: "Production Qty",
                id: "quantity",
                accessor: "quantity",
                style: {
                    flex: '0 0 110px'
                },
                disableSortBy: true,
            },
            {
                Header: "Schedule Time",
                id: "scheduleTime",
                accessor: "scheduleTime",
                style: {
                    flex: '0 0 110px'
                },
                disableSortBy: true,
            },
            {
                Header: "Available Capacity",
                id: "availableCapacity",
                accessor: "availableCapacity",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
            },
            {
                Header: "Used Capacity",
                id: "usedCapacity",
                accessor: "usedCapacity",
                style: {
                    flex: '0 0 100px'
                },
                disableSortBy: true,
            },
            {
                Header: "Status",
                id: "operationStatus",
                accessor: "operationStatus",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var tempValue = !original.operationStatus ? statusConstant.NEW_STATUS : original.operationStatus;
                    original.operationStatus = tempValue;
                    return (
                        <div className="full-td progress-button" style={{
                            backgroundColor: StatusUtil.getStatusColor(tempValue)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(tempValue)}</div>
                            <div className="items">
                                <Nav pullRight>
                                    <NavDropdown id={'operationStatus'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
                                        {OPERATION_STATUS_LIST.map((tempAttributeListObj) => (
                                            <MenuItem name="operationStatus" id={tempAttributeListObj.statusKey + "_" + index}
                                                onClick={(e) => { that.handleOperationStatusChange(e, original) }}
                                            >
                                                <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
                                                {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                                            </MenuItem>
                                        ))}
                                    </NavDropdown>
                                </Nav>
                            </div>

                        </div>
                    )
                }
            },
            {
                Header: "Process owner",
                id: "owner",
                accessor: "owner",
                disableSortBy: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_MFG_ORDERVIEW_ORDER_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Resource Name",
                id: "resourceName",
                accessor: "resourceName",
            },
            {
                Header: "MO - Detail ",
                id: "mfgOrderId",
                accessor: "mfgOrderId",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
            },
            {
                Header: "Product",
                id: "productId",
                accessor: "productId",
                disableSortBy: true,
            },
            {
                Header: "Production Qty",
                id: "quantity",
                accessor: "quantity",
                style: {
                    flex: '0 0 140px'
                },
                disableSortBy: true,
            },
            {
                Header: "Schedule Time",
                id: "scheduleTime",
                accessor: "scheduleTime",
                style: {
                    flex: '0 0 140px'
                },
                disableSortBy: true,
            },
            {
                Header: "Available Capacity",
                id: "availableCapacity",
                accessor: "availableCapacity",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
            },
            {
                Header: "Used Capacity",
                id: "usedCapacity",
                accessor: "usedCapacity",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
            },
            {
                Header: "Operations",
                id: "operation",
                accessor: "operation",
                disableSortBy: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_MFG_DRAFT_ORDER_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product",
                id: "uniqueCode",
                accessor: "uniqueCode",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let tempUniqueObj = null;
                    let uniqueName = null;
                    if (that.props.productList && that.props.productList.Items) {
                        tempUniqueObj = CommonUtil.getFilteredObjFromArray(that.props.productList.Items,
                            'productId', original.uniqueCode);
                        uniqueName = CommonUtil.isNotNull(tempUniqueObj) ? tempUniqueObj.productName : null;
                    }
                    return (
                        <div>
                            {original.uniqueCode + " | " + uniqueName}
                        </div>
                    );
                },
            },
            {
                Header: "Facility",
                id: "facilityName",
                accessor: "facilityName",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let facilityName;
                    if (that.props.facilityList && that.props.facilityList.Items) {
                        let tempFacilityObj = CommonUtil.getFilteredObjFromArray(that.props.facilityList.Items,
                            'facilityId', original.facilityId);
                        facilityName = CommonUtil.isNotNull(tempFacilityObj) ? tempFacilityObj.facilityName : null;
                    }
                    return (
                        <div>
                            {original.facilityId + " | " + facilityName}
                        </div>
                    );
                },
            },
            {
                Header: "Quantity",
                id: "orderQuantity",
                accessor: "orderQuantity",
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { index, original } = cell.row;
                    let value = original.orderRequest && original.orderRequest.quantity;
                    let tempUniqueObj = CommonUtil.getFilteredObjFromArray(that.props.productList.Items,
                        'productId', original.uniqueCode);
                    let productUOM = tempUniqueObj && tempUniqueObj.productUOM;
                    return (
                        value + " " + productUOM
                    )
                }
            },
            {
                Header: "Total Cost",
                id: "totalValue",
                accessor: "totalValue",
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let totalIngredientValue = original.orderRequest && original.orderRequest.totalIngredientValue;
                    let totalOperationValue = original.orderRequest && original.orderRequest.totalOperationValue;
                    let totalValue = CommonUtil.getFloatValue(totalIngredientValue) +
                        CommonUtil.getFloatValue(totalOperationValue);
                    return (
                        CommonUtil.getFloatValue(totalValue, true) + " " + that.props.currencyCode
                    )
                }
            },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: "0 0 110px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(statusConstant.DRAFT_STATUS),
                            borderRadius: '5px'
                        }}
                            id={original.uniqueCode + "_" + "status" + "_" + index + "_" + original.draftCode}>
                            {StatusUtil.getStatusLabel(statusConstant.DRAFT_STATUS)}
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "action",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 60px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon>
                                <div className="circle">
                                    <i title="Confirm" id={original.uniqueCode + "_" + "confirm" +
                                        "_" + index + "_" + original.draftCode}
                                        className="fa fa-check" onClick={(e) => that.handleConfirmDraftAction(e, that)} />
                                </div>
                                <div className="circle">
                                    <i title="Delete" id={original.uniqueCode + "_" + commonConstant.DELETE_ACTION_MODE +
                                        "_" + index + "_" + original.draftCode}
                                        className="fa fa-trash" onClick={(e) => MfgUtil.handleDeleteDraftPopup(e, that)} />
                                </div>
                            </Button>
                        </div>
                    );
                },
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        },
    };
};

export const ADVANCE_SEARCH_LIST = (that) => {
    return {
        attributeObj: {
            orderNumber: '',
        },
        attributeList: [
            {
                name: "orderNumber",
                type: "TEXTBOX",
                label: "",
                inputType: "text",
                fieldWidth: 12,
                numberOfRow: 0,
                placeholder: "Search by Mfg Order/Product",
            },
        ],
    }
};

export const CREATE_CONFIGURE_DEADLINE = {
    attributeObj: {
        days: '',
        startingDay: '',
        dayHours: '',
        weeklyHours: '',
        allLocations: '',
    },
    attributeList: [
        {
            name: "days",
            type: "TEXTBOX",
            label: "How many days in a week",
            required: true,
            fieldWidth: 6,
            inputType: "number",
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            maxLength: 10,
            minLength: 1,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "startingDay",
            type: "DROPDOWN",
            label: "Starting Day",
            required: true,
            inputType: "label",
            fieldWidth: 6,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "Select",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: [
                { value: 'Monday', label: 'Monday' },
                { value: 'Tuesday', label: 'Tuesday' },
                { value: 'Wednesday', label: 'Wednesday' },
                { value: 'Thursday', label: 'Thursday' },
                { value: 'Friday', label: 'Friday' },
                { value: 'Saturday', label: 'Saturday' },
                { value: 'Sunday', label: 'Sunday' },
            ]
        },
        {
            name: "dayHours",
            type: "DROPDOWN",
            label: "How many Hours in a day",
            required: true,
            fieldWidth: 6,
            inputType: "label",
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "Select",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: [
                { value: '1', label: '1' },
                { value: '2', label: '2' },
                { value: '3', label: '3' },
                { value: '4', label: '4' },
                { value: '5', label: '5' },
                { value: '6', label: '6' },
                { value: '7', label: '7' },
                { value: '8', label: '8' },
                { value: '9', label: '9' },
                { value: '10', label: '10' },
                { value: '11', label: '11' },
                { value: '12', label: '12' },
                { value: '13', label: '13' },
                { value: '14', label: '14' },
                { value: '15', label: '15' },
                { value: '16', label: '16' },
                { value: '17', label: '17' },
                { value: '18', label: '18' },
                { value: '19', label: '19' },
                { value: '20', label: '20' },
                { value: '21', label: '21' },
                { value: '22', label: '22' },
                { value: '23', label: '23' },
                { value: '24', label: '24' }
            ]
        },
        {
            name: "weeklyHours",
            type: "TEXTBOX",
            label: "Weekly Hours",
            required: true,
            fieldWidth: 6,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            maxLength: 32,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "allLocations",
            type: "CHECKBOX",
            label: "Apply this settings to all the locations",
            required: false,
            fieldWidth: 12,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
    ],
};

export const MANAGE_HEADER_STATUS_LIST = [
    {
        statusKey: statusConstant.ALL_STATUS
    },
    {
        statusKey: statusConstant.NEW_STATUS
    },
    {
        statusKey: statusConstant.IN_PROGRESS_STATUS
    },
    // {
    //     statusKey: statusConstant.BLOCKED_STATUS
    // },
    {
        statusKey: statusConstant.OVERDUE_STATUS
    }
]

export const HEADER_STATUS_LIST = [
    {
        statusKey: statusConstant.NEW_STATUS
    },
    {
        statusKey: statusConstant.IN_PROGRESS_STATUS
    },
    {
        statusKey: statusConstant.COMPLETED_STATUS
    },
    // {
    //     statusKey: statusConstant.BLOCKED_STATUS
    // }
]


export const OPERATION_STATUS_LIST = [
    {
        statusKey: statusConstant.NEW_STATUS
    },
    {
        statusKey: statusConstant.IN_PROGRESS_STATUS
    },
    {
        statusKey: statusConstant.COMPLETED_STATUS
    }
]

