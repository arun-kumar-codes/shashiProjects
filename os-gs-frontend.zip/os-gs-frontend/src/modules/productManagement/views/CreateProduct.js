import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, ControlLabel, Tabs, Tab, FormControl, InputGroup } from "react-bootstrap";
import Select from "react-select";
import { touch } from "redux-form";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { setProductDetails, getProductDetails, setReducerInitMode } from "../actions/productActions";
// import { getSupplierList, getSupplierDetails } from "../../supplierManagement/actions/supplierActions";
import { getIngredientList, getIngredientDetails } from "../../ingredientManagement/actions/ingredientActions";
import { getProductList, getSKUNumber } from '../../productManagement/actions/productActions';
import { getOperationDetails } from "../../operation/actions/operationActions";
import { setActionMode } from "../../../actions/appActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as productConstant from '../constant/productConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CustomRadio from "../../../components/CustomRadio/CustomRadio";
import CommonUtil from '../../common/util/commonUtil';
import PopularTableUtil from '../../common/util/popularTableUtil.js';
import PopupUtil from '../../common/util/popupUtil';
import LabelUtil from '../../common/util/labelUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import _ from 'lodash';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import product from "assets/img/product-page-icon.svg";
import CreateSupplierModal from '../../common/components/CreateSupplierModal';
import mixpanel from "../../analytics/mixpanel/mixpael";
import * as statusConstant from '../../common/constant/statusConstant';
// import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import { getDataDictionaryDetails, getTierPricingDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import SuggestionUtil from '../../common/util/suggestionUtil';
import VariationsModal from './VariationsModal';
import isAuthorized from "auth-plugin/index.js";
import { getUserProfile } from "../../userManagement/actions/userActions";

let Modal = require('react-bootstrap-modal');
class CreateProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      tierPriceAttributeList: null,
      attributeObj: {
        source: 'buy'
      },
      // supplierDetails: null,
      // showSupplierFields: false,
      submitted: false,
      alert: null,
      source: "buy",
      ingredients: [],
      operations: [],
      bomKitComponents: [],
      selectedTab: "INGREDIENT",
      ingredientTableKey: "ingredients",
      operationTableKey: "operations",
      bomKitComponentTableKey: 'bomKitComponents',
      // facilityList: [],
      // allList: [{ label: 'All', value: 'All' }],
      showBrand: true,
      showVariationModal: false,
      variant: false,
      load: true,
      reload: false,
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleSave = this.handleSave.bind(this);
    // this.getCompleteDetails = this.getCompleteDetails.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  getVariationDetails = async () => {
    await this.setState({ showVariationModal: false });
  }

  handleVariationModal = (event) => {
    this.setState({ showVariationModal: true, variant: true });
  }

  handleTableSuggestionChange = async (event, eventId, searchOptions) => {
    var id = parseInt(eventId.split('_')[1]);

    if (this.state.selectedTab == 'INGREDIENT') {
      await PopularTableUtil.handleTableSuggestionChangeAMS(event, eventId, searchOptions,
        this, this.getSelectedTablekey(), "purchaseOrderIngredient");
      await this.props.getIngredientDetails(event[0].productId);
    } else if (this.state.selectedTab === 'BOM_KIT') {
      await PopularTableUtil.handleTableSuggestionChangeAMS(event,eventId,searchOptions,
        this,this.getSelectedTablekey(), "saleOrder");
      await this.props.getProductDetails(event[0].productId);
      await this.setState({ reload: true, load: false });
    } else {
      await PopularTableUtil.handleTableSuggestionChange(event,eventId,searchOptions,
        this,this.getSelectedTablekey());
      await this.setOperationDefaultRowData(id, this.getSelectedTablekey());
      await this.handleTableCalculation(this.getSelectedTablekey());
    }
  }

  setBomKitComponentDefaultRowData = async(tableDataKeyName) => {
    let attributeDataList = [...this.state[tableDataKeyName]];
    const { productDetails } = this.props;
    let i = attributeDataList.findIndex(value => value.productId == productDetails.productId);
    if (productDetails !== null) {
      attributeDataList[i].ingredientId = undefined;
      attributeDataList[i].ingredientName = undefined;
      attributeDataList[i].productUOM = productDetails.productUOM;
      attributeDataList[i].purchasePrice = productDetails.purchasePrice;
    }
    attributeDataList = attributeDataList.filter(item => {
      if(item.productId) {
        return item;
      }
    })
    await this.setState({ [tableDataKeyName]: attributeDataList, reload: false });
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  setIngredientDefaultRowData = async (tableDataKeyName) => {
    let attributeDataList = [...this.state[tableDataKeyName]];
    const { ingredientDetails } = this.props;
    let i = attributeDataList.findIndex(value => value.ingredientId == ingredientDetails.productId);
    if (ingredientDetails !== null) {
      attributeDataList[i].ingredientUOM = ingredientDetails.productUOM;
      attributeDataList[i].purchasePrice = ingredientDetails.purchasePrice;
      attributeDataList[i].totalCosts = CommonUtil.getFloatValue(ingredientDetails.quantity * ingredientDetails.ingredientId, true);
    }
    attributeDataList = attributeDataList.filter(item => {
      if(item.ingredientId) {
        return item;
      }
    })
    await this.setState({ [tableDataKeyName]: attributeDataList });
    await this.handleTableCalculation(this.getSelectedTablekey());
  }

  setOperationDefaultRowData = (id, tableDataKeyName) => {
    var selectedData = '';
    var attributeDataList = [...this.state[tableDataKeyName]];
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (id == i) {
        this.props && this.props.operationList && this.props.operationList.filter(value => {
          if (value.operationId && String(value.operationId).toLowerCase().indexOf(
            attributeDataList[i].operationId &&
            String(attributeDataList[i].operationId).toLowerCase()) !== -1) {
            selectedData = value;
          }
        });
        if (selectedData && selectedData !== null) {
          attributeDataList[i].duration = selectedData.duration;
          attributeDataList[i].cost = selectedData.cost;
          attributeDataList[i].status = "new";
        }
      }
    }
    this.setState({ [tableDataKeyName]: attributeDataList });
  }

  // handleCustomDropDownChange = async (event, obj) => {
  //   if (obj.name == 'supplier') {
  //     const { attributeObj } = this.state;
  //     attributeObj.leadTime = "";
  //     attributeObj.moq = "";
  //     attributeObj.moa = "";
  //     attributeObj.tax = "";
  //     attributeObj.purchasePrice = "";

  //     const { attributeList } = this.state;
  //     var newlist = attributeList.map((item) => {
  //       if (item.supplierfields) {
  //         if (item.name == 'purchasePrice') {
  //           item.required = true;
  //         }
  //         item.showField = true;
  //         item.createMode = 'enable';
  //         item.cloneMode = 'enable';
  //         item.editMode = 'enable';
  //       }

  //       return item;
  //     });

  //     if (CommonUtil.isEditMode(this.props.actionMode)) {
  //       attributeObj.showSupplierFields = true;
  //     }
  //     await this.setState({
  //       attributeList: newlist,
  //       attributeObj: {
  //         ...attributeObj,
  //         [obj.name]: event.value,
  //         "supplierId": event.value
  //       },
  //     });
  //     this.props.getSupplierDetails(event.value);
  //   }
  // }

  handleRadioButtonsChange = async (event) => {
    const { name, value } = event.target;
    const { attributeObj } = this.state;
    if (value === "make") {
      await this.props.getIngredientList({ isDropdown: true, isIngredient: true });
      await this.props.getOperationDetails();
      await this.setState({
        selectedTab: 'INGREDIENT'
      })
      this.setSelectedTableDetails('INGREDIENT');
    } else if (value === 'kit') {
      await this.props.getProductList({ isDropdown: true, isSellable: true });
      await this.setState({
        selectedTab: 'BOM_KIT'
      });
      this.setSelectedTableDetails('BOM_KIT');
    }
    const { attributeList } = this.state;
    attributeObj.ingredientCost = '';
    attributeObj.operationCost = '';
    attributeObj.kittingCost = '';
    attributeObj.stockOut = '';
    this.setState({
      attributeObj: {
        ...attributeObj,
        source: value
      }
    });

    await this.updateCommonAttribute(value);
  }

  updateCommonAttribute = async (value) => {
    let attributeList = CommonUtil.getDropDownOptionsFromDictionary(
      pagePropertyListConstant.CREATE_PRODUCT_PAGE_LIST(this).attributeList,
      this.props.dataDictionaryList);

    const { actionMode } = this.props;
    if(CommonUtil.isNotNull(this.state.attributeObj.taxes)) {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'taxes', `${actionMode}ShowFlag`, true);
    }
    if (value === "make") {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'kittingCost', `${actionMode}ShowFlag`, false);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'purchasePrice', `label`, "Total Cost");
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'packSizeQty', `${actionMode}ShowFlag`, true);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'volume', `${actionMode}ShowFlag`, true);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'volumeUnit', `${actionMode}ShowFlag`, true);
    } else if (value === 'buy') {

      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'kittingCost', `${actionMode}ShowFlag`, false);

      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'packSizeQty', `${actionMode}ShowFlag`, true);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'volume', `${actionMode}ShowFlag`, true);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'volumeUnit', `${actionMode}ShowFlag`, true);
    } else if (value === 'kit') {

      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'kittingCost', `${actionMode}ShowFlag`, true);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'purchasePrice', `label`, "Total Cost");
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'packSizeQty', `${actionMode}ShowFlag`, false);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'volume', `${actionMode}ShowFlag`, false);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'volumeUnit', `${actionMode}ShowFlag`, false);
    }
    if(((this.props.userProfile && this.props.userProfile.metadata) ? (this.props.userProfile.metadata.isSubCategoryVisible ? this.props.userProfile.metadata.isSubCategoryVisible : true): false)) {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'subcategory', `${actionMode}ShowFlag`, this.props.userProfile.metadata.isSubCategoryVisible ? this.props.userProfile.metadata.isSubCategoryVisible : false);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'subcategory', `required`, this.props.userProfile.metadata.isSubCategoryVisible ? this.props.userProfile.metadata.isSubCategoryVisible : false);
    }

    await this.setState({ attributeList: attributeList });
  }

  handleTableCalculation = (tableDataKeyName) => {
    if (CommonUtil.isBothEqual(tableDataKeyName, 'ingredients')) {
      this.handleIngredientTableCalulation(tableDataKeyName);
    }
    if (CommonUtil.isBothEqual(tableDataKeyName, 'operations')) {
      this.handleOperationTableCalulation(tableDataKeyName);
    }
    if (CommonUtil.isBothEqual(tableDataKeyName, 'bomKitComponents')) {
      this.handleKittingTableCalulation(tableDataKeyName);
    }
  }

  handleIngredientTableCalulation = (tableDataKeyName) => {
    var attributeDataList = [...this.state[tableDataKeyName]];
    var grandTotal = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (attributeDataList[i].purchasePrice && attributeDataList[i].quantity) {
        var tempPurchasePrice = 0, tempQuantity = 0, usgCostPerUnit = 0;
        tempPurchasePrice = parseFloat(attributeDataList[i].purchasePrice);
        // usgCostPerUnit = parseFloat(attributeDataList[i].usgCostPerUnit);
        tempQuantity = parseFloat(attributeDataList[i].quantity);
        // usgCostPerUnit = parseFloat(usgCostPerUnit * tempQuantity);
        tempPurchasePrice = parseFloat(tempPurchasePrice * tempQuantity);
        grandTotal = parseFloat(grandTotal + tempPurchasePrice);

        // attributeDataList[i].purchasePrice = parseFloat(usgCostPerUnit).toFixed(2);
      }
    }
    grandTotal = parseFloat(grandTotal).toFixed(2);
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        ingredientCost: grandTotal
      },
      [tableDataKeyName]: attributeDataList
    })
  }

  handleKittingTableCalulation = (tableDataKeyName) => {
    var attributeDataList = [...this.state[tableDataKeyName]];
    var grandTotal = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (attributeDataList[i].purchasePrice && attributeDataList[i].quantity) {
        var tempPurchasePrice = 0, tempQuantity = 0;
        tempPurchasePrice = parseFloat(attributeDataList[i].purchasePrice);
        tempQuantity = parseFloat(attributeDataList[i].quantity);
        tempPurchasePrice = parseFloat(tempPurchasePrice * tempQuantity);
        grandTotal = parseFloat(grandTotal + tempPurchasePrice);
      }
    }
    grandTotal = parseFloat(grandTotal).toFixed(2);
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        kittingCost: grandTotal
      }
    })
  }

  handleOperationTableCalulation = (tableDataKeyName) => {
    var attributeDataList = [...this.state[tableDataKeyName]];
    var grandTotal = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (attributeDataList[i].cost && attributeDataList[i].duration) {
        var tempOperationCost = 0, tempDuration = 0;
        tempOperationCost = parseFloat(attributeDataList[i].cost);
        tempDuration = parseFloat(attributeDataList[i].duration);
        tempOperationCost = parseFloat(tempOperationCost * tempDuration);
        grandTotal = parseFloat(grandTotal + tempOperationCost);
      }
    }
    grandTotal = parseFloat(grandTotal).toFixed(2);
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        operationCost: grandTotal
      }
    })
  }

  getSelectedTablekey = (selectedTab) => {
    if (this.state.selectedTab == 'INGREDIENT' || selectedTab == 'INGREDIENT') {
      return this.state.ingredientTableKey;
    }
    if (this.state.selectedTab == 'OPERATION' || selectedTab == 'OPERATION') {
      return this.state.operationTableKey;
    }

    if (this.state.selectedTab == 'BOM_KIT' || selectedTab == 'BOM_KIT') {
      return this.state.bomKitComponentTableKey
    }
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleDeleteRowPopup = (event) => {
    this.setState({ eventId: event.target.id });
    var popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    var popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleTableRemove = async (event) => {
    this.setState({ alert: null });
    var tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, this.getSelectedTablekey(), true);
    this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleLinkClick = (event) => {
    event.preventDefault();
    this.handleFamilyRedirection(productConstant.MANAGE_PRODUCT_PAGE_URL,
      this.getFamilyRequestParams(event));
  }

  generateSKUClick = (event) => {
    this.props.getSKUNumber();
  }

  modifyTaxesLink = () => {
    this.props.history.push("/admin/manage-sale-tax");
  }

  handleFamilyRedirection = (redirectURL, params) => {
    this.setState({ redirect: true, redirectUrl: redirectURL, params }, () => {
    });
  }

  getFamilyRequestParams(event) {
    var tempParamas = {};
    tempParamas.family = this.state.attributeObj && this.state.attributeObj.family;
    return tempParamas;
  }

  componentDidMount = async () => {
    mixpanel.track("Create product loaded");
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({searchInput : searchInput ? searchInput : ''})
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getProductDetails(this.props.selectedProductCode, {categoryId: this.props.selectedCategoryCode});
      }
    } else {
      CommonUtil.handlePageRedirection(productConstant.MANAGE_PRODUCT_PAGE_URL, this);
    }
    this.props.getDataDictionaryDetails();
    // this.props.getFacilityList();
    this.props.getTierPricingDetails();
    this.props.getUserProfile();
    // this.props.getSupplierList();
    this.setSelectedTableDetails(this.state.selectedTab);
    const commonAttributeList = pagePropertyListConstant.CREATE_PRODUCT_PAGE_LIST(this);
    await this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      tierPriceAttributeList: commonAttributeList.tierPriceAttributeList,
      operations: CommonUtil.isCreateMode(this.props.actionMode) ? [{}] : [],
      ingredients: CommonUtil.isCreateMode(this.props.actionMode) ? [{}] : [],
      bomKitComponents: CommonUtil.isCreateMode(this.props.actionMode) ? [{}] : [],
      attributeObj: commonAttributeList.attributeObj,
    });
    this.updateCommonAttribute(this.state.source);
  }

  handleTabClick = (label, event) => {
    var selectedTabKey = label.toUpperCase();
    this.setState({
      selectedTab: label.toUpperCase(),
    }, function () {
      this.setSelectedTableDetails(selectedTabKey);
    })
  }

  setSelectedTableDetails = (selectedTab) => {

    const tableAttributeList = pagePropertyListConstant["CREATE_PRODUCT_" +
      selectedTab.toUpperCase() + "_TABLE_LIST"](this);

    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.attributeList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
      brandList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'brandList')]
    })
  }

  updateAttributeObj(supplierDetails) {
    const { attributeObj } = this.state;
    if (supplierDetails.products != null) {
      for (let i = 0; i < supplierDetails.products.length; i++) {
        if (supplierDetails.products[i].productId == attributeObj.productId) {
          attributeObj.leadTime = supplierDetails.products[i].leadTime;
          attributeObj.moq = supplierDetails.products[i].moq;
          attributeObj.moa = supplierDetails.products[i].moa;
          attributeObj.tax = supplierDetails.products[i].taxCode;
          attributeObj.purchasePrice = supplierDetails.products[i].purchasePrice;
          attributeObj.showSupplierFields = true;
          this.setState({
            attributeObj: {
              ...attributeObj
            }
          });
        }
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj && this.state.load) {
      this.updateApiData(this.props.attributeObj);
    }

    if (CommonUtil.isCreateMode(this.props.actionMode) && _.size(this.props.tierPricing) && prevProps.tierPricing != this.props.tierPricing) {
      const commonAttributeList = pagePropertyListConstant.CREATE_PRODUCT_PAGE_LIST(this, this.props.tierPricing);
      this.setState({
        attributeObj : { ...this.state.attributeObj, tierPrices: this.props.tierPricing },
        tierPriceAttributeList: commonAttributeList.tierPriceAttributeList,
      })
    }

    // if (this.props.supplierDetails != null && prevProps.supplierDetails != this.props.supplierDetails) {
    //   if (CommonUtil.isEditMode(this.props.actionMode) || CommonUtil.isViewMode(this.props.actionMode)) {
    //     this.updateAttributeObj(this.props.supplierDetails);
    //   }
    // }

    // if (this.props.supplierList != null && prevProps.supplierList != this.props.supplierList) {
    //   this.updateSupplierDropDownList();
    // }
    if (this.props.skuNumber != null && prevProps.skuNumber != this.props.skuNumber) {
      this.updateSkuNumber();
    }
    if (this.props.operationList != null && prevProps.operationList != this.props.operationList) {
      this.updateOperationDropDownList();
    }
    if (this.props.ingredientList != null && prevProps.ingredientList != this.props.ingredientList) {
      this.updateIngredientDropDownList();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.ingredientDetails != null && prevProps.ingredientDetails != this.props.ingredientDetails) {
      this.setIngredientDefaultRowData(this.getSelectedTablekey());
    }
    if (this.props.productDetails != null && prevProps.productDetails != this.props.productDetails && this.state.reload) {
      this.setBomKitComponentDefaultRowData(this.getSelectedTablekey());
    }
    // if (prevProps.location.key !== this.props.location.key) {
    //   if (!CommonUtil.isCreateMode(this.props.actionMode)) {
    //     this.props.getProductDetails(this.props.selectedProductCode);
    //   } else {
    //     this.createNew();
    //   }
    // }
    if (prevProps.location.key !== this.props.location.key && this.props.location.state === "new") {
      if (CommonUtil.isCreateMode(this.props.actionMode)) {
        this.createNew();
      }
    }
    // if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
    //   this.updateFacilityDropDownList();
    // }
  }

  // updateFacilityDropDownList = async () => {
  //   let tempFacilityList = CommonUtil.getOptionsFromList(this.props.facilityList, 'facilityId', 'facilityName', null, true)
  //   const { attributeList } = this.state;
  //   var newlist = attributeList.map((item) => {
  //     if (item.name === "stockOut") {
  //       item.options = [...this.state.allList, ...tempFacilityList]
  //     }
  //     return item;
  //   });

  //   await this.setState({
  //     attributeList: newlist,
  //     facilityList: [...this.state.allList, ...tempFacilityList]
  //   });
  // }

  async updateApiData(attributeObj) {
    const commonAttributeList = pagePropertyListConstant.CREATE_PRODUCT_PAGE_LIST(this);
    await this.setState({ showBrand: false })
    const selectedTab = attributeObj.source == 'kit' ? 'BOM_KIT' : 'INGREDIENT';

    if(attributeObj.source == 'kit') {
      await this.props.getProductList({ isDropdown: true, isSellable: true });
    } else if (attributeObj.source == 'make') {
      await this.props.getIngredientList({ isDropdown: true, isIngredient: true });
      await this.props.getOperationDetails();
    }

    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      attributeObj.ingredients = attributeObj.ingredients.map((ingr) => {
        delete ingr.id;
        return ingr;
      });

      attributeObj.bomKitComponents = attributeObj.bomKitComponents.map((prod) => {
        delete prod.id;
        return prod;
      });

      attributeObj.operations = attributeObj.operations.map((op) => {
        delete op.id;
        return op;
      });
    }
    let taxesList = [];
    _.size(attributeObj.taxes) && attributeObj.taxes.map(item => {
      if(item.isactive) {
        let temp = item.taxName + " (" + (item.taxType == "volume" ? "$" : "") + item.taxValue + (item.taxType == "percentage" ? "%" : "") + ")"
        taxesList.push(temp);
      }
    })
    let taxes = taxesList.join(", ");

    await this.setState({
      attributeObj: {
        ...attributeObj,
        productId: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productId,
        productName: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productName,
        productSKU: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productSKU,
        source: attributeObj.source,
        brand: attributeObj.brand,
        taxes: CommonUtil.isCloneMode(this.props.actionMode) ? '' : taxes,
        // stockOut: CommonUtil.isNotNull(attributeObj.stockOut) ? this.getStockOut(attributeObj.stockOut) : []
      },
      selectedTab,
      ingredients: [...attributeObj.ingredients],
      bomKitComponents: [...attributeObj.bomKitComponents],
      operations: [...attributeObj.operations], function() {
      },
      showBrand: true,
      tierPriceAttributeList: commonAttributeList.tierPriceAttributeList,
      load: false,
    });
    // if (!CommonUtil.isCreateMode(this.props.actionMode)) {
    //   this.getDefaultSupplierPrice();
    // }
    this.setSelectedTableDetails(selectedTab);
    this.handleTableCalculation(this.getSelectedTablekey());
    await this.updateCommonAttribute(attributeObj.source);
  }

  // getStockOut = (stockOut) => {
  //   let tempFacilityList = CommonUtil.getOptionsFromList(this.props.facilityList, 'facilityId', 'facilityName', null, true);
  //   let tempStockOutList = [];
  //   let facilityList = [...this.state.allList, ...tempFacilityList];
  //   if (CommonUtil.isNotNull(facilityList) && CommonUtil.isNotNull(stockOut)) {
  //     for (let i = 0; i < stockOut.length; i++) {
  //       for (let j = 0; j < facilityList.length; j++) {
  //         if (stockOut[i] == facilityList[j].value) {
  //           tempStockOutList.push(facilityList[j]);
  //         }
  //       }
  //     }
  //   }
  //   return tempStockOutList;
  // }

  createNew = async () => {
    await this.setState({ showBrand: false })
    let tempObj = [];
    tempObj.ingredients = [{}];
    tempObj.operations = [{}];
    await this.setState({
      attributeObj: {
        ...tempObj,
        source: 'buy',
        // productId: "",
        productName: "",
        productGTIN: "",
        productSKU: "",
        salesPrice: "",
        transferPrice: "",
        // hsnCode: "",
        // upcNumber: "",
        purchasePrice: "",
        brand: "",
        packSizeQty: "",
        volume: "",
        // status: statusConstant.ACTIVE_STATUS,
      },
      showBrand: true,
      ingredients: [...tempObj.ingredients],
      operations: [...tempObj.operations],
    });
    this.handleTableCalculation(this.getSelectedTablekey());
  };

  updateSupplierDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.supplierList, 'supplierId', 'supplierName');
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'supplierId')
    })
    if (!CommonUtil.isCreateMode(this.props.actionMode)) {
      this.getDefaultSupplierPrice();
    }
  }

  updateSkuNumber = async () => {
    const { attributeObj } = this.state;
    await this.setState({
      attributeObj: {
        ...attributeObj,
        productSKU: this.props.skuNumber + "",
      }
    })
  }

  getDefaultSupplierPrice = async () => {
    if (this.props.supplierList != null && this.props.attributeObj != null) {
      let selectedSupplierObj = CommonUtil.getFilteredObjFromArray(
        this.props.supplierList, 'supplierId', this.props.attributeObj.supplier);
      if (selectedSupplierObj != null) {
        let selectedProductObj = CommonUtil.getFilteredObjFromArray(
          selectedSupplierObj.products, 'productId', this.props.selectedProductCode);
        const { attributeObj } = this.state;
        if (CommonUtil.isEditMode(this.props.actionMode) || CommonUtil.isViewMode(this.props.actionMode)) {
          await this.setState({
            attributeObj: {
              ...attributeObj,
              purchasePrice: selectedProductObj ? selectedProductObj.purchasePrice : ''
            },
          })
        } else {
          await this.setState({
            attributeObj: {
              ...attributeObj,
              purchasePrice: '',
              supplier: ''
            },
          })
        }
      }
    }
  }

  updateOperationDropDownList = () => {
    this.setState({ operationList: this.props.operationList })
  }

  updateIngredientDropDownList = () => {
    this.setState({ ingredientList: this.props.ingredientList });
    // this.mergeProductIngredientList();
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleStatusAction = (status) => {
    var tempObj = {};
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updateSaleOrderDeleteStatus(tempObj, this.state.attributeObj.saleOrderId);
  }

  handleSave = async (event) => {
    this.setState({ submitted: true, alert: null, variant: false });

    const { attributeObj } = this.state;
    var tempObj = _.cloneDeep(attributeObj), actionMode = this.props.actionMode;
    const productId = attributeObj.productId;
    delete tempObj.productId;
    delete tempObj.taxes;
    const tierPrices = _.get(tempObj, 'tierPrices', []);
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, actionMode);
    tempObj.tierPrices = tierPrices;
    tempObj.source == null ? tempObj.source = 'buy' : tempObj.source = tempObj.source;
    // tempObj.family = CommonUtil.isNullValue(tempObj.family) ? 'family' : tempObj.family;
    tempObj.subcategory = tempObj.subcategory ? tempObj.subcategory : tempObj.category; 
    if (tempObj.source == 'make') {
      tempObj.ingredients = [...this.state.ingredients];
      tempObj.ingredients = tempObj.ingredients.map((r) => {
        r.totalCosts = CommonUtil.getFloatValue(r.quantity * r.purchasePrice, true)
        // delete r.usgCostPerUnit;
        // delete r.usgPackSizeQty;
        // delete r.usgUOM;
        return r;
      });
      delete tempObj.kittingCost;

      tempObj.operations = this.state.operations;
      // tempObj.supplier = '';
      tempObj.bomKitComponents = [];
      tempObj.kittingCost = '';
    } else if (tempObj.source == 'kit') {
      tempObj.bomKitComponents = this.state.bomKitComponents;
      tempObj.ingredients = [];
      tempObj.operations = [];
      tempObj.operationCost = '';
      tempObj.ingredientCost = '';
    } else {
      tempObj.ingredients = [];
      tempObj.operations = [];
      tempObj.operationCost = '';
      tempObj.ingredientCost = '';
      tempObj.bomKitComponents = [];
      tempObj.kittingCost = '';
      tempObj.source = "buy";
    }
    // if (CommonUtil.isNotNull(attributeObj.stockOut)) {
    //   for (let i = 0; i < attributeObj.stockOut.length; i++) {
    //     stockOut.push(attributeObj.stockOut[i]["value"]);
    //   }
    // }
    // tempObj.stockOut = stockOut;
    if (this.isValidRequestObj(tempObj)) {
      this.props.setProductDetails(tempObj, actionMode, CommonUtil.getFloatValue(productId));
    }
  }

  handleSubmit = () => {

    const { operations, ingredients, attributeObj, bomKitComponents } = this.state;
    if (attributeObj.source == 'make') {
      if ((operations != null && operations.length > 0 && operations[0].operationName) && (ingredients != null && ingredients.length > 0 && ingredients[0].ingredientId)) {
        this.handleSave();
      } else if (((operations.length == 0) || (operations != null && operations.length > 0 && !operations[0].operationName)) && (ingredients != null && ingredients.length > 0 && ingredients[0].ingredientId)) {
        PopupUtil.popupSaveProductMakeOperation(this);
      } else if ((operations != null && operations.length > 0 && operations[0].operationName) && ((ingredients.length == 0) || (ingredients != null && ingredients.length > 0 && !ingredients[0].ingredientId))) {
        PopupUtil.popupSaveProductMakeIngredients(this);
      } else {
        PopupUtil.popupSaveProductMake(this);
      }
    } else if (attributeObj.source == 'kit') {
      if (bomKitComponents != null && bomKitComponents.length > 0 && bomKitComponents[0].productId) {
        this.handleSave();
      } else {
        PopupUtil.popupSaveProductKitting(this);
      }
    } else {
      this.handleSave();
    }
  }

  isValidRequestObj = (tempObj) => {

    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }

    if (tempObj.ingredients.length > 0 && tempObj.ingredients[0].ingredientId) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.ingredients,
        pagePropertyListConstant.CREATE_PRODUCT_INGREDIENT_TABLE_LIST(this).tableColumnList)) {
        return false;
      }
    } else {
      tempObj.ingredients = [];
    }

    if (tempObj.operations.length > 0 && tempObj.operations[0].operationName) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.operations,
        pagePropertyListConstant.CREATE_PRODUCT_OPERATION_TABLE_LIST(this).tableColumnList)) {
        return false;
      }
    } else {
      tempObj.operations = [];
    }

    if (tempObj.bomKitComponents.length > 0 && tempObj.bomKitComponents[0].productId) {
      if (
        !ValidationUtil.validateArrayListRequestObj(
          tempObj.bomKitComponents,
          pagePropertyListConstant.CREATE_PRODUCT_BOM_KIT_TABLE_LIST(this).tableColumnList
        )) {
        return false;
      }
    } else {
      tempObj.bomKitComponents = [];
    }

    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      if (this.state.variant == true) {
        this.setState({ variant: false });
        this.props.handleClick(CommonUtil.prepareVariantSuccessPopUpConfig());
      } else if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.setAjaxCallStatus(null);
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.setAjaxCallStatus(null);
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      if (!this.state.isSupplierPopupFlag) {
        this.props.setAjaxCallStatus(null);
        setTimeout(this.handlePopupContinue, 0);
      } else {
        this.props.setAjaxCallStatus(null);
        this.setState({ openModal: false });
        this.closeModal();
        this.props.getSupplierList();
      }
    }
    if (this.props.ajaxCallStatus.status == "FAILED" && this.state.openModal == false) {
      if (this.state.variant !== true) {
        PopupUtil.handleCustomErroMsg(this);
        this.props.setAjaxCallStatus(null);
      }
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = this.state.attributeObj.status ? this.state.attributeObj.status : null;
    CommonUtil.handlePageRedirection(productConstant.MANAGE_PRODUCT_PAGE_URL, this, params);
  }

  handleTableAddRow = (event) => {
    if (this.state.attributeObj.source == 'make') {
      if (this.state.selectedTab == 'INGREDIENT') {
        if (this.state.ingredientList.length > this.state.ingredients.length) {
          PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
        }
      }
      if (this.state.selectedTab == 'OPERATION') {
        if (this.state.operationList.length > this.state.operations.length) {
          PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
        }
      }
    } else if (this.state.attributeObj.source == 'kit') {
      if (this.state.productIngredientOptions.length > this.state.bomKitComponents.length) {
        PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
      }
    }
  }

  updateProductDropDownList = () => {
    this.setState({ productList: this.props.productList, productIngredientOptions: this.props.productList });
    // this.mergeProductIngredientList();
  }

  // mergeProductIngredientList = () => {
  //   // if (CommonUtil.isNotNull(this.props.productList) && CommonUtil.isNotNull(this.props.ingredientList)
  //   // && this.props.ingredientList.length > 0 && this.props.productList.length > 0) {

  //   if (CommonUtil.isNotNull(this.props.productList)
  //     && this.props.productList.length > 0) {

  //     let buyProductList = CommonUtil.getFilteredListFromArray(this.props.productList, 'source', 'buy');
  //     let makeProductList = CommonUtil.getFilteredListFromArray(this.props.productList, 'source', 'make');
  //     let allProductList = [];
  //     Array.prototype.push.apply(allProductList, buyProductList);
  //     Array.prototype.push.apply(allProductList, makeProductList);
  //     // this.setState({ productIngredientOptions: [...allProductList, ...this.props.ingredientList] });
  //     this.setState({ productIngredientOptions: [...allProductList] });

  //   }
  // }

  // showModal = () => {
  //   this.setState({ openModal: true, isSupplierPopupFlag: true });
  // };

  // closeModal = () => {
  //   this.setState({ openModal: false, isSupplierPopupFlag: false });
  // };

  // getCompleteDetails = (completeDetails) => {
  //   this.setState({ openModal: false, isSupplierPopupFlag: false });
  // }

  handleBrandSuggestionChange = async (event, eventId) => {
    let { attributeObj } = this.state;
    if (event != null && event.length > 0) {
      attributeObj[eventId] = event[0].value
      await this.setState({ attributeObj: attributeObj })
    }
  }
  setBrandValue = async (text) => {
    let { attributeObj } = this.state;
    attributeObj.brand = text;
    await this.setState({ attributeObj: attributeObj })
  }

  handleTierDropdownChange(event, obj, index, that) {
    let { attributeObj } = that.state;
    let updatedTierPrice = { ...attributeObj.tierPrices[index], [obj.name]: event.value };
    let updatedTierPrices = [...attributeObj.tierPrices];
    updatedTierPrices[index] = updatedTierPrice;
    let updatedAttributeObj = { ...attributeObj, tierPrices: updatedTierPrices };
    this.setState({ attributeObj: updatedAttributeObj });
  }

  handleChangeTierValue(event, index, that) {
    console.log({ event, index, that })
    const { name, value } = event.target;
    let { attributeObj } = that.state;
    let updatedTierPrice = { ...attributeObj.tierPrices[index], [name]: value };
    let updatedTierPrices = [...attributeObj.tierPrices];
    updatedTierPrices[index] = updatedTierPrice;
    let updatedAttributeObj = { ...attributeObj, tierPrices: updatedTierPrices };
    this.setState({ attributeObj: updatedAttributeObj });
  }

  handleTableTierTextBoxChange(event, that) {
    const { name, value } = event.target;
    let { attributeObj } = that.state;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.attributeObj.tierPrices];
    attributeDataList[id][name] = value;
    const u = { ...attributeObj, tierPrices: [...attributeDataList]  }
    this.setState({ attributeObj: u });
  }

  handleNumberChange(event, that) {
    const { name, value } = event.target;
    let { attributeObj } = that.state;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.attributeObj.tierPrices];
    const re = /^\d+(\.\d{0,2})?$/;
    if (value === '' || re.test(value)) {
      attributeDataList[id][name] = value;
      const u = { ...attributeObj, tierPrices: [...attributeDataList]  }
      this.setState({ attributeObj: u });
    } else {
      attributeDataList[id][name] = value.substring(0, value.length - 1);
      const u = { ...attributeObj, tierPrices: [...attributeDataList]  }
      this.setState({ attributeObj: u });
    }
  }

  maxLengthCheck(object, maxLength) {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  }

  maxValueCheck(object, maxValue) {
    let customErrorFlag = false;
    if (object.target.value > maxValue) {
      object.target.value = object.target.value.slice(0, 3)
      customErrorFlag = true
    }
    return customErrorFlag;
  }

  render() {
    const { attributeList, attributeObj, submitted,
      tableColumnList, tableConfig, customErrorFlag, customErrorObj, tierPriceAttributeList } = this.state;
    const tableDataList = this.state[this.getSelectedTablekey()];
    const actionMode = this.props.actionMode;
    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params, searchInput: this.state.searchInput }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={product} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    productConstant.EDIT_PRODUCT_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      productConstant.VIEW_PRODUCT_HEADER_TITLE
                      : productConstant.CREATE_PRODUCT_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {!CommonUtil.isCreateMode(this.props.actionMode) && isAuthorized("productVariations") && <div className="page-control-buttons">
                    <Button fill wd className="create-options btn-default btn-fill btn-wd" style={{ height: '36px' }} onClick={(e) => this.handleVariationModal(e)}>Variations</Button>
                  </div>}
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSubmit}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <div>
                        <Row className="content-section">
                          {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                            tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                attributeObj.source == 'buy' && tempAttributeListObj.supplierfields == true ?
                                  (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                    TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag, null, customErrorObj)
                                    : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                      TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag, null, customErrorObj)
                                      : null
                                  : TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag, null, customErrorObj)
                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  attributeObj.source == 'buy' && tempAttributeListObj.supplierfields == true ?
                                    (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                      DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                        DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                        : null
                                    : DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : tempAttributeListObj.type == "CUSTOM_RADIO" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?

                                    <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index} className="product-checkbox">
                                      <FormGroup style={{ width: '100%' }}>
                                        <div>
                                          <ControlLabel style={{ textTransform: 'none' }}>
                                            {tempAttributeListObj.label}
                                            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                          </ControlLabel>
                                        </div>
                                        <div className="source-btn">
                                          {tempAttributeListObj.checkList.map((check, Nestedindex) => {
                                            return (
                                              <Col md={4} key={Nestedindex}>
                                                <CustomRadio key={Nestedindex} name={check.name} number={check.name} label={check.label}
                                                  onChange={this.handleRadioButtonsChange} value={check.value}
                                                  disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                                  checked={attributeObj.source == check.value} />
                                              </Col>
                                            )
                                          })}
                                        </div>
                                      </FormGroup>
                                    </Col>
                                    : tempAttributeListObj.type == "SUGGESTION_BOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?

                                      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                        <FormGroup style={{ width: '100%' }}>
                                          <ControlLabel style={{ textTransform: 'none' }}>
                                            {tempAttributeListObj.label}
                                            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                          </ControlLabel>
                                          {this.state.showBrand ?
                                            <SuggestionUtil
                                              searchOptionList={["value"]}
                                              id={tempAttributeListObj.name}
                                              setNoFocus={true}
                                              options={this.state.brandList}
                                              selectedListKeys={[tempAttributeListObj.name]}
                                              selectedAttributeList={[attributeObj]}
                                              placeholder="Select"
                                              disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                              value={attributeObj[tempAttributeListObj.name] ? attributeObj[tempAttributeListObj.name] : ''}
                                              selectedValue={attributeObj[tempAttributeListObj.name] ? attributeObj[tempAttributeListObj.name] : ""}
                                              reSelect={true}
                                              onChange={(e) => this.handleBrandSuggestionChange(e, tempAttributeListObj.name,
                                                ["value", "label"])}
                                              handleSuggestionChange={this.handleBrandSuggestionChange}
                                              onInputChange={(text) => this.setBrandValue(text)}
                                            />
                                            : <FormControl />}
                                          {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                                            <small className="text-danger">
                                              {tempAttributeListObj.mandatoryMsgText}
                                            </small>
                                          }
                                        </FormGroup>
                                      </Col>
                                      : null))
                          }

                        </Row>
                        {_.size(attributeObj.tierPrices) > 0 && <Row>
                          <Col md={12}>
                            <div className="orgcontact-title">Tier Pricing</div>
                          </Col>
                        </Row>}
                        {_.size(attributeObj.tierPrices) > 0 && attributeObj.tierPrices.map((tempAttributeDataListObj, index) => (
                          <Row>
                            {tierPriceAttributeList != null && tierPriceAttributeList.map((tempAttributeListObj, index1) => (
                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index1}>
                                  <FormGroup>
                                    <ControlLabel style={{ marginBottom: 'unset' }}>
                                      <span> {tempAttributeListObj.label}
                                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
                                    </ControlLabel>
                                    <FormControl
                                      id={tempAttributeListObj.name + '_' + index}
                                      componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                                      name={tempAttributeListObj.name}
                                      onPaste={(e) => tempAttributeListObj.inputType == "number" ? CommonUtil.handleNumberPaste(e, this) : null}
                                      onBlur={(e) => this.handleChangeTierValue(e, index, this)}
                                      onChange={(e) => {
                                        this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                                        if (tempAttributeListObj.type == "TEXTBOX_TAX") { this.maxValueCheck(e, 100) };
                                        tempAttributeListObj.inputType == "number" ?
                                          this.handleNumberChange(e, this) :
                                          this.handleTableTierTextBoxChange(e, this)
                                      }}
                                      disabled={!tempAttributeDataListObj['adjustmentType'] || tempAttributeDataListObj['adjustmentType'] === "Global"}
                                      value={(tempAttributeDataListObj['adjustmentType'] === 'Global' || tempAttributeDataListObj[tempAttributeListObj.name] === null || !tempAttributeDataListObj['adjustmentType']) ? tempAttributeDataListObj['percentage'] : tempAttributeDataListObj[tempAttributeListObj.name]}
                                      onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                      onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                      maxLength={tempAttributeListObj.maxLength}
                                      rows={tempAttributeListObj.numberOfRow}
                                    />
                                    {submitted && tempAttributeListObj.required && !CommonUtil.isNotNull(tempAttributeDataListObj[tempAttributeListObj.name]) &&
                                      <small className="text-danger">
                                        {tempAttributeListObj.mandatoryMsgText}
                                      </small>
                                    }
                                    {submitted && customErrorFlag && tempAttributeDataListObj[tempAttributeListObj.name] ?
                                      <small className="text-danger">
                                        {tempAttributeListObj.customMessage}
                                      </small>
                                      : null
                                    }
                                    {(touch || submitted) && tempAttributeListObj.maxLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                      +tempAttributeDataListObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
                                      <small className="text-danger">
                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                      </small>
                                    }
                                    {(touch || submitted) && tempAttributeListObj.minLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                      +tempAttributeDataListObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
                                      <small className="text-danger">
                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                      </small>
                                    }
                                    {(touch || submitted) && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.type == "TEXTBOX_TAX" && tempAttributeDataListObj[tempAttributeListObj.name] > 100 ?
                                      <small className="text-danger">
                                        Allowed value limit is 0 to 100.
                                      </small>
                                      : null
                                    }
                                  </FormGroup>
                                </Col>
                                : tempAttributeListObj.type == "DROPDOWN" ?
                                  <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                    <FormGroup>
                                      {tempAttributeListObj.label}
                                      {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                      <Select name={tempAttributeListObj.name}
                                        id={tempAttributeListObj.name + '_' + index}
                                        onChange={(e, obj) => this.handleTierDropdownChange(e, obj, index, this)}
                                        isMulti={tempAttributeListObj.isMulti}
                                        value={CommonUtil.getSelectedOptionLabel(tempAttributeListObj.options, (tempAttributeDataListObj[tempAttributeListObj.name] || 'Global'))}
                                        classNamePrefix="react-select"
                                        isDisabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
                                        placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options} />
                                      {(touch || submitted) && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                                        <small className="text-danger">
                                          {tempAttributeListObj.mandatoryMsgText}
                                        </small>
                                      }
                                    </FormGroup>
                                  </Col>
                                  : null
                            ))
                            }
                          </Row>
                        ))}
                      </div>
                    </div>
                  }
                  ftTextRight
                // legend={
                //   <>
                //     {!CommonUtil.isViewMode(this.props.actionMode) ?
                //       <div>
                //         <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                //         <Button className="btn-save btn-fill" onClick={this.handleSubmit}>Save</Button>
                //       </div>
                //       :
                //       <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                //     }
                //   </>
                // }
                />
              </form>
            </Col>
          </Row>
          {<Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      {attributeObj && attributeObj.source == 'make' ?
                        <Tabs activeKey={this.state.selectedTab} onSelect={this.handleTabClick} id="table-tab">
                          <Tab eventKey={'INGREDIENT'} title={productConstant.INGREDIENT_TABLE_NAME}>
                            {tableDataList != null &&
                              <Row>
                                {tableColumnList != null && tableColumnList.length > 0 ?
                                  <div>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                    <div className="add-new-section">
                                      <Col md={12}>
                                        {!CommonUtil.isViewMode(this.props.actionMode) ?
                                          <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                            <i className=" fa fa-plus" />
                                            Add Row
                                          </div>
                                          : null}
                                      </Col>
                                    </div>
                                  </div>
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>}
                          </Tab>
                          <Tab eventKey={'OPERATION'} title={productConstant.OPERATION_TABLE_NAME}>
                            {tableDataList != null &&
                              <Row>
                                {tableColumnList != null && tableColumnList.length > 0 ?
                                  <div>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                    <div className="add-new-section">
                                      <Col md={12}>
                                        {!CommonUtil.isViewMode(this.props.actionMode) ?
                                          <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                            <i className=" fa fa-plus" />
                                            Add Row
                                          </div>
                                          : null}
                                      </Col>
                                    </div>
                                  </div>
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>}
                          </Tab>
                        </Tabs>
                        : attributeObj && attributeObj.source == 'kit' ?
                          <Tabs id="table-tab" activeKey='BOM_KIT'>
                            <Tab eventKey={'BOM_KIT'} title={productConstant.BOM_KIT_TABLE_NAME}>
                              {tableDataList != null &&
                                <Row>
                                  {tableColumnList != null && tableColumnList.length > 0 ?
                                    <div>
                                      <Table columns={tableColumnList}
                                        data={tableDataList}
                                        config={tableConfig}
                                        getRowProps={this.getTdProps}
                                        that={this}
                                      />
                                      <div className="add-new-section">
                                        <Col md={12}>
                                          {!CommonUtil.isViewMode(this.props.actionMode) ?
                                            <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                              <i className=" fa fa-plus" />
                                              Add Row
                                            </div>
                                            : null}
                                        </Col>
                                      </div>
                                    </div>
                                    : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                </Row>}
                            </Tab>
                          </Tabs> : null}
                      {this.state.showVariationModal == true ?
                        <VariationsModal
                          productId={this.props.selectedProductCode}
                          productName={attributeObj.productName}
                          getVariationDetails={this.getVariationDetails}>
                        </VariationsModal>
                        : null}
                    </div>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSubmit}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>}
        </Grid>
        {/* {this.state.openModal == true ?
          <CreateSupplierModal getCompleteDetails={this.getCompleteDetails} /> : null
        } */}
      </div >
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.product.productDetails,
    // supplierDetails: state.supplier.supplierDetails,
    selectedProductCode: state.product.selectedProductCode,
    selectedCategoryCode: state.product.selectedCategoryCode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    productList: state.product.productList,
    skuNumber: state.product.skuNumber,
    ingredientList: state.ingredient.ingredientList,
    // supplierList: state.supplier.supplierList,
    operationList: state.operation.operationDetails,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    // facilityList: state.facility.facilityList,
    tierPricing: state.dataDictionary.tierPricing,
    userProfile: state.user.userProfile,
    ingredientDetails: state.ingredient.ingredientDetails,
    productDetails: state.product.productDetails,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setProductDetails: (productDetailsObj, actionMode, productId) => dispatch(setProductDetails(productDetailsObj, actionMode, productId)),
  getProductDetails: (selectedProductCode, selectedCategoryCode) => dispatch(getProductDetails(selectedProductCode, selectedCategoryCode)),
  // getSupplierDetails: selectedSupplierCode => dispatch(getSupplierDetails(selectedSupplierCode)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  // getSupplierList: (params) => dispatch(getSupplierList(params)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  getSKUNumber: (params) => dispatch(getSKUNumber(params)),
  getOperationDetails: (params) => dispatch(getOperationDetails(params)),
  // getFacilityList: (params) => dispatch(getFacilityList(params)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getTierPricingDetails: () => dispatch(getTierPricingDetails()),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getIngredientDetails: (id) => dispatch(getIngredientDetails(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateProduct);
