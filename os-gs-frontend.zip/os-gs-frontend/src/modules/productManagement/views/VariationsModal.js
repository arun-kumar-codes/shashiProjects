import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Tabs, Tab, } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions.js";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant.js";
import CommonUtil from "../../common/util/commonUtil.js";
import PopupUtil from "../../common/util/popupUtil.js";
import Table from "../../../views/Tables/PopularTable/Table/Table.jsx";
import { Redirect } from "react-router-dom";
import Select from "react-select";
import { getProductList, getProductSearchList, getProductDetailList, getProductDetails, getSKUNumber, setProductMapping, setNewProductMapping, getMappedProductList} from '../actions/productActions.js';
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox.jsx';
import isAuthorized from "auth-plugin";
import PopularTableUtil from '../../common/util/popularTableUtil';
import _ from 'lodash';
import ValidationUtil from '../../common/util/validationUtil';
import SuggestionUtil from '../../common/util/suggestionUtil';
var Modal = require('react-bootstrap-modal')

class VariationsModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataList: [],
      variantList: [],
      params: null,
      brand: '',
      brandName: '',
      brandSearch: '',
      brandList: [],
      searchInput: "",
      selectedFilter: "",
      additionalParams: null,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      allList: [{ label: 'All', value: '' }],
      isAllChecked: false,
      customError: false,
      defaultSelectedTab: "CREATE",
      selectedTab: "CREATE",
      selectedProduct: {},
      productId: this.props.productId,
      productName: this.props.productName,
      showSuggestionInput: true,
      error: false,
    };
    this.handleCreateVariants = this.handleCreateVariants.bind(this);
    this.handleAddVariants = this.handleAddVariants.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true });
    await this.setSelectedTabDetails(this.state.selectedTab);
    await this.props.getProductDetails(this.props.productId);
  };

  setSelectedTabDetails = async (selectedTab) => {
    const managePageList = pagePropertyListConstant["PRODUCTS_VARIANTS_" + selectedTab + "_PAGE_LIST"](this);
    const { search, brand } = this.state;
    var additionalParams = {};
    if(CommonUtil.isNotNull(search)) additionalParams["search"] = search;
    if(CommonUtil.isNotNull(brand)) additionalParams["brand"] = brand;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      ttableDataList: [],
      attributeObj: [],
      searchInput: "",
      selectedTab: selectedTab,
      additionalParams: additionalParams,
      brandList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'brandList')]
    });
    await this.makeCustomAPICall(additionalParams, selectedTab);
  };

  makeCustomAPICall(tempParamas, selectedTab) {
    this.setState({isAllChecked: false})
    if(selectedTab == "MAP") {
      this.props.getProductList({isDropdown: true, source: 'buy', brand: tempParamas.brand });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.productDetails != null && prevProps.productDetails != this.props.productDetails) {
      if(this.state.selectedTab == "CREATE") {
        this.updateMappedProduct(this.props.productDetails);
      } else {
        this.setDefaultRowData(this.props.productDetails);
      }
    }
    if(this.props.mappedProductList != null && prevProps.mappedProductList != this.props.mappedProductList) {
      if(this.state.selectedTab == "CREATE") {
        this.updateMappedProductList(this.props.mappedProductList);
      }
    }
    if (this.props.skuNumber != null && prevProps.skuNumber != this.props.skuNumber) {
      this.updateSkuNumber();
    }
  }

  setDefaultRowData = async (productDetails) => {
    let attributeDataList = this.state.tableDataList;
    let i = attributeDataList.findIndex(value => value.productId == productDetails.productId);
    if (productDetails !== null) {
      attributeDataList[i].purchasePrice = productDetails.purchasePrice || 0;
      attributeDataList[i].salesPrice = productDetails.salesPrice || 0;
    }
    await this.setState({ tableDataList: [] });
    await this.setState({ tableDataList: attributeDataList });
  }

  updateSkuNumber = async () => {
    const { variantList, selectedSKURow } = this.state;
    variantList = variantList.map((item, index) => {
      if(selectedSKURow == index) {
        item.productSKU = this.props.skuNumber + "";
      }
      return item
    })
    await this.setState({
      variantList: variantList,
    })
  }

  updateProductDropDownList = async () => {
    let list = _.cloneDeep(this.props.productList);
    let alreadyAddedList = _.cloneDeep(this.props.mappedProductList)
    alreadyAddedList = alreadyAddedList.map(item => { return item.productId; });
    list = list.filter(item => !alreadyAddedList.includes(item.productId));
    list = await list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    this.setState({ productList: list });
  }

  updateMappedProductList = async (tempList) => {
    if(tempList && tempList.length > 0) {
      let parentProduct = tempList.filter(item => !item.parentProductId)
      tempList = await tempList.sort((a,b) => (a.parentProductId > b.parentProductId) ? 1 : ((b.parentProductId > a.parentProductId) ? -1 : 0))
      await this.setState({ variantList: [], productId: parentProduct[0].productId, productName: parentProduct[0].productName })
      await this.setState({ variantList: tempList})
    }
  }

  updateMappedProduct = async (tempList) => {
    let temp = _.cloneDeep(tempList);
    delete temp.productId;
    temp.productSKU = '';
    await this.setState({ selectedProduct: temp})
    await PopularTableUtil.handleTableAddRowVariant(this, "variantList");
    await this.props.getMappedProductList(this.props.productId);
  }

  closeModal = (event) => {
    this.props.getVariationDetails();
    this.setState({ openModal: false, submitted: false });
  }
  generateSKUClick = async (event) => {
    var tempId = event.target.id.split("_");
    await this.setState({ selectedSKURow: tempId[1] })
    await this.props.getSKUNumber();
  }
  
  handleAddVariants = async (event) => {
    this.setState({ submitted: true, alert: null });
    const { tableDataList } = this.state;
    let tempData = []
    tableDataList && tableDataList.map((item) => {
      tempData.push({"productId" : item.productId})
    })
    if(tempData && tempData.length > 0 ) {
      await this.props.setProductMapping(tempData, this.props.productId)
      // await this.setState({ openModal: false });
      // await this.props.getVariationDetails();
    }
  }

  handleAddNewRow = async () => {
    PopularTableUtil.handleTableAddRowVariant(this, "variantList");
  }

  handleDeleteRowPopup = (event) => {
    this.setState({ eventId: event.target.id });
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancelRemove;
    let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleDeleteMapRowPopup = (event) => {
    this.setState({ eventId: event.target.id });
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleMapTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancelRemove;
    let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  copyPrice = async () => {
    const { variantList } = this.state;
    if(variantList && variantList.length > 0) {
      let salesPrice = variantList[0].salesPrice;
      let purchasePrice = variantList[0].purchasePrice;
      let tempVariantList = variantList.map(item => {
        item.salesPrice = salesPrice;
        item.purchasePrice = purchasePrice;
        return item;
      })
      await this.setState({ variantList: tempVariantList });
    }
  }

  handleTableRemove = async (event) => {
    this.setState({ alert: null });
    let tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, "variantList", true);
  };

  handleMapTableRemove = async (event) => {
    this.setState({ alert: null });
    let tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, "tableDataList", true);
  };

  handlePopupCancelRemove = () => {
    this.setState({ alert: null });
  }

  handleCreateVariants = async () => {
    this.setState({ submitted: true, alert: null });
    const { variantList } = this.state;
    let tempData = {}
    tempData.productId = this.props.productId;
    tempData.variantList = variantList;
    
    if(this.isValidRequestObj(tempData) && tempData.variantList && tempData.variantList.length > 0 ) {
      await this.props.setNewProductMapping(tempData)
      // await this.setState({ openModal: false });
      // await this.props.getVariationDetails();
    }
  }

  isValidRequestObj = (tempObj) => {
    if (tempObj.variantList.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.variantList,
        pagePropertyListConstant.PRODUCTS_VARIANTS_CREATE_PAGE_LIST(this).tableColumnList)) {
        return false;
      }
    }
    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.setState({ openModal: false, error: false });
      this.props.getVariationDetails();
      // this.props.handleClick(CommonUtil.prepareVariantSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      let errorMessage = this.props.ajaxCallStatus.data &&
      this.props.ajaxCallStatus.data.response &&
      this.props.ajaxCallStatus.data.response.data;
      let productId = errorMessage.replace(/[^0-9]/g, "")
      if(productId) {
        this.setState({ error: true, code: productId});
      } else {
        PopupUtil.popupErrorResponse(this);
        this.props.setAjaxCallStatus(null);
      }
    }
  }

  handlePopupCancel() {
    this.props.getVariationDetails();
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  handlebrandDropdownChange = async (tempObj) => {
    await this.setState({
      brand: tempObj.value, brandName: tempObj.label,
    });
    this.setSelectedTabDetails(this.state.selectedTab);
  }
  handleTabClick = (label, event) => {
    let selectedTabKey = label.toUpperCase();
    this.setSelectedTabDetails(selectedTabKey);
  };

  handleTableTextBoxChange = async (event) => {
    await PopularTableUtil.handleTableTextBoxChange(event, this, "variantList");
  }

  handleTableSuggestionChange = async (event, eventId, searchOptions) => {
    let key = "productId";
    let selectedRow = 0;
    let { tableDataList } = this.state;
    if (event != null && event.length > 0) {
      await this.setState({ showSuggestionInput: false })
      const alreadyExist = tableDataList.some(product => product.productId === event[0].productId)
      if (!alreadyExist) {
        // let selectedLenght = tableDataList.length;
        // if(selectedLenght >= 500) {
        //   await this.setState({ customError: true, showSuggestionInput: true })
        // } else {
          PopularTableUtil.handleTableSuggestionChangeAMS(event, eventId, searchOptions,
            this, "tableDataList", "purchaseOrder");
          this.props.getProductDetails(event[0].productId);
          await this.setState({ customError: false, showSuggestionInput: true })
          selectedRow = 0
        // }
      } else {
        await this.setState({ showSuggestionInput: true })
      }
    }
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, search, brandSearch, customError, variantList, showSuggestionInput, error, code} = this.state;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Variations | PRO-{this.state.productId} | {this.state.productName}</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
          {this.state.alert}
            <div className="main-content create-page">
              <Grid fluid>
                <Tabs id="manage-purchase-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-tabs">
                  <Tab eventKey="CREATE" title="CREATE/UPDATE">
                    <Col md={12}>
                      <form>
                        <Card
                          content={
                            <div>
                              {tableColumnList != null ?
                                <Row>
                                  {variantList != null && variantList.length > 0 ?
                                    <Table columns={tableColumnList}
                                      data={variantList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                    : null}
                                </Row> : null
                              }
                              <Row>
                                <Col md={12}>
                                    {!CommonUtil.isViewMode(this.props.actionMode) && isAuthorized("changeProductStatus") ?
                                      <div className="add-row-button" onClick={(e) => this.handleAddNewRow(e)}>
                                        <i className=" fa fa-plus" />
                                        Add Row
                                      </div>
                                    : null}
                                </Col>
                              </Row>

                            </div>
                          }
                          ftTextRight
                          legend={
                            <>
                              {!CommonUtil.isViewMode(this.props.actionMode) && isAuthorized("changeProductStatus") ?
                                <div>
                                  <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                  <Button className="btn-save btn-fill" onClick={this.handleCreateVariants}>Save</Button>
                                </div>
                                :
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                              }
                            </>
                          }
                        />
                      </form>
                    </Col>
                  </Tab>
                  <Tab eventKey="MAP" title="MAP">
                    <Row>
                      <Col md={12}>
                        <form>
                          <Card
                            content={
                              <div>
                                <Row>
                                  <Col md={6}>
                                    <div className="suggestion-box">
                                      <i className="fa fa-search"></i>
                                      {showSuggestionInput && <SuggestionUtil
                                        searchOptionList={["productId", "productName", "productSKU"]}
                                        id={'productId'}
                                        options={this.state.productList}
                                        selectedListKeys={['productId', 'productSKU']}
                                        selectedAttributeList={this.state.products}
                                        placeholder="Search by Product Code/Name/SKU"
                                        disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                        value={this.state.selelctedValue}
                                        selectedValue={this.state.selelctedValue}
                                        resetOnSelection={true}
                                        reSelect={true}
                                        onChange={(e) => this.handleTableSuggestionChange(e, 'productId',
                                          ["productId", "productName"])}
                                        handleSuggestionChange={this.handleTableSuggestionChange}
                                      />}
                                    </div>
                                  </Col>
                                  {customError && <Col md={12}><p className="text-danger">Product limit of 500 has reached in the order.</p></Col>}
                                  {error && <Col md={12}><p className="text-danger">Variation for PRO-{code} is already exist.</p></Col>}
                                  {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                    <Table
                                      columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                  ) : null}
                                </Row>
                              </div>
                            }
                            ftTextRight
                            legend={
                              <>
                                {isAuthorized("changeProductStatus") ?
                                  <div>
                                    <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                    <Button className="btn-save btn-fill" onClick={this.handleAddVariants}>Map</Button>
                                  </div>
                                  :
                                  <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                }
                              </>
                            }
                          />
                        </form>
                      </Col>
                    </Row>
                  </Tab>
                </Tabs>

              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    productList: state.product.productList,
    productDetailList: state.product.productDetailList,
    productDetails: state.product.productDetails,
    mappedProductList: state.product.mappedProductList,
    skuNumber: state.product.skuNumber,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getProductList: (id) => dispatch(getProductList(id)),
  getProductDetailList: (id) => dispatch(getProductDetailList(id)),
  getProductSearchList: params => dispatch(getProductSearchList(params)),
  getProductDetails: selectedProductCode => dispatch(getProductDetails(selectedProductCode)),
  getSKUNumber: (params) => dispatch(getSKUNumber(params)),
  setProductMapping: (params, id) => dispatch(setProductMapping(params, id)),
  setNewProductMapping: (params) => dispatch(setNewProductMapping(params)),
  getMappedProductList: (id) => dispatch(getMappedProductList(id)),
});
export default connect(mapStateToProps, mapDispatchToProps)(VariationsModal);
