import * as productConstant from "./productConstant";
import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import _ from 'lodash';
import { FormControl, InputGroup, FormGroup, Col, Row } from "react-bootstrap";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import SuggestionUtil from "../../common/util/suggestionUtil";
import StatusUtil from "../../common/util/statusUtil";
import * as statusConstant from "../../common/constant/statusConstant";
import * as commonConstant from "../../common/constant/commonConstant";
import isAuthorized from "auth-plugin";
import CommonUtil from "../../common/util/commonUtil";
import Select from "react-select";
import DownloadSKUBarCode from "../../CreateQRCode/views/DownloadSKUBarCode";
import CustomCheckbox from "../../../components/CustomCheckbox/CustomCheckbox";
import currencyIcon from "../../common/util/currencyIcon";

const adjustmentType = [
  {
    label: 'Global',
    value: 'Global',
  },
  {
    label: 'Fixed Price',
    value: 'Fixed Price',
  },
  {
    label: 'Custom',
    value: 'Custom',
  }
]

export const CREATE_PRODUCT_PAGE_LIST = (that, tierPrices) => {
  const attributeList = [
    {
      name: "productId",
      type: "UNIQUE_CODE",
      prefix: "PRO",
      label: "Product Code",
      required: false,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      createModeRemoveFlag: true,
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "productName",
      type: "TEXTBOX",
      label: "Product Name",
      required: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 500,
      minLength: 1,
      customMessage: "Product Name already exist.",
    },
    {
      name: "category",
      type: "DROPDOWN",
      label: "Category",
      required: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "categoryList",
      options: [],
    },
    {
      name: "subcategory",
      type: "DROPDOWN",
      label: "Sub Category",
      required: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "subcategoryList",
      options: [],
    },
    {
      name: "brand",
      type: "DROPDOWN",
      label: "Brand",
      required: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "Select",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      numberOfRow: 0,
      dataDictionaryFlag: true,
      dataDictionaryId: "brandList",
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "productUOM",
      type: "DROPDOWN",
      label: "UoM",
      required: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "unitofMesurementList",
      options: [],
    },
    {
      name: "productGTIN",
      type: "TEXTBOX",
      label: "GTIN",
      required: false,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: false,
      viewModeShowFlag: false,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 25,
      minLength: 3,
    },
    {
      name: "productSKU",
      type: "TEXTBOX",
      label: "SKU/GTIN",
      required: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 25,
      minLength: 3,
      errorType: "sku",
      MsgText: "Generate SKU",
      MsgTextHref: "#",
      linkOnClickFun: that.generateSKUClick,
    },
    {
      name: "kittingCost",
      type: "TEXTBOX",
      label: "Kitting Cost",
      inputType: "number",
      showCurrency: true,
      required: false,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: false,
      makeShowFlag: false,
      kittingShowFlag: true,
      numberOfRow: 0,
      maxLength: 10,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "salesPrice",
      type: "TEXTBOX",
      label: "Sales Price",
      inputType: "number",
      showCurrency: true,
      required: true,
      allowCopyPaste: true,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 10,
      minLength: 1,
    },
    // {
    //   name: "exciseTax",
    //   type: "TEXTBOX",
    //   label: "Excise Tax %",
    //   inputType: "number",
    //   showCurrency: false,
    //   required: false,
    //   fieldWidth: 3,
    //   fieldWidthSmall: 4,
    //   createMode: "enable",
    //   cloneMode: "enable",
    //   editMode: "enable",
    //   viewMode: "disabled",
    //   createModeShowFlag: true,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: true,
    //   viewModeShowFlag: true,
    //   supplierfields: false,
    //   buyShowFlag: true,
    //   makeShowFlag: true,
    //   kittingShowFlag: true,
    //   numberOfRow: 0,
    //   mandatoryMsgText: "Field can not be empty.",
    //   maxLength: 10,
    //   minLength: 1,
    // },
    {
      name: "taxes",
      type: "TEXTBOX",
      label: "Taxes",
      required: false,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: false,
      viewModeShowFlag: false,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      numberOfRow: 0,
      // MsgText: "Modify Tax",
      // MsgTextHref: "",
      // linkOnClickFun: that.modifyTaxesLink,
    },
    {
      name: "packSizeQty",
      type: "TEXTBOX",
      label: "Pack Size Qty",
      inputType: "number",
      numberType: "fixed",
      showCurrency: false,
      required: false,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      showField: false,
      buyShowFlag: true,
      makeShowFlag: false,
      kittingShowFlag: false,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 10,
      minLength: 1,
    },
    {
      name: "volume",
      type: "TEXTBOX",
      label: "Volume",
      inputType: "number",
      showCurrency: false,
      required: false,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      showField: false,
      buyShowFlag: true,
      makeShowFlag: false,
      kittingShowFlag: false,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 10,
      minLength: 1,
    },
    {
      name: "volumeUnit",
      type: "DROPDOWN",
      label: "Volume Unit",
      required: false,
      fieldWidth: 3,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "unitofMesurementList",
      options: [],
    },
    {
      name: "isIngredient",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "isSellable",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
  ];

  const tierPriceAttributeList = [
    {
      name: "tierId",
      type: "DROPDOWN",
      label: "Customer Tier",
      required: false,
      fieldWidth: 2,
      fieldWidthSmall: 4,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "categoryList",
      options: _.map(_.get(that, 'props.attributeObj.tierPrices', tierPrices || []), tier => ({ label: tier.tierName, value: tier.tierId })),
    },
    {
      name: "adjustmentType",
      type: "DROPDOWN",
      label: "Adjustment Type",
      required: false,
      fieldWidth: 2,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "categoryList",
      options: adjustmentType,
    },
    {
      name: "tierValue",
      type: "TEXTBOX",
      label: "Value",
      required: true,
      fieldWidth: 3,
      inputType: "number",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
    },
  ]

  const sourceAttribute = {
    name: "source",
    type: "CUSTOM_RADIO",
    checkList: [
      {
        name: "buy",
        label: "Buy",
        value: "buy",
      },
      {
        name: "make",
        label: "Make",
        value: "make",
      },
      {
        name: "kit",
        label: "Kit",
        value: "kit",
      },
    ],
    label: "How do i source the product?",
    required: false,
    fieldWidth: 3,
    fieldWidthSmall: 4,
    createMode: "enable",
    cloneMode: "enable",
    editMode: "enable",
    viewMode: "disabled",
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    supplierfields: false,
    buyShowFlag: true,
    makeShowFlag: true,
    kittingShowFlag: true,
    numberOfRow: 0,
    mandatoryMsgText: "Field can not be empty.",
  };

  if (isAuthorized("productVariations")) {
    attributeList.splice(1, 0, sourceAttribute);
  }

  const costAttribute =     {
    name: "purchasePrice",
    type: "TEXTBOX",
    label: "Cost",
    inputType: "number",
    required: true,
    allowCopyPaste: true,
    showCurrency: true,
    fieldWidth: 3,
    fieldWidthSmall: 4,
    createMode: "enable",
    cloneMode: "enable",
    editMode: "enable",
    viewMode: "disabled",
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    supplierfields: true,
    showField: true,
    buyShowFlag: true,
    makeShowFlag: false,
    kittingShowFlag: false,
    numberOfRow: 0,
    mandatoryMsgText: "Field can not be empty.",
    maxLength: 10,
    minLength: 1,
    tooltipText:
      "Please select a default supplier to enter the purchase price.",
  };

  if (isAuthorized("viewCost")) {
    attributeList.splice(9, 0, costAttribute);
  }

  return {
    attributeObj: {
      // productId: '',
      productName: "",
      category: "",
      subcategory: "",
      brand: "",
      productUOM: "",
      productGTIN: "",
      source: "buy",
      kittingCost: "",
      productSKU: "",
      purchasePrice: "",
      salesPrice: "",
      exciseTax: "",
      packSizeQty: "",
      volume: "",
      volumeUnit: "",
      isSellable: true,
      isIngredient: false,
    },
    attributeList: attributeList,
    tierPriceAttributeList: tierPriceAttributeList,
  };
};

export const MANAGE_PRODUCT_PAGE_LIST = (that) => {
  const tableColumnList = [
    {
      Header: "Product Code",
      id: "productId",
      style: {
        flex: "0 0 120px",
      },
      accessor: "productId",
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return <>PRO-{value}</>;
      },
    },
    {
      Header: "Product Name",
      id: "productName",
      accessor: "productName",
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return (
            <div
              id={original.productId + "_1" + index + "_" + original.stocktype}
              title={original.productId ? (original.productName) : ''}>
              {
                <span >{original.productId ? (original.productName) : ''} </span>
              }
          </div>
        )
      }
    },
    {
      Header: "SKU",
      id: "productSKU",
      accessor: "productSKU",
      style: {
        flex: "0 0 120px",
      },
    },
    {
      Header: "Category",
      id: "category",
      accessor: "category",
      style: {
        flex: "0 0 120px",
      },
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return (
          <>
            {CommonUtil.getSelectedOptionNameFromCode(
              that.props.dataDictionaryList,
              original.category
            )}
          </>
        );
      },
    },
    {
      Header: "Brand",
      id: "brand",
      accessor: "brand",
      style: {
        flex: "0 0 120px",
      },
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return (
          <>
            {CommonUtil.getSelectedOptionNameFromCode(
              that.props.dataDictionaryList,
              original.brand
            )}
          </>
        );
      },
    },
    {
      Header: "Sale Price",
      id: "salesPrice",
      accessor: "salesPrice",
      style: {
        flex: "0 0 100px",
      },
    },
    {
      Header: "Actions",
      id: "actions",
      accessor: "actions",
      sortable: false,
      style: {
        flex: "0 0 110px",
      },
      className: "action",
      disableSortBy: true,
      disableFilters: true,
      Cell: ({ cell }) => {
        const { value } = cell;
        const { index, original } = cell.row;
        return (
          <div className="actions-left">
            {(isAuthorized("changeProductStatus") ||
              isAuthorized("viewProduct")) &&
              (isAuthorized("deactivateProduct") ||
                isAuthorized("barcodeProduct") ||
                true) && (
                <Nav pullRight>
                  <NavDropdown
                    id={
                      original.productId +
                      "_" +
                      commonConstant.MENU_ACTION_MODE
                    }
                    title={
                      <i
                        className="fa fa-ellipsis-v"
                        id={
                          original.productId +
                          "_" +
                          commonConstant.MENU_ACTION_MODE
                        }
                        onClick={(e) => that.getTdProps(e)}
                      />
                    }
                    noCaret
                  >
                    {isAuthorized("changeProductStatus") &&
                      isAuthorized("deactivateProduct") &&
                      (!original.status ? (
                        <MenuItem
                          id={
                            original.productId +
                            "_" +
                            commonConstant.MENU_ACTION_MODE +
                            "_" +
                            productConstant.ACTIVE_PRODUCT
                          }
                          onClick={(e) => that.getTdProps(e)}
                        >
                          Activate
                        </MenuItem>
                      ) : (
                        <MenuItem
                          id={
                            original.productId +
                            "_" +
                            commonConstant.MENU_ACTION_MODE +
                            "_" +
                            productConstant.DEATIVATE_PRODUCT
                          }
                          onClick={(e) => that.getTdProps(e)}
                        >
                          Deactivate
                        </MenuItem>
                      ))}
                    {isAuthorized("viewProduct") &&
                      isAuthorized("barcodeProduct") &&
                      original.status && (
                        <>
                          <DownloadSKUBarCode
                            SKUNumber={original.productSKU}
                          />
                          <MenuItem
                            id={
                              original.productId + "_" + original.productSKU
                            }
                            onClick={(e) => that.generateBarCode(e)}
                          >
                            Generate Barcode
                          </MenuItem>
                        </>
                      )}
                    {isAuthorized("productVariations") && (
                      <MenuItem
                        id={original.productId}
                        onClick={(e) =>
                          that.handleVariationModal(
                            e,
                            original.productId,
                            original.productName
                          )
                        }
                      >
                        Variations
                      </MenuItem>
                    )}
                  </NavDropdown>
                </Nav>
              )}
            <Button bsStyle="default" simple icon>
              {original.status && isAuthorized("editProduct") ? (
                <div className="circle">
                  <i
                    title="edit"
                    id={
                      original.productId +
                      "_" +
                      commonConstant.EDIT_ACTION_MODE +
                      "_" +
                      index +
                      "_" +
                      original.category
                    }
                    className="fa fa-pencil"
                    onClick={(e) => that.getTdProps(e)}
                  />
                </div>
              ) : null}
              {original.status && isAuthorized("cloneProduct") ? (
                <div className="circle">
                  <i
                    title="clone"
                    id={
                      original.productId +
                      "_" +
                      commonConstant.CLONE_ACTION_MODE +
                      "_" +
                      index +
                      "_" +
                      original.category
                    }
                    className="fa fa-copy"
                    onClick={(e) => that.getTdProps(e)}
                  />
                </div>
              ) : null}
              {isAuthorized("viewProduct") ? (
                <div className="circle">
                  <i
                    title="view"
                    id={
                      original.productId +
                      "_" +
                      commonConstant.VIEW_ACTION_MODE +
                      "_" +
                      index +
                      "_" +
                      original.category
                    }
                    className="fa fa-eye"
                    onClick={(e) => that.getTdProps(e)}
                  />
                </div>
              ) : null}
            </Button>
          </div>
        );
      },
    },
  ];

  const costPriceColumn =     {
    Header: "Cost Price",
    id: "purchasePrice",
    accessor: "purchasePrice",
    style: {
      flex: "0 0 100px",
    },
  };

  if (isAuthorized("viewCost")) {
    tableColumnList.splice(5, 0, costPriceColumn);
  }

  return {
    tableColumnList,
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: "",
        },
      ],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const CREATE_PRODUCT_INGREDIENT_TABLE_LIST = (that) => {
  return {
    tableData: [
      {
        ingredient: "",
        quantity: "",
        ingredientUOM: "",
        purchasePrice: "",
      },
    ],
    tableColumnList: [
      {
        Header: "Ingredient",
        id: "ingredientId",
        name: "ingredientId",
        accessor: "ingredientId",
        style: {
          flex: "0 0 35%",
        },
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <div
              className="full-width"
              title={
                original.ingredientId
                  ? original.ingredientId + "|" + original.ingredientName
                  : ""
              }
            >
              <SuggestionUtil
                className={that.state.submitted && !value ? "required-error" : "" }
                searchOptionList={["productId", "productName", "productSKU"]}
                id={"productId" + "_" + index}
                options={that.state.ingredientList}
                selectedListKeys={["productId", "productSKU"]}
                selectedAttributeList={that.state.ingredients}
                placeholder=""
                setNoFocus={true}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ""}
                selectedValue={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ""}
                onChange={(e) => that.handleTableSuggestionChange(e, "productId" + "_" + index, ["productId", "productName"])
                }
                handleSuggestionChange={that.handleTableSuggestionChange}
              />
            </div>
          );
        },
      },
      {
        Header: "Quantity",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        type: "text",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !original.quantity &&
                  original.ingredientId
                  ? "required-error"
                  : ""
              }
            >
              <FormControl
                id={"quantity" + "_" + index}
                data-type={"number"}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                name={"quantity"}
                onChange={that.handleTableTextBoxChange}
                disabled={
                  that.props.actionMode == "disabled"
                    ? true
                    : CommonUtil.isViewMode(that.props.actionMode)
                      ? true
                      : false
                }
                value={original.quantity}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
              <InputGroup.Addon>
                {CommonUtil.getSelectedOptionNameFromCode(
                  that.props.dataDictionaryList,
                  //   original.usgUOM
                  original.ingredientUOM
                )}
              </InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      //   {
      //     Header: "Cost Per Unit ($)",
      //     id: "usgCostPerUnit",
      //     accessor: "usgCostPerUnit",
      //     name: "usgCostPerUnit",
      //     required: false,
      //     type: "text",
      //     disableSortBy: true,
      //     disableFilters: true,
      //     createModeRemoveFlag: true,
      //     cloneModeRemoveFlag: true,
      //     createModeShowFlag: true,
      //     cloneModeShowFlag: true,
      //     editModeShowFlag: true,
      //     viewModeShowFlag: true,
      //     className: "input-field",
      //     Cell: ({ cell }) => {
      //       const { value } = cell;
      //       const { index, original } = cell.row;
      //       return (
      //         <InputGroup
      //           className={that.state.submitted && !value ? "required-error" : ""}
      //         >
      //           <FormControl
      //             id={"usgCostPerUnit" + "_" + index}
      //             name={"usgCostPerUnit"}
      //             data-type={"number"}
      //             onPaste={(e) => {
      //               e.preventDefault();
      //               return false;
      //             }}
      //             min={0}
      //             disabled={true}
      //             value={CommonUtil.getFloatValue(original.usgCostPerUnit, true)}
      //             onKeyUp={(e) => {
      //               CommonUtil.maxLengthCheck(e, 10);
      //             }}
      //             onKeyDown={(e) => {
      //               CommonUtil.maxLengthCheck(e, 10);
      //             }}
      //             maxLength={10}
      //             minLength={1}
      //           />
      //         </InputGroup>
      //         //  CommonUtil.initializeValue(original.ingredientUOM)
      //       );
      //     },
      //   },
      {
        Header: "Cost Per Unit ($)",
        id: "purchasePrice",
        accessor: "purchasePrice",
        name: "purchasePrice",
        required: false,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeRemoveFlag: true,
        cloneModeRemoveFlag: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? "required-error" : ""}
            >
              <FormControl
                id={"purchasePrice" + "_" + index}
                name={"purchasePrice"}
                data-type={"number"}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                min={0}
                disabled={true}
                value={CommonUtil.getFloatValue(original.purchasePrice, true)}
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
            </InputGroup>
            //  CommonUtil.initializeValue(original.ingredientUOM)
          );
        },
      },
        {
          Header: "Total Cost($)",
          id: "totalCosts",
          accessor: "totalCosts",
          name: "totalCosts",
          required: false,
          type: "number",
          inputType: "number",
          disableSortBy: true,
          disableFilters: true,
          createModeRemoveFlag: false,
          cloneModeRemoveFlag: false,
          createModeShowFlag: true,
          cloneModeShowFlag: true,
          editModeShowFlag: true,
          viewModeShowFlag: true,
          className: "input-field",
          Cell: ({ cell }) => {
            const { value } = cell;
            const { index, original } = cell.row;
            return (
              <div style={{ padding: '6px'}}>{CommonUtil.getFloatValue(original.quantity * original.purchasePrice, true)}</div>
            );
          },
        },
      // {
      //     Header: "Pack Size Qty",
      //     id: "usgPackSizeQty",
      //     accessor: "usgPackSizeQty",
      //     name: "usgPackSizeQty",
      //     required: false,
      //     type: "text",
      //     // inputType: "number",
      //     disableSortBy: true,
      //     disableFilters: true,
      //     createModeShowFlag: false,
      //     cloneModeShowFlag: false,
      //     editModeShowFlag: false,
      //     viewModeShowFlag: false,
      //     className: "input-field",
      //     Cell: ({ cell }) => {
      //         const { value } = cell;
      //         const { index, original } = cell.row;

      //         return (
      //             <InputGroup
      //                 className={that.state.submitted && !value ? 'required-error' : ''}>
      //                 <FormControl id={'usgPackSizeQty' + '_' + index}
      //                     name={'usgPackSizeQty'}
      //                     data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
      //                     min={0}
      //                     // onChange={(e) => that.handleTableTextBoxChange(e)}
      //                     disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : true}
      //                     value={original.usgPackSizeQty}
      //                     onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
      //                     onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
      //                     maxLength={10}
      //                     minLength={1} />
      //                  <InputGroup.Addon>{ CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.usgUOM) }</InputGroup.Addon>
      //             </InputGroup>
      //         )
      //     }
      // },
      //   {
      //     Header: "Total Cost($)",
      //     id: "purchasePrice",
      //     accessor: "purchasePrice",
      //     name: "purchasePrice",
      //     required: true,
      //     type: "number",
      //     inputType: "number",
      //     disableSortBy: true,
      //     disableFilters: true,
      //     className: "input-field",
      //     Cell: ({ cell }) => {
      //       const { value } = cell;
      //       const { index, original } = cell.row;
      //       return (
      //         <InputGroup
      //           className={
      //             that.state.submitted &&
      //             original.ingredientId &&
      //             !original.purchasePrice
      //               ? "required-error"
      //               : ""
      //           }
      //         >
      //           <FormControl
      //             id={"purchasePrice" + "_" + index}
      //             data-type={"number"}
      //             onPaste={(e) => {
      //               e.preventDefault();
      //               return false;
      //             }}
      //             name={"purchasePrice"}
      //             onChange={that.handleTableTextBoxChange}
      //             disabled={
      //               that.props.actionMode == "disabled"
      //                 ? true
      //                 : CommonUtil.isViewMode(that.props.actionMode)
      //                 ? true
      //                 : false
      //             }
      //             value={original.purchasePrice}
      //             className="center-align"
      //             onKeyUp={(e) => {
      //               CommonUtil.maxLengthCheck(e, 10);
      //             }}
      //             onKeyDown={(e) => {
      //               CommonUtil.maxLengthCheck(e, 10);
      //             }}
      //             maxLength={10}
      //             minLength={1}
      //           />
      //           {/*<InputGroup.Addon>
      //                             {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
      //         </InputGroup>
      //       );
      //     },
      //   },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        style: {
          flex: "0 0 60px",
        },
        className: "action justify-content-center",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button
                bsStyle="default"
                simple
                icon
                disabled={
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false
                }
              >
                <div className="circle">
                  <i
                    title="remove"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-trash"
                    onClick={(e) => that.handleDeleteRowPopup(e)}
                  />
                </div>
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const CREATE_PRODUCT_OPERATION_TABLE_LIST = (that) => {
  return {
    tableData: [
      {
        operationName: "",
        duration: "",
        cost: "",
        operationId: "",
      },
    ],
    tableColumnList: [
      {
        Header: "Process",
        id: "operationId",
        name: "operationId",
        accessor: "operationId",
        required: true,
        type: "text",
        style: {
          flex: "0 0 350px",
        },
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            // <div className="full-width" title={original.operationName ? original.operationName : ''}>
            <SuggestionUtil
              className={that.state.submitted && !value ? "required-error" : ""}
              searchOptionList={["operationId", "operationName"]}
              id={"operationId" + "_" + index}
              options={that.state.operationList}
              selectedListKeys={["operationId"]}
              selectedAttributeList={that.state.operations}
              disabled={
                CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }
              placeholder=""
              setNoFocus={true}
              value={
                original.operationId
                  ? original.operationId + "|" + original.operationName
                  : ""
              }
              selectedValue={
                original.operationId
                  ? original.operationId + "|" + original.operationName
                  : ""
              }
              onChange={(e) =>
                that.handleTableSuggestionChange(
                  e,
                  "operationId" + "_" + index,
                  ["operationId", "operationName"]
                )
              }
              handleSuggestionChange={that.handleTableSuggestionChange}
            />
            // </div>
          );
        },
      },
      {
        Header: "Production Time",
        id: "duration",
        accessor: "duration",
        name: "duration",
        required: true,
        type: "text",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  original.operationId &&
                  !original.duration
                  ? "required-error"
                  : ""
              }
            >
              <FormControl
                id={"duration" + "_" + index}
                data-type={"number"}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                name={"duration"}
                onChange={that.handleTableTextBoxChange}
                disabled={
                  that.props.actionMode == "disabled"
                    ? true
                    : isAuthorized("viewOperations") ||
                      CommonUtil.isViewMode(that.props.actionMode)
                      ? true
                      : false
                }
                value={original.duration}
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
              <InputGroup.Addon>hrs</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Cost",
        id: "cost",
        accessor: "cost",
        name: "cost",
        required: true,
        type: "text",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted && original.operationId && !original.cost
                  ? "required-error"
                  : ""
              }
            >
              <FormControl
                id={"cost" + "_" + index}
                data-type={"number"}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                name={"cost"}
                onChange={that.handleTableTextBoxChange}
                disabled={
                  that.props.actionMode == "disabled"
                    ? true
                    : isAuthorized("viewOperations") ||
                      CommonUtil.isViewMode(that.props.actionMode)
                      ? true
                      : false
                }
                value={value}
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
              {/*<InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        style: {
          flex: "0 0 60px",
        },
        className: "action justify-content-center",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button
                bsStyle="default"
                simple
                icon
                disabled={
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false
                }
              >
                <div className="circle">
                  <i
                    title="remove"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-trash"
                    onClick={(e) => that.handleDeleteRowPopup(e)}
                  />
                </div>
              </Button>
            </div>
          );
        },
      },
      // {
      //     name: "operationId",
      //     id: "operationId",
      //     type: "TEMP",
      //     createModeShowFlag: true,
      //     cloneModeShowFlag: true,
      //     editModeShowFlag: true,
      // },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      addNewRowFunction: that.handleTableAddRow,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const CREATE_PRODUCT_BOM_KIT_TABLE_LIST = (that) => {
  return {
    tableData: [
      {
        productId: "",
        quantity: "",
        productUOM: "",
        purchasePrice: "",
      },
    ],
    tableColumnList: [
      {
        Header: "Components",
        id: "productId",
        name: "productId",
        accessor: "productId",
        style: {
          flex: "0 0 35%",
        },
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <div
              className="full-width"
              title={
                original.productId
                  ? original.productId + "|" + original.productName
                  : ""
              }
            >
              <SuggestionUtil
                className={
                  that.state.submitted && !value ? "required-error" : ""
                }
                searchOptionList={["productId","productName","productSKU"]}
                id={"productId" + "_" + index}
                options={that.state.productIngredientOptions}
                selectedListKeys={["productId"]}
                selectedAttributeList={that.state.bomKitComponents}
                setNoFocus={true}
                reSelect={false}
                placeholder=""
                disabled={
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false
                }
                value={
                  original.productId
                    ? original.productId + "|" + original.productName
                    : ""
                }
                selectedValue={
                  original.productId
                    ? original.productId + "|" + original.productName
                    : ""
                }
                onChange={(e) =>
                  that.handleTableSuggestionChange(
                    e,
                    "productId" + "_" + index,
                    [
                      "productId",
                      "productName",
                    ]
                  )
                }
                handleSuggestionChange={that.handleTableSuggestionChange}
              />
            </div>
          );
        },
      },
      {
        Header: "Quantity",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        inputType: "number",
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? "required-error" : ""}
            >
              <FormControl
                id={"quantity" + "_" + index}
                data-type={"number"}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                name={"quantity"}
                onChange={that.handleTableTextBoxChange}
                disabled={
                  that.props.actionMode == "disabled"
                    ? true
                    : CommonUtil.isViewMode(that.props.actionMode)
                      ? true
                      : false
                }
                value={original.quantity}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
              <InputGroup.Addon>
                {CommonUtil.getSelectedOptionNameFromCode(
                  that.props.dataDictionaryList,
                  original.productUOM
                )}
              </InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Cost",
        id: "purchasePrice",
        accessor: "purchasePrice",
        name: "purchasePrice",
        required: true,
        type: "number",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  original.productId &&
                  !original.purchasePrice
                  ? "required-error"
                  : ""
              }
            >
              <FormControl
                id={"purchasePrice" + "_" + index}
                data-type={"number"}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                name={"purchasePrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={
                  that.props.actionMode == "disabled"
                    ? true
                    : CommonUtil.isViewMode(that.props.actionMode)
                      ? true
                      : false
                }
                value={original.purchasePrice}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
              {/*<InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        style: {
          flex: "0 0 60px",
        },
        className: "action justify-content-center",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button
                bsStyle="default"
                simple
                icon
                disabled={
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false
                }
              >
                <div className="circle">
                  <i
                    title="remove"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-trash"
                    onClick={(e) => that.handleDeleteRowPopup(e)}
                  />
                </div>
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

// export const CREATE_SUPPLIER_MODAL_LIST = (that) => ({
//     attributeObj: {
//         supplierName: "",
//     },
//     locationAttributeObj: {
//         locationName: "",
//         address: "",
//         country: "",
//         state: "",
//         city: "",
//         zipcode: "",
//     },
//     attributeList: [
//         {
//             name: "supplierName",
//             type: "TEXTBOX",
//             label: "supplier Name",
//             required: true,
//             fieldWidth: 12,
//             numberOfRow: 0,
//             createModeShowFlag: true,
//             cloneModeShowFlag: true,
//             editModeShowFlag: true,
//             viewModeShowFlag: true,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             maxLength: 32,
//             minLength: 3,
//             mandatoryMsgText: "Field can not be empty.",
//         },
//     ],
//     attributeListLocation: [
//         {
//             name: "locationName",
//             type: "TEXTBOX",
//             label: "Location Name",
//             inputType: "text",
//             required: true,
//             fieldWidth: 6,
//             createMode: "enable",
//             cloneMode: "enable",
//             editMode: "enable",
//             viewMode: "disabled",
//             placeholder: "",
//             numberOfRow: 0,
//             maxLength: 32,
//             minLength: 3,
//             mandatoryMsgText: "Field can not be empty.",
//         },
//         {
//             name: "address",
//             type: "TEXTBOX",
//             label: "Address",
//             inputType: "text",
//             required: true,
//             fieldWidth: 6,
//             createMode: "enable",
//             cloneMode: "enable",
//             editMode: "enable",
//             viewMode: "disabled",
//             placeholder: "",
//             numberOfRow: 0,
//             maxLength: 100,
//             minLength: 3,
//             mandatoryMsgText: "Field can not be empty.",
//         },
//         {
//             name: "country",
//             type: "DROPDOWN",
//             label: "Country",
//             required: true,
//             isCountry: true,
//             fieldWidth: 3,
//             createMode: "enable",
//             cloneMode: "enable",
//             editMode: "enable",
//             viewMode: "disabled",
//             placeholder: "",
//             numberOfRow: 0,
//             mandatoryMsgText: "Field can not be empty.",
//             options: [],
//         },
//         {
//             name: "state",
//             type: "DROPDOWN",
//             label: "State",
//             required: true,
//             fieldWidth: 3,
//             isState: true,
//             createMode: "enable",
//             cloneMode: "enable",
//             editMode: "enable",
//             viewMode: "disabled",
//             placeholder: "",
//             numberOfRow: 0,
//             mandatoryMsgText: "Field can not be empty.",
//             options: [],
//         },
//         {
//             name: "city",
//             type: "DROPDOWN",
//             label: "City",
//             required: true,
//             fieldWidth: 3,
//             isCity: true,
//             createMode: "enable",
//             cloneMode: "enable",
//             editMode: "enable",
//             viewMode: "disabled",
//             placeholder: "",
//             numberOfRow: 0,
//             mandatoryMsgText: "Field can not be empty.",
//             options: [],
//         },
//         {
//             name: "zipcode",
//             type: "TEXTBOX",
//             label: "Zip Code",
//             minValue: 0,
//             required: true,
//             fieldWidth: 3,
//             createMode: "enable",
//             cloneMode: "enable",
//             editMode: "enable",
//             viewMode: "disabled",
//             placeholder: "",
//             numberOfRow: 0,
//             maxLength: 15,
//             minLength: 3,
//             mandatoryMsgText: "Field can not be empty.",
//         },
//     ],
// });

// export const CREATE_SUPPLIER_PRODUCT_MODAL_TABLE_LIST = (that) => {
//     return {
//         tableData: [{
//             leadTime: '',
//             moq: '',
//             moa: '',
//             taxCode: '',
//         }],
//         tableColumnList: [
//             {
//                 Header: "Lead Time(days)",
//                 id: "leadTime",
//                 name: "leadTime",
//                 accessor: "leadTime",
//                 type: "text",
//                 required: true,
//                 inputType: 'number',
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <FormControl
//                             className={that.state.submitted && original.productId &&
//                                 !original.leadTime ? 'required-error center-align' : 'center-align'}
//                             id={'leadTime' + '_' + index}
//                             data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'leadTime'}
//                             onChange={that.handleTableTextBoxChange}
//                             disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                             value={value}
//                             onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                             onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                             maxLength={10}
//                             minLength={1} />

//                     )
//                 }
//             },
//             {
//                 Header: "MOQ",
//                 id: "moq",
//                 name: "moq",
//                 title: "Minimum Order Quantity",
//                 accessor: "moq",
//                 type: "text",
//                 required: true,
//                 inputType: 'number',
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <InputGroup className={that.state.submitted &&
//                             original.productId &&
//                             !original.moq ? 'required-error' : ''}>
//                             <FormControl
//                                 id={'moq' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moq'}
//                                 onChange={that.handleTableTextBoxChange}
//                                 disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                                 value={value}
//                                 className="center-align"
//                                 onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 maxLength={10}
//                                 minLength={1} />
//                             <InputGroup.Addon>{ CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM) }</InputGroup.Addon>
//                         </InputGroup>
//                     )
//                 }
//             },
//             {
//                 Header: "MOA",
//                 id: "moa",
//                 name: "moa",
//                 title: "Minimum Order Amount",
//                 accessor: "moa",
//                 type: "text",
//                 required: true,
//                 inputType: 'number',
//                 submitted: that.state.submitted,
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <InputGroup className={that.state.submitted &&
//                             original.productId &&
//                             !original.moa ? 'required-error' : ''}>
//                             <FormControl
//                                 id={'moa' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moa'}
//                                 onChange={that.handleTableTextBoxChange}
//                                 disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                                 value={value}
//                                 className="center-align"
//                                 onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 maxLength={10}
//                                 minLength={1} />
//                             <InputGroup.Addon>{ CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.productUOM) }</InputGroup.Addon>
//                         </InputGroup>
//                     )
//                 }
//             },
//             {
//                 Header: "Tax %",
//                 id: "taxCode",
//                 name: "taxCode",
//                 accessor: "taxCode",
//                 type: "text",
//                 dataDictionaryFlag: true,
//                 dataDictionaryId: 'taxList',
//                 required: true,
//                 submitted: that.state.submitted,
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <Select
//                             className={that.state.submitted && original.productId &&
//                                 !original.taxCode ? 'required-error center-align' : 'center-align'}
//                             id={'taxCode' + '_' + index}
//                             name={"taxCode" + '_' + index}
//                             onChange={that.handleTableDropDownChange}
//                             options={that.props.dataDictionaryList &&
//                                 that.props.dataDictionaryList.dataDictionaryList &&
//                                 that.props.dataDictionaryList.dataDictionaryList.taxList}
//                             classNamePrefix="react-select"
//                             isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                             value={{ "label": original.taxCode }} />
//                     )
//                 }
//             },
//             {
//                 Header: "Action",
//                 id: "actions",
//                 accessor: "actions",
//                 sticky: "right",
//                 className: "action justify-content-center",
//                 style: {
//                     flex: '0 0 60px',
//                 },
//                 disableSortBy: true,
//                 disableFilters: true,
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <div className="actions-left">
//                             <Button bsStyle="default" simple icon disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
//                                 <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
//                                     className="fa fa-trash" onClick={(e) => that.handleTableRemove(e)} />
//                                 </div>
//                             </Button>
//                         </div>
//                     )
//                 }
//             }
//         ],
//         tableConfig: {
//             defaultFilteredList: [],
//             defaultSortedList: [],
//             defaultPageSize: 50,
//             addNewRowFunction: that.handleTableAddRow,
//             showExport: false,
//             customPagination: false,
//             showServerSideFilter: false,
//             isFilterEnabed: false,
//             showPagination: false,
//             showAddRow: false,
//             isDraggable: false,
//         }
//     }
// };

// export const CREATE_SUPPLIER_INGREDIENT_MODAL_TABLE_LIST = (that) => {
//     return {
//         tableData: [{
//             leadTime: '',
//             moq: '',
//             moa: '',
//             taxCode: '',
//         }],
//         tableColumnList: [
//             {
//                 Header: "Lead Time(days)",
//                 id: "leadTime",
//                 name: "leadTime",
//                 accessor: "leadTime",
//                 type: "text",
//                 required: true,
//                 inputType: 'number',
//                 submitted: that.state.submitted,
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <FormControl
//                             className={that.state.submitted && original.ingredientId &&
//                             className={that.state.submitted && original.productId &&
//                                 !original.leadTime ? 'required-error center-align' : 'center-align'}
//                             id={'leadTime' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'leadTime'}
//                             onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                             value={value}
//                             onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                             onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                             maxLength={10}
//                             minLength={1} />
//                     )
//                 }
//             },
//             {
//                 Header: "MOQ",
//                 id: "moq",
//                 name: "moq",
//                 accessor: "moq",
//                 type: "text",
//                 required: true,
//                 inputType: 'number',
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <InputGroup className={that.state.submitted && original.ingredientId &&
//                             !original.moq ? 'required-error' : ''}>
//                             <FormControl id={'moq' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moq'}
//                                 onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                                 value={value} className="center-align"
//                                 onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 maxLength={10}
//                                 minLength={1} />
//                             <InputGroup.Addon>{original.ingredientUOM}</InputGroup.Addon>
//                         </InputGroup>
//                     )
//                 }
//             },
//             {
//                 Header: "MOA",
//                 id: "moa",
//                 name: "moa",
//                 accessor: "moa",
//                 type: "text",
//                 required: true,
//                 inputType: 'number',
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <InputGroup className={that.state.submitted && original.ingredientId &&
//                             !original.moa ? 'required-error' : ''}>
//                             <FormControl id={'moa' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moa'}
//                                 onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                                 value={value} className="center-align"
//                                 onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
//                                 maxLength={10}
//                                 minLength={1} />
//                             <InputGroup.Addon>{original.ingredientUOM}</InputGroup.Addon>
//                         </InputGroup>
//                     )
//                 }
//             },
//             {
//                 Header: "Tax %",
//                 id: "taxCode",
//                 name: "taxCode",
//                 accessor: "taxCode",
//                 type: "text",
//                 dataDictionaryFlag: true,
//                 dataDictionaryId: 'taxList',
//                 required: true,
//                 submitted: that.state.submitted,
//                 className: "input-field",
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <Select
//                             className={that.state.submitted && original.ingredientId &&
//                                 !original.taxCode ? 'required-error center-align' : 'center-align'}
//                             id={'taxCode' + '_' + index}
//                             name={"taxCode" + '_' + index}
//                             onChange={that.handleTableDropDownChange}
//                             options={that.props.dataDictionaryList &&
//                                 that.props.dataDictionaryList.dataDictionaryList &&
//                                 that.props.dataDictionaryList.dataDictionaryList.taxList}
//                             classNamePrefix="react-select"
//                             isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
//                             value={{ "label": original.taxCode }} />
//                     )
//                 }
//             },
//             {
//                 Header: "Action",
//                 id: "actions",
//                 accessor: "actions",
//                 sticky: "right",
//                 className: "action justify-content-center",
//                 style: {
//                     flex: '0 0 60px'
//                 },
//                 disableSortBy: true,
//                 disableFilters: true,
//                 Cell: ({ cell }) => {
//                     const { value } = cell;
//                     const { index, original } = cell.row;
//                     return (
//                         <div className="actions-left">
//                             <Button bsStyle="default" simple icon disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
//                                 <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
//                                     className="fa fa-trash" onClick={(e) => that.handleTableRemove(e)} />
//                                 </div>
//                             </Button>
//                         </div>
//                     )
//                 }
//             }
//         ],
//         tableConfig: {
//             defaultFilteredList: [],
//             defaultSortedList: [],
//             defaultPageSize: 50,
//             addNewRowFunction: that.handleTableAddRow,
//             showExport: false,
//             customPagination: false,
//             showServerSideFilter: false,
//             isFilterEnabed: false,
//             showPagination: false,
//             showAddRow: false,
//             isDraggable: false,
//         }
//     }
// };

// export const LOCATION_PAGE_LIST =
// {
//     attributeObj: {
//         locationName: '',
//         address: '',
//         country: '',
//         state: '',
//         city: '',
//         zipcode: '',
//         isDefault: false
//     },
//     attributeList: [
//         {
//             name: "locationName",
//             type: "TEXTBOX",
//             label: "Location Name",
//             required: true,
//             fieldWidth: 4,
//             numberOfRow: 0,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             createModeShowFlag: true,
//             maxLength: 32,
//             lengthValidationMessage: "Max length of 32 chars exceeded",
//             mandatoryMsgText: "Field can not be empty."
//         },
//         {
//             name: "address",
//             type: "TEXTBOX",
//             label: "Address",
//             inputType: "text",
//             required: true,
//             fieldWidth: 8,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             createModeShowFlag: true,
//             placeholder: "",
//             numberOfRow: 0,
//             maxLength: 100,
//             lengthValidationMessage: "Max length of 100 chars exceeded",
//             mandatoryMsgText: "Field can not be empty."
//         },
//         {
//             name: "country",
//             type: "DROPDOWN",
//             label: "Country",
//             required: true,
//             isCountry: true,
//             fieldWidth: 3,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             createModeShowFlag: true,
//             placeholder: "",
//             numberOfRow: 0,
//             mandatoryMsgText: "Field can not be empty.",
//             options: []
//         },
//         {
//             name: "state",
//             type: "DROPDOWN",
//             label: "State",
//             required: true,
//             fieldWidth: 3,
//             isState: true,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             createModeShowFlag: true,
//             placeholder: "",
//             numberOfRow: 0,
//             mandatoryMsgText: "Field can not be empty.",
//             options: []
//         },
//         {
//             name: "city",
//             type: "DROPDOWN",
//             label: "City",
//             required: true,
//             fieldWidth: 3,
//             isCity: true,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             createModeShowFlag: true,
//             placeholder: "",
//             numberOfRow: 0,
//             mandatoryMsgText: "Field can not be empty.",
//             options: []
//         },
//         {
//             name: "zipcode",
//             type: "TEXTBOX",
//             label: "Zip Code",
//             minValue: 0,
//             required: true,
//             fieldWidth: 3,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             createModeShowFlag: true,
//             placeholder: "",
//             numberOfRow: 0,
//             maxLength: 15,
//             lengthValidationMessage: "Max length of 15 chars exceeded",
//             mandatoryMsgText: "Field can not be empty."
//         }
//     ]

// };

// export const CREATE_SUPPLIER_PAGE_LIST =
// {
//     attributeObj: {
//         supplierId: '',
//         supplierName: '',
//         status: statusConstant.ACTIVE_STATUS,
//         locations: [],
//         documents: []
//     },
//     attributeList: [
//         {
//             name: "supplierId",
//             type: "UNIQUE_CODE",
//             label: "Supplier Code",
//             prefix: "SUP",
//             required: false,
//             fieldWidth: 6,
//             inputType: "text",
//             numberOfRow: 0,
//             createModeRemoveFlag: true,
//             cloneModeRemoveFlag: true,
//             createModeShowFlag: true,
//             cloneModeShowFlag: true,
//             editModeShowFlag: true,
//             viewModeShowFlag: true,
//             createMode: 'disabled',
//             cloneMode: 'disabled',
//             editMode: 'disabled',
//             viewMode: 'disabled',
//             mandatoryMsgText: "Field can not be empty.",
//         },
//         {
//             name: "supplierName",
//             type: "TEXTBOX",
//             label: "Supplier Name",
//             required: true,
//             fieldWidth: 12,
//             numberOfRow: 0,
//             createModeShowFlag: true,
//             cloneModeShowFlag: true,
//             editModeShowFlag: true,
//             viewModeShowFlag: true,
//             createMode: 'enable',
//             cloneMode: 'enable',
//             editMode: 'enable',
//             viewMode: 'disabled',
//             maxLength: 32,
//             lengthValidationMessage: "Max length of 32 chars exceeded",
//             mandatoryMsgText: "Field can not be empty.",
//             customMessage: "Supplier Name already exist."
//         },
//         {
//             name: "status",
//             type: "TEMP",
//             createModeShowFlag: true,
//             cloneModeShowFlag: true,
//             editModeShowFlag: true,
//             viewModeShowFlag: true,
//         },
//         {
//             name: "version",
//             type: "TEMP",
//             createModeShowFlag: false,
//             cloneModeShowFlag: false,
//             editModeShowFlag: true,
//         },
//         {
//             name: "locations",
//             type: "TEMP",
//             createModeShowFlag: true,
//             cloneModeShowFlag: true,
//             editModeShowFlag: true,
//         },
//         {
//             name: "documents",
//             type: "TEMP",
//             createModeShowFlag: true,
//             cloneModeShowFlag: true,
//             editModeShowFlag: true,
//         },
//     ]
// };

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: "",
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Product Code/Name",
      },
    ],
  };
};
export const PRODUCTS_VARIANTS_MAP_PAGE_LIST = (that) => {
  const tableColumnList = [
    {
      Header: "Product",
      id: "productId",
      name: "productId",
      accessor: "productId",
      required: true,
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      disableSortBy: true,
      disableFilters: true,
      className: "input-field",
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return (
          <div
            className="full-width"
            title={
              original.productId
                ? original.productId + "|" + original.productName
                : ""
            }
          >
            {original.productId
              ? original.productId + "|" + original.productName
              : ""}
          </div>
        );
      },
    },
    {
      Header: "SKU",
      id: "productSKU",
      accessor: "productSKU",
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      disableSortBy: true,
      disableFilters: true,
      className: "input-field",
      style: {
        flex: "0 0 120px",
      },
    },
    {
      Header: "Sale Price",
      id: "salesPrice",
      accessor: "salesPrice",
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      disableSortBy: true,
      disableFilters: true,
      style: {
        flex: "0 0 120px",
      },
      Cell: ({ cell }) => {
        cell.column.Header = that.props.currencyCode
          ? "Sale Price" +
          " " +
          "(" +
          currencyIcon.getCurrencyIcon(that.props.currencyCode) +
          ")"
          : "Sale Price";
        const { value } = cell;
        const { index, original } = cell.row;
        return <>{CommonUtil.getFloatValue(value, true)}</>;
      },
    },
    {
      Header: "Actions",
      id: "actions",
      accessor: "actions",
      className: "action justify-content-center",
      style: {
        flex: "0 0 60px",
      },
      disableSortBy: true,
      disableFilters: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      Cell: ({ cell }) => {
        const { value } = cell;
        const { index, original } = cell.row;
        return (
          <div
            className={
              CommonUtil.isViewMode(that.props.actionMode) ||
                !isAuthorized("changeProductStatus")
                ? "actions-left disabled"
                : "actions-left"
            }
          >
            <Button bsStyle="default" simple icon>
              <div className="circle">
                <i
                  title="remove"
                  id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                  className="fa fa-trash"
                  onClick={(e) => that.handleDeleteMapRowPopup(e)}
                />
              </div>
            </Button>
          </div>
        );
      },
    },
  ];

  const purchasePriceColumn =  {
    Header: "Purchase Price",
    id: "purchasePrice",
    accessor: "purchasePrice",
    inputType: "text",
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    disableSortBy: true,
    disableFilters: true,
    style: {
      flex: "0 0 120px",
    },
    Cell: ({ cell }) => {
      cell.column.Header = that.props.currencyCode
        ? "Purchase Price" +
        " " +
        "(" +
        currencyIcon.getCurrencyIcon(that.props.currencyCode) +
        ")"
        : "Purchase Price";
      const { value } = cell;
      const { index, original } = cell.row;
      return <>{CommonUtil.getFloatValue(value, true)}</>;
    },
  };

  if (isAuthorized("viewCost")) {
    tableColumnList.slice(3, 0, purchasePriceColumn);
  }

  return {
    tableColumnList,
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 100,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const PRODUCTS_VARIANTS_CREATE_PAGE_LIST = (that) => {
  const tableColumnList = [
    {
      Header: "Product Code",
      id: "productId",
      accessor: "productId",
      style: {
        flex: "0 0 110px",
      },
      disableSortBy: true,
      disableFilters: true,
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return <>{value && `PRO-${value}`}</>;
      },
    },
    {
      Header: "Product",
      id: "productName",
      name: "productName",
      accessor: "productName",
      required: true,
      type: "text",
      disableSortBy: true,
      disableFilters: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      className: "input-field",
      // style: {
      //     flex: '0 0 30%'
      // },
      Cell: ({ cell }) => {
        var value = cell.value;
        const { index, original } = cell.row;
        return (
          <InputGroup
            className={
              that.state.submitted && !CommonUtil.isNotNull(value)
                ? "required-error"
                : ""
            }
          >
            <FormControl
              id={"productName" + "_" + index}
              name={"productName"}
              min={0}
              onChange={that.handleTableTextBoxChange}
              disabled={
                CommonUtil.isViewMode(that.props.actionMode) ||
                  !isAuthorized("changeProductStatus")
                  ? true
                  : false
              }
              value={value}
              onKeyUp={(e) => {
                CommonUtil.maxLengthCheck(e, 500);
              }}
              onKeyDown={(e) => {
                CommonUtil.maxLengthCheck(e, 500);
              }}
              maxLength={100}
              minLength={3}
            />
          </InputGroup>
        );
      },
    },
    {
      Header: "SKU",
      id: "productSKU",
      accessor: "productSKU",
      name: "productSKU",
      required: true,
      type: "text",
      disableSortBy: true,
      disableFilters: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      className: "input-field",
      style: {
        flex: "0 0 130px",
      },
      Cell: ({ cell }) => {
        const { value } = cell;
        const { index, original } = cell.row;
        return (
          <InputGroup
            className={
              original.productName &&
              (that.state.submitted && !CommonUtil.isNotNull(value)
                ? "required-error"
                : "")
            }
          >
            <FormControl
              id={"productSKU" + "_" + index}
              name={"productSKU"}
              min={0}
              onChange={that.handleTableTextBoxChange}
              disabled={
                CommonUtil.isViewMode(that.props.actionMode) ||
                  !isAuthorized("changeProductStatus")
                  ? true
                  : false
              }
              value={value}
              onKeyUp={(e) => {
                CommonUtil.maxLengthCheck(e, 25);
              }}
              onKeyDown={(e) => {
                CommonUtil.maxLengthCheck(e, 25);
              }}
              maxLength={25}
              minLength={3}
            />
            <InputGroup.Addon>
              <i
                class="fa fa-barcode"
                aria-hidden="true"
                onClick={(e) => that.generateSKUClick(e)}
                id={"productSKU" + "_" + index}
              />
            </InputGroup.Addon>
          </InputGroup>
        );
      },
    },
    // {
    //   Header: "GTIN",
    //   id: "productGTIN",
    //   accessor: "productGTIN",
    //   name: "productGTIN",
    //   required: false,
    //   type: "text",
    //   disableSortBy: true,
    //   disableFilters: true,
    //   createModeShowFlag: false,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: false,
    //   viewModeShowFlag: false,
    //   className: "input-field",
    //   style: {
    //     flex: "0 0 110px",
    //   },
    //   Cell: ({ cell }) => {
    //     const { value } = cell;
    //     const { index, original } = cell.row;
    //     return (
    //       <InputGroup
    //         className={
    //           original.productName &&
    //           (that.state.submitted && !CommonUtil.isNotNull(value)
    //             ? "required-error"
    //             : "")
    //         }
    //       >
    //         <FormControl
    //           id={"productGTIN" + "_" + index}
    //           name={"productGTIN"}
    //           min={0}
    //           onChange={that.handleTableTextBoxChange}
    //           disabled={
    //             CommonUtil.isViewMode(that.props.actionMode) ||
    //               !isAuthorized("changeProductStatus")
    //               ? true
    //               : false
    //           }
    //           value={value}
    //           onKeyUp={(e) => {
    //             CommonUtil.maxLengthCheck(e, 25);
    //           }}
    //           onKeyDown={(e) => {
    //             CommonUtil.maxLengthCheck(e, 25);
    //           }}
    //           maxLength={25}
    //           minLength={3}
    //         />
    //       </InputGroup>
    //     );
    //   },
    // },
    {
      Header: "Sale Price",
      id: "salesPrice",
      accessor: "salesPrice",
      name: "salesPrice",
      required: true,
      type: "text",
      inputType: "number",
      isZeroAllowed: true,
      disableSortBy: true,
      disableFilters: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      className: "input-field",
      style: {
        flex: "0 0 120px",
      },
      Cell: ({ cell }) => {
        cell.column.Header = that.props.currencyCode
          ? "Sale Price" +
          " " +
          "(" +
          currencyIcon.getCurrencyIcon(that.props.currencyCode) +
          ")"
          : "Sale Price";
        const { value } = cell;
        const { index, original } = cell.row;
        return (
          <InputGroup
            className={
              original.productName &&
              (that.state.submitted && !CommonUtil.isNotNull(value)
                ? "required-error"
                : "")
            }
          >
            <FormControl
              id={"salesPrice" + "_" + index}
              data-type={"number"}
              onPaste={(e) => {
                e.preventDefault();
                return false;
              }}
              name={"salesPrice"}
              min={0}
              onChange={that.handleTableTextBoxChange}
              disabled={
                CommonUtil.isViewMode(that.props.actionMode) ||
                  !isAuthorized("changeProductStatus")
                  ? true
                  : false
              }
              value={value}
              onKeyUp={(e) => {
                CommonUtil.maxLengthCheck(e, 10);
              }}
              onKeyDown={(e) => {
                CommonUtil.maxLengthCheck(e, 10);
              }}
              maxLength={10}
              minLength={1}
            />
          </InputGroup>
        );
      },
    },
    {
      Header: "Actions",
      id: "actions",
      accessor: "actions",
      className: "action justify-content-center",
      style: {
        flex: "0 0 60px",
      },
      disableSortBy: true,
      disableFilters: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      Cell: ({ cell }) => {
        const { value } = cell;
        const { index, original } = cell.row;
        return (
          <div
            className={
              CommonUtil.isViewMode(that.props.actionMode) ||
                !isAuthorized("changeProductStatus")
                ? "actions-left disabled"
                : "actions-left"
            }
          >
            <Button bsStyle="default" simple icon>
              {!original.parentProductId && index == 0 && (
                <div className="circle">
                  <i
                    title="clone"
                    id={"copy" + "_" + index}
                    className="fa fa-copy"
                    onClick={(e) => that.copyPrice(e)}
                  />
                </div>
              )}
              {index !== 0 && (
                <div className="circle">
                  <i
                    title="remove"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-trash"
                    onClick={(e) => that.handleDeleteRowPopup(e)}
                  />
                </div>
              )}
            </Button>
          </div>
        );
      },
    },
    {
      id: "productUOM",
      name: "productUOM",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "productTax",
      name: "productTax",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "category",
      name: "category",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "brand",
      name: "brand",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "volumeUnit",
      name: "volumeUnit",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "volume",
      name: "volume",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "packSizeQty",
      name: "packSizeQty",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      id: "documentList",
      name: "documentList",
      name: "documentList",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
  ];

  const purchasePriceColumn =     {
    Header: "Purchase Price",
    id: "purchasePrice",
    accessor: "purchasePrice",
    name: "purchasePrice",
    required: true,
    type: "text",
    inputType: "number",
    isZeroAllowed: true,
    disableSortBy: true,
    disableFilters: true,
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    className: "input-field",
    style: {
      flex: "0 0 120px",
    },
    Cell: ({ cell }) => {
      cell.column.Header = that.props.currencyCode
        ? "Purchase Price" +
        " " +
        "(" +
        currencyIcon.getCurrencyIcon(that.props.currencyCode) +
        ")"
        : "Purchase Price";
      const { value } = cell;
      const { index, original } = cell.row;
      return (
        <InputGroup
          className={
            original.productName &&
            (that.state.submitted && !CommonUtil.isNotNull(value)
              ? "required-error"
              : "")
          }
        >
          <FormControl
            id={"purchasePrice" + "_" + index}
            data-type={"number"}
            onPaste={(e) => {
              e.preventDefault();
              return false;
            }}
            name={"purchasePrice"}
            min={0}
            onChange={that.handleTableTextBoxChange}
            disabled={
              CommonUtil.isViewMode(that.props.actionMode) ||
                !isAuthorized("changeProductStatus")
                ? true
                : false
            }
            value={value}
            onKeyUp={(e) => {
              CommonUtil.maxLengthCheck(e, 10);
            }}
            onKeyDown={(e) => {
              CommonUtil.maxLengthCheck(e, 10);
            }}
            maxLength={10}
            minLength={1}
          />
        </InputGroup>
      );
    },
  };

  if (isAuthorized("viewCost")) {
    tableColumnList.splice(4, 0, purchasePriceColumn);
  }

  return {
    tableData: [
      {
        productId: "",
        quantity: "",
        salePrice: "",
        taxValue: "",
        availability: "",
        productUOM: "",
      },
    ],
    tableColumnList,
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};
export const MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST = (that) => {
  const actionColumn =  {
    Header: "Actions",
    id: "actions",
    accessor: "actions",
    className: "action justify-content-center",
    style: {
      flex: "0 0 60px",
    },
    disableSortBy: true,
    disableFilters: true,
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    Cell: ({ cell }) => {
      const { value } = cell;
      const { index, original } = cell.row;
      const { productList } = that.props
      const firstChecked = productList && productList.find(item => item.isChecked);
      return (
        <div
          className={
            CommonUtil.isViewMode(that.props.actionMode) ||
              !isAuthorized("changeProductStatus")
              ? "actions-left disabled"
              : "actions-left"
          }
        >
          {(firstChecked && original && original.productId === firstChecked.productId) ?
          <Button bsStyle="default" simple icon>
              <div className="circle">
                <i
                  title="clone"
                  id={"copy" + "_" + index}
                  className="fa fa-copy"
                  onClick={(e) => that.copyPrice(original)}
                />
              </div>
          </Button> 
          : null}
        </div>
      );
    },
  };

  return {
    tableColumnList: [
      {
        Header: "",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        required: false,
        disableSortBy: true,
        disableFilters: true,
        createModeRemoveFlag: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox
                inline
                number={
                  original.productId +
                  "_" +
                  commonConstant.CREATE_ACTION_MODE +
                  "_" +
                  index
                }
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)}
              />
            </div>
          );
        },
      },
      {
        Header: "Product Code",
        id: "productId",
        accessor: "productId",
        name: "productId",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return <>PRO-{value}</>;
        },
      },
      {
        Header: "Product Name",
        id: "productName",
        accessor: "productName",
        name: "productName",
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !CommonUtil.isNotNull(value) &&
                  original.isChecked
                  ? "required-error"
                  : ""
              }
              style={{
                border: original.isChecked ? "1px solid #70707080" : "none",
              }}
            >
              <FormControl
                id={"productName" + "_" + index}
                name={"productName"}
                min={0}
                onChange={that.handleTableTextBoxChange}
                disabled={!original.isChecked ? true : false}
                value={value}
                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 100)}}
                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 100)}}
                maxLength={100}
                minLength={3}
              />
            </InputGroup>
          );
        },
      },
      {
        Header: "Cost Price",
        id: "purchasePrice",
        accessor: "purchasePrice",
        name: "purchasePrice",
        style: {
          flex: "0 0 100px",
        },
        type: "text",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        inputType: "number",
        submitted: that.state.submitted,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          console.log('cost', value)
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !CommonUtil.isNotNull(value) &&
                  original.isChecked
                  ? "required-error"
                  : ""
              }
              style={{
                border: original.isChecked ? "1px solid #70707080" : "none",
              }}
            >
              <FormControl
                id={"purchasePrice" + "_" + index}
                data-type={"number"}
                name={"purchasePrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={!original.isChecked ? true : false}
                value={value}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
            </InputGroup>
          );
        },
      },
      {
        Header: "Sale Price",
        id: "salesPrice",
        accessor: "salesPrice",
        name: "salesPrice",
        style: {
          flex: "0 0 100px",
        },
        type: "text",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        inputType: "number",
        submitted: that.state.submitted,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !CommonUtil.isNotNull(value) &&
                  original.isChecked
                  ? "required-error"
                  : ""
              }
              style={{
                border: original.isChecked ? "1px solid #70707080" : "none",
              }}
            >
              <FormControl
                id={"salesPrice" + "_" + index}
                data-type={"number"}
                name={"salesPrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={!original.isChecked ? true : false}
                value={value}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
            </InputGroup>
          );
        },
      },
    ],
    tierPriceColumns: [actionColumn],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};
export const MANAGE_MULTI_SELECTION_TIER_PRODUCTS_PAGE_LIST = (that, tierPrices) => {
  const tierPriceColumns = _.map(tierPrices, tier => {
    return {
      Header: tier.tierName,
      id: `tierId_${tier.tierId}`,
      accessor: `tierId_${tier.tierId}`,
      name: `tierId_${tier.tierId}`,
      style: {
        flex: "0 0 190px",
      },
      type: "text",
      required: true,
      inputType: "number",
      submitted: that.state.submitted,
      className: "input-field",
      disableSortBy: true,
      disableFilters: true,
      Cell: ({ cell }) => {
        const { value } = cell;
        const { index, original } = cell.row;
        const adjustmentTypeValue = CommonUtil.getSelectedOptionLabel(adjustmentType, (_.get(original, `tierId_${tier.tierId}.adjustmentType`) ? _.get(original, `tierId_${tier.tierId}.adjustmentType`) : 'Global'));
        return (
          <Row style={{
            display: 'flex',
            position: 'relative',
            margin: '0px',
            width: '100%'
          }}>
            <Row style={{ width: 'calc(100% - 120px)', margin: '0px' }}>
              <InputGroup
                className={
                  that.state.submitted &&
                    !CommonUtil.isNotNull(_.get(value, 'percentage')) &&
                    original.isChecked
                    ? "required-error"
                    : ""
                }
                style={{
                  border: (original.isChecked && adjustmentTypeValue.label !== 'Global') ? "1px solid #70707080" : "none",
                }}
              >
                <FormControl
                  id={"tierPrice" + "_" + index}
                  data-type={"number"}
                  name={`tierId_${tier.tierId}`}
                  onChange={(e) => that.handleTierValueChange(e, original, `tierId_${tier.tierId}`)}
                  disabled={(!original.isChecked || adjustmentTypeValue.label === 'Global') ? true : false}
                  value={_.get(original, `tierId_${tier.tierId}.tierValue`) !== null ? _.get(original, `tierId_${tier.tierId}.tierValue`) : _.get(value, 'percentage')}
                  className="center-align"
                  onKeyUp={(e) => {
                    CommonUtil.maxLengthCheck(e, 10);
                  }}
                  onKeyDown={(e) => {
                    CommonUtil.maxLengthCheck(e, 10);
                  }}
                  maxLength={10}
                  minLength={1}
                />

              </InputGroup>
            </Row>
            <Row style={{
              width: `120px`,
              margin: `0px`,
            }}>
              <FormGroup style={{marginBottom: '0'}}>
                <Select
                  name={`tierId_${tier.tierId}.adjustmentType`}
                  onChange={(e) => that.handleTierAdjustmentTypeChange(e, original, `tierId_${tier.tierId}`)}
                  value={adjustmentTypeValue}
                  id={'_id'}
                  isDisabled={!original.isChecked ? true : false}
                  options={adjustmentType} 
                />

              </FormGroup>
            </Row>
          </Row>
        );
      },
    }
  });

  const actionColumn =  {
    Header: "Actions",
    id: "actions",
    accessor: "actions",
    className: "action justify-content-center",
    style: {
      flex: "0 0 60px",
    },
    disableSortBy: true,
    disableFilters: true,
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    Cell: ({ cell }) => {
      const { value } = cell;
      const { index, original } = cell.row;
      const {tableDataList}=that.state
      const firstChecked = tableDataList && tableDataList.find(item => item.isChecked);

      return (
        <div
          className={
            CommonUtil.isViewMode(that.props.actionMode) ||
              !isAuthorized("changeProductStatus")
              ? "actions-left disabled"
              : "actions-left"
          }
        >
          {(firstChecked && original && original.productId === firstChecked.productId) ?
          <Button bsStyle="default" simple icon>
              <div className="circle">
                <i
                  title="clone"
                  id={"copy" + "_" + index}
                  className="fa fa-copy"
                  onClick={(e) => that.copyTierPrice(original)}
                />
              </div>
          </Button>
           : null}
        </div>
      );
    },
  };

  return {
    tableColumnList: [
      {
        Header: "",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        required: false,
        disableSortBy: true,
        disableFilters: true,
        createModeRemoveFlag: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox
                inline
                number={
                  original.productId +
                  "_" +
                  commonConstant.CREATE_ACTION_MODE +
                  "_" +
                  index
                }
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)}
              />
            </div>
          );
        },
      },
      {
        Header: "Product Code",
        id: "productId",
        accessor: "productId",
        name: "productId",
        disableSortBy: true,
        disableFilters: true,
        required: true,
        style: {
          flex: "0 0 100px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return <>PRO-{value}</>;
        },
      },
      {
        Header: "Product Name",
        id: "productName",
        accessor: "productName",
        name: "productName",
        required: false,
        style: {
          flex: "0 0 200px",
        },
        disableSortBy: true,
        disableFilters: true,
      },
      {
        Header: "Cost Price",
        id: "purchasePrice",
        accessor: "purchasePrice",
        name: "purchasePrice",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        style: {
          flex: "0 0 90px",
        },
      },
      {
        Header: "Sale Price",
        id: "salesPrice",
        accessor: "salesPrice",
        name: "salesPrice",
        required: false,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 90px",
        },
      },
    ],
    tierPriceColumns: [...tierPriceColumns, actionColumn],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};