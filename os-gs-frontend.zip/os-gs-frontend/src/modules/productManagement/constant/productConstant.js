export const CREATE_PRODUCT_HEADER_TITLE = "Create Product";
export const EDIT_PRODUCT_HEADER_TITLE = "Edit Product";
export const VIEW_PRODUCT_HEADER_TITLE = "View Product";
export const MANAGE_PRODUCT_HEADER_TITLE = "Product";

export const CREATE_PRODUCT = "createProduct";
export const DEATIVATE_PRODUCT = "deactivateProduct";
export const ACTIVE_PRODUCT = "activateProduct";
export const MODULE_NAME = "product";
export const UPDATE_PRODUCT = "updateProduct";
export const UPDATE_TIER = "updateTier";

export const CREATE_PRODUCT_PAGE_URL = '/admin/create-product';
export const MANAGE_PRODUCT_PAGE_URL = '/admin/manage-product';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_PRODUCT_LIST_URL = BASE_URL + '/products';
export const GET_PRODUCT_DETAILS_LIST = BASE_URL + '/products/multi';
export const GET_PRODUCT_DETAILS_URL = BASE_URL + '/products/';
export const GET_SKU_DETAILS_URL = BASE_URL + '/products/generate/sku';
export const SET_CREATE_PRODUCT_DETAILS_URL = BASE_URL + '/products/v1/';
export const SET_UPDATE_PRODUCT_DETAILS_URL = BASE_URL + '/products/v1/';
export const SET_UPDATE_PRODUCT_STATUS_URL = BASE_URL + '/products/';
export const GET_PRODUCT_GROSS_URL = BASE_URL + '/products/gross';
export const SET_CREATE_BULK_PRODUCT_URL = `${BASE_URL}/productsbulkupload/v1/`;
export const GET_PRODUCT_SEARCH_URL = BASE_URL + '/products';
export const GET_MAPPED_PRODUCT_LIST = BASE_URL + '/products/variant/';
export const SET_PRODUCT_MAPPING = BASE_URL + '/products/variant/';
export const SET_CREATE_UPDATE_PRODUCT_MAPPING = BASE_URL + '/products/variant';
export const SET_PRODUCT_PRICE = BASE_URL + '/products/price';

export const INGREDIENT_TABLE_NAME = 'INGREDIENTS';
export const OPERATION_TABLE_NAME = 'OPERATIONS';
export const BOM_KIT_TABLE_NAME = 'BOM-KIT COMPONENT';
