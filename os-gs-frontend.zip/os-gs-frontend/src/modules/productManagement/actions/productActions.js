import axios from '../../../axios/axios';
import * as productActionTypes from './productActionTypes';
import * as actionTypes from '../../../actions/actionTypes';
import * as productConstant from '../constant/productConstant';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: productActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setProductDetails(productDetailsObj, actionMode, productId) {

  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(productConstant.SET_CREATE_PRODUCT_DETAILS_URL,
        productDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }

  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(productConstant.SET_UPDATE_PRODUCT_DETAILS_URL +
        productId, productDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedProductCode(selectedProductCode) {
  return function (dispatch) {
    dispatch({
      type: productActionTypes.SET_SELECTED_PRODUCT_CODE,
      payload: selectedProductCode
    });
  }
}

export function setSelectedCategoryCode(selectedCategoryCode) {
  return function (dispatch) {
    dispatch({
      type: productActionTypes.SET_SELECTED_CATEGORY_CODE,
      payload: selectedCategoryCode
    });
  }
}

export function getProductList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

// export function getProductGrossList(requestObj) {
//   return function (dispatch) {
//     dispatch(beginAjaxCall());
//     axios.post(productConstant.GET_PRODUCT_GROSS_URL, requestObj).then(response => {
//       if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
//         dispatch({
//           type: productActionTypes.GET_PRODUCT_GROSS_LIST,
//           payload: response.data
//         });
//       }
//         dispatch(endAjaxCall());
//       }).catch(error => {
//         dispatch(endAjaxCall());
//       });
//   };
// }

export function getProductGrossList(params) {
  return function (dispatch) {
    // dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_GROSS_LIST,
          payload: response.data
        });
      }
      // dispatch(endAjaxCall());
    }).catch(error => {
      // dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getProductDetails(selectedProductCode, params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_DETAILS_URL +
      selectedProductCode, { params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: productActionTypes.GET_PRODUCT_DETAILS,
            payload: response.data[0]
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function getSKUNumber() {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_SKU_DETAILS_URL).then(response => {
        if (response.status == 200) {
          dispatch({
            type: productActionTypes.GET_SKU_DETAILS,
            payload: response.data
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function updateProductStatus(productDetailsObj, additionalData) {
  let params = { isIngredient: false, limit: 15, page: 1, pageIndex: 1 };
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(productConstant.SET_UPDATE_PRODUCT_STATUS_URL +
      productDetailsObj.productId, productDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(productConstant.GET_PRODUCT_LIST_URL, { params: params }).then(response => {
            if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
              dispatch(setAjaxCallStatus(updateApiResponse(response, additionalData)));
              dispatch({
                type: productActionTypes.GET_PRODUCT_LIST,
                payload: response.data
              })
            }
            dispatch(endAjaxCall());
          })
        }
      }).catch(error => {
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
        dispatch(endAjaxCall());
      });
  }
}

export function setBulkProduct(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(productConstant.SET_CREATE_BULK_PRODUCT_URL, params).then(response => {
      if (response.status == 200) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch({
          type: actionTypes.SET_UPLOAD_IMPORT_FILE_STATUS,
          payload: response.data.uploadDetails
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
      throw error;
    });
  };
}

export function getProductSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getProductDetailList(list, facilityId, customerId, tierId,supplierId) {
  let url = '';
  if (facilityId && customerId) {
    url = productConstant.GET_PRODUCT_DETAILS_LIST + "/?facilityId=" + facilityId + "&customerId=" + customerId + "&tierId=" + tierId;
  } else if (facilityId && supplierId) {
    url = productConstant.GET_PRODUCT_DETAILS_LIST + "/?facilityId=" + facilityId + "&supplierId=" + supplierId;
  } else if (facilityId) {
    url = productConstant.GET_PRODUCT_DETAILS_LIST + "/?facilityId=" + facilityId;
  } else {
    url = productConstant.GET_PRODUCT_DETAILS_LIST
  }
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(url, list).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_DETAILS_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function setProductMapping(params, selectedProductCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.put(productConstant.SET_PRODUCT_MAPPING + selectedProductCode, params).then(response => {
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}

export function setNewProductMapping(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(productConstant.SET_CREATE_UPDATE_PRODUCT_MAPPING, params).then(response => {
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}

export function getMappedProductList(selectedProductCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_MAPPED_PRODUCT_LIST + selectedProductCode).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_MAPPED_PRODUCT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}
export function setProductPrice(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.put(productConstant.SET_PRODUCT_PRICE, params).then(response => {
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}