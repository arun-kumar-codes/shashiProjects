export const MANAGE_PURCHASE_ORDER_HEADER_TITLE = "Purchase Order";
export const CREATE_PURCHASE_HEADER_TITLE = "Create Purchase Order";
export const EDIT_PURCHASE_HEADER_TITLE = "Edit Purchase Order";
export const VIEW_PURCHASE_HEADER_TITLE = "View Purchase Order";
export const VIEW_PAYMENT_DETAILS = "viewPayment";
export const MODULE_NAME = "Purchase Order";
export const CREATE_PURCHASE_ORDER = "createPurchaseOrder";
export const CREATE_PURCHASE_ORDER_PAGE_URL = "/admin/create-purchase-order";
export const MANAGE_PURCHASE_ORDER_PAGE_URL = "/admin/manage-purchase-order";
export const MANAGE_DOCUMENT_PAGE_URL = "/admin/manage-documents";

export const AMEND_STATUS_ERROR_MSG = "Are you sure, you want to amend order Status! ";

export const IS_QBO = process.env.REACT_APP_QBO_ACTIVE;
export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_PURCHASE_ORDER_LIST_URL = `${BASE_URL}/purchaseorders`;
export const GET_PURCHASE_ORDER_STOCK_LIST_URL = `${BASE_URL}/purchaseorders/stocks/`;
export const GET_PURCHASE_ORDER_DETAILS_URL = `${BASE_URL}/purchaseorders/`;
export const SET_CREATE_PURCHASE_ORDER_DETAILS_URL = `${BASE_URL}/purchaseorders/`;
export const SET_UPDATE_PURCHASE_ORDER_DETAILS_URL = `${BASE_URL}/purchaseorders/`;
export const SET_UPDATE_PURCHASE_ORDER_PAYMENT_URL = `${BASE_URL}/purchaseorders/updatepayment`;
export const SET_UPDATE_PURCHASE_ORDER_STATUS_URL = `${BASE_URL}/purchaseorders/`;
export const SET_UPDATE_PURCHASE_ORDER_AMEND_STATUS_URL = `${BASE_URL}/purchaseorders/updateStatus/`;
export const DOWNLOAD_XLS_FILE_URL = `${BASE_URL}/purchaseorders/downloadxls`;
export const VALID_RECEIVABLE_PAYABLE_AMOUNT = "Please enter amount!";
export const VALID_ACCOUNT_DESCRIPTION_COMBINATION = "Expense account and description already exist.";

export const GET_QBO_DETAILS_URL = `${BASE_URL}/qbo/checkQBOConnection`;
export const GET_QBO_BILL_DETAILS_URL = `${BASE_URL}/qbo/createQBOBill`;
export const GET_PURCHASE_ORDER_SEARCH_URL = BASE_URL + '/purchaseorders/search';

export const MANAGE_PAGE_TAB_LIST = [
    {
        key: "OPEN",
        title: "OPEN"
    },
    {
        key: "COMPLETED",
        title: "COMPLETED"
    },
    {
        key: "DRAFT",
        title: "DRAFT"
    },
];

export const MANAGE_PAGE_TAB_LIST_WITHOUT_DRAFT = [
    {
        key: "OPEN",
        title: "OPEN"
    },
    {
        key: "COMPLETED",
        title: "COMPLETED"
    },
]

