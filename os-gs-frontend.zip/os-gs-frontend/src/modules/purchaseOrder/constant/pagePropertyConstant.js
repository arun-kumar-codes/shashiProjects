import React from "react";
import Button from "components/CustomButton/CustomButton.jsx";
import StatusUtil from "../../common/util/statusUtil";
import * as purchaseOrderConstant from './purchaseOrderConstant';
import { FormControl, InputGroup } from "react-bootstrap";
import SuggestionUtil from "../../common/util/suggestionUtil";
import CommonUtil from "../../common/util/commonUtil";
import * as stockAdjustmentConstant from '../../stockAdjustment/constant/stockAdjustmentConstant';
import * as commonConstant from "../../common/constant/commonConstant";
import * as statusConstant from "../../common/constant/statusConstant";
import PurchaseOrderUtil from "../views/PurchaseOrderUtil";
import Datetime from "react-datetime";
import isAuthorized from "auth-plugin";
import Select from "react-select";
import currencyIcon from '../../common/util/currencyIcon';
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox';
import moment from "moment";


export const CREATE_PURCHASE_ORDER_PAGE_LIST = (that) => ({
  attributeObj: {
    purchaseOrderId: "",
    supplierId: "",
    supplierName: "",
    facilityId: "",
    locationName: "",
    createdDate: CommonUtil.getTodaysDate(),
    requestedDeliveryDate: CommonUtil.getTodaysDate(),
    receivedDate: "",
    invoiceDate: "",
    status: statusConstant.NEW_STATUS,
    productIngredientList: [],
    paymentStatus: statusConstant.PENDING_STATUS,
    paymentDetailsList: [],
    totalPaidAmount: 0
  },
  attributeList: [
    {
      name: "purchaseOrderId",
      type: "UNIQUE_CODE",
      label: "Purchase Order Number",
      prefix: "PO",
      required: false,
      inputType: "label",
      fieldWidth: 3,
      createModeRemoveFlag: true,
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "invoiceNumber",
      type: "TEXTBOX",
      label: "Invoice Number",
      prefix: "",
      required: false,
      inputType: "label",
      fieldWidth: 3,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      numberOfRow: 0,
      maxLength: 100,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "supplierId",
      type: "DROPDOWN",
      label: "Supplier",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "disabled",
      viewMode: "disabled",
      customAttribute: false,
      isDropdownCall: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "shipLocationName",
      type: "DROPDOWN",
      label: "Ship From",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "facilityId",
      type: "DROPDOWN",
      label: "Ship To",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    // {
    //   name: "createdDate",
    //   type: "DATE",
    //   label: "Created Date",
    //   required: true,
    //   fieldWidth: 3,
    //   inputType: "date",
    //   cloneModeRemoveFlag: true,
    //   createModeShowFlag: true,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: true,
    //   viewModeShowFlag: true,
    //   backDateNotAllowed: true,
    //   createMode: "disabled",
    //   cloneMode: "disabled",
    //   editMode: "disabled",
    //   viewMode: "disabled",
    //   placeholder: "",
    //   numberOfRow: 0,
    //   mandatoryMsgText: "Field can not be empty.",
    // },
    {
      name: "requestedDeliveryDate",
      type: "DATE",
      label: "Requested Delivery Date",
      required: true,
      fieldWidth: 3,
      inputType: "date",
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      backDateNotAllowed: false,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "invoiceDate",
      type: "DATE",
      label: "Invoice Date",
      required: false,
      fieldWidth: 3,
      inputType: "date",
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      backDateNotAllowed: false,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "receivedDate",
      type: "DATE",
      label: "Date Received",
      required: false,
      fieldWidth: 3,
      inputType: "date",
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      backDateNotAllowed: false,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "shippingMethod",
      type: "DROPDOWN",
      label: "Shipping Method",
      required: false,
      fieldWidth: 3,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: false,
      viewModeShowFlag: false,
      numberOfRow: 0,
      dataDictionaryFlag: true,
      dataDictionaryId: 'shippingMethod',
    },
    {
      name: "incoterms",
      type: "DROPDOWN",
      label: "Incoterms",
      required: false,
      fieldWidth: 3,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: false,
      viewModeShowFlag: false,
      numberOfRow: 0,
      dataDictionaryFlag: true,
      dataDictionaryId: 'incoterms',
    },
    {
      name: "reference",
      type: "TEXTBOX",
      label: "References",
      required: false,
      fieldWidth: 3,
      createMode: 'enable',
      cloneMode: 'enable',
      editMode: 'enable',
      viewMode: 'disabled',
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      numberOfRow: 0,
      maxLength: 32,
      minLength: 1,
    },
    {
      name: "status",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      name: "totalValue",
      type: "TEMP",
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      name: "version",
      type: "TEMP",
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
    {
      name: "productIngredientList",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "createdDate",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    // {
    //   name: "termsCondition",
    //   type: "TEMP",
    //   createModeShowFlag: true,
    //   cloneModeShowFlag: true,
    //   editModeShowFlag: true,
    // },
    {
      name: "paymentStatus",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
  ],
  // termsAttributeList: [
  //   {
  //     name: "termsCondition",
  //     type: "DROPDOWN",
  //     label: "Terms & Conditions",
  //     required: false,
  //     fieldWidth: 12,
  //     createMode: 'enable',
  //     cloneMode: 'enable',
  //     editMode: 'enable',
  //     viewMode: 'disabled',
  //     createModeShowFlag: true,
  //     cloneModeShowFlag: true,
  //     editModeShowFlag: true,
  //     viewModeShowFlag: true,
  //     numberOfRow: 0,
  //     dataDictionaryFlag: true,
  //     isTermConditionFlag: true,
  //     dataDictionaryId: 'termsCondition',
  //   },
  // ],
});

export const PAYMENT_PROCESS_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Received Date",
        id: "receivedDate",
        name: "receivedDate",
        accessor: "receivedDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"receivedDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }}
              name={'receivedDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "receivedDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Received Amount",
        id: "receivedAmount",
        accessor: "receivedAmount",
        name: "receivedAmount",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl id={'receivedAmount' + '_' + index}
                min={0}
                name={'receivedAmount'} onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode)}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          )
        }
      },
      {
        Header: "Payment Mode",
        id: "paymentMode",
        accessor: "paymentMode",
        name: "paymentMode",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: false,
        style: {
          flex: "0 0 120px",
        },
        dataDictionaryId: 'paymentMode',
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={'paymentMode' + '_' + index}
              name={"paymentMode" + '_' + index}
              onChange={that.handleTableDropDownChange}

              options={[
                { label: "CASH", value: "CASH" },
                { label: "CHEQUE", value: "CHEQUE" },
                { label: "RTGS", value: "RTGS" },
                { label: "NEFT", value: "NEFT" },
                { label: "UPI", value: "UPI" },
              ]}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={{ "label": original.paymentMode }} />
          )
        },
      },
      {
        Header: "Description",
        id: "description",
        name: "description",
        accessor: "description",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"description" + "_" + index}
                name={"description"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "actions",
        name: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle">
                  <i title="view" id={original.purchaseOrderId + "_" + index + "_" + original.ruleCode}
                    className="fa fa-trash"
                    onClick={(e) => that.handleTableRemove(e)}
                  />
                </div>
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST = (that) => {
  return {
    tableData: [],
    tableColumnList: [
      {
        Header: "Product",
        id: "uniqueCode",
        name: "uniqueCode",
        accessor: "uniqueCode",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 20%",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let isDelivered = CommonUtil.getFloatValue(original.deliveredQuantity) > 0 ? true : false;
          return (
            <div className="full-width" title={original.uniqueCode ? original.uniqueCode + "|" + original.uniqueName : ''}>
              <SuggestionUtil
                // className={that.state.submitted && !value ? 'required-error' : ''}
                searchOptionList={["ingredientId", "ingredientName", "productId", "productName", "productSKU"]}
                id={'uniqueCode' + '_' + index}
                options={that.state.productIngredientOptions}
                selectedListKeys={['uniqueCode', "productSKU"]}
                selectedAttributeList={that.state.productIngredientList}
                placeholder=""
                disabled={isDelivered || CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={original.uniqueCode ? original.uniqueCode + "|" + original.uniqueName : ''}
                selectedValue={original.uniqueCode ? original.uniqueCode + "|" + original.uniqueName : ''}
                onChange={(e) => that.handleTableSuggestionChange(e, 'uniqueCode' + '_' + index,
                  ["productId", "productName", "ingredientId", "ingredientName"])}
                handleSuggestionChange={that.handleTableSuggestionChange}
              />
            </div>
          )
        },
      },
      {
        Header: "Quantity",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          return (
            <InputGroup
              className={original.uniqueCode && (that.state.submitted && !value ? 'required-error' : '')}>
              <FormControl
                id={"quantity" + "_" + index}
                name={"quantity"}
                data-type={'number'}
                onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isReceivedAllStatus ||
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Received Qty",
        id: "deliveredQuantity",
        accessor: "deliveredQuantity",
        name: "deliveredQuantity",
        required: false,
        inputType: "float",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedFlag = PurchaseOrderUtil.isReceivedStatus(tempValue);
          return (
            <div className={CommonUtil.getFloatValue(original.deliveredQuantity) > 0 ? 'link' : ''}
              id={original.uniqueCode + '_' + index}
              name={'deliveredQuantity'}
              onClick={isReceivedFlag ? (e) => that.handleTableStatusButtonClick(e) : null}>
              {CommonUtil.getFloatValue(original.deliveredQuantity) + "  " +
                CommonUtil.initializeValue(original.productUOM)}
            </div>
          )
        }
      },
      {
        Header: "Rate",
        id: "price",
        accessor: "price",
        name: "price",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Rate" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Rate";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup className={original.uniqueCode && (that.state.submitted && !value ? 'required-error' : '')}>
              <FormControl
                id={"price" + "_" + index}
                data-type={'number'}
                onPaste={(e) => { e.preventDefault(); return false }}
                name={"price"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      {
        Header: "Amount",
        id: "totalPrice",
        name: "totalPrice",
        accessor: "totalPrice",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amount" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amount";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={original.uniqueCode && (that.state.submitted && !value ? 'required-error' : '')}>
              <FormControl
                id={"totalPrice" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"totalPrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, value)}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
            </InputGroup>
          );
        },
      },
      // {
      //   Header: "Excise Tax(%)",
      //   id: "taxValue",
      //   accessor: "taxValue",
      //   name: "taxValue",
      //   inputType: "float",
      //   required: true,
      //   style: {
      //     flex: "0 0 90px",
      //   },
      //   disableSortBy: true,
      //   isZeroAllowed: true,
      //   disableFilters: true,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   dataDictionaryFlag: true,
      //   dataDictionaryId: 'taxList',
      //   className: "input-field",
      //   Cell: ({ cell }) => {
      //     var value = cell.value;
      //     const { index, original } = cell.row;
      //     return (
      //       <Select
      //         className={that.state.submitted &&
      //           CommonUtil.isNullValue(value) ? 'required-error' : ''}
      //         id={'taxValue' + '_' + index}
      //         name={"taxValue" + '_' + index}
      //         onChange={that.handleTableDropDownChange}
      //         options={that.props.dataDictionaryList &&
      //           that.props.dataDictionaryList.dataDictionaryList &&
      //           that.props.dataDictionaryList.dataDictionaryList.taxList}
      //         classNamePrefix="react-select"
      //         isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
      //         value={{ "label": original.taxValue }} />
      //     )
      //   },
      // },
      {
        Header: "Volume",
        id: "totalVolume",
        accessor: "totalVolume",
        name: "totalVolume",
        required: false,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div id={'totalVolume' + '_' + index} name={'totalVolume'}>
              {CommonUtil.getFloatValue(original.totalVolume, true) + "  " +
                CommonUtil.initializeValue(original.volumeUnit)}
            </div>
          )
        }
      },

      {
        Header: "Order Status",
        id: "orderStatus",
        accessor: "orderStatus",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          value = PurchaseOrderUtil.getIngredientStatus(original);
          return (
            <div className={`full-td`}
              id={original.uniqueCode + "_" + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Document",
        id: "document",
        accessor: "document",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 80px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let documentCount = PurchaseOrderUtil.getDocumentCount(original.documents) +
            CommonUtil.isNaNValue(parseInt(original.documentCount));
          documentCount = CommonUtil.isNaNValue(documentCount);
          return (
            <a className={documentCount > 0 ? `link` : ''}
              id={original.uniqueCode + "_" + that.props.purchaseOrderId + "_" + index}
              onClick={(e) => documentCount > 0 ? PurchaseOrderUtil.handleTableUploadButtonClick(e, that) : null}>
              {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
            </a>
          )
        }
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 50px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          var tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
          var selectedListCount = PurchaseOrderUtil.getSelectedListCount(that.state.productIngredientList);
          return (
            <div className="actions-left">
              {selectedListCount > 1 ?
                <Button bsStyle="default" simple icon>
                  <div className={CommonUtil.isViewMode(that.props.actionMode) ? 'circle disabled' : 'circle'}>
                    {tempStatus == statusConstant.COMPLETED_STATUS ?
                      <i title="Completed"
                        id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                        className="fa fa-thumbs-up" />
                      : tempStatus == statusConstant.PARTIAL_RECEIVED ?
                        <i title="Receive"
                          id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                          className="fa fa-truck"
                          onClick={(e) => PurchaseOrderUtil.handleTableReceiveStockButtonClick(e, that)} />
                        : tempStatus == statusConstant.NEW_STATUS ?
                          <i title="remove"
                            id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                            className="fa fa-trash"
                            onClick={(e) => that.handleDeleteRowPopup(e)} />
                          : null}

                  </div>

                </Button>
                : null}
            </div>
          );
        },
      },
      {
        id: "uniqueName",
        name: "uniqueName",
        name: "uniqueName",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "receivedQuantity",
        name: "receivedQuantity",
        name: "receivedQuantity",
        inputType: "float",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "productUOM",
        name: "productUOM",
        name: "productUOM",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "category",
        name: "category",
        name: "category",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "brand",
        name: "brand",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
    },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volume",
        name: "volume",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "documents",
        name: "documents",
        name: "documents",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "invoiceNumber",
        name: "invoiceNumber",
        name: "invoiceNumber",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "transportDetail",
        name: "transportDetail",
        name: "transportDetail",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const CREATE_PURCHASE_ORDER_PRODUCT_RECEIVE_TABLE_LIST = (that) => {
  return {
    tableData: [
      {
        product: "",
        quantity: "",
        price: "",
        taxValue: "",
        totalPrice: "",
        productUOM: "",
        category: "",
      },
    ],
    tableColumnList: [
      {
        Header: "Product",
        id: "uniqueCode",
        name: "uniqueCode",
        accessor: "uniqueCode",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 20%",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let isDelivered = CommonUtil.getFloatValue(original.deliveredQuantity) > 0 ? true : false;
          return (
            <div className="full-width" title={original.uniqueCode ? original.uniqueCode + "|" + original.uniqueName : ''}>
              <SuggestionUtil
                className={that.state.submitted && !value ? 'required-error' : ''}
                searchOptionList={["ingredientId", "ingredientName", "productId", "productName"]}
                id={'uniqueCode' + '_' + index}
                options={that.state.productIngredientOptions}
                selectedListKeys={['uniqueCode']}
                selectedAttributeList={that.state.productIngredientList}
                disabled={isDelivered || CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                placeholder=""
                value={original.uniqueCode ? original.uniqueCode + "|" + original.uniqueName : ''}
                selectedValue={original.uniqueCode ? original.uniqueCode + "|" + original.uniqueName : ''}
                onChange={(e) => that.handleTableSuggestionChange(e, 'uniqueCode' + '_' + index,
                  ["productId", "productName", "ingredientId", "ingredientName"])}
                handleSuggestionChange={that.handleTableSuggestionChange}
              />
            </div>
          )
        },
      },
      {
        Header: "Ordered Qty",
        id: "quantity",
        accessor: "quantity",
        name: "quantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl
                id={"quantity" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"quantity"}
                disabled={isReceivedAllStatus ||
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                onChange={that.handleTableTextBoxChange}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1}
              />
              <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Received Qty",
        id: "deliveredQuantity",
        accessor: "deliveredQuantity",
        name: "deliveredQuantity",
        required: false,
        inputType: "float",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedFlag = PurchaseOrderUtil.isReceivedStatus(tempValue);
          return (
            <div className={CommonUtil.getFloatValue(original.deliveredQuantity) > 0 ? 'link' : ''}
              id={original.uniqueCode + '_' + index}
              name={'deliveredQuantity'}
              onClick={isReceivedFlag ? (e) => that.handleTableStatusButtonClick(e) : null}>
              {CommonUtil.getFloatValue(original.deliveredQuantity) + "  " +
                CommonUtil.initializeValue(original.productUOM)}
            </div>
          )
        }
      },
      {
        Header: "Left Qty",
        id: "leftQuantity",
        accessor: "leftQuantity",
        name: "leftQuantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"leftQuantity" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={"leftQuantity"}
                onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={CommonUtil.getFloatValue(PurchaseOrderUtil.getLeftQuantity(original), 2)}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Current Received Qty",
        id: "receivedQuantity",
        accessor: "receivedQuantity",
        name: "receivedQuantity",
        required: true,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
          let isReceivedAllStatus = PurchaseOrderUtil.isReceivedAllStatus(that);
          return (
            <InputGroup className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl
                id={"receivedQuantity" + "_" + index}
                name={"receivedQuantity"}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isReceivedAllStatus || tempStatus == statusConstant.COMPLETED_STATUS ||
                  CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
            </InputGroup>
          );
        },
      },
      {
        Header: "Volume",
        id: "totalVolume",
        accessor: "totalVolume",
        name: "totalVolume",
        required: false,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div id={'totalVolume' + '_' + index} name={'totalVolume'}>

              {CommonUtil.getFloatValue(original.totalVolume, true) + "  " +
                CommonUtil.initializeValue(original.volumeUnit)}
            </div>
          )
        }
      },
      {
        Header: "Order Status",
        id: "orderStatus",
        accessor: "orderStatus",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        disableSortBy: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          value = PurchaseOrderUtil.getIngredientStatus(original);
          return (
            <div className={`full-td`}
              id={original.uniqueCode + "_" + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Document",
        id: "document",
        accessor: "document",
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          let documentCount = PurchaseOrderUtil.getDocumentCount(original.documents) +
            CommonUtil.isNaNValue(parseInt(original.documentCount));
          documentCount = CommonUtil.isNaNValue(documentCount);
          return (
            <a className={documentCount > 0 ? `link` : ''}
              id={original.uniqueCode + "_" + that.props.purchaseOrderId + "_" + index}
              onClick={(e) => documentCount > 0 ? PurchaseOrderUtil.handleTableUploadButtonClick(e, that) : null}>
              {CommonUtil.isNaNValue(documentCount) + " Uploaded"}
            </a>
          )
        }
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempStatus = PurchaseOrderUtil.getIngredientStatus(original);
          let receivedQuantity = CommonUtil.getFloatValue(original.receivedQuantity);
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle">
                  {tempStatus == statusConstant.COMPLETED_STATUS ?
                    <i title="All Received"
                      id={original.uniqueCode + "_" + index}
                      className="fa fa-thumbs-up"
                    />
                    :
                    receivedQuantity > 0 ?
                      <i
                        title="upload"
                        id={original.uniqueCode + "_" + index}
                        className="fa fa-upload"
                        onClick={(e) => PurchaseOrderUtil.handleTableUploadButtonClick(e, that)}
                      /> : null}
                </div>
              </Button>
            </div>
          );
        },
      },
      {
        id: "uniqueName",
        name: "uniqueName",
        name: "uniqueName",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volume",
        name: "volume",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "productUOM",
        name: "productUOM",
        name: "productUOM",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const PURCHASE_ORDER_STOCK_VIEW_MODAL_TABLE_LIST = (that) => {
  return {
    tableData: [
    ],
    tableColumnList: [
      {
        Header: "Received Date",
        id: "createddate",
        name: "createddate",
        accessor: "createddate",
        required: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        inputType: "text",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            CommonUtil.getCurrentZoneFormatDate(value)
          )
        }
      },
      {
        Header: "Batch",
        id: "uti",
        accessor: "uti",
        name: "uti",
        required: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <FormControl id={"uti" + "_" + index} name={"uti"}
              onChange={that.handleTableTextBoxChange}
              disabled={true}
              value={value} />
          );
        },
      },
      {
        Header: "Quantity",
        id: "receivedstock",
        accessor: "receivedstock",
        name: "receivedstock",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl id={"receivedstock" + "_" + index}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={"receivedstock"}
                disabled={true} value={value} />
              <InputGroup.Addon> {that.state.entityUOM} </InputGroup.Addon>
            </InputGroup>
          );
        },
      }

    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const PURCHASE_ORDER_DOCUMENT_UPLOAD_MODAL_LIST = (that) => ({
  attributeObj: {
    utiCode: "",
    invoiceNumber: "",
    transportDetail: "",
  },
  attributeList: [
    {
      name: "utiCode",
      type: "DROPDOWN",
      label: "Select UTI Number",
      required: true,
      fieldWidth: 8,
      customAttribute: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "invoiceNumber",
      type: "TEXTBOX",
      label: "Invoice Number",
      required: false,
      inputType: "text",
      fieldWidth: 6,
      customAttribute: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "transportDetail",
      type: "TEXTBOX",
      label: "Transport Detail",
      required: false,
      inputType: "text",
      fieldWidth: 6,
      customAttribute: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
  ],
});

export const PURCHASE_ORDER_DOCUMENT_UPLOAD_MODAL_TABLE_LIST = (that) => {
  return {
    tableData: [
    ],
    tableColumnList: [
      {
        Header: "Document Type",
        id: "documentType",
        accessor: "documentType",
        name: "documentType",
        inputType: "float",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: true,
        dataDictionaryId: 'documentTypeList',
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select id={'documentType' + '_' + index}
              className={!value ? 'required-error' : ''}
              name={"documentType" + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList.documentTypeList}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={{ "label": original.documentType }} />
          )
        },
      },
      {
        Header: "Name",
        id: "documentName",
        name: "documentName",
        accessor: "documentName",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup className={(!value || value.length < 3) ? 'required-error' : ''}>
              <FormControl
                id={"documentName" + "_" + index}
                name={"documentName"}
                onChange={that.handleTableTextBoxChange}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
      {
        Header: "Expiry Date",
        id: "documentExpiryDate",
        name: "documentExpiryDate",
        accessor: "documentExpiryDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              id={"documentExpiryDate" + '_' + index}
              timeFormat={false}
              isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: CommonUtil.isViewMode(that.props.actionMode) ? true : false
              }}
              name={'documentExpiryDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "documentExpiryDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "QC Type",
        id: "qcType",
        accessor: "qcType",
        name: "qcType",
        inputType: "float",
        required: false,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: true,
        dataDictionaryId: 'qcType',
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select id={'qcType' + '_' + index}
              name={"qcType" + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList &&
                that.props.dataDictionaryList.dataDictionaryList.qcTypeList}
              classNamePrefix="react-select"
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={{ "label": original.qcType }} />
          )
        },
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 90px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle nocircle">
                  {<a href={original.documentURL} download="click to download">
                    <img title="document" src={CommonUtil.getDocumentIcon(original.fileType)} alt="Document" />
                  </a>
                  }
                </div>
                <div className="circle">
                  {<i title="remove"
                    id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                    className="fa fa-trash"
                    onClick={(e) => that.handleTableRemove(e)} />
                  }
                </div>
              </Button>
            </div>
          );
        },
      },

    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};

export const MANAGE_OPEN_PURCHASE_ORDER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order#",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
        isQBOAttribute: false,
        style: {
          flex: "0 0 100px",
        },
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        isQBOAttribute: false,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let supplierName;
          if (that.props.supplierList && that.props.supplierList.Items) {
            let tempSupplierObj = CommonUtil.getFilteredObjFromArray(that.props.supplierList.Items,
              'supplierId', original.supplierId);
            supplierName = CommonUtil.isNotNull(tempSupplierObj) ? tempSupplierObj.supplierName : null;
          }
          return (
            <div>
              {original.supplierId + " | " + supplierName}
            </div>
          );
        },
      },
      {
        Header: "Value",
        id: "totalValue",
        accessor: "totalValue",
        isQBOAttribute: false,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Value" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Value";
          var value = cell.value ? cell.value : 0.00;
          return (
            currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, CommonUtil.getFloatValue(value, true))
          )
        }
      },
      {
        Header: "ETA",
        id: "requestedDeliveryDate",
        accessor: "requestedDeliveryDate",
        isQBOAttribute: false,
        style: {
          flex: "0 0 80px",
        },
        disableSortBy: true,
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value),
              borderRadius: '5px'
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Bills Status",
        id: "billStatus",
        accessor: "billStatus",
        isQBOAttribute: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let qboBillStatus = PurchaseOrderUtil.getQBOBillStatus(original.billingSourceName);
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + original.billingSourceId}
              style={{
                backgroundColor: StatusUtil.getStatusColor(qboBillStatus),
                borderRadius: '5px'
              }}
              onClick={(e) => that.getQBOBillDetails(e)}>
              {StatusUtil.getStatusLabel(qboBillStatus)}
            </div>
          )
        }
      },
      {
        Header: "Payment Status",
        id: "paymentStatus",
        accessor: "paymentStatus",
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + commonConstant.MENU_ACTION_MODE
                + '_' + purchaseOrderConstant.VIEW_PAYMENT_DETAILS + '_' + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}
              onClick={(e) => that.handleMenuPopupAction(e)}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "actions",
        isQBOAttribute: false,
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="edit" id={original.purchaseOrderId + "_" +
                      commonConstant.EDIT_ACTION_MODE + "_" + index}
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                {isAuthorized("viewPurchaseOrder") &&
                  <div className="circle">
                    <i title="view" id={original.purchaseOrderId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                      className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_COMPLETED_PURCHASE_ORDER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order#",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
        isQBOAttribute: false,
        style: {
          flex: "0 0 150px",
        },
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let supplierName = null;
          if (that.props.supplierList && that.props.supplierList.Items) {
            let tempSupplierObj = CommonUtil.getFilteredObjFromArray(that.props.supplierList.Items,
              'supplierId', original.supplierId);
            supplierName = CommonUtil.isNotNull(tempSupplierObj) ? tempSupplierObj.supplierName : null;
          }
          return (
            <div>
              {original.supplierId + " | " + supplierName}
            </div>
          );
        },
      },
      {
        Header: "Value",
        id: "totalValue",
        accessor: "totalValue",
        isQBOAttribute: false,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Value" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Value";
          var value = cell.value ? cell.value : 0.00;
          return (
            currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, value)
          )
        }
      },
      {
        Header: "ETA",
        id: "requestedDeliveryDate",
        accessor: "requestedDeliveryDate",
        isQBOAttribute: false,
        style: {
          flex: "0 0 80px",
        },
        disableSortBy: true,
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        isQBOAttribute: false,
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value),
              borderRadius: '5px'
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Bills Status",
        id: "billStatus",
        accessor: "billStatus",
        isQBOAttribute: true,
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let qboBillStatus = PurchaseOrderUtil.getQBOBillStatus(original.billingSourceName);
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + original.billingSourceId}
              style={{
                backgroundColor: StatusUtil.getStatusColor(qboBillStatus),
                borderRadius: '5px'
              }}
              onClick={(e) => that.getQBOBillDetails(e)}>
              {StatusUtil.getStatusLabel(qboBillStatus)}
            </div>
          )
        }
      },
      {
        Header: "Payment Status",
        id: "paymentStatus",
        accessor: "paymentStatus",
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          let { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td link statusbuttonlink"
              id={original.purchaseOrderId + "_" + commonConstant.MENU_ACTION_MODE
                + '_' + purchaseOrderConstant.VIEW_PAYMENT_DETAILS + '_' + index}
              style={{
                backgroundColor: StatusUtil.getStatusColor(value),
                borderRadius: '5px'
              }}
              onClick={(e) => that.getTdProps(e)}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "action",
        isQBOAttribute: false,
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle">
                  <i title="view" id={original.purchaseOrderId + "_" + commonConstant.VIEW_ACTION_MODE +
                    "_" + index}
                    className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                </div>

                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="Credit Note"
                      id={original.purchaseOrderId + '_' + commonConstant.MENU_ACTION_MODE + "_" +
                        stockAdjustmentConstant.PO_RETURN_STATUS + "_" + index}
                      className="fa fa-money" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }

                {isAuthorized("editPurchaseOrder") &&
                  <div className="circle">
                    <i title="Amend Status"
                      id={original.purchaseOrderId + '_' + commonConstant.MENU_ACTION_MODE + "_" +
                        statusConstant.UPDATE_STATUS + "_" + index}
                      className="fa fa-reply" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_DRAFT_PURCHASE_ORDER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Product",
        id: "uniqueCode",
        accessor: "uniqueCode",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempUniqueObj = null;
          let isProFlag = CommonUtil.getModuleNameFromCode(original.uniqueCode);
          let uniqueName = null;
          if (isProFlag && that.props.productList && that.props.productList.Items) {
            tempUniqueObj = CommonUtil.getFilteredObjFromArray(that.props.productList.Items,
              'productId', original.uniqueCode);
            uniqueName = CommonUtil.isNotNull(tempUniqueObj) ? tempUniqueObj.productName : null;
          } else if (that.props.ingredientList && that.props.ingredientList.Items) {
            tempUniqueObj = CommonUtil.getFilteredObjFromArray(that.props.ingredientList &&
              that.props.ingredientList.Items, 'ingredientId', original.uniqueCode);
            uniqueName = CommonUtil.isNotNull(tempUniqueObj) ? tempUniqueObj.ingredientName : null;
          }
          return (
            <div>
              {original.uniqueCode + " | " + uniqueName}
            </div>
          );
        },
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let supplierId, supplierName;
          if (that.props.supplierList && that.props.supplierList.Items) {
            supplierId = original.orderRequest ? original.orderRequest.supplierId : null;
            let tempSupplierObj = CommonUtil.getFilteredObjFromArray(that.props.supplierList.Items,
              'supplierId', supplierId);
            supplierName = CommonUtil.isNotNull(tempSupplierObj) ? tempSupplierObj.supplierName : null;
          }
          return (
            <div>
              {supplierId + " | " + supplierName}
            </div>
          );
        },
      },
      {
        Header: "Facility",
        id: "facilityName",
        accessor: "facilityName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let facilityName;
          if (that.props.facilityList && that.props.facilityList.Items) {
            let tempFacilityObj = CommonUtil.getFilteredObjFromArray(that.props.facilityList.Items,
              'facilityId', original.facilityId);
            facilityName = CommonUtil.isNotNull(tempFacilityObj) ? tempFacilityObj.facilityName : null;
          }
          return (
            <div>
              {original.facilityId + " | " + facilityName}
            </div>
          );
        },
      },
      {
        Header: "Quantity",
        id: "orderQuantity",
        accessor: "orderQuantity",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let value = original.orderRequest && original.orderRequest.productIngredientList &&
            original.orderRequest.productIngredientList[0].quantity;
          let productUOM = original.orderRequest && original.orderRequest.productIngredientList &&
            original.orderRequest.productIngredientList[0].productUOM;
          return (
            value + " " + productUOM
          )
        }
      },
      {
        Header: "Total Cost",
        id: "totalValue",
        accessor: "totalValue",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Total Cost" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Cost";
          const { index, original } = cell.row;
          let totalValue = original.orderRequest ? original.orderRequest.totalValue : 0;
          return (
            currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, CommonUtil.getFloatValue(totalValue, true))
          )
        }
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(statusConstant.DRAFT_STATUS),
              borderRadius: '5px'
            }}
              id={original.uniqueCode + "_" + "status" + "_" + index + "_" + original.draftCode}>
              {StatusUtil.getStatusLabel(statusConstant.DRAFT_STATUS)}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                <div className="circle">
                  <i title="Confirm" id={original.uniqueCode + "_" + "confirm" +
                    "_" + index + "_" + original.draftCode}
                    className="fa fa-check" onClick={(e) => that.handleConfirmDraftAction(e, that)} />
                </div>
                <div className="circle">
                  <i title="Delete" id={original.uniqueCode + "_" + commonConstant.DELETE_ACTION_MODE +
                    "_" + index + "_" + original.draftCode}
                    className="fa fa-trash" onClick={(e) => PurchaseOrderUtil.handleDeleteDraftPopup(e, that)} />
                </div>
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: '',
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Purchase Order/Product",
      },
    ],
  }
};

export const HEADER_STATUS_LIST = [
  {
    statusKey: statusConstant.NEW_STATUS,
  },
  {
    statusKey: statusConstant.PARTIAL_RECEIVED,
  },
  {
    statusKey: statusConstant.COMPLETED_STATUS,
  },
];

export const MANAGE_HEADER_STATUS_LIST = [
  {
    statusKey: statusConstant.ALL_STATUS
  },
  {
    statusKey: statusConstant.NEW_STATUS,
  },
  {
    statusKey: statusConstant.PARTIAL_RECEIVED,
  },
  {
    statusKey: statusConstant.OVERDUE_STATUS
  }
]
export const CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST = (that) => {
  return {
      tableData: [],
      tableColumnList: [
          {
              Header: "Account",
              id: "account",
              name: "account",
              accessor: "account",
              required: true,
              inputType: "text",
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              disableSortBy: true,
              disableFilters: true,
              className: "input-field",
              dataDictionaryFlag: true,
              dataDictionaryId: 'accountList',
              Cell: ({ cell }) => {
                  let { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <div className="full-width" title={original.account}>
                          <Select
                              className={that.state.submitted &&
                                  CommonUtil.isNullValue(value) ? 'required-error' : ''}
                              id={'account' + '_' + index}
                              name={"account" + '_' + index}
                              onChange={that.handleTableDropDownChange}
                              options={that.props.dataDictionaryList &&
                                  that.props.dataDictionaryList.dataDictionaryList &&
                                  that.props.dataDictionaryList.dataDictionaryList.accountList}
                              classNamePrefix="react-select"
                              isDisabled={false}
                              value={{ "label": original.account }} />
                      </div>
                  );
              },
          },
          {
              Header: "Description",
              id: "description",
              name: "description",
              accessor: "description",
              required: true,
              inputType: "text",
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              disableSortBy: true,
              disableFilters: true,
              className: "input-field",
              dataDictionaryFlag: true,
              dataDictionaryId: 'expenses',
              Cell: ({ cell }) => {
                  let { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <div className="full-width" title={original.description}>
                          <Select
                              className={that.state.submitted &&
                                  CommonUtil.isNullValue(value) ? 'required-error' : ''}
                              id={'description' + '_' + index}
                              name={"description" + '_' + index}
                              onChange={that.handleTableDropDownChange}
                              options={that.props.dataDictionaryList &&
                                  that.props.dataDictionaryList.dataDictionaryList &&
                                  that.props.dataDictionaryList.dataDictionaryList.expenses}
                              classNamePrefix="react-select"
                              isDisabled={false}
                              value={{ "label": original.description }} />
                      </div>
                  );
              },
          },
          {
              Header: "Mode",
              id: "paymentMode",
              name: "paymentMode",
              accessor: "paymentMode",
              required: true,
              inputType: "text",
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              disableSortBy: true,
              disableFilters: true,
              className: "input-field",
              dataDictionaryFlag: true,
              dataDictionaryId: 'paymentModeList',
              style: {
                  flex: "0 0 150px",
              },
              Cell: ({ cell }) => {
                  let { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <Select
                          className={that.state.submitted &&
                              CommonUtil.isNullValue(value) ? 'required-error' : ''}
                          id={'paymentMode' + '_' + index}
                          name={"paymentMode" + '_' + index}
                          onChange={that.handleTableDropDownChange}
                          options={that.props.dataDictionaryList &&
                              that.props.dataDictionaryList.dataDictionaryList &&
                              that.props.dataDictionaryList.dataDictionaryList.paymentModeList}
                          classNamePrefix="react-select"
                          isDisabled={false}
                          value={{ "label": original.paymentMode }} />
                  );
              },
          },
          {
              Header: "Date",
              id: "expenseDate",
              name: "expenseDate",
              accessor: "expenseDate",
              required: true,
              inputType: "text",
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              disableSortBy: true,
              disableFilters: true,
              style: {
                  flex: "0 0 120px",
              },
              className: "input-field",
              Cell: ({ cell }) => {
                  let value = cell.value;
                  const { index, original } = cell.row;
                  return (
                      <Datetime
                          className={that.state.submitted && !value ? 'required-error' : ''}
                          id={"expenseDate" + '_' + index}
                          timeFormat={false}
                          closeOnSelect={true}
                          inputProps={{
                              readOnly: true,
                              placeholder: "Date Picker Here",
                              disabled: false
                          }}
                          name={'expenseDate'}
                          onChange={(moment) => that.handleTableDateChange(moment, "expenseDate" + "_" + index)}
                          dateFormat="MM-DD-YYYY"
                          value={value ? moment(value) : ''}
                      />
                  )
              },
          },
          {
              Header: "Amount",
              id: "expenseAmount",
              accessor: "expenseAmount",
              name: "expenseAmount",
              required: false,
              inputType: "number",
              disableSortBy: true,
              createModeShowFlag: true,
              cloneModeShowFlag: true,
              editModeShowFlag: true,
              viewModeShowFlag: true,
              disableFilters: true,
              style: {
                  flex: "0 0 150px",
              },
              className: "input-field",
              Cell: ({ cell }) => {
                  cell.column.Header = that.props.currencyCode ? ("Amount" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")") : "Amount";
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <InputGroup>
                          <FormControl
                              id={"expenseAmount" + "_" + index}
                              data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                              name={"expenseAmount"}
                              onChange={that.handleTableTextBoxChange}
                              disabled={false}
                              value={value}
                              onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                              onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                              maxLength={10}
                              minLength={1} />
                          {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
                      </InputGroup>
                  );
              },
          },
          {
              Header: "Action",
              id: "action",
              accessor: "action",
              className: "action justify-content-center",
              style: {
                  flex: "0 0 80px",
              },
              disableSortBy: true,
              disableFilters: true,
              Cell: ({ cell }) => {
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <div className="actions-left">
                          <div className="circle">
                              <i title="remove"
                                  id={commonConstant.EDIT_ACTION_MODE + "_" + index}
                                  className="fa fa-trash"
                                  onClick={(e) => that.handleDeleteRowPopup(e)} />
                          </div>
                      </div>
                  );
              },
          },
          {
              id: "version",
              name: "version",
              type: "TEMP",
              createModeShowFlag: false,
              cloneModeShowFlag: false,
              editModeShowFlag: true,
              viewModeShowFlag: true,
          },
          {
              id: "expenseId",
              name: "expenseId",
              type: "TEMP",
              createModeShowFlag: false,
              cloneModeShowFlag: false,
              editModeShowFlag: true,
              viewModeShowFlag: true,
          },

      ],
      tableConfig: {
          defaultFilteredList: [],
          defaultSortedList: [],
          defaultPageSize: 50,
          showExport: false,
          customPagination: false,
          showServerSideFilter: false,
          isFilterEnabed: false,
          showPagination: false,
          showAddRow: false,
          isDraggable: false,
      },
  };
};
export const MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "",
        id: "actions",
        accessor: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox inline 
                number={original.productId + "_" + commonConstant.CREATE_ACTION_MODE + '_' + index}
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)} />
            </div>
          )
        }
      },
      {
        Header: "Product Code",
        id: "productId",
        accessor: "productId",
        style: {
          flex: "0 0 140px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>PRO-{value}</>
          )
        }
      },
      {
        Header: "Product Name",
        id: "productName",
        accessor: "productName"
      },
      // {
      //   Header: "Purchase Price",
      //   id: "purchasePrice",
      //   accessor: "purchasePrice",
      //   style: {
      //     flex: "0 0 140px",
      //   },
      // },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};