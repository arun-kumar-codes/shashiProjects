import React, { Component } from "react";
import { connect } from "react-redux";
import { PDFDownloadLink } from "@react-pdf/renderer";
import PurchaseOrderInvoice from "./PurchaseOrderInvoice";
import CommonUtil from "../../common/util/commonUtil";
import { getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getSupplierDetails } from "../../supplierManagement/actions/supplierActions";

class GenerateInvoicePDF extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      show: false,
      supplierObj: null,
      facilityObj: null
    };
  }

  updateSupplierDetails = () => {
    this.setState({ supplierObj: this.props.supplierDetails });
    this.onDownLoadClick();
  }

  updateFacilityDetails = () => {
    this.setState({ facilityObj: this.props.facilityDetails });
    this.onDownLoadClick();
  }

  componentDidMount = () => {
    const { attributeObj } = this.props;
    if (this.props.isDownLoadPdf) {
      this.props.getSupplierDetails(attributeObj.supplierId);
      this.props.getFacilityDetails(attributeObj.facilityId);
      this.setState({ show: true, orgInformation: CommonUtil.getOrgInformation(this.props.dataDictionaryList) });
    }
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.supplierDetails != null && prevProps.supplierDetails != this.props.supplierDetails) {
      this.updateSupplierDetails();
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      this.updateFacilityDetails();
    }
  }

  onDownLoadClick = () => {
    const { supplierDetails, facilityDetails } = this.props;
    if (supplierDetails != null && facilityDetails != null && this.props.isDownLoadPdf) {
      setTimeout(() => {
        this.refs.current.click();
      }, 1000);
    }
  }

  render() {
    const { show, facilityObj, supplierObj, orgInformation } = this.state;
    return (
      (show && supplierObj && facilityObj ?
        <PDFDownloadLink
          document={<PurchaseOrderInvoice
            attributeObj={this.props.attributeObj}
            facilityObj={facilityObj}
            supplierObj={supplierObj}
            stateGST={this.props.stateGST}
            centralGST={this.props.centralGST}
            userProfile={this.props.userProfile}
            currencyCode={this.props.currencyCode}
            orgInformation={orgInformation}
            companyImage={this.props.imageUrl}
          />}
          fileName={this.props.attributeObj.purchaseOrderId}
          style={{ color: "#1E1E1E" }}
          children={<i className='invoice-download fa fa-download' ref="current" title={"download"}></i>}>
        </PDFDownloadLink>
        : null

      )
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    actionMode: state.app.actionMode,
    currencyCode: state.dataDictionary.currencyCode,
    stateGST: state.dataDictionary.stateGST,
    centralGST: state.dataDictionary.centralGST,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    userProfile: state.user.userProfile,
    attributeObj: state.purchaseOrder.purchaseOrderDetails,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    supplierList: state.supplier.supplierList,
    supplierDetails: state.supplier.supplierDetails,
    facilityDetails: state.facility.facilityDetails,
    facilityList: state.facility.facilityList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  getFacilityDetails: (id) => dispatch(getFacilityDetails(id)),
  getSupplierDetails: (id) => dispatch(getSupplierDetails(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(GenerateInvoicePDF);