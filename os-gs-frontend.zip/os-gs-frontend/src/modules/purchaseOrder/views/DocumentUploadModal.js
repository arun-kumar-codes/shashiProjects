import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { getReceivedStockList } from "../actions/purchaseOrderActions";
import DragDrop from "../../../components/DragDrop/DragDrop.jsx";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil.js";
import PopupUtil from "../../common/util/popupUtil";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import PurchaseOrderUtil from "./PurchaseOrderUtil.js";
var Modal = require('react-bootstrap-modal')

class DocumentUploadModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      entityUOM: null,
      selectedProductIngObj: null,
      selectedUTICode: null,
      tableDataKey: "tableDataList",
      tableDataList: [],
      params: null,
      newUTIList: [{ label: 'Create Document for New UTI', utiCode: 'NEW-UTI' }],
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  handleTableTextBoxChange = async (event) => {
    await PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    this.updateDocumentTableData();
  };

  handleTableDropDownChange = async (event, obj) => {
    await PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    this.updateDocumentTableData();
  };

  handleTableDateChange = (event, eventId) => {
    PopularTableUtil.handleTableDateChange(event, eventId, this, this.getSelectedTablekey());
  };

  updateDocumentTableData = () => {
    let { tableDataList, documents, attributeObj } = this.state;
    let tempDataList = CommonUtil.removeObjFromArray(documents, "uti",
      attributeObj.utiCode)
    documents = [...tableDataList, ...tempDataList];
    this.setState({ documents: documents });
  }

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleTableButtonMenuAction = (event) => {
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };

  handleTableRemove = async (event) => {
    this.setState({ alert: null });
    await PopularTableUtil.handleTableRemove(event, this, this.getSelectedTablekey());
    this.updateDocumentTableData();
  };

  componentDidMount = async () => {
    this.setState({ openModal: true });
    let commonAttributeList = pagePropertyListConstant.PURCHASE_ORDER_DOCUMENT_UPLOAD_MODAL_LIST(this);
    let selectedProductIngObj = PurchaseOrderUtil.getSelectedProductIngDetails(
      [...this.props.productIngredientList], this.props.uniqueCode);

    let uniqueUTIList = PurchaseOrderUtil.getDocumentUTIList(selectedProductIngObj.documents);
    if (CommonUtil.getFloatValue(selectedProductIngObj.receivedQuantity) > 0) {
      uniqueUTIList = [...uniqueUTIList, ...this.state.newUTIList];
    }
    let attributeObj = commonAttributeList.attributeObj;
    attributeObj.newInvoiceNumber = CommonUtil.initializeValue(selectedProductIngObj.newInvoiceNumber);
    attributeObj.newTransportDetail = CommonUtil.initializeValue(selectedProductIngObj.newTransportDetail);
    if (uniqueUTIList[0].utiCode == "NEW-UTI") {
      attributeObj.invoiceNumber = CommonUtil.initializeValue(selectedProductIngObj.newInvoiceNumber);
      attributeObj.transportDetail = CommonUtil.initializeValue(selectedProductIngObj.newTransportDetail);
      attributeObj.utiCode = uniqueUTIList[0].utiCode;
    }

    await this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(commonAttributeList.attributeList,
        CommonUtil.getOptionsFromList(uniqueUTIList, 'utiCode', 'utiCode'), 'utiCode'),
      documents: selectedProductIngObj.documents,
      selectedProductIngObj: selectedProductIngObj,
      attributeObj: attributeObj,
      selectedUTICode: uniqueUTIList[0].utiCode,
      tableDataList: CommonUtil.getFilteredListFromArray(selectedProductIngObj.documents,
        "uti", uniqueUTIList[0].utiCode),
    });
    await this.updateCustomDropDownChange(uniqueUTIList[0].utiCode);
    this.setSelectedTableDetails(this.state.selectedTab);
  };

  setSelectedTableDetails = (selectedTab) => {
    this.props.getReceivedStockList({
      purchaseOrderId: this.props.purchaseOrderId, orderNumber: this.props.uniqueCode
    });
    const tableAttributeList = pagePropertyListConstant.PURCHASE_ORDER_DOCUMENT_UPLOAD_MODAL_TABLE_LIST(this);
    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.attributeList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.purchaseOrderStockList != null && prevProps.purchaseOrderStockList != this.props.purchaseOrderStockList) {
      this.handleStockResponse();
    }
  }

  handleStockResponse = async () => {
    let { attributeObj, selectedUTICode } = this.state;
    let tempAttributeObj = {};
    if (selectedUTICode != "NEW-UTI") {
      tempAttributeObj = CommonUtil.getFilteredObjFromArray(this.props.purchaseOrderStockList.Items,
        "uti", selectedUTICode);
      tempAttributeObj.utiCode = selectedUTICode;
      tempAttributeObj.newInvoiceNumber = CommonUtil.initializeValue(attributeObj.newInvoiceNumber);
      tempAttributeObj.newTransportDetail = CommonUtil.initializeValue(attributeObj.newTransportDetail);
      attributeObj = { ...tempAttributeObj };
      await this.setState({ attributeObj: attributeObj });
    }
  }

  closeModal = (event) => {
    this.props.getUploadDocumentDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    this.setState({ submitted: true });
    const { attributeObj, selectedUTICode } = this.state;
    let tempObj = {};
    tempObj.documents = this.state.documents;
    if (selectedUTICode === "NEW-UTI") {
      tempObj.newInvoiceNumber = CommonUtil.initializeValue(attributeObj.invoiceNumber);
      tempObj.newTransportDetail = CommonUtil.initializeValue(attributeObj.transportDetail);
    } else {
      tempObj.newInvoiceNumber = CommonUtil.initializeValue(attributeObj.newInvoiceNumber);
      tempObj.newTransportDetail = CommonUtil.initializeValue(attributeObj.newTransportDetail);
    }

    tempObj.uniqueCode = this.props.uniqueCode;
    if (CommonUtil.isNotNull(tempObj.documents) && tempObj.documents.length > 0) {
      let openFlag = false;
      for (var i=0; i<tempObj.documents.length; i++) {
        if(CommonUtil.isNotNull(tempObj.documents[i].documentType) && CommonUtil.isNotNull(tempObj.documents[i].documentName) && tempObj.documents[i].documentName.length > 2) {
          openFlag = true;
        } else {
          openFlag = false;
        }  
      }
      if (openFlag == true) {
        this.setState({ openModal: false, });
        this.props.getUploadDocumentDetails(tempObj);
      } else {
        this.setState({ openModal: true, });
      }
    } else {
      this.setState({ openModal: false, });
      this.props.getUploadDocumentDetails(tempObj);
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getUploadDocumentDetails(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  updateCustomDropDownChange = async (value) => {
    let { attributeList } = this.state;
    let isUTINewFlag = false;
    value == "NEW-UTI" ? isUTINewFlag = true : isUTINewFlag = false;
    let isEnableFlag = isUTINewFlag ? 'enable' : 'disabled';
    attributeList = CommonUtil.updateArrayListObjValue(attributeList,
      "name", "invoiceNumber", "editMode", isEnableFlag);
    attributeList = CommonUtil.updateArrayListObjValue(attributeList,
      "name", "transportDetail", "editMode", isEnableFlag);
    await this.setState({ attributeList: attributeList });
  }

  handleCustomDropDownChange = async (event, obj) => {
    let { attributeObj, documents, selectedUTICode } = this.state;
    let tempAttributeObj = null;
    await this.updateCustomDropDownChange(event.value);

    if (selectedUTICode == "NEW-UTI" && event.value != "NEW-UTI") {
      attributeObj.newInvoiceNumber = CommonUtil.initializeValue(attributeObj.invoiceNumber);
      attributeObj.newTransportDetail = CommonUtil.initializeValue(attributeObj.transportDetail);
    }

    if (event.value == "NEW-UTI") {
      attributeObj.invoiceNumber = CommonUtil.initializeValue(attributeObj.newInvoiceNumber);
      attributeObj.transportDetail = CommonUtil.initializeValue(attributeObj.newTransportDetail);
    } else if (CommonUtil.isNotNull(this.props.purchaseOrderStockList)) {
      tempAttributeObj = CommonUtil.getFilteredObjFromArray(this.props.purchaseOrderStockList.Items,
        "uti", event.value);
      tempAttributeObj.newInvoiceNumber = CommonUtil.initializeValue(attributeObj.newInvoiceNumber);
      tempAttributeObj.newTransportDetail = CommonUtil.initializeValue(attributeObj.newTransportDetail);
      attributeObj = { ...tempAttributeObj };
    }

    await this.setState({
      attributeObj: {
        ...attributeObj,
        [obj.name]: event.value,
      },
      selectedUTICode: event.value,
      tableDataList: CommonUtil.getFilteredListFromArray([...documents], "uti", event.value),
    })
  }

  getDocumentDetails = (documents) => {
    const { attributeObj } = this.state;
    if (CommonUtil.isNotNull(attributeObj.utiCode)) {
      let tableDataList = [...documents];
      for (let i = 0; i < tableDataList.length; i++) {
        if (CommonUtil.isNullValue(tableDataList[i].uti)) {
          tableDataList[i].uti = attributeObj.utiCode;
        }
      }
      this.setState({
        documents: [...tableDataList],
        tableDataList: CommonUtil.getFilteredListFromArray([...documents],
          "uti", attributeObj.utiCode),
      });
    }
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList,
      tableConfig, tableDataList, selectedProductIngObj, documents } = this.state;
    const actionMode = this.props.actionMode;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              {selectedProductIngObj != null &&
                <div>
                  <div className="model-heading">Upload Documents</div>
                  <div className="subsection">
                    <div className="model-subheading">{selectedProductIngObj.uniqueName}</div>
                  </div>
                </div>
              }
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Row className="content-section">
                        {attributeList != null &&
                          attributeList.map((tempAttributeListObj, index) =>

                            tempAttributeListObj.type == "TEXTBOX" &&
                              tempAttributeListObj[actionMode + "ShowFlag"] == true ?
                              TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "DROPDOWN" &&
                                tempAttributeListObj[actionMode + "ShowFlag"] == true ?
                                DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                : null
                          )}
                      </Row>
                    </form>
                  </Col>
                </Row>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            {tableColumnList != null ? (
                              <Row>
                                {tableDataList != null &&
                                  tableDataList.length > 0 ? (
                                    <Table
                                      columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                  ) : null}
                              </Row>
                            ) : null}
                          </div>
                        }

                      />
                    </form>
                  </Col>
                  <Col md={12}>
                    <Card
                      plain
                      title=""
                      content={
                        <DragDrop
                          minSize={0}
                          maxSize={5000000}
                          multiple={false}
                          disabled={CommonUtil.isViewMode(actionMode) ? true : false}
                          errormsg="File size exceed max size limit of 5 MB."
                          typeerror="File type is not accepted"
                          attributeList={tableColumnList}
                          getdocumentdetails={this.getDocumentDetails}
                          files={documents != null && documents.length > 0 ?
                            documents : null}
                          hideDocument={true}
                          fileNamePrefix={attributeObj != null && attributeObj.facilityId}
                          moduleName="purchaseOrder"
                        />
                      }
                      ftTextRight
                      legend={
                        CommonUtil.isViewMode(this.props.actionMode) ?
                          <div>
                            <Button className="btn-cancel" onClick={this.closeModal}>
                              Cancel
                              </Button>
                          </div>
                          : <div>
                            <Button className="btn-cancel" onClick={this.closeModal}>
                              Cancel
                              </Button>

                            <Button className="btn-save btn-fill btn-wd" onClick={this.handleSave}>
                              Save
                              </Button>
                          </div>
                      }
                    />
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    purchaseOrderStockList: state.purchaseOrder.purchaseOrderStockList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getReceivedStockList: (params) => dispatch(getReceivedStockList(params))
});
export default connect(mapStateToProps, mapDispatchToProps)(DocumentUploadModal);
