import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { getReceivedStockList } from "../actions/purchaseOrderActions";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil.js";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import PurchaseOrderUtil from "./PurchaseOrderUtil.js";
var Modal = require('react-bootstrap-modal')

class StockViewModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      entityUOM: null,
      selectedProductIngDetails: null,
      tableDataKey: "tableDataList",
      tableDataList: [],
      params: null,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleTableButtonMenuAction = (event) => {
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };

  componentDidMount = () => {
    this.setState({ openModal: true });
    let selectedProductIngDetails = PurchaseOrderUtil.getSelectedProductIngDetails(
      [...this.props.attributeObj.productIngredientList], this.props.uniqueCode);
    this.props.getReceivedStockList({
      purchaseOrderId: this.props.purchaseOrderId,
      orderNumber: this.props.uniqueCode
    });
    this.setState({
      selectedProductIngDetails: selectedProductIngDetails,
      entityUOM: selectedProductIngDetails.productUOM
    });
    this.setSelectedTableDetails(this.state.selectedTab);
  };

  setSelectedTableDetails = (selectedTab) => {
    const tableAttributeList = pagePropertyListConstant.PURCHASE_ORDER_STOCK_VIEW_MODAL_TABLE_LIST(this);
    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.attributeList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.purchaseOrderStockList != null && prevProps.purchaseOrderStockList != this.props.purchaseOrderStockList) {
      this.setState({ tableDataList: [...this.props.purchaseOrderStockList.Items] });
    }
  }

  closeModal = (event) => {
    this.props.getStockViewDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    this.props.getStockViewDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getStockViewDetails(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, selectedProductIngDetails } = this.state;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              {selectedProductIngDetails != null &&
                <div>
                  <div className="model-heading">{selectedProductIngDetails.uniqueName}</div>
                  <div className="subsection">
                    <div className="model-subheading">Selected item UTI/Batch details.</div>
                  </div>
                </div>
              }
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            {tableColumnList != null ? (
                              <Row>
                                {tableDataList != null &&
                                  tableDataList.length > 0 ? (
                                    <Table
                                      columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                  ) : null}
                              </Row>
                            ) : null}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <div>
                            <Button className="btn-cancel" onClick={this.closeModal}>
                              Cancel
                            </Button>
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    purchaseOrderStockList: state.purchaseOrder.purchaseOrderStockList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getReceivedStockList: (params) => dispatch(getReceivedStockList(params))
});
export default connect(mapStateToProps, mapDispatchToProps)(StockViewModal);
