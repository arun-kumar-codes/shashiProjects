import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, Tab, Tabs, FormGroup, ControlLabel, Form } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as purchaseOrderConstant from "../constant/purchaseOrderConstant";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as commonConstant from '../../common/constant/commonConstant';
import { setCreditNoteDetails } from "../../stockAdjustment/actions/stockAdjustmentActions";
import { getSupplierList } from "../../supplierManagement/actions/supplierActions";
import * as stockAdjustmentConstant from '../../stockAdjustment/constant/stockAdjustmentConstant';
import Select from "react-select";
import { connect } from "react-redux";
import {
  setSelectedPurchaseOrderCode, getPurchaseOrderList, getQBODetails, updatePurchaseOrderAmendStatus,
  getQBOBillDetails, downLoadXLSFile, getPurchaseOrderSearchList
} from "../actions/purchaseOrderActions";
import CommonUtil from "../../common/util/commonUtil";
import * as statusConstant from '../../common/constant/statusConstant';
import PaymentProcessModal from "./PaymentProcessModal";
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getIngredientList } from "../../ingredientManagement/actions/ingredientActions";
import { getProductList } from '../../productManagement/actions/productActions';
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import { setActionMode } from "../../../actions/appActions";
import StatusUtil from '../../common/util/statusUtil';
import PaginationUtil from "../../common/util/paginationUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import filter from "assets/img/filter.svg";
import pin from "assets/img/pin.svg";
import download from "assets/img/download.svg";
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import { updateAutomationDraftStatus, getAutomationDraftOrderList } from "../../automation/actions/automationActions";
import source from "assets/img/source-page-icon.svg";
import PurchaseOrderUtil from "./PurchaseOrderUtil";
import mixpanel from "../../analytics/mixpanel/mixpael";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import PopupUtil from '../../common/util/popupUtil';
import LabelUtil from "modules/common/util/labelUtil";
import TextBoxUtil from '../../common/util/textBoxUtil';
import check from "assets/img/check.svg";

class ManagePurchaseOrder extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      purchaseOrderId: null,
      defaultSelectedTab: "OPEN",
      selectedTab: "OPEN",
      status: null,
      facilityList: [],
      allList: [{ label: 'All', value: '' }],
      qboBillAction: null,
      qboDetail: null,
      qboBillDetail: null,
      search: null,
      openPaymentModal: false,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  componentDidMount = async () => {
    mixpanel.track("Manage purchase order loaded");
    let params = CommonUtil.getAdditonalPathParams(this);
    let location = CommonUtil.getAdditonalPathLocation(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getFacilityList({ isDropdown: true });
    this.props.getSupplierList({ isDropdown: true });
    const { selectedTab } = this.state;
    if (CommonUtil.isNotNull(location)) {
      await this.props.getFacilityDetails(location);
    }
    if (params == "COMPLETED") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("COMPLETED");
      const { location, history } = this.props;
      history.replace();
    } else if (params == "DRAFT") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("DRAFT");
      const { location, history } = this.props;
      history.replace();
    } else {
      await this.setSelectedTabDetails(selectedTab);
    }
  };

  setSelectedTabDetails = async (selectedTab) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    const managePageList = pagePropertyListConstant["MANAGE_" + selectedTab + "_PURCHASE_ORDER_PAGE_LIST"](this);
    const tableColumnList = PurchaseOrderUtil.getAttributeListForQBOAccount(managePageList.tableColumnList,
      PurchaseOrderUtil.isQBOAccount(this));
    let additionalParams = { status: selectedTab.toLowerCase() };
    if (this.state.location) {
      additionalParams.location = this.state.location;
    }
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: tableColumnList,
      tableConfig: managePageList.tableConfig,
      lastEvaluatedKeyArray: [],
      additionalParams: additionalParams,
      selectedTab: selectedTab,
      searchInput: "",
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
      limit: managePageList.tableConfig.defaultPageSize
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this), selectedTab);
  };

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim(), location: '', locationName: 'All' });
      this.setSelectedTabDetails(this.state.selectedTab);
      this.setState({ menuOpen: false, status: null });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleTabClick = (label, event) => {
    PaginationUtil.initPaginationParams(this);
    let selectedTabKey = label.toUpperCase();
    this.setSelectedTabDetails(selectedTabKey);
  };

  componentDidUpdate(prevProps) {
    if (this.props.purchaseOrderList != null && prevProps.purchaseOrderList != this.props.purchaseOrderList) {
      this.handleCustomPagination();
    }
    if (this.props.automationDraftList != null && prevProps.automationDraftList != this.props.automationDraftList) {
      this.handleCustomPagination();
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
    if (this.props.qboDetail != null && prevProps.qboDetail != this.props.qboDetail) {
      this.handleQBODetails();
    }
    if (this.props.qboBillDetail != null && prevProps.qboBillDetail != this.props.qboBillDetail) {
      this.handleQBOBillDetails();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      let tempObj = {};
      tempObj.value = this.props.facilityDetails.facilityId; tempObj.label = this.props.facilityDetails.facilityId + " | " + this.props.facilityDetails.facilityName;
      this.handleLocationDropdownChange(tempObj);
    }
    if (this.props.location.state != null && prevProps.location.key !== this.props.location.key) {
      this.setSelectedTabDetails(this.props.location.state)
      this.props.getFacilityDetails(this.props.location.location);
    }
  }

  handleCustomPagination = () => {
    if (this.state.selectedTab == "DRAFT" && CommonUtil.isNotNull(this.props.automationDraftList)) {
      PaginationUtil.handlePagination(this.props.automationDraftList, this);
    } else if (CommonUtil.isNotNull(this.props.purchaseOrderList)) {
      PaginationUtil.handlePagination(this.props.purchaseOrderList, this);
    }
  }

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      PaginationUtil.initPaginationParams(this);
      this.setSelectedTabDetails(this.state.selectedTab);
      if (this.state.qboBillAction == 'create') {
        this.props.handleClick(CommonUtil.prepareBillCreatedSuccessPopUpConfig());
        return
      } else if (this.state.qboBillAction == 'view') {
        return
      } else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      let errorMessage = this.props.ajaxCallStatus.data &&
        this.props.ajaxCallStatus.data.response &&
        this.props.ajaxCallStatus.data.response.data;
      if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "411") {
        PurchaseOrderUtil.QBOSupplierNotExitPopup(this);
      } else {
        PopupUtil.popupErrorResponse(this);
      }
      await this.props.setAjaxCallStatus(null);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput } = this.state;
    let DataArray = [];
    let filteredData = this.props.purchaseOrderList.Items.filter(value => {
      let Data = this.dataFilter(value, searchInput);
      if (CommonUtil.isNotNull(Data)) {
        DataArray.push(Data);
      }
      return (
        value.purchaseOrderId.toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.supplierId).toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    if (CommonUtil.isNotNull(DataArray)) {
      this.setState({ tableDataList: DataArray });
    } else {
      this.setState({ tableDataList: filteredData });
    }
  };

  dataFilter = (output, searchInput) => {
    let filteredData2 = output.productIngredientList.filter(value => {
      return (
        value.uniqueName.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.uniqueCode.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    if (CommonUtil.isNotNull(filteredData2)) {
      return output;
    }
  }

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ location: tempObj.value, locationName: tempObj.label });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handleExportFileDownLoad = () => {
    this.props.downLoadXLSFile();
  }

  handleFIlter = (event) => {
    let status = CommonUtil.isNotNull(event) ? event.toLowerCase() : null;
    let filteredData = this.props.purchaseOrderList.Items.filter((value) => {
      if (event == statusConstant.OVERDUE_STATUS) {
        return (CommonUtil.isDateExpired(value.requestedDeliveryDate) == true);
      } else if (event == statusConstant.ALL_STATUS) {
        return value;
      } else if (event !== "") {
        return value.status.toLowerCase() == event.toLowerCase();
      }
      return value;
    });
    this.setState({ tableDataList: filteredData, selectedFilter: event, status: status });
  }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedPurchaseOrderCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(purchaseOrderConstant.CREATE_PURCHASE_ORDER_PAGE_URL, this);
  };

  getQBOBillDetails = (e) => {
    if (PurchaseOrderUtil.isInActiveQBOAccount(this)) {
      PurchaseOrderUtil.QBOInActivePopup(this);
      return;
    }
    let eventId = e.target.id.split("_");
    let qboParams = {};
    qboParams.purchaseorderCode = eventId[0];
    if (CommonUtil.isNullValue(eventId[1])) {
      qboParams.action = 'create';
      this.setState({ qboBillAction: 'create' });
    } else {
      qboParams.action = 'view';
      this.setState({ qboBillAction: 'view' });
      qboParams.sourceId = eventId[1];
    }
    this.props.getQBOBillDetails(qboParams);
  };

  updateFacilityDropDownList = () => {
    this.setState({
      facilityList: CommonUtil.getOptionsFromList(
        this.props.facilityList.Items, 'facilityId', 'facilityName')
    })
  }

  handleQBODetails = async () => {
    await this.setState({ qboDetail: this.props.qboDetail });
    const managePageList = pagePropertyListConstant["MANAGE_" + this.state.selectedTab
      + "_PURCHASE_ORDER_PAGE_LIST"](this);
    const tableColumnList = PurchaseOrderUtil.getAttributeListForQBOAccount(
      managePageList.tableColumnList, PurchaseOrderUtil.isQBOAccount(this));
    this.setState({ tableColumnList: tableColumnList });
  }

  handleQBOBillDetails = () => {
    this.setState({ qboBillDetail: this.props.qboBillDetail });
    if (this.state.qboBillAction == 'create') {
      const { limit, currentPage } = this.state;
      this.props.getPurchaseOrderList(PaginationUtil.getPaginationParams(currentPage,
        limit, this));
    } else if (this.state.qboBillAction == 'view') {
      if (CommonUtil.isNotNull(this.props.qboBillDetail.qboURL)) {
        window.open(this.props.qboBillDetail.qboURL);
      }
    }
  }

  handleMenuPopupAction = async (event) => {
    let tempId = event.target.id.split("_");
    if (tempId[2] == purchaseOrderConstant.CREATE_PURCHASE_ORDER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(purchaseOrderConstant.CREATE_PURCHASE_ORDER_PAGE_URL, this);
    } else if (tempId[2] == purchaseOrderConstant.VIEW_PAYMENT_DETAILS) {
      await this.setState({ openPaymentModal: true, purchaseOrderId: tempId[0] });
    } else if (tempId[2] == stockAdjustmentConstant.PO_RETURN_STATUS) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      let params = { orderCode: tempId[0], action: stockAdjustmentConstant.PO_RETURN_STATUS };
      this.props.setCreditNoteDetails(params);
      CommonUtil.handlePageRedirection(stockAdjustmentConstant.CREATE_STOCK_ADJUSTMENT_PAGE_URL, this);
    } else if (tempId[2] == statusConstant.UPDATE_STATUS) {
      this.setState({ purchaseOrderId: tempId[0] });
      PurchaseOrderUtil.handleAmendStatusPopup(this);
    }
  };

  handleAmendStatus = () => {
    const { purchaseOrderId } = this.state;
    this.props.updatePurchaseOrderAmendStatus(purchaseOrderId);
    this.setState({ alert: null, purchaseOrderId: null });
  }


  getPaymentModalDetails = () => {
    PaginationUtil.initPaginationParams(this);
    this.setState({ openPaymentModal: false });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handlePopupCancel = () => {
    this.setState({ alert: null, purchaseOrderId: null });
  };

  handleConfirmDraftAction = (event) => {
    this.setState({ alert: null });
    let tempId = event.target.id.split("_");
    let tempDraftObj = {};
    tempDraftObj.uniqueCode = tempId[0];
    tempDraftObj.draftCode = tempId[3];
    tempDraftObj.isDeleted = false;
    tempDraftObj.isConfirmed = true;
    this.props.updateAutomationDraftStatus(tempDraftObj);
  };

  handleDeleteDraftAction = () => {
    this.setState({ alert: null });
    const { draftId } = this.state;
    let tempId = draftId.split("_");
    let tempDraftObj = {};
    tempDraftObj.uniqueCode = tempId[0];
    tempDraftObj.draftCode = tempId[3];
    tempDraftObj.isDeleted = true;
    tempDraftObj.isConfirmed = false;
    this.props.updateAutomationDraftStatus(tempDraftObj);
  };

  makeCustomAPICall(tempParamas, selectedTab) {
    if (selectedTab == "DRAFT") {
      tempParamas.moduleName = "PO";
      this.props.getAutomationDraftOrderList(tempParamas);
    } else {
      if (CommonUtil.isNotNull(tempParamas.search)) {
        this.props.getPurchaseOrderSearchList(tempParamas);
      } else {
        this.props.getPurchaseOrderList(tempParamas);
      }
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      this.handleMenuPopupAction(event);
    }
  };

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    PaginationUtil.initPaginationParams(this);
    if (tempId[1] === "search") {
      await this.setState({ search: null, status: null, selectedFilter: null, searchInput: "" });
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
    if (tempId[1] === "status") {
      await this.setState({ status: null, lastEvaluatedKeyArray: [], selectedFilter: null });
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter, openPaymentModal, purchaseOrderId, search, status } = this.state;
    const MANAGE_PAGE_TAB_LIST = isAuthorized("draftTab") ? purchaseOrderConstant.MANAGE_PAGE_TAB_LIST : purchaseOrderConstant.MANAGE_PAGE_TAB_LIST_WITHOUT_DRAFT;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ? (
          <Redirect push to={this.state.redirectUrl}></Redirect>
        ) : null}
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={source} alt="" className="page-icon" />
                  {purchaseOrderConstant.MANAGE_PURCHASE_ORDER_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl
                        type="text"
                        name="searchInput"
                        placeholder="Search by Purchase Order/Product"
                        value={this.state.searchInput}
                        onChange={this.handleChange}
                      />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {this.state.selectedTab === "OPEN" && (
                    <Nav pullRight>
                      <NavDropdown title={<div className="filter"><img src={filter} alt="" /></div>}
                        noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                        {pagePropertyListConstant.MANAGE_HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                          <MenuItem key={index} eventKey={tempAttributeListObj.statusKey} className={selectedFilter === tempAttributeListObj.statusKey ? "active" : null}>
                            {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                          </MenuItem>
                        ))}
                      </NavDropdown>
                    </Nav>
                  )}

                  {isAuthorized("createPurchaseOrder") &&
                    <Button
                      id={"purchaseOrderId" + "_" + commonConstant.MENU_ACTION_MODE +
                        "_" + purchaseOrderConstant.CREATE_PURCHASE_ORDER}
                      fill wd className="create-options btn-default btn-fill btn-wd"
                      onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                  </Button>
                  }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {status || search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ?
                          <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                        {status ?
                          <div className="filtertag">{StatusUtil.getStatusLabel(status)} <i id="filter-status" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    <Tabs id="manage-purchase-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-tabs">
                      {MANAGE_PAGE_TAB_LIST.map((tempTabObj, index) => (
                        <Tab eventKey={tempTabObj.key} title={tempTabObj.title}>
                          {tableColumnList != null ? (
                            <Row>
                              {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                  <Table
                                    columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                ) : (
                                  <Col md={12}>
                                    <div className="no-record">No Record Found</div>
                                  </Col>
                                )}
                            </Row>
                          ) : (
                              <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>
                            )}
                        </Tab>
                      ))}
                      {openPaymentModal ?
                        <PaymentProcessModal
                          purchaseOrderId={purchaseOrderId}
                          getPaymentModalDetails={this.getPaymentModalDetails}
                          that={this}
                        >
                        </PaymentProcessModal>
                        : null}

                      <FormGroup className="location-dropdown">
                        <div className="export-btn" onClick={this.handleExportFileDownLoad}>
                          <img src={download} alt="" /> Export
                        </div>
                        <div className="location-control">
                          <img src={pin} alt="" />
                          <div title={this.state.locationName} >
                            <Select
                              classNamePrefix="react-select"
                              name="location"
                              placeholder="Location"
                              value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                              onChange={(value) => this.handleLocationDropdownChange(value)}
                              options={[...this.state.allList, ...this.state.facilityList]} />
                          </div>
                        </div>
                      </FormGroup>
                    </Tabs>
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    purchaseOrderList: state.purchaseOrder.purchaseOrderList,
    automationDraftList: state.automation.automationDraftList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    facilityList: state.facility.facilityList,
    supplierList: state.supplier.supplierList,
    ingredientList: state.ingredient.ingredientList,
    productList: state.product.productList,
    qboDetail: state.purchaseOrder.qboDetail,
    qboBillDetail: state.purchaseOrder.qboBillDetail,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    facilityDetails: state.facility.facilityDetails,
    purchaseOrderSearchList: state.purchaseOrder.purchaseOrderSearchList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setSelectedPurchaseOrderCode: (selectedSaleOrderCode) => dispatch(setSelectedPurchaseOrderCode(selectedSaleOrderCode)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getQBODetails: (id) => dispatch(getQBODetails(id)),
  downLoadXLSFile: (id) => dispatch(downLoadXLSFile(id)),
  getQBOBillDetails: (id) => dispatch(getQBOBillDetails(id)),
  updateAutomationDraftStatus: (draftOrderDetails) => dispatch(updateAutomationDraftStatus(draftOrderDetails)),
  getAutomationDraftOrderList: (params) => dispatch(getAutomationDraftOrderList(params)),
  getPurchaseOrderList: (id) => dispatch(getPurchaseOrderList(id)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getFacilityDetails: selectedFacilityCode => dispatch(getFacilityDetails(selectedFacilityCode)),
  setCreditNoteDetails: (params) => dispatch(setCreditNoteDetails(params)),
  getPurchaseOrderSearchList: params => dispatch(getPurchaseOrderSearchList(params)),
  updatePurchaseOrderAmendStatus: id => dispatch(updatePurchaseOrderAmendStatus(id)),

});
export default connect(mapStateToProps, mapDispatchToProps)(ManagePurchaseOrder);
