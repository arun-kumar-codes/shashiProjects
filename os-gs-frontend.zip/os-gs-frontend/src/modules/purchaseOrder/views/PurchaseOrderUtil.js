import * as statusConstant from '../../common/constant/statusConstant';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import * as purchaseOrderConstant from '../constant/purchaseOrderConstant';
import ValidationUtil from '../../common/util/validationUtil';

const PurchaseOrderUtil = {
    handleButtonStatusChange: function (event, that) {
        const { name, id } = event.target;
        if (CommonUtil.isCreateOrCloneMode(that.props.actionMode)) {
            return;
        }
        let currOrderSequence = this.getOrderStatusSequence(this.getCurrOrderStatus(that.state.productIngredientList));
        let selectedOrderSequence = this.getOrderStatusSequence(id);
        if (currOrderSequence > selectedOrderSequence) {
            return;
        }
        if (id == statusConstant.COMPLETED_STATUS) {
            this.handleTableCalculation("productIngredientList", that, true);
        }
        if (id == statusConstant.PARTIAL_RECEIVED || id == statusConstant.COMPLETED_STATUS) {
            that.setSelectedTableDetails(true);
        } else {
            that.setSelectedTableDetails(false);
        }
        CommonUtil.handleButtonStatusChange(event, that);
    },
    handleTableReceiveStockButtonClick: function (event, that) {
        that.setSelectedTableDetails(true);
    },
    handleTableViewDocumentClick: function (event, that, documentCount) {
        event.preventDefault();
        if (CommonUtil.getFloatValue(documentCount) == 0) {
            return;
        }
        let eventId = event.target && event.target.id.split("_");
        let params = {}
        params.uniqueCode = eventId[0];
        params.orderCode = eventId[1];
        CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_DOCUMENT_PAGE_URL, that, params);
    },
    handleTableUploadButtonClick: function (event, that) {
        let uniqueCode = event.target && event.target.id.split("_")[0];
        that.setState({ openDocumentModal: true, uniqueCode: uniqueCode });
    },
    getLeftQuantity: function (tempObj) {
        return CommonUtil.getFloatValue(tempObj.quantity) -
            CommonUtil.getFloatValue(tempObj.deliveredQuantity);
    },
    updateShippingLocationList: function (that) {
        const { supplierDetails } = that.props;
        that.setState({
            attributeList: CommonUtil.setDropDownOptionsInAttribute(that.state.attributeList,
                CommonUtil.getOptionsFromList(supplierDetails.locations, 'locationName',
                    'city'), 'shipLocationName')
        });
    },
    handleAmendStatusPopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onConfirmClick = that.handleAmendStatus;
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(
            popupActionButton, purchaseOrderConstant.AMEND_STATUS_ERROR_MSG, true);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    getIngredientStatus: function (tempObj) {
        let tempValue = this.getLeftQuantity(tempObj);
        if (CommonUtil.getFloatValue(tempObj.quantity) == 0 &&
            CommonUtil.getFloatValue(tempObj.deliveredQuantity) == 0) {
            return statusConstant.NEW_STATUS;
        }
        if (tempValue == 0 && CommonUtil.getFloatValue(tempObj.quantity) > 0) {
            return statusConstant.COMPLETED_STATUS;
        }
        if (tempValue > 0 && CommonUtil.getFloatValue(tempObj.deliveredQuantity) > 0) {
            return statusConstant.PARTIAL_RECEIVED;
        }
        if (tempValue > 0 && CommonUtil.getFloatValue(tempObj.deliveredQuantity) == 0) {
            return statusConstant.NEW_STATUS;
        }
    },
    isReceivedStatus: function (value) {
        if (value == statusConstant.PARTIAL_RECEIVED || value == statusConstant.COMPLETED_STATUS) {
            return true;
        }
        return false;
    },
    QBOInActivePopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareQBOInactivePopUpConfig(popupActionButton);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    QBOSupplierNotExitPopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareQBOSupplierNotExitPopUpConfig(popupActionButton);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    isQBOAccount: function (that) {
        const { qboDetail } = that.state;
        if (CommonUtil.isNotNull(qboDetail) && CommonUtil.isBothEqual(qboDetail.qboStatus, "active")) {
            return true;
        } else if (CommonUtil.isNotNull(qboDetail) && CommonUtil.isBothEqual(qboDetail.qboStatus, "inactive")) {
            return true;
        }
        return false;
    },
    isInActiveQBOAccount: function (that) {
        const { qboDetail } = that.state;
        if (CommonUtil.isNotNull(qboDetail) && CommonUtil.isBothEqual(qboDetail.qboStatus, "inactive")) {
            return true;
        }
        return false;
    },
    getQBOBillStatus: function (value) {
        if (CommonUtil.isBothEqual(value, "QBO")) {
            return statusConstant.CREATE_BILLS_STATUS;
        } else {
            return statusConstant.PENDING_BILLS_STATUS;
        }
    },
    getAttributeListForQBOAccount: function (attributeList, isQBOAccount) {
        let tempAttributeList = [];
        for (let i = 0; i < attributeList.length; i++) {
            if (!attributeList[i]["isQBOAttribute"] || (attributeList[i]["isQBOAttribute"] && isQBOAccount)) {
                tempAttributeList.push(attributeList[i]);
            }
        }
        return tempAttributeList;
    },
    getDocumentUTIList: function (documents) {
        let tempUTIList = [];
        if (!CommonUtil.isNullArray(documents)) {
            let utiList = [...new Set(documents.map(item => item.uti))];
            for (let i = 0; i < utiList.length; i++) {
                let tempObj = {};
                tempObj.utiCode = utiList[i];
                if (CommonUtil.isNotNull(tempObj.utiCode) && tempObj.utiCode != "NEW-UTI") {
                    tempUTIList.push(tempObj);
                }
            }
        }
        return tempUTIList;
    },
    handleUploadDocumentDetails: function (uploadDocumentObj, that) {
        const { productIngredientList } = that.state;
        for (let j = 0; j < that.state.productIngredientList.length; j++) {
            if (CommonUtil.isBothEqual(uploadDocumentObj.uniqueCode, productIngredientList[j].uniqueCode)) {
                productIngredientList[j].documents = uploadDocumentObj.documents;
                productIngredientList[j].invoiceNumber = uploadDocumentObj.newInvoiceNumber;
                productIngredientList[j].transportDetail = uploadDocumentObj.newTransportDetail;
                productIngredientList[j].newInvoiceNumber = uploadDocumentObj.newInvoiceNumber;
                productIngredientList[j].newTransportDetail = uploadDocumentObj.newTransportDetail;
            }
        }
        that.setState({ productIngredientList: [...productIngredientList] })
    },
    getSelectedProductIngDetails: function (productIngredientList, uniqueCode) {
        let selectedEntityObj = "";
        let attributeDataList = [...productIngredientList];
        attributeDataList && attributeDataList.filter((value) => {
            if ((value.uniqueCode && value.uniqueCode.toLowerCase().indexOf(uniqueCode &&
                uniqueCode.toLowerCase()) !== -1)) {
                selectedEntityObj = value;
            }
        });
        return selectedEntityObj
    },
    handleDeleteDraftPopup(event, that) {
        that.setState({ draftId: event.target.id });
        let popupActionButton = {};
        popupActionButton.onConfirmClick = that.handleDeleteDraftAction;
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    getOrderStatusSequence(status) {
        let statusSequence = 0;
        switch (status) {
            case statusConstant.NEW_STATUS:
                statusSequence = 1;
                break;
            case statusConstant.PARTIAL_RECEIVED:
                statusSequence = 2;
                break;
            case statusConstant.COMPLETED_STATUS:
                statusSequence = 3;
                break;
            default:
                statusSequence = 0;
        }
        return statusSequence;
    },
    getCurrOrderStatus: function (productIngredientList) {
        let attributeDataList = [...productIngredientList];
        let orderSequence = 3;
        let currOrderStatus = null;
        for (let i = 0; i < attributeDataList.length; i++) {
            let currOrderSequence = this.getOrderStatusSequence(this.getIngredientStatus(attributeDataList[i]));
            if (orderSequence !== 1) {
                if (orderSequence > currOrderSequence) {
                    orderSequence = currOrderSequence;
                    currOrderStatus = this.getIngredientStatus(attributeDataList[i]);
                }
            }
        }
        return currOrderStatus;
    },
    getSelectedListCount: function (productIngredientList) {
        if (productIngredientList != null && productIngredientList.length > 0) {
            return productIngredientList.length;
        }
        return 0;
    },
    setDefaultRowData: function (tableDataKeyName, that) {
        let attributeDataList = [...that.state[tableDataKeyName]];
        const { productDetails } = that.props;
        let i = attributeDataList.findIndex(value => value.uniqueCode == productDetails.productId);
        if (productDetails !== null) {
            attributeDataList[i].productUOM = productDetails.productUOM || productDetails.ingredientUOM;
            attributeDataList[i].price = productDetails.purchasePrice || 0;
            attributeDataList[i].taxValue = productDetails.exciseTax || 0; //productDetails.exciseTax || 0;
            attributeDataList[i].receivedQuantity = 0;
            attributeDataList[i].deliveredQuantity = 0;
            attributeDataList[i].volumeUnit = productDetails.volumeUnit || null;
            attributeDataList[i].category = productDetails.category || null;
            attributeDataList[i].brand = productDetails.brand || null;
            attributeDataList[i].volume = productDetails.volume || 0;
            attributeDataList[i].packSizeQty = productDetails.packSizeQty || 0;
        }
        that.setState({ [tableDataKeyName]: attributeDataList });
    },
    getDocumentCount: function (documents) {
        if (!CommonUtil.isNullArray(documents) && documents.length > 0) {
            return parseInt(documents.length);
        }
        return 0;
    },
    isReceivedAllStatus: function (that) {
        if (that.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
            return true;
        }
        return false;
    },
    handleTaxValidation: function (that) {
        let popupActionButton = {};
        popupActionButton.onConfirmClick = that.handleTaxConfirmation;
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareTaxPopUpConfig(popupActionButton);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    checkTaxValidation: function (arrayList) {
        let filteredList = arrayList.filter(function (tempObj) {
            return CommonUtil.getFloatValue(tempObj.taxValue) < 0
        });
        if (filteredList.length > 0) {
            return false;
        }
        return true;
    },

    handleTableCalculation: async function (tableDataKeyName, that, isReceivedAllStatus) {
        await this.handleExpensesTableCalulation("expenseDetails", that);
        await this.handleOrderDetailsTableCalulation("productIngredientList", that, isReceivedAllStatus);
    },

    handleOrderDetailsTableCalulation: async function (tableDataKeyName, that, isReceivedAllStatus) {
        let attributeDataList = [...that.state[tableDataKeyName]];
        let totalUnits = 0, subTotalWithoutTax = 0, taxTotal = 0, grandTotal = 0,
            stateTaxTotal = 0, centralTaxTotal = 0;;

        const { totalExpenses } = that.state;

        for (let i = 0; i < that.state[tableDataKeyName].length; i++) {
            if (attributeDataList[i].price) {
                let tempPrice = 0, tempQuantity = 0, tempTaxCode = 0,
                    tempReceivedQuantity = 0, tempLeftQuantity = 0, tempDeliveredQuantity = 0;

                tempPrice = CommonUtil.getFloatValue(attributeDataList[i].price);
                tempQuantity = CommonUtil.getFloatValue(attributeDataList[i].quantity);
                tempDeliveredQuantity = CommonUtil.getFloatValue(attributeDataList[i].deliveredQuantity);
                tempReceivedQuantity = CommonUtil.getFloatValue(attributeDataList[i].receivedQuantity);
                tempTaxCode = 0; //CommonUtil.getFloatValue(attributeDataList[i].taxValue);

                attributeDataList[i].totalVolume = CommonUtil.getFloatValue(tempQuantity) *
                    CommonUtil.getFloatValue(attributeDataList[i].volume) *
                    CommonUtil.getFloatValue(attributeDataList[i].packSizeQty);

                if (tempQuantity < tempDeliveredQuantity) {
                    tempQuantity = tempDeliveredQuantity;
                }
                tempLeftQuantity = tempQuantity - tempDeliveredQuantity;
                if (tempReceivedQuantity > tempLeftQuantity) {
                    tempReceivedQuantity = tempLeftQuantity;
                }

                tempPrice = CommonUtil.getFloatValue(tempPrice * tempQuantity);
                attributeDataList[i].totalPrice = CommonUtil.getFloatValue(tempPrice, true);
                totalUnits = parseFloat(totalUnits + tempQuantity);
                subTotalWithoutTax = parseFloat(subTotalWithoutTax + tempPrice);
                taxTotal = parseFloat(taxTotal + parseFloat((tempPrice / 100) * tempTaxCode));

                if (isReceivedAllStatus) {
                    attributeDataList[i].receivedQuantity = tempLeftQuantity;
                } else {
                    attributeDataList[i].receivedQuantity = tempReceivedQuantity;
                }
                attributeDataList[i].taxValue = 0; //parseFloat(attributeDataList[i].taxValue).toFixed(2);
            } else {
                attributeDataList[i].totalPrice = "";
            }
        }

        grandTotal = CommonUtil.getFloatValue((subTotalWithoutTax + taxTotal), true);
        taxTotal = CommonUtil.getFloatValue(taxTotal, true);
        subTotalWithoutTax = CommonUtil.getFloatValue(subTotalWithoutTax, true);
        stateTaxTotal = parseFloat((taxTotal / 100) * CommonUtil.getFloatValue(that.props.stateGST));
        centralTaxTotal = parseFloat((taxTotal / 100) * CommonUtil.getFloatValue(that.props.centralGST));
        stateTaxTotal = CommonUtil.getFloatValue(stateTaxTotal).toFixed(2);
        centralTaxTotal = CommonUtil.getFloatValue(centralTaxTotal).toFixed(2);

        grandTotal = CommonUtil.getFloatValue(grandTotal) + CommonUtil.getFloatValue(totalExpenses);
        const attributeObj = { ...that.state.attributeObj, totalValue: grandTotal };
        await that.setState({
            [tableDataKeyName]: attributeDataList,
            totalUnits: CommonUtil.getFloatValue(totalUnits, true),
            subTotalWithoutTax: CommonUtil.getFloatValue(subTotalWithoutTax, true),
            taxTotal: CommonUtil.getFloatValue(taxTotal, true),
            stateTaxTotal: CommonUtil.getFloatValue(stateTaxTotal, true),
            centralTaxTotal: CommonUtil.getFloatValue(centralTaxTotal, true),
            grandTotal: CommonUtil.getFloatValue(grandTotal, true),
            attributeObj,
        });
    },
    handleExpensesTableCalulation: function (tableDataKeyName, that) {
        let attributeDataList = [...that.state[tableDataKeyName]];
        let totalReceivable = 0;
        for (let i = 0; i < that.state[tableDataKeyName].length; i++) {
            let tempReceivable = 0;
            tempReceivable = CommonUtil.getFloatValue(attributeDataList[i].expenseAmount);
            totalReceivable = CommonUtil.getTotalValue(totalReceivable, tempReceivable);
        }
        let totalExpenses = CommonUtil.getFloatValue(totalReceivable, true);
        that.setState({
            [tableDataKeyName]: attributeDataList,
            totalReceivable: totalReceivable,
            totalExpenses: totalExpenses,
        });
    },
    checkReceivedQuantityValidation: function (arrayList) {
        let filteredList = arrayList.filter(function (tempObj) {
            return CommonUtil.getFloatValue(tempObj.receivedQuantity) > 0
        });
        if (filteredList.length > 0) {
            return true;
        }
        return false;
    },
    isValidExpenseAmount: function (arrayList) {
        let filteredList = arrayList.filter(function (tempObj) {
            return CommonUtil.getFloatValue(tempObj.payableAmount) > 0 ||
                CommonUtil.getFloatValue(tempObj.receivableAmount) > 0
        });
        if (filteredList.length == arrayList.length) {
            return true;
        }
        return false;
    },
    validExpenseAmountPopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, purchaseOrderConstant.VALID_RECEIVABLE_PAYABLE_AMOUNT, false);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
    isValidExpenseRequestObj: function (that, tempObj, tableColumnList) {
        if (tempObj.expenseDetails.length > 0) {
            if (!ValidationUtil.validateArrayListRequestObj(tempObj.expenseDetails, tableColumnList)) {
                return false;
            }
            if (!this.isValidExpenseCombination(tempObj.expenseDetails)) {
                this.validExpenseCombinationPopup(that);
                return false;
            }
            return true;
        }
        return true;
    },
    isValidExpenseCombination: function (arrayList) {
        let tempList = arrayList.map((item) => {
            return item.account + " " + item.description;
        })
        const result = tempList.some((element, index) => {
            return tempList.indexOf(element) !== index
        });
        return !result;
    },
    validExpenseCombinationPopup: function (that) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = that.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, purchaseOrderConstant.VALID_ACCOUNT_DESCRIPTION_COMBINATION, false);
        that.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    },
};

export default PurchaseOrderUtil;