import React, { Component } from "react";
import { Grid, Row, Col, FormControl } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import Select from "react-select";
import { getProductList, getProductSearchList, getProductDetailList } from '../../productManagement/actions/productActions';
import PaginationUtil from "../../common/util/paginationUtil";
var Modal = require('react-bootstrap-modal')

class MultipleSelectionModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataList: [],
      params: null,
      family: '',
      familyName: '',
      familySearch: '',
      familyList: [],
      searchInput: "",
      selectedFilter: "",
      additionalParams: null,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true });
    this.setSelectedTabDetails();
  };

  setSelectedTabDetails = (status) => {
    const managePageList = pagePropertyListConstant.MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST(this);
    const { search, family } = this.state;
    var additionalParams = {};
    if(CommonUtil.isNotNull(search)) additionalParams["search"] = search;
    if(CommonUtil.isNotNull(family)) additionalParams["family"] = family;
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      tableDataList: this.props.productList.Items,
      attributeObj: this.props.productList.Items,
      searchInput: "",
      additionalParams: additionalParams,
      familyList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'familyList')]
    });
    this.makeCustomAPICall(additionalParams);
  };

  makeCustomAPICall(tempParamas) {
    this.props.getProductList({isDropdown: true, family: tempParamas.family });
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.productDetailList != null && prevProps.productDetailList != this.props.productDetailList) {
      let tempList = this.props.productDetailList;
      tempList.map((item) => {
        item.price = item.purchasePrice;
        item.totalPrice = 0;
        item.uniqueCode = item.productId;
        item.uniqueName = item.productName;
      })
      this.props.getProductSelectionDetails(tempList);
      this.setState({ openModal: false, submitted: true});
    }
  }

  updateProductDropDownList = async () => {
    let list = this.props.productList
    list = await list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    await this.setState({ tableDataList: [], attributeObj: [] })
    await this.setState({ tableDataList: list, attributeObj: list })
  }

  closeModal = (event) => {
    this.props.getProductSelectionDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave = async (event) => {
    const { attributeObj } = this.state;
    let tempList = [];
    tempList = attributeObj && attributeObj.filter((item) => item.isChecked == true).map((item) => {
      let temp = {
        productId : item.productId,
        productName : item.productName
      }
      return temp
    })
    if(tempList && tempList.length > 0 ) {
      this.setState({ submitted: true });
      await this.props.getProductDetailList(tempList)
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getProductSelectionDetails(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  handleFamilyDropdownChange = async (tempObj) => {
    await this.setState({
      family: tempObj.value, familyName: tempObj.label,
    });
    this.setSelectedTabDetails();
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = async () => {
    let { searchInput } = this.state;
    let list = this.props.productList.Items
    list = await list.sort((a,b) => (a.productCode > b.productCode) ? 1 : ((b.productCode > a.productCode) ? -1 : 0))
    let filteredData = list.filter((value) => {
      return (
        value.productCode.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    await this.setState({ tableDataList: [] });
    await this.setState({ tableDataList: filteredData, attributeObj: filteredData });
  };

  handleSubmit = (event) => {
    event.preventDefault();
  }

  handleCheckBoxChange = async (event) => {
    const { id, checked } = event.target;
    var tempId = id.split("_");
    const { attributeObj, tableDataList} = this.state;
    attributeObj.map((item) => {
      if(item.productId === tempId[0]) {
        item.isChecked = checked;
      }
    })
    tableDataList.map((item) => {
      if(item.productId === tempId[0]) {
        item.isChecked = checked;
      }
    })
    await this.setState({
      attributeObj: attributeObj,
      tableDataList: tableDataList
    })
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, search, familySearch} = this.state;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Add Multiple Products</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            <Row className="header-section" style={{marginBottom: '30px'}}>
                              <Col md={4}>
                                <Select
                                  classNamePrefix="react-select"
                                  name="family"
                                  onChange={(value) => this.handleFamilyDropdownChange(value)}
                                  value={{ "label": this.state.familyName ? this.state.familyName : 'Select Family' }}
                                  options={[...this.state.familyList]}
                                  placeholder="Select Family"
                                />
                              </Col>
                              <Col md={6}>
                                <div className="right-section multi-selection ">
                                  <div className="search-section advance" style={{width: '100%'}}>
                                    <form onSubmit={this.handleSubmit}>
                                    <i className="fa fa-search"></i>
                                    <FormControl type="text" name="searchInput" placeholder="Search by Product Code/Name"
                                      value={this.state.searchInput} onChange={this.handleChange} />
                                    </form>
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            {tableColumnList != null ? (
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                  <Table className={"table-box-height"} 
                                    columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                ) : null}
                              </Row>
                            ) : null}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>Add Product</Button>
                              </div>
                              :
                              <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                            }
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    productList: state.product.productList,
    productDetailList: state.product.productDetailList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getProductList: (id) => dispatch(getProductList(id)),
  getProductDetailList: (id) => dispatch(getProductDetailList(id)),
  getProductSearchList: params => dispatch(getProductSearchList(params)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MultipleSelectionModal);
