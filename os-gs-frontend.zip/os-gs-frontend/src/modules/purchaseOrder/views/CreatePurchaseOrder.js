import React, { Component } from "react";
import { Grid, Row, Col, Nav, NavDropdown, MenuItem, FormGroup, ControlLabel, Tabs, Tab } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import {
  setPurchaseOrderDetails,
  getPurchaseOrderDetails,
  updatePurchaseOrderDeleteStatus,
  setReducerInitMode,
  getQBODetails,
  getQBOBillDetails
} from "../actions/purchaseOrderActions";
import { setActionMode } from "../../../actions/appActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as purchaseOrderConstant from "../constant/purchaseOrderConstant";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { getIngredientList } from "../../ingredientManagement/actions/ingredientActions";
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getSupplierList, getSupplierDetails } from "../../supplierManagement/actions/supplierActions";
import { getProductList, getProductDetails } from '../../productManagement/actions/productActions';
import ValidationUtil from "../../common/util/validationUtil";
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil";
import PopupUtil from "../../common/util/popupUtil";
import LabelUtil from "modules/common/util/labelUtil";
import StockViewModal from "./StockViewModal";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DateUtil from "../../common/util/dateUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import StatusUtil from "../../common/util/statusUtil";
import * as commonConstant from "../../common/constant/commonConstant";
import * as statusConstant from "../../common/constant/statusConstant";
import PurchaseOrderUtil from '../views/PurchaseOrderUtil';
import isAuthorized from "auth-plugin";
import source from "assets/img/source-page-icon.svg";
import _ from 'lodash';
import DocumentUploadModal from "./DocumentUploadModal";
import mixpanel from "../../analytics/mixpanel/mixpael";
import GenerateInvoicePDF from "./GenerateInvoicePDF";
import pdf from 'assets/img/pdf.svg';
import Select from "react-select";
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import currencyIcon from '../../common/util/currencyIcon';
import CustomUtil from "./CustomUtil";
import MultipleSelectionModal from './MultipleSelectionModal';

class CreatePurchaseOrder extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      uniqueCode: null,
      openDocumentModal: false,
      openStockModal: false,
      isTaxValidationDone: false,
      productIngredientList: [],
      submitted: false,
      isDownLoadPdf: false,
      alert: null,
      qboBillAction: null,
      qboDetail: null,
      qboBillDetail: null,
      receivedStatusFlag: null,
      expenseDetails: [],
      selectedTab: "ORDERDETAILS",
      productTableKey: "productIngredientList",
      expensesTableKey: "expenseDetails",
      multipleSelectionModal: false,
    };
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Create purchase order loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getPurchaseOrderDetails(this.props.purchaseOrderId);
      }
    } else {
      CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_PURCHASE_ORDER_PAGE_URL, this);
    }
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getProductList({ isDropdown: true });
    this.props.getSupplierList({ isDropdown: true });
    this.props.getFacilityList({ isDropdown: true });
    this.setSelectedTableDetails();

    const commonAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_PAGE_LIST(this);
    await this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      termsAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.termsAttributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
    const orgInformation = await CommonUtil.getOrgInformation(this.props.dataDictionaryList);
    const imageUrl = await CommonUtil.getImageBlobFromUrl(orgInformation.logoURL);
    await this.setState({
      imageUrl: imageUrl,
    });
  };

  setSelectedTableDetails = (receivedStatusFlag) => {
    let tableAttributeList = [], tableColumnList = [];
    const { attributeObj, selectedTab } = this.state;
    if (attributeObj && selectedTab == "EXPENSESDETAILS") {
      tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this);
    } else {
      if (receivedStatusFlag) {
        tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_RECEIVE_TABLE_LIST(this);
      } else {
        tableAttributeList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this);
      }
    }
    const tempList = [...Array(20)].map(() => ({}))
    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.tableColumnList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
      receivedStatusFlag: receivedStatusFlag,
      dictionaryData: this.props.dataDictionaryList
    });
  };

  getSelectedTablekey = (selectedTab) => {
    if (this.state.selectedTab == 'ORDERDETAILS' || selectedTab == 'ORDERDETAILS') {
      return this.state.productTableKey;
    } else if (this.state.selectedTab == 'EXPENSESDETAILS' || selectedTab == 'EXPENSESDETAILS') {
      return this.state.expensesTableKey;
    }
  }

  getProductSelectionDetails = async (list) => {
    if (list) {
      const { productIngredientList } = this.state;
      let tempList = [...productIngredientList, ...list]
      let uniqueList = _.uniqBy(tempList, 'uniqueCode');
      await this.setState({ productIngredientList: [] })
      await this.setState({ productIngredientList: uniqueList.filter((x) => x.uniqueCode) })
    }
    this.setState({ multipleSelectionModal: false });
  }

  handleMultipleSelection = (event) => {
    this.setState({ multipleSelectionModal: true });
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  handleTableDateChange = (event, eventId) => {
    PopularTableUtil.handleTableDateChange(event, eventId, this, this.getSelectedTablekey());
  }

  handleTableSuggestionChange = (event, eventId, searchOptions, shouldNewRowAdded) => {
    let id = parseInt(eventId.split('_')[1]);
    let key = eventId.split('_')[0];
    if (event != null && event.length > 0) {
      let attributeDataList = [...this.state[this.getSelectedTablekey()]];
      if (event[0].productId && CommonUtil.isNotNull(id)) {
        attributeDataList[id].uniqueCode = event[0].productId;
        attributeDataList[id].uniqueName = event[0].productName;
      }
      else {
        attributeDataList[id].uniqueCode = event[0].ingredientId;
        attributeDataList[id].uniqueName = event[0].ingredientName;
      }
      this.setState({ productIngredientList: attributeDataList });
      CustomUtil.handleCustomDropDownCall(event, key, this, true);
      if (shouldNewRowAdded) {
        this.handleTableAddRow();
      }
    }
  }

  handleCustomDropDownCall = async (event, obj) => {
    CustomUtil.handleCustomDropDownCall(event, obj, this);
  };


  handleDeleteRowPopup = (event) => {
    this.setState({ eventId: event.target.id });
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleTableRemove = async (event) => {
    this.setState({ alert: null });
    let tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, this.getSelectedTablekey(), true);
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  };

  handleTableAddRow = (event) => {
    if (this.state.productIngredientList.length < this.state.productIngredientOptions.length) {
      PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
    }
  };

  handleTableButtonMenuAction = (event) => {
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };

  handleTableStatusButtonClick = (event) => {
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    let uniqueCode = event.target && event.target.id.split("_")[0];
    this.setState({ openStockModal: true, uniqueCode: uniqueCode });
  }

  getStockViewDetails = () => {
    this.setState({ openStockModal: false });
  }

  getUploadDocumentDetails = (uploadDocumentObj) => {
    this.setState({ openDocumentModal: false });
    if (uploadDocumentObj != null && uploadDocumentObj.documents &&
      uploadDocumentObj.documents.length >= 0) {
      PurchaseOrderUtil.handleUploadDocumentDetails({ ...uploadDocumentObj }, this);
    }
  }

  componentDidUpdate(prevProps, prevState) {
    CustomUtil.handleAPIResponse(this, prevProps, prevState);
  }

  handleQBODetails = async () => {
    await this.setState({ qboDetail: this.props.qboDetail });
  }

  handleQBOBillDetails = () => {
    this.setState({ qboBillDetail: this.props.qboBillDetail });
    if (this.state.qboBillAction == 'create') {
      const { limit, currentPage } = this.state;
      this.props.getPurchaseOrderDetails(this.state.attributeObj.purchaseOrderId);
    } else if (this.state.qboBillAction == 'view') {
      if (CommonUtil.isNotNull(this.props.qboBillDetail.qboURL)) {
        window.open(this.props.qboBillDetail.qboURL);
      }
    }
  }

  getQBOBillDetails = (e) => {
    if (PurchaseOrderUtil.isInActiveQBOAccount(this)) {
      PurchaseOrderUtil.QBOInActivePopup(this);
      return
    }
    let eventId = e.target.id.split("_");
    let qboParams = {};
    qboParams.purchaseorderCode = eventId[0];
    if (CommonUtil.isNullValue(eventId[1])) {
      qboParams.action = 'create';
      this.setState({ qboBillAction: 'create' });
    } else {
      qboParams.action = 'view';
      this.setState({ qboBillAction: 'view' });
      qboParams.sourceId = eventId[1];
    }
    this.props.getQBOBillDetails(qboParams);
  };

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  updateIngredientDropDownList = () => {
    this.setState({ ingredientList: this.props.ingredientList.Items });
    this.mergeProductIngredientList();
  }

  updateProductDropDownList = () => {
    this.setState({ productList: this.props.productList });
    this.mergeProductIngredientList();
  }

  mergeProductIngredientList = async () => {
    const { productIngredientList } = this.state;
    let activeProductList = [];
    this.props.productList && Array.prototype.push.apply(activeProductList, this.props.productList.Items);
    const tempList = CommonUtil.isNotNull(productIngredientList) ? productIngredientList : [...Array(20)].map(() => ({}))
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      await this.setState({ productIngredientList: [...tempList] });
    }
    await this.setState({ productIngredientOptions: [...activeProductList] })
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  updateFacilityDropDownList = () => {
    this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList,
        CommonUtil.getOptionsFromList(this.props.facilityList.Items,
          'facilityId', 'facilityName'), 'facilityId')
    })
  }

  updateSupplierDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.supplierList.Items,'supplierId', 'supplierName');
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({
        attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'supplierId')
    })
  }

  handleSave(event) {
    this.setState({ submitted: true, qboBillAction: null });
    let tempObj = this.state.attributeObj;
    tempObj.totalValue = this.state.grandTotal;

    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj, this.state.attributeList,
      this.props.actionMode);
    tempObj.productIngredientList = [];
    tempObj.productIngredientList = [...this.state.productIngredientList].filter((item, index) => item.uniqueCode);

    tempObj.productIngredientList = ValidationUtil.removeAttributeFromArrayList(tempObj.productIngredientList,
      pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this).tableColumnList,
      commonConstant.CREATE_ACTION_MODE);
    tempObj.expenseDetails = [...this.state.expenseDetails];
    const tableColumnList = pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this).tableColumnList;
    tempObj.expenseDetails = ValidationUtil.removeAttributeFromArrayList(tempObj.expenseDetails, tableColumnList,
      this.props.actionMode);
    if (this.isValidRequestObj(tempObj) && PurchaseOrderUtil.isValidExpenseRequestObj(this, tempObj, tableColumnList)) {
      this.props.setPurchaseOrderDetails(tempObj, this.props.actionMode);
    }
  }

  isValidRequestObj = (tempObj) => {
    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }
    if (tempObj.productIngredientList.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.productIngredientList,
        pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this).tableColumnList)) {
        return false;
      }
      // if (this.state.receivedStatusFlag && !PurchaseOrderUtil.checkReceivedQuantityValidation(tempObj.productIngredientList)) {
      //   if (tempObj.status != statusConstant.COMPLETED_STATUS) {
      //     return false;
      //   }
      // }
    }
    if (CommonUtil.isCreateMode(this.props.actionMode)) {
      if (!this.state.isTaxValidationDone && !PurchaseOrderUtil.checkTaxValidation(tempObj.productIngredientList)) {
        PurchaseOrderUtil.handleTaxValidation(this);
        return false;
      }
    }
    if (tempObj.expenseDetails.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.expenseDetails,
        pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this).tableColumnList)) {
        return false;
      }
    }
    return true;
  }

  handleHeaderIconClick = (e, action) => {
    switch (action) {
      case commonConstant.PRINT_ACTION:
        this.printPurchaseOrder();
        break;
      case commonConstant.CLONE_ACTION:
        this.clonePurchaseOrder();
        this.setSelectedTableDetails()
        break;
      case commonConstant.TRASH_ACTION:
        this.deletePurchaseOrder();
        break;
      case commonConstant.DOWNLOAD_ACTION_MODE:
        this.downloadPurchaseOrder();
        break;
      default:
        console.log("Invalid header action");
    }
  };

  downloadPurchaseOrder = (params) => {
    if (!CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      this.setState({ isDownLoadPdf: true });
    }
  }
  printPurchaseOrder = (params) => {
    // TODO
  };

  clonePurchaseOrder = (params) => {
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    this.props.setActionMode(commonConstant.CLONE_ACTION_MODE);
    this.props.getPurchaseOrderDetails(this.state.attributeObj.purchaseOrderId);
  };

  deletePurchaseOrder = (params) => {
    if (!CommonUtil.isEditMode(this.props.actionMode)) {
      return;
    }
    if (this.state.attributeObj.status !== statusConstant.NEW_STATUS) {
      return;
    }
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleStatusAction;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeletPopUpConfig(
      popupActionButton, purchaseOrderConstant.MODULE_NAME);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  };

  handleStatusAction = (status) => {
    let tempObj = {};
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updatePurchaseOrderDeleteStatus(tempObj, this.state.attributeObj.purchaseOrderId);
  };

  handleTaxConfirmation = async () => {
    await this.setState({ isTaxValidationDone: true, alert: null });
    this.handleSave();
  };

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      } else {
        if (CommonUtil.isNullValue(this.state.attributeObj.billingSourceName)) {
          if (this.state.qboBillAction == 'create') {
            this.props.handleClick(CommonUtil.prepareBillCreatedSuccessPopUpConfig());
            return
          } else {
            this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
          }
        } else {
          if (this.state.qboBillAction == 'view') {
            return
          } else {
            this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
          }
        }
      }
      let params = null;
      if (this.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
        params = "COMPLETED";
      }
      setTimeout(CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_PURCHASE_ORDER_PAGE_URL, this, params), 0);
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      let errorMessage = this.props.ajaxCallStatus.data &&
        this.props.ajaxCallStatus.data.response &&
        this.props.ajaxCallStatus.data.response.data;
      if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "411") {
        PurchaseOrderUtil.QBOSupplierNotExitPopup(this);
      } else {
        PopupUtil.popupErrorResponse(this);
      }
      await this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = null;
    if (this.state.attributeObj.status == statusConstant.COMPLETED_STATUS) {
      params = "COMPLETED";
    }
    CommonUtil.handlePageRedirection(purchaseOrderConstant.MANAGE_PURCHASE_ORDER_PAGE_URL, this, params);
  }

  async updateApiData(attributeObj) {
    await this.setState({
      attributeObj: {
        ...attributeObj,
        purchaseOrderId: CommonUtil.isCloneMode(this.props.actionMode)
          ? "" : attributeObj.purchaseOrderId,
      },
      productIngredientList: [...attributeObj.productIngredientList],
      expenseDetails: attributeObj.expenseDetails ? [...attributeObj.expenseDetails] : [],
    });
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  }

  updateCloneData = async (attributeObj) => {
    let tempObj = attributeObj;
    tempObj.status = statusConstant.NEW_STATUS;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj, this.state.attributeList, this.props.actionMode);
    tempObj.createdDate = CommonUtil.getTodaysDate();
    tempObj.productIngredientList = ValidationUtil.removeAttributeFromArrayList(tempObj.productIngredientList,
      pagePropertyListConstant.CREATE_PURCHASE_ORDER_PRODUCT_TABLE_LIST(this).tableColumnList,
      commonConstant.CLONE_ACTION_MODE);
    tempObj.expenseDetails = tempObj.expenseDetails ? ValidationUtil.removeAttributeFromArrayList(tempObj.expenseDetails,
      pagePropertyListConstant.CREATE_PURCHASE_ORDER_EXPENSESDETAILS_PRODUCT_TABLE_LIST(this).tableColumnList,
      commonConstant.CLONE_ACTION_MODE) : [];
    await this.setState({
      attributeObj: {
        ...tempObj,
        purchaseOrderId: CommonUtil.isCloneMode(this.props.actionMode) ? "" : tempObj.purchaseOrderId,
      },
      productIngredientList: [...tempObj.productIngredientList],
      expenseDetails: [...tempObj.expenseDetails],
      isDownLoadPdf: false
    });
    this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  };

  createNew = async () => {
    const tempList = [...Array(20)].map(() => ({}))
    let tempObj = [];
    tempObj.status = statusConstant.NEW_STATUS;
    tempObj.createdDate = CommonUtil.getTodaysDate();
    tempObj.productIngredientList = [];
    tempObj.expenseDetails = [];
    await this.setState({
      attributeObj: {
        ...tempObj,
        purchaseOrderId: "",
      },
      productIngredientList: [...tempList],
      expenseDetails: [...tempObj.expenseDetails],
    });
    await this.handleTableAddRow();
    PurchaseOrderUtil.handleTableCalculation(this.getSelectedTablekey(), this);
  };

  handleTabClick = async (label, event) => {
    let selectedTabKey = label.toUpperCase();
    await this.setState({ selectedTab: selectedTabKey })
    this.setSelectedTableDetails();
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList, tableConfig, stateTaxTotal, centralTaxTotal,
      totalUnits, taxTotal, grandTotal, subTotalWithoutTax, termsAttributeList, imageUrl, totalExpenses } = this.state;
    const tableDataList = this.state[this.getSelectedTablekey()];
    const actionMode = this.props.actionMode;
    const currencyCode = this.props.currencyCode;
    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}

        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={source} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    purchaseOrderConstant.EDIT_PURCHASE_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      purchaseOrderConstant.VIEW_PURCHASE_HEADER_TITLE
                      : purchaseOrderConstant.CREATE_PURCHASE_HEADER_TITLE}
                </div>
              </Col>

              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {isAuthorized("createPurchaseOrderActions") &&
                    <div className="page-action-buttons">
                      <div className={`btn-fill btn-wd btn btn-default progress-button ${!CommonUtil.isEditMode(actionMode) ? 'disabled' : ''}`}
                        style={{
                          backgroundColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status),
                          borderColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status)
                        }}>
                        <div className="items">{StatusUtil.getStatusLabel(attributeObj && attributeObj.status)}
                        </div>
                        {!CommonUtil.isViewMode(this.props.actionMode) && !CommonUtil.isCreateOrCloneMode(this.props.actionMode) ?
                          <div className="items">
                            <Nav pullRight>
                              <NavDropdown id={'status'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
                                {pagePropertyListConstant.HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                                  <MenuItem key={index} name="status" id={tempAttributeListObj.statusKey}
                                    onClick={(e) => PurchaseOrderUtil.handleButtonStatusChange(e, this)}
                                    disabled={false}>
                                    <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
                                    {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                                  </MenuItem>
                                ))}
                              </NavDropdown>
                            </Nav>
                          </div>
                          : null}
                      </div>
                      {(CommonUtil.isEditMode(actionMode) || CommonUtil.isViewMode(actionMode)) && attributeObj && this.props.qboDetail && this.props.qboDetail.qboStatus != "NA" ?
                        <div className='btn-fill btn-wd btn progress-button qbo'
                          onClick={(e) => this.getQBOBillDetails(e)}
                          id={attributeObj.purchaseOrderId + "_" + attributeObj.billingSourceId}
                          style={{
                            backgroundColor: StatusUtil.getStatusColor(PurchaseOrderUtil.getQBOBillStatus(attributeObj.billingSourceName)),
                            borderColor: StatusUtil.getStatusColor(PurchaseOrderUtil.getQBOBillStatus(attributeObj.billingSourceName))
                          }}>
                          {StatusUtil.getStatusLabel(PurchaseOrderUtil.getQBOBillStatus(attributeObj && attributeObj.billingSourceName))}
                        </div>
                        : null}

                      {this.state.isDownLoadPdf == true ? <GenerateInvoicePDF isDownLoadPdf={true} imageUrl={imageUrl} /> : <i className="fa fa-download invoice-download" title={"Download"} onClick={(e) => this.handleHeaderIconClick(e, commonConstant.DOWNLOAD_ACTION_MODE)} ></i>}

                      {/*<i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-print' : 'fa fa-print disabled'} title={"Print"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.PRINT_ACTION)} ></i>*/}
                      <i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-copy' : 'fa fa-copy disabled'} title={"Clone"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.CLONE_ACTION)} ></i>
                      <i className={(CommonUtil.isEditMode(actionMode) && StatusUtil.getStatusLabel(attributeObj && attributeObj.status) === 'New') ? 'fa fa-trash' : 'fa fa-trash disabled'} title={"Trash"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.TRASH_ACTION)} ></i>
                    </div>
                  }
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    !this.props.insideInventory && <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                          tempAttributeListObj.type == "FIXED" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            LabelUtil.fixedAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                            : tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : null))
                        }
                      </Row>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <Tabs id="create-sale-tabs" className="table-tabs-without-border" activeKey={this.state.selectedTab} onSelect={this.handleTabClick}>
                      <Tab eventKey={'ORDERDETAILS'} title="ORDER DETAILS">
                        {tableColumnList != null ?
                          <Row>
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                              <Table
                                columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                            ) : null}

                            <div className="add-new-section">
                              <Col md={6}>
                                <Row>
                                  <Col md={12}>
                                    {attributeObj.status === statusConstant.NEW_STATUS &&
                                      !CommonUtil.isViewMode(this.props.actionMode) ?
                                      <div className="add-row-button" onClick={!CommonUtil.isViewMode(actionMode) ?
                                        (e) => this.handleTableAddRow(e) : null}>
                                        <i className=" fa fa-plus" />
                                        Add Row
                                    </div>
                                      : null}
                                  </Col>
                                  <Col md={12}>
                                    {attributeObj.status === statusConstant.NEW_STATUS &&
                                      !CommonUtil.isViewMode(this.props.actionMode) ?
                                      <div className="add-row-button" onClick={(e) => this.handleMultipleSelection(e)}>
                                        <i className=" fa fa-plus" />
                                        Add multiple products
                                      </div>
                                      : null}
                                  </Col>
                                  <Col md={6} className="tcs">
                                    <Row>
                                      {termsAttributeList != null && termsAttributeList.map((tempAttributeListObj, index) => (
                                        DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      ))}
                                    </Row>
                                  </Col>
                                </Row>
                              </Col>
                              <Col md={6}>
                                <ul className="total-section">
                                  <li>
                                    <Col md={6} className="total-section-field-title"> Total Units </Col>
                                    <Col md={6} className="total-section-field-value">
                                      {totalUnits}
                                    </Col>
                                  </li>
                                  <li>
                                    <Col md={6} className="total-section-field-title">
                                      Subtotal
                                  </Col>
                                    {subTotalWithoutTax ? (
                                      <Col md={6} className="total-section-field-value">
                                        {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, subTotalWithoutTax)}
                                      </Col>
                                    ) : null}
                                  </li>

                                  <li>
                                    <Col md={6} className="total-section-field-title">
                                      Total Expense
                                  </Col>
                                    <Col md={6} className="total-section-field-value">
                                      {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalExpenses)}
                                    </Col>
                                  </li>


                                  <li>
                                    <Col md={6} className="total-section-field-title">
                                      <b>Final Total</b>
                                    </Col>
                                    {grandTotal ? (
                                      <Col md={6} className="total-section-field-value">
                                        <b>{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, grandTotal)}</b>
                                      </Col>
                                    ) : null}
                                  </li>
                                </ul>
                              </Col>
                            </div>
                          </Row>
                          : null}
                      </Tab>
                      {(CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditMode(actionMode) || CommonUtil.isViewMode(actionMode)) &&
                        <Tab eventKey={'EXPENSESDETAILS'} title="EXPENSE DETAILS">
                          {tableColumnList != null ? (
                            <Row>
                              <Table
                                columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              <div className="add-new-section">
                                <Col md={6}>
                                  <Row>
                                    <Col md={12}>
                                      {
                                        <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                          <i className=" fa fa-plus" />
                                          Add Row
                                        </div>
                                      }
                                    </Col>
                                  </Row>
                                </Col>
                                <Col md={6}>
                                  <ul className="total-section">
                                    {/* <li>
                                      <Col md={6} className="total-section-field-title">Amount Receivable</Col>
                                      <Col md={6} className="total-section-field-value">
                                        {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalReceivable)}
                                      </Col>
                                    </li>
                                    <li>
                                      <Col md={6} className="total-section-field-title">Amount Payable</Col>
                                      <Col md={6} className="total-section-field-value">
                                        {currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalPayable)}
                                      </Col>
                                    </li> */}
                                    <li>
                                      <Col md={6} className="total-section-field-title">
                                        <b>Total Expense</b>
                                      </Col>
                                      {totalExpenses ? (
                                        <Col md={6} className="total-section-field-value">
                                          <b>{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, totalExpenses)}</b>
                                        </Col>
                                      ) : null}
                                    </li>
                                  </ul>
                                </Col>
                              </div>
                            </Row>
                          ) : null}
                        </Tab>
                      }
                      {this.state.openStockModal == true ?
                        <StockViewModal
                          attributeObj={this.state.attributeObj}
                          purchaseOrderId={this.props.purchaseOrderId}
                          uniqueCode={this.state.uniqueCode}
                          getStockViewDetails={this.getStockViewDetails}>
                        </StockViewModal>
                        : null}
                      {this.state.openDocumentModal == true ?
                        <DocumentUploadModal
                          productIngredientList={this.state.productIngredientList}
                          purchaseOrderId={this.props.purchaseOrderId}
                          uniqueCode={this.state.uniqueCode}
                          getUploadDocumentDetails={this.getUploadDocumentDetails}>
                        </DocumentUploadModal>
                        : null}
                      {this.state.multipleSelectionModal == true ?
                        <MultipleSelectionModal
                          saleOrderId={this.props.saleOrderId}
                          getProductSelectionDetails={this.getProductSelectionDetails}>
                        </MultipleSelectionModal>
                        : null}
                    </Tabs>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        !this.props.insideInventory && <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.purchaseOrder.purchaseOrderDetails,
    purchaseOrderId: state.purchaseOrder.selectedPurchaseOrderCode,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    productList: state.product.productList,
    supplierList: state.supplier.supplierList,
    ingredientList: state.ingredient.ingredientList,
    facilityList: state.facility.facilityList,
    currencyCode: state.dataDictionary.currencyCode,
    stateGST: state.dataDictionary.stateGST,
    centralGST: state.dataDictionary.centralGST,
    qboDetail: state.purchaseOrder.qboDetail,
    qboBillDetail: state.purchaseOrder.qboBillDetail,
    productDetails: state.product.productDetails,
    facilityDetails: state.facility.facilityDetails,
    supplierDetails: state.supplier.supplierDetails,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setPurchaseOrderDetails: (purchaseOrderDetailsObj, actionMode) => dispatch(setPurchaseOrderDetails(purchaseOrderDetailsObj, actionMode)),
  getPurchaseOrderDetails: (selectedPurchaseOrderCode) => dispatch(getPurchaseOrderDetails(selectedPurchaseOrderCode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  updatePurchaseOrderDeleteStatus: (purchaseOrderDetails, purchaseOrderId) => dispatch(updatePurchaseOrderDeleteStatus(purchaseOrderDetails, purchaseOrderId)),
  setReducerInitMode: (init) => dispatch(setReducerInitMode(init)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getFacilityDetails: (id) => dispatch(getFacilityDetails(id)),
  getProductDetails: (id) => dispatch(getProductDetails(id)),
  getSupplierDetails: (id) => dispatch(getSupplierDetails(id)),
  getQBODetails: (id) => dispatch(getQBODetails(id)),
  getQBOBillDetails: (id) => dispatch(getQBOBillDetails(id)),
});
export default connect(mapStateToProps, mapDispatchToProps)(CreatePurchaseOrder);
