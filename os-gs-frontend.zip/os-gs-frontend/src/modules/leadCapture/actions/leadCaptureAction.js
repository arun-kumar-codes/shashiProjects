import axios from '../../../axios/axios.js';
import * as leadCaptureActionTypes from './leadCaptureActionType';
import * as leadCaptureConstant from '../constant/leadCaptureConstants';
import { beginAjaxCall, endAjaxCall } from "../../../actions/ajaxStatusActions";

let headers = {
  "Access-Control-Allow-Origin": "*",
  methods: "GET,PUT,POST,DELETE"
};


export function setLeadCaptureCount(count) {
  return function (dispatch) {
    dispatch({
      type: leadCaptureActionTypes.GET_LEADCAPTURE_COUNT,
      payload: count
    });
  }
}

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: leadCaptureActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setPageVisitCount(count) {
  return function (dispatch) {
    dispatch({
      type: leadCaptureActionTypes.GET_PAGE_VISIT_COUNT,
      payload: count
    });
  }
}

export function getLeadCaptureList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(leadCaptureConstant.GET_LEADCAPTURE_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: leadCaptureActionTypes.GET_LEADCAPTURE_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getLeadCaptureCount(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(leadCaptureConstant.GET_LEADCAPTURE_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: leadCaptureActionTypes.GET_LEADCAPTURE_COUNT,
          payload: response.data.Count
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getPageVisitCount(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(leadCaptureConstant.GET_PAGE_VISIT_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: leadCaptureActionTypes.GET_PAGE_VISIT_COUNT,
          payload: response.data.Count
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getPageVisitList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(leadCaptureConstant.GET_PAGE_VISIT_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: leadCaptureActionTypes.GET_PAGE_VISIT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}
