import axios from "axios";
import * as leadcaptureActionTypes from './leadcaptureActionTypes';
import * as leadcaptureConstant from '../constant/leadcaptureConstant';
import { beginAjaxCall, endAjaxCall } from "../../../actions/ajaxStatusActions";

let headers = {
  "Access-Control-Allow-Origin": "*",
  methods: "GET,PUT,POST,DELETE"
};

export function getLeadcaptureList() {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(leadcaptureConstant.GET_LEADCAPTURE_LIST_URL, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: leadcaptureActionTypes.GET_LEADCAPTURE_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      throw error;
    });
  };
}




