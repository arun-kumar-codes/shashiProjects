import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, Form, FormGroup, ControlLabel, MenuItem, Navbar } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as leadCaptureConstant from '../constant/leadCaptureConstants';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { getLeadCaptureList } from "../actions/leadCaptureAction";
import CommonUtil from '../../common/util/commonUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";

import filter from 'assets/img/filter.svg';

class ManageLeadCapture extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      productSelect: null,
      geographySelect: null,
      datefromSelect: null,
      datetoSelect: null,
      menuOpen: false,
      currentPage: 1,
    };
    this.dropdownToggle = this.dropdownToggle.bind(this)
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this)
  }

  componentDidMount = () => {
      mixpanel.track("Manage Lead capture loaded");
    this.props.getLeadCaptureList(this.props.location && this.props.location.state);
    const managePageList = pagePropertyListConstant.LEADCAPTURE_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      defaultFilteredList: managePageList.defaultFilteredList,
      defaultSortedList: managePageList.defaultSortedList,
      defaultPageSize: managePageList.defaultPageSize,
      tableConfig: managePageList.tableConfig,
      tableDataList: leadCaptureConstant.dataTable,
    })
  }

  componentDidUpdate(prevProps) {
    if (prevProps.leadCaptureList != this.props.leadCaptureList && this.props.leadCaptureList != null) {
      this.setState({
        tableDataList: CommonUtil.getCurrentZoneDate(this.props.leadCaptureList.Items, 'capture_ts'),
      })
    }
  }

  dropdownToggle(newValue) {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown() {
    this._forceOpen = true;
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = leadCaptureConstant.dataTable.filter(value => {
      return (
        value.product.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  render() {
    const { tableColumnList, tableDataList, defaultSortedList, defaultFilteredList, defaultPageSize,
      tableConfig } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }

        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">

              <Col sm={4} md={4}>

              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search By Product"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </div>

                  <Nav pullRight>
                    <NavDropdown title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <FormGroup>
                            <ControlLabel className="col-md-3">Product</ControlLabel>
                            <Col md={8}>

                              <FormControl className="react-select primary" type="text" name="productSelect"
                                placeholder="Search By Product"
                                value={this.state.productSelect}
                                onChange={value => this.setState({ productSelect: value })} />

                            </Col>
                          </FormGroup>
                          <FormGroup>
                            <ControlLabel className="col-md-3">Geography</ControlLabel>
                            <Col md={8}>
                              <FormControl className="react-select primary" type="text" name="geography"
                                placeholder="Search By Geography"
                                value={this.state.geography}
                                onChange={value => this.setState({ geography: value })} />
                            </Col>
                          </FormGroup>
                          <FormGroup>
                            <ControlLabel className="col-md-3">Date</ControlLabel>
                            <Col md={4}>
                              <FormControl className="react-select primary" type="date" name="fromDate"
                                placeholder="From Date"
                                value={this.state.fromDate}
                                onChange={value => this.setState({ fromDate: value })} />
                            </Col>
                            <Col md={4}>
                              <FormControl className="react-select primary" type="date" name="toDate"
                                placeholder="To Date"
                                value={this.state.toDate}
                                onChange={value => this.setState({ toDate: value })} />
                            </Col>
                          </FormGroup>
                        </Form>
                      </MenuItem>
                    </NavDropdown>
                  </Nav>

                  <div className="btn-fill btn-default btn-wd btn create-options">
                    <i className="fa fa-download" />export
                  </div>
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    leadCaptureList: state.leadCapture.leadCaptureList,
    dataDictionaryList:state.dataDictionary.dataDictionaryList
  };
}

const mapDispatchToProps = dispatch => ({
  getLeadCaptureList: parmas => dispatch(getLeadCaptureList(parmas)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageLeadCapture);
