import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, Form, FormGroup, ControlLabel, MenuItem, Navbar } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as leadCaptureConstant from '../constant/leadCaptureConstants';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import Select from "react-select";
import { connect } from "react-redux";
import { getPageVisitList } from "../actions/leadCaptureAction";
import CommonUtil from '../../common/util/commonUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";

import filter from 'assets/img/filter.svg';


class ManagePageVisit extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      productSelect: null,
      geographySelect: null,
      datefromSelect: null,
      datetoSelect: null,
      currentPage: 1,
    };
  }

  componentDidMount = () => {
      mixpanel.track("Manage page visit");
    this.props.getPageVisitList(this.props.location && this.props.location.state);
    const managePageList = pagePropertyListConstant.PAGE_VISIT_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      defaultFilteredList: managePageList.defaultFilteredList,
      defaultSortedList: managePageList.defaultSortedList,
      defaultPageSize: managePageList.defaultPageSize,
      tableConfig: managePageList.tableConfig,
      tableDataList: leadCaptureConstant.dataTable,
    })
  }

  componentDidUpdate(prevProps) {
    if (prevProps.pageVisitList != this.props.pageVisitList && this.props.pageVisitList != null) {
      this.setState({
        tableDataList: CommonUtil.getCurrentZoneDate(this.props.pageVisitList.Items),
      })
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = leadCaptureConstant.dataTable.filter(value => {
      return (
        value.product.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  render() {
    const { tableColumnList, tableDataList, defaultSortedList, defaultFilteredList,
      defaultPageSize, tableConfig } = this.state;

    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }

        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">

              <Col sm={4} md={4}>

              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search By Product"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </div>

                  <Nav pullRight>
                    <NavDropdown title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status filter-form">
                      <Form horizontal>
                        <FormGroup>
                          <ControlLabel className="col-md-3">Product</ControlLabel>
                          <Col md={8}>
                            <Select className="react-select primary" classNamePrefix="react-select"
                              name="productSelect" value={this.state.productSelect}
                              onChange={value => this.setState({ productSelect: value })}
                              options={[
                                { value: "2", label: "Foobar" },
                                { value: "3", label: "Is great" }
                              ]}
                              placeholder=""
                            />
                          </Col>
                        </FormGroup>
                        <FormGroup>
                          <ControlLabel className="col-md-3">Geography</ControlLabel>
                          <Col md={8}>
                            <Select className="react-select primary" classNamePrefix="react-select" name="geographySelect"
                              value={this.state.geographySelect} onChange={value =>
                                this.setState({ geographySelect: value })
                              }
                              options={[
                                { value: "2", label: "Foobar" },
                                { value: "3", label: "Is great" }
                              ]}
                              placeholder=""
                            />
                          </Col>
                        </FormGroup>
                        <FormGroup>
                          <ControlLabel className="col-md-3">Date</ControlLabel>
                          <Col md={4}>
                            <Select
                              className="react-select primary" classNamePrefix="react-select"
                              name="dateformSelect" value={this.state.dateformSelect}
                              onChange={value => this.setState({ dateformSelect: value })}
                              options={[
                                { value: "2", label: "Foobar" },
                                { value: "3", label: "Is great" }
                              ]}
                              placeholder="From"
                            />
                          </Col>
                          <Col md={4}>
                            <Select className="react-select primary" classNamePrefix="react-select"
                              name="datetoSelect" value={this.state.datetoSelect}
                              onChange={value => this.setState({ datetoSelect: value })}
                              options={[
                                { value: "2", label: "Foobar" },
                                { value: "3", label: "Is great" }
                              ]}
                              placeholder="To"
                            />
                          </Col>
                        </FormGroup>
                      </Form>
                    </NavDropdown>
                  </Nav>

                  <div className="btn-fill btn-wd btn btn-default create-options">
                    <i className="fa fa-download" />export
                  </div>
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    pageVisitList: state.leadCapture.pageVisitList,
    dataDictionaryList:state.dataDictionary.dataDictionaryList
  };
}

const mapDispatchToProps = dispatch => ({
  getPageVisitList: parmas => dispatch(getPageVisitList(parmas))
});

export default connect(mapStateToProps, mapDispatchToProps)(ManagePageVisit);
