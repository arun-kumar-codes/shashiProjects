import React, { Component } from "react";
import {
  Grid,
  Row,
  Col,
  FormControl,
  Nav,
  NavDropdown,
  Form,
  FormGroup,
  ControlLabel,
  MenuItem,
  Navbar,
} from "react-bootstrap";
import { Link, Redirect } from "react-router-dom";
import ReactTable from "react-table-6";
import Card from "components/Card/Card.jsx";
import * as leadcaptureConstant from "../constant/leadcaptureConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import Select from "react-select";
import { connect } from "react-redux";
import { getLeadcaptureList } from "../actions/leadcaptureActions";

class LeadCapture extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      productSelect: null,
      geographySelect: null,
      datefromSelect: null,
      datetoSelect: null,
    };
  }

  componentDidMount = () => {
    this.props.getLeadcaptureList();
    this.setState({
      tableColumnList:
        pagePropertyListConstant.LEADCAPTURE_PAGE_LIST.tableColumnList,
      defaultFilteredList:
        pagePropertyListConstant.LEADCAPTURE_PAGE_LIST.defaultFilteredList,
      defaultSortedList:
        pagePropertyListConstant.LEADCAPTURE_PAGE_LIST.defaultSortedList,
      defaultPageSize:
        pagePropertyListConstant.LEADCAPTURE_PAGE_LIST.defaultPageSize,
      tableDataList: leadcaptureConstant.dataTable,
    });
  };

  componentDidUpdate(prevProps) {
    if (
      prevProps.leadcaptureList != this.props.leadcaptureList &&
      this.props.leadcaptureList != null
    ) {
      this.setState({
        tableDataList: this.props.leadcaptureList,
      });
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = leadcaptureConstant.dataTable.filter((value) => {
      return value.product.toLowerCase().includes(searchInput.toLowerCase());
    });
    this.setState({ tableDataList: filteredData });
  };

  render() {
    const {
      tableColumnList,
      tableDataList,
      defaultSortedList,
      defaultFilteredList,
      defaultPageSize,
    } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ? (
          <Redirect push to={this.state.redirectUrl}></Redirect>
        ) : null}

        <Grid fluid>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    <Row>
                      <div className="header-section">
                        <Col md={5}>
                          <div className="page-title">
                            {
                              leadcaptureConstant.LEADCAPTUREDETAILS_HEADER_TITLE
                            }
                          </div>
                        </Col>
                        <Col md={7} sd={12}>
                          <div className="search-section">
                            <i className="fa fa-search"></i>
                            <FormControl
                              type="text"
                              name="searchInput"
                              placeholder="Search By Product"
                              value={this.state.searchInput}
                              onChange={this.handleChange}
                            />
                          </div>

                          <div className="btn-fill btn-wd btn-round btn btn-info create-options">
                            <i className="fa fa-download" />
                            export
                          </div>
                          <Nav pullRight>
                            <NavDropdown
                              title={
                                <div>
                                  {" "}
                                  <i className="fa fa-filter" />{" "}
                                </div>
                              }
                              noCaret
                              id="status-filter"
                              className="filter-status filter-form"
                            >
                              <Form horizontal>
                                <FormGroup>
                                  <ControlLabel className="col-md-3">
                                    Keyword
                                  </ControlLabel>
                                  <Col md={8}>
                                    <FormControl
                                      placeholder=""
                                      type="text"
                                      name="Keyword"
                                    />
                                  </Col>
                                </FormGroup>
                                <FormGroup>
                                  <ControlLabel className="col-md-3">
                                    Product
                                  </ControlLabel>
                                  <Col md={8}>
                                    <Select
                                      className="react-select primary"
                                      classNamePrefix="react-select"
                                      name="productSelect"
                                      value={this.state.productSelect}
                                      onChange={(value) =>
                                        this.setState({ productSelect: value })
                                      }
                                      options={[
                                        { value: "2", label: "Foobar" },
                                        { value: "3", label: "Is great" },
                                      ]}
                                      placeholder=""
                                    />
                                  </Col>
                                </FormGroup>
                                <FormGroup>
                                  <ControlLabel className="col-md-3">
                                    Geography
                                  </ControlLabel>
                                  <Col md={8}>
                                    <Select
                                      className="react-select primary"
                                      classNamePrefix="react-select"
                                      name="geographySelect"
                                      value={this.state.geographySelect}
                                      onChange={(value) =>
                                        this.setState({
                                          geographySelect: value,
                                        })
                                      }
                                      options={[
                                        { value: "2", label: "Foobar" },
                                        { value: "3", label: "Is great" },
                                      ]}
                                      placeholder=""
                                    />
                                  </Col>
                                </FormGroup>
                                <FormGroup>
                                  <ControlLabel className="col-md-3">
                                    Date
                                  </ControlLabel>
                                  <Col md={4}>
                                    <Select
                                      className="react-select primary"
                                      classNamePrefix="react-select"
                                      name="dateformSelect"
                                      value={this.state.dateformSelect}
                                      onChange={(value) =>
                                        this.setState({ dateformSelect: value })
                                      }
                                      options={[
                                        { value: "2", label: "Foobar" },
                                        { value: "3", label: "Is great" },
                                      ]}
                                      placeholder="From"
                                    />
                                  </Col>
                                  <Col md={4}>
                                    <Select
                                      className="react-select primary"
                                      classNamePrefix="react-select"
                                      name="datetoSelect"
                                      value={this.state.datetoSelect}
                                      onChange={(value) =>
                                        this.setState({ datetoSelect: value })
                                      }
                                      options={[
                                        { value: "2", label: "Foobar" },
                                        { value: "3", label: "Is great" },
                                      ]}
                                      placeholder="To"
                                    />
                                  </Col>
                                </FormGroup>
                              </Form>
                            </NavDropdown>
                          </Nav>
                        </Col>
                      </div>
                    </Row>
                    {tableColumnList != null ? (
                      <Row>
                        <ReactTable
                          data={tableDataList}
                          columns={tableColumnList}
                          defaultSorted={defaultSortedList}
                          defaultFiltered={defaultFilteredList}
                          defaultPageSize={defaultPageSize}
                          nextText={<i className="fa fa-chevron-right" />}
                          previousText={<i className="fa fa-chevron-left" />}
                          showPaginationTop
                          getTdProps={this.getTdProps}
                          className="-striped -highlight"
                        />
                      </Row>
                    ) : null}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    leadcaptureList: state.leadcapture.leadcaptureList,
    ajaxCallsInProgress: state.ajaxStatusReducer.ajaxCallsInProgress,
  };
}

const mapDispatchToProps = (dispatch) => ({
  getLeadcaptureList: (id) => dispatch(getLeadcaptureList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(LeadCapture);
