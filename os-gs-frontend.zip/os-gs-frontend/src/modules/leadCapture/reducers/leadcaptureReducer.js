import * as leadcaptureActionTypes from "../actions/leadcaptureActionTypes";

const initialState = {
  leadcaptureList: null,
};

const leadcaptureReducer = (state = initialState, action) => {
  switch (action.type) {
    case leadcaptureActionTypes.GET_LEADCAPTURE_LIST:
      return {
        ...state,
        leadcaptureList: action.payload
      };
    default:
      return state;
  }
};

export default leadcaptureReducer;
