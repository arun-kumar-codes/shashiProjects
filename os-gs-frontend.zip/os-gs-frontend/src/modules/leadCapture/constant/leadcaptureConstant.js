export const LEADCAPTUREDETAILS_HEADER_TITLE = "Leads Capture";

export const BASE_URL = 'http://my-json-server.typicode.com';

export const GET_LEADCAPTURE_LIST_URL = BASE_URL + '/vermashankey/testing/post';


export const dataTable = [
];