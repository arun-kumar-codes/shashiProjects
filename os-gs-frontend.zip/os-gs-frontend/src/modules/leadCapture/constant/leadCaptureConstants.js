export const LEADCAPTUREDETAILS_HEADER_TITLE = "Leads Capture";

export const MANAGE_LEAD_CAPTURE_KEY = 'MANAGE-LEAD-CAPTURE';
export const MANAGE_PAGE_VISIT_KEY = 'MANAGE-PAGE-VISIT';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_LEADCAPTURE_LIST_URL = `${BASE_URL}/customercontacts`;
export const GET_PAGE_VISIT_LIST_URL = `${BASE_URL}/qrmetadata`;

export const dataTable = [];