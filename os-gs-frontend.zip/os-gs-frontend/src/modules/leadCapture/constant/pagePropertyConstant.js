import * as leadcaptureConstant from './leadCaptureConstants';
import React, { Component } from "react";

export const LEADCAPTURE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Email",
        id: "pk",
        accessor: "pk"
      },
      {
        Header: "Batch ID",
        id: "batch_id",
        accessor: "batch_id"
      },
      {
        Header: "Product",
        id: "product_code",
        accessor: "product_code",
        style: {
          flex: '0 0 25%'
        },
      },
      {
        Header: "Geography",
        id: "tenant_city",
        accessor: "tenant_city"
      },
      {
        Header: "Date",
        id: "capture_ts",
        accessor: "capture_ts"
      }
    ],
    defaultPageSize: 10,
    defaultSortedList: [
      {
        id: "capture_ts",
        desc: false
      }
    ],
    tableConfig: {
      rowId: 'pk',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: true,
    }
  }
};

export const PAGE_VISIT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Batch ID",
        id: "batch_id",
        accessor: "batch_id"
      },
      {
        Header: "Product",
        id: "product_code",
        accessor: "product_code",
        style: {
          flex: '0 0 25%'
        },
      },
      {
        Header: "Geography",
        id: "tenant_city",
        accessor: "tenant_city"
      },
      {
        Header: "Date",
        id: "scan_ts",
        accessor: "scan_ts"
      }
    ],
    defaultPageSize: 10,
    defaultSortedList: [
      {
        id: "scan_ts",
        desc: false
      }
    ],
    tableConfig: {
      rowId: 'pk',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: true,
    }
  }
};
