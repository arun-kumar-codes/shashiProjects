import axios from '../../../axios/axios';
import * as mappingActionTypes from './mappingActionTypes';
import * as mappingConstant from '../constant/mappingConstant';
import { beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse, failedApiResponse } from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: mappingActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setProductMapDetails(productDetailsObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.put(mappingConstant.SET_SIMILAR_PRODUCT_DETAILS_URL + productDetailsObj.productId,
       productDetailsObj).then(response => {
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}

export function getSimilarProductList(selectedProductCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(mappingConstant.GET_SIMILAR_PRODUCT_LIST + selectedProductCode).then(response => {
      if (response.status == 200) {
        dispatch({
          type: mappingActionTypes.GET_SIMILAR_PRODUCT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

