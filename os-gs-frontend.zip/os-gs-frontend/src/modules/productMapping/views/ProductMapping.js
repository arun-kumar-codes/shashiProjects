import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Tabs, Tab } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import * as mappingConstant from '../constant/mappingConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import { connect } from "react-redux";
import CommonUtil from '../../common/util/commonUtil';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import { getProductList } from "../../productManagement/actions/productActions";
import { getSimilarProductList, setProductMapDetails } from "../actions/mappingActions";
import { setActionMode } from "../../../actions/appActions";
import { getUserProfile } from "../../userManagement/actions/userActions";
import mapping from "assets/img/mapping-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import PopupUtil from '../../common/util/popupUtil';
import scrollToComponent from 'react-scroll-to-component';

class ProductMapping extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      status: null,
      key: 1,
      selectedTab: "PRODUCT_MAPPING",
      additionalParams: null,
      openModal: false,
      showDetailView: false,
      similarProductList: [],
      childProductList: [],
      selectedProductCode: null,
      selectedProductName: null,
      selectedSourceChannel: null,
      manualProductList: [],

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Product Mapping loaded");
    this.props.getUserProfile();
    const { selectedTab } = this.state;
    this.setSelectedTabDetails(selectedTab);
  }

  setSelectedTabDetails = async (selectedTab) => {
    let managePageList = pagePropertyListConstant[selectedTab.toUpperCase() + "_LIST"](this);
    let additionalParams = null;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      searchInput: null,
      selectedTab: selectedTab,
      showDetailView: false,
      similarProductList: [],
      childProductList: [],
      selectedProductCode: null,
      selectedProductName: null,
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this));
  }

  componentDidUpdate(prevProps) {
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      PaginationUtil.handlePagination(this.props.productList, this);
      this.setState({ productList: [...this.props.productList.Items] });
    }
    if (this.props.similarProductList != null && prevProps.similarProductList != this.props.similarProductList) {
      this.updateSimiliarProductList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      await this.setSelectedTabDetails(this.state.selectedTab);
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  updateSimiliarProductList = () => {
    this.setState({ similarProductList: this.props.similarProductList });
  }

  addChildProduct = async (productId) => {
    let { childProductList, similarProductList } = this.state;
    let tempProductObj = CommonUtil.getFilteredObjFromArray(similarProductList, 'productId', productId);
    similarProductList = CommonUtil.removeObjFromArray(similarProductList, 'productId', productId);
    childProductList.push({
      "productId": productId, "productName": tempProductObj.productName,
      "sourceChannel": tempProductObj.sourceChannel
    });
    await this.setState({ childProductList: [] });
    this.setState({ childProductList: childProductList, similarProductList: similarProductList });
  }

  removeChildProduct = async (productId) => {
    let { childProductList, similarProductList } = this.state;
    let tempChildProductList = [...childProductList];
    similarProductList.push(CommonUtil.getFilteredObjFromArray(tempChildProductList, 'productId', productId));
    childProductList = CommonUtil.removeObjFromArray(childProductList, 'productId', productId);
    await this.setState({ similarProductList: [] });
    this.setState({ childProductList: childProductList, similarProductList: similarProductList });
  }

  showChildProducts = async (productId) => {
    this.props.getSimilarProductList(productId);
    let childPageList = pagePropertyListConstant.CHILD_PRODUCT_LIST(this);
    let similarProductPageList = pagePropertyListConstant.SIMILAR_PRODUCT_LIST(this);
    let selectedProductObj = CommonUtil.getFilteredObjFromArray(JSON.parse(JSON.stringify(this.props.productList.Items)),
      'productId', productId);
    await this.setState({
      childTableColumnList: childPageList.tableColumnList,
      childTableConfig: childPageList.tableConfig,
      similarProductTableColumnList: similarProductPageList.tableColumnList,
      similarProductTableConfig: similarProductPageList.tableConfig,
      selectedProductCode: productId,
      similarProductList: [],
      selectedProductName: selectedProductObj.productName,
      selectedSourceChannel: selectedProductObj.sourceChannel,
      childProductList: selectedProductObj && selectedProductObj.childProductList ?
        selectedProductObj.childProductList : [],
      showDetailView: true
    });
    await scrollToComponent(this.details, { offset: 0, align: 'top', duration: 1500});
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.productList.Items.filter((value) => {
      return (
        String(value.productId).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  searchChildProductList = (event) => {
    let searchInput = event.target.value
    if (CommonUtil.isNotNull(searchInput)) {
      let { similarProductList } = this.state;
      let filteredData = this.props.productList.Items.filter((value) => {
        return (
          (String(value.productId).toLowerCase().includes(searchInput.toLowerCase()) ||
            value.productName.toLowerCase().includes(searchInput.toLowerCase())) &&
          value.sourceChannel != commonConstant.ORIGINSCALE &&
          similarProductList.filter((similarProduct) => similarProduct.productId != value.productId));
      });
      if (filteredData != null && filteredData.length > 0) {
        similarProductList = [...similarProductList, ...filteredData];
      }
      this.setState({ similarProductList: similarProductList });
    }
  }

  makeCustomAPICall(tempParamas) {
    this.props.getProductList(tempParamas);
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("#");
    if (CommonUtil.isMenuMode(tempId[2])) {
      CommonUtil.overlay(event);
    }
  }

  handleSave = (event) => {
    this.setState({ submitted: true });
    let tempObj = {};
    tempObj.productId = this.state.selectedProductCode;
    tempObj.childProductList = [...this.state.childProductList];
    if (tempObj.productId != null) {
      this.props.setProductMapDetails(tempObj);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, childProductList, manualProductList, selectedSourceChannel,
      childTableColumnList, childTableConfig, similarProductTableColumnList, similarProductTableConfig,
      selectedTab, showDetailView, similarProductList, selectedProductCode, selectedProductName } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={mapping} alt="" className="page-icon" />
                  {mappingConstant.MAPPING_DETAILS_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search By Code / Name"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </div>
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    <Tabs id="mapping-tabs" className="table-tabs-without-border">

                      <Tab eventKey={'Product_Mapping'} title="PRODUCT MAPPING">
                        {tableColumnList != null ?
                          <Row>
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                          </Row>
                          : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}

                        {showDetailView &&
                          <Row className="mapping-detail" ref={(section) => { this.details = section; }}>
                            <Col md={6}>
                              <div className="heading">{selectedProductCode} | {selectedProductName}</div>
                              <div className="subheading">Child Product List</div>
                              {childProductList != null && childProductList.length > 0 ?
                                <Table columns={childTableColumnList}
                                  data={childProductList}
                                  config={childTableConfig}
                                  getRowProps={this.getTdProps}
                                  that={this}
                                />
                                : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                            </Col>
                            <Col md={6}>
                              {selectedSourceChannel == commonConstant.ORIGINSCALE ?
                                <div className="search-section">
                                  <i className="fa fa-search" onClick={this.searchChildProductList}></i>
                                  <FormControl type="text" name="searchInput" placeholder="Search By Code / Name"
                                    value={this.state.childSearchInput} onClick={this.searchChildProductList} />
                                </div>
                                : null}
                              <div className="subheading">Similar Product List</div>
                              {(similarProductList != null && similarProductList.length > 0) ||
                                (manualProductList != null && manualProductList.length > 0) ?
                                <Table columns={similarProductTableColumnList}
                                  data={[...similarProductList, ...manualProductList]}
                                  config={similarProductTableConfig}
                                  getRowProps={this.getTdProps}
                                  that={this}
                                />
                                : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                            </Col>
                          </Row>
                        }
                      </Tab>
                    </Tabs>
                  </div>
                }
                ftTextRight
                legend={
                  <>
                    {selectedTab == "PRODUCT_MAPPING" ?
                      !CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel">Back</Button>
                      : null
                    }
                  </>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    productList: state.product.productList,
    similarProductList: state.mapping.similarProductList,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
  };
}

const mapDispatchToProps = dispatch => ({
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProductMapDetails: (productObj) => dispatch(setProductMapDetails(productObj)),
  getSimilarProductList: (id) => dispatch(getSimilarProductList(id)),
  getProductList: (id) => dispatch(getProductList(id)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProductMapping);
