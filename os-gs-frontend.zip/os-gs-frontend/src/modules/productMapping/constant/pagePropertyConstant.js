import React from "react";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import CommonUtil from '../../common/util/commonUtil';
import Button from "components/CustomButton/CustomButton.jsx";

export const PRODUCT_MAPPING_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product Code",
                id: "productId",
                accessor: "productId",
                style: {
                    cursor: 'grab'
                },
                style: {
                    flex: '0 0 120px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td label-black"
                            id={original.productId + "_" + index + "_" + original.productName}
                            onClick={() => that.showChildProducts(original.productId)}>
                            <span> {original.productId}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Product Detail",
                id: "productName",
                accessor: "productName",
                style: {
                    cursor: 'grab'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td label-black"
                            id={original.productId + "_" + index + "_" + original.productName}
                            onClick={() => that.showChildProducts(original.productId)}>
                            <span> {original.productName}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Category",
                id: "category",
                accessor: "category",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 150px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td label-black"
                            id={original.productId + "_" + index + "_" + original.productName}
                            onClick={() => that.showChildProducts(original.productId)}>
                            <span> {original.category}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Family",
                id: "family",
                accessor: "family",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 150px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td label-black"
                            id={original.productId + "_" + index + "_" + original.productName}
                            onClick={() => that.showChildProducts(original.productId)}>
                            <span> {original.family}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Product Origin",
                id: "sourceChannel",
                accessor: "sourceChannel",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 150px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let productOrigin = original.sourceChannel ? original.sourceChannel : null;
                    return (
                        <div className="full-td label-black"
                            id={original.productId + "_" + index + "_" + original.productName}
                            onClick={() => that.showChildProducts(original.productId)}>
                            <span> {productOrigin}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Product Mapped",
                id: "productmapped",
                accessor: "productmapped",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 120px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let childProductList = original.childProductList ? original.childProductList.length : 0;
                    return (
                        <div className="full-td label-black"
                            id={original.productId + "_" + index + "_" + original.productName}
                            onClick={() => that.showChildProducts(original.productId)}>
                            <span> {childProductList}</span>
                        </div>
                    )
                }
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const CHILD_PRODUCT_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product Code",
                id: "productId",
                accessor: "productId",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 100px'
                },
            },
            {
                Header: "Product Name",
                id: "productName",
                accessor: "productName",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let productName = original.productName ? original.productName : null;
                    return (
                        <div className="full-td label-black">
                            <span> {productName}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Product Origin",
                id: "productOrigin",
                accessor: "productOrigin",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 120px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let productOrigin = original.sourceChannel ? original.sourceChannel : null;
                    return (
                        <div className="full-td label-black">
                            <span> {productOrigin}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 50px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (

                        <div className="actions-left">
                            <Button bsStyle="default" simple icon
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle">
                                    <i title="delete" id={original.productId + "_" + index}
                                        className="fa fa-trash" onClick={() => that.removeChildProduct(original.productId)} />
                                </div>
                            </Button>
                        </div>

                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 20,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            isDraggable: false,
        }
    }
};

export const SIMILAR_PRODUCT_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product Code",
                id: "productId",
                accessor: "productId",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 100px'
                },
            },
            {
                Header: "Product Name",
                id: "productName",
                accessor: "productName",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let productName = original.productName ? original.productName : null;
                    return (
                        <div className="full-td label-black">
                            <span> {productName}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Product Origin",
                id: "productOrigin",
                accessor: "productOrigin",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 120px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let productOrigin = original.sourceChannel ? original.sourceChannel : null;
                    return (
                        <div className="full-td label-black">
                            <span> {productOrigin}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 50px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle">
                                    <i title="add" id={original.productId + "_" + index}
                                        className="fa fa-plus" onClick={() => that.addChildProduct(original.productId)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 20,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            isDraggable: false,
        }
    }
};

