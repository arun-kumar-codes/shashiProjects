export const MAPPING_DETAILS_HEADER_TITLE = "Mapping";
export const MODULE_NAME = "Product Mapping";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_SIMILAR_PRODUCT_LIST = BASE_URL + '/products/similarProducts/';
export const SET_SIMILAR_PRODUCT_DETAILS_URL = BASE_URL + '/products/mapProducts/';

