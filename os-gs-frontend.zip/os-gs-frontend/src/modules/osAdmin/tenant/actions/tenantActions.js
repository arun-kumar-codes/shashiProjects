import axios from "../../../../axios/axios";
import * as tenantActionTypes from "./tenantActionTypes";
import * as tenantConstant from "../constant/tenantConstant";
import {
    beginAjaxCall, endAjaxCall, updateApiResponse, setAjaxCallStatus,
    failedApiResponse
} from "../../../../actions/ajaxStatusActions";

export function setReducerInitMode() {
    return function (dispatch) {
        dispatch({
            type: tenantActionTypes.SET_REDUCER_INIT_MODE,
            payload: null,
        });
    };
}

export function getTenantList(params) {
    return function (dispatch) {
        dispatch(beginAjaxCall());
        axios.get(tenantConstant.GET_TENANT_LIST_URL, { params: params }).then((response) => {
            if (response.status == 200) {
                dispatch({
                    type: tenantActionTypes.GET_TENANT_LIST,
                    payload: response.data,
                });
            }
            dispatch(endAjaxCall());
        }).catch((error) => {
            dispatch(endAjaxCall());
            throw error;
        });
    };
}

export function updateTenantDetails(tenantDetailsObj) {
    return function (dispatch) {
        dispatch(beginAjaxCall());
        axios.put(tenantConstant.UPDATE_TENANT_DATA_URL, tenantDetailsObj).then(response => {
            dispatch(setAjaxCallStatus(updateApiResponse(response)));
            if (response.status == 200) {
                dispatch({
                    type: tenantActionTypes.TENANT_DETAIL,
                    payload: response.data,
                });
            }
            dispatch(endAjaxCall());
        }).catch(error => {
            dispatch(endAjaxCall());
            dispatch(setAjaxCallStatus(failedApiResponse(error)));
            throw error;
        });
    };
}

