import React from "react";
import StatusUtil from '../../../common/util/statusUtil';
import * as statusConstant from '../../../common/constant/statusConstant';

export const UPDATE_TENANT_PAGE_LIST = {
  attributeObj: {
    tenantId: "",
    moduleCode: '',
    action: '',
  },
  attributeList: [
    {
      name: "tenantId",
      type: "TEXTBOX",
      label: "Tenant Id",
      required: true,
      fieldWidth: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      maxLength: 32,
      minLength: 3,
    },
    {
      name: "moduleCode",
      label: "Module Code",
      type: "DROPDOWN",
      required: true,
      fieldWidth: 4,
      isMulti: false,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "Select ModuleCode",
      mandatoryMsgText: "Field can not be empty.",
      options: [
        { value: 'product', label: 'Product' },
        { value: 'ingredient', label: 'Ingredient' },
        { value: 'facility', label: 'Facility' },
        { value: 'supplier', label: 'Supplier' },
        { value: 'customer', label: 'Customer' },
        { value: 'so', label: 'Sales' },
        { value: 'mfg', label: 'Make' },
        { value: 'po', label: 'Procure' },
        { value: 'sto', label: 'Stock Transfer' },
        { value: 'kit', label: 'Bundle' },
      ]
    },
    {
      name: "action",
      label: "Action",
      type: "DROPDOWN",
      required: true,
      fieldWidth: 4,
      customAttribute: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "Select Action",
      mandatoryMsgText: "Field can not be empty.",
      options: [
        { value: 'ADD', label: 'Add' },
        { value: 'REMOVE', label: 'Remove' },
        { value: 'COPY', label: 'Copy' },
        { value: 'UPDATE', label: 'Update' },
      ]
    },
    {
      name: "status",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      name: "version",
      type: "TEMP",
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
  ]
};

export const UPDATE_TENANT_ADD_ACTION_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      attributeName: '',
      value: '',
    },
    attributeList: [
      {
        name: "attributeName",
        type: "TEXTBOX",
        label: "Attribute Name",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 30,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "value",
        type: "TEXTBOX",
        label: "Attribute Value",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 50,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },

    ]
  };
};

export const UPDATE_TENANT_COPY_ACTION_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      attributeName: '',
      copyFrom: '',
    },
    attributeList: [
      {
        name: "copyFrom",
        type: "TEXTBOX",
        label: "Copy From",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 30,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "attributeName",
        type: "TEXTBOX",
        label: "Attribute Name",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 30,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      }
    ]
  };
};

export const UPDATE_TENANT_REMOVE_ACTION_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      attributeName: '',
    },
    attributeList: [
      {
        name: "attributeName",
        type: "TEXTBOX",
        label: "Attribute Name",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 30,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },
    ]
  };
};

export const UPDATE_TENANT_UPDATE_ACTION_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      attributeName: '',
      value: '',
    },
    attributeList: [
      {
        name: "attributeName",
        type: "TEXTBOX",
        label: "Attribute Name",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 30,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "value",
        type: "TEXTBOX",
        label: "Attribute Value",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 50,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },

    ]
  };
};


export const MANAGE_TENANT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Company Name",
        id: "companyName",
        accessor: "companyName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>
              {original.companyName}
            </>
          )
        }
      },
      {
        Header: "Tenant Id",
        id: "tenantid",
        accessor: "tenantid",
      },
      {
        Header: "User Name",
        id: "firstName",
        accessor: "firstName",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>
              {original.firstName} {original.lastName}
            </>
          )
        }
      },
      {
        Header: "Email",
        id: "email",
        accessor: "email",
      },
      {
        Header: "Contact Number",
        id: "phoneNumber",
        accessor: "phoneNumber",
        style: {
          flex: '0 0 150px'
        },
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: '0 0 130px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value)
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      }

    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_HEADER_STATUS_LIST = [
  {
    statusKey: statusConstant.ALL_STATUS
  },
  {
    statusKey: statusConstant.INACTIVE_STATUS
  },
  {
    statusKey: statusConstant.CONFIRMED_STATUS
  },
  {
    statusKey: statusConstant.UNCONFIRMED_STATUS
  }
]

