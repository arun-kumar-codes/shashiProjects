export const TENANT_DETAILS_HEADER_TITLE = "Create Tenant";
export const MANAGE_TENANT_HEADER_TITLE = "Manage Tenant";

export const CREATE_TENANT = "createTenant";
export const MODULE_NAME = "tenant";
export const MANAGE_TENANT_PAGE_URL = '/admin/manage-tenant';
export const UPDATE_TENANT_PAGE_URL = "/admin/update-tenant";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_TENANT_LIST_URL = `${BASE_URL}/osadmin/tenants`;
export const UPDATE_TENANT_DATA_URL = `${BASE_URL}/prodsupport/updatedata`;

