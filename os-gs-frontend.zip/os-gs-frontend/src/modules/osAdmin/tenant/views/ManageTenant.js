import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import Table from '../../../../views/Tables/PopularTable/Table/Table';
import { connect } from "react-redux";
import { setActionMode } from "../../../../actions/appActions";
import { getTenantList } from "../actions/tenantActions";
import { setAjaxCallStatus } from '../../../../actions/ajaxStatusActions';
import PopupUtil from "../../../common/util/popupUtil";
import filter from 'assets/img/filter.svg';
import PaginationUtil from '../../../common/util/paginationUtil';
import StatusUtil from '../../../common/util/statusUtil'
import tenants from "assets/img/Users-page-icon.svg";
import mixpanel from "../../../analytics/mixpanel/mixpael";

class ManageTenant extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      selectedFilter: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      status: null,

      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Manage Tenants loaded");
    const managePageList = pagePropertyListConstant.MANAGE_TENANT_PAGE_LIST(this);
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (prevProps.tenantList != this.props.tenantList && this.props.tenantList != null) {
      PaginationUtil.handlePagination(this.props.tenantList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.tenantList.Items.filter((value) => {
      return (
        value.companyName.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.tenantid.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  };

  handleFIlter = (event) => {
    let filteredData = this.props.tenantList.Items.filter(value => {
      if (event !== '') {
        return (
          value.status && value.status.toLowerCase() == event.toLowerCase()
        );
      }
      return (value);
    });
    this.setState({ tableDataList: filteredData, selectedFilter: event });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      PopupUtil.popupErrorResponse(this);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  makeCustomAPICall(tempParamas) {
    this.props.getTenantList(tempParamas);
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter } = this.state;

    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect>
          : null}

        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={tenants} alt="" className="page-icon" />
                  Tenant
                </div>
              </Col>

              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl
                      type="text"
                      name="searchInput"
                      placeholder="Search by Name/Email"
                      value={this.state.searchInput}
                      onChange={this.handleChange}
                    />
                  </div>

                  <Nav pullRight>
                    <NavDropdown title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                      {pagePropertyListConstant.MANAGE_HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                        <MenuItem key={index} eventKey={tempAttributeListObj.statusKey} className={selectedFilter === tempAttributeListObj.statusKey ? "active" : null}>
                          {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                        </MenuItem>
                      ))}

                    </NavDropdown>
                  </Nav>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>

                    {tableColumnList != null ? (
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                    ) : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    tenantList: state.tenant.tenantList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getTenantList: (id) => dispatch(getTenantList(id))
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageTenant);
