import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { getTenantList, updateTenantDetails } from "../actions/tenantActions";
import { setAjaxCallStatus } from '../../../../actions/ajaxStatusActions';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as tenantConstant from '../constant/tenantConstant';
import ValidationUtil from '../../../common/util/validationUtil';
import CommonUtil from '../../../common/util/commonUtil';
import PopupUtil from '../../../common/util/popupUtil';
import TextBoxUtil from '../../../common/util/textBoxUtil';
import DropDownUtil from '../../../common/util/dropDownUtil';
import users from "assets/img/Users-page-icon.svg";
import mixpanel from "../../../analytics/mixpanel/mixpael";
import * as commonConstant from '../../../common/constant/commonConstant';
import isAuthorized from "auth-plugin";

class UpdateTenant extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
    };

    this.handleSave = this.handleSave.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Update Tenant loaded");
    this.props.getTenantList();
    this.setState({
      attributeList: pagePropertyListConstant.UPDATE_TENANT_PAGE_LIST.attributeList,
      attributeObj: pagePropertyListConstant.UPDATE_TENANT_PAGE_LIST.attributeObj,
    })
  }

  componentDidUpdate(prevProps, prevState) {
    // if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
    //   this.handleAjaxResponse();
    // }
    if (this.props.tenantDetail != null && prevProps.tenantDetail != this.props.tenantDetail) {
      this.handleAjaxResponse();
    }
  }

  handleCustomDropDownChange = async (event, obj) => {
    if (obj.name == 'action') {
      await CommonUtil.handleDropDownChange(event, obj, this);
      this.handlePageViewByAction(event.value);
    }
  }
  handlePageViewByAction = async (action) => {
    let attributeListBottom = [];
    if (action == "ADD") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.UPDATE_TENANT_ADD_ACTION_PAGE_LIST(this)));
    } else if (action == "COPY") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.UPDATE_TENANT_COPY_ACTION_PAGE_LIST(this)));
    } else if (action == "REMOVE") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.UPDATE_TENANT_REMOVE_ACTION_PAGE_LIST(this)));
    } else if (action == "UPDATE") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.UPDATE_TENANT_UPDATE_ACTION_PAGE_LIST(this)));
    }
    let { attributeObj } = this.state;
    attributeObj.attributeName = '';
    attributeObj.value = '';
    attributeObj.copyFrom = '';
    await this.setState({
      attributeObj: attributeObj,
      attributeObjBottom: attributeListBottom.attributeObj,
      attributeListBottom: CommonUtil.getDropDownOptionsFromDictionary(
        attributeListBottom.attributeList, this.props.dataDictionaryList),
    });
  };

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
    this.setState({ attributeList: null })
  }

  handleSave = (event) => {
    this.setState({ submitted: true });
    let tempObj = JSON.parse(JSON.stringify(this.state.attributeObj));
    if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeListBottom)) {
        tempObj = this.buildAttributeListByAction(tempObj);
        this.props.updateTenantDetails(tempObj);
      }
    }
  }

  buildAttributeListByAction = (attributeObj) => {
    attributeObj.attributeList = [];
    if (attributeObj.action == "ADD") {
      attributeObj.attributeList.push({ "attributeName": attributeObj.attributeName, value: attributeObj.value });
      delete attributeObj.attributeName;
      delete attributeObj.value;
    } else if (attributeObj.action == "REMOVE") {
      attributeObj.attributeList.push({ "attributeName": attributeObj.attributeName });
      delete attributeObj.attributeName;
    } else if (attributeObj.action == "COPY") {
      attributeObj.attributeList.push({ "attributeName": attributeObj.attributeName, copyFrom: attributeObj.copyFrom });
      delete attributeObj.attributeName;
      delete attributeObj.copyFrom;
    } else if (attributeObj.action == "UPDATE") {
      attributeObj.attributeList.push({ "attributeName": attributeObj.attributeName, value: attributeObj.value });
      delete attributeObj.attributeName;
      delete attributeObj.value;
    }
    return attributeObj;
  }

  async handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareTenentUpdateSuccessPopUpConfig(this.props.tenantDetail.updateCount, this.props.tenantDetail.totalCount));
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      PopupUtil.popupErrorResponse(this);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    CommonUtil.handlePageRedirection(tenantConstant.UPDATE_TENANT_PAGE_URL, this);
  }

  render() {
    const { attributeList, attributeObj, submitted, attributeListBottom, attributeObjBottom } = this.state;
    const actionMode = commonConstant.CREATE_ACTION_MODE;
    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={users} alt="" className="page-icon" />
                  Update Tenant Details
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      {isAuthorized("updateTenant") &&
                        <>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : null))
                            }
                          </Row>
                          <Row>
                            {attributeListBottom != null && attributeListBottom.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : null))
                            }
                          </Row>
                        </>
                      }
                    </div>
                  }
                  ftTextRight
                  legend={
                    <div>
                      {isAuthorized("updateTenant") &&
                        <>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>
                            Cancel
                          </Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>
                            Save
                          </Button>
                        </>
                      }
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.user.userDetails,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    tenantDetail: state.tenant.tenantDetail,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  updateTenantDetails: (tenantDetailsObj) => dispatch(updateTenantDetails(tenantDetailsObj)),
  getTenantList: selectedUserCode => dispatch(getTenantList(selectedUserCode)),
});
export default connect(mapStateToProps, mapDispatchToProps)(UpdateTenant);