import React from 'react';
import { useBarcode } from '@createnextapp/react-barcode';

function DownloadBarCode({value, utiNumber}) {
    const barcodeId = `generatedBarcode${value}${utiNumber}`;
  const { inputRef } = useBarcode({
    value: value,
    options: {
      displayValue: true,
      background: 'white',
      text: `${value}|${utiNumber}`
    }
  });

  return (
    <div className="hidden" >
      <div id={barcodeId} className="design"><svg ref={inputRef} alt="" /></div>
    </div>)

};

export default DownloadBarCode;