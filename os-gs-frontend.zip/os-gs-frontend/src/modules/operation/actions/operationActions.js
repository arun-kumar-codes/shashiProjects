import axios from '../../../axios/axios';
import * as operationActionTypes from './operationActionTypes';
import * as operationConstant from '../constant/operationConstant';
import * as actionTypes from '../../../actions/actionTypes';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";

export function setOperationActionMode(operationActionMode) {
  return function (dispatch) {
    dispatch({
      type: operationActionTypes.SET_OPERATION_ACTION_MODE,
      payload: operationActionMode
    });
  }
}

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: operationActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setSelectedOperationCode(operationId) {
  return function (dispatch) {
    dispatch({
      type: operationActionTypes.SET_SELECTED_OPERATION_CODE,
      payload: operationId
    });
  }
}

export function setOperationDetails(operationDetailsObj, actionMode) {

  if (actionMode === operationConstant.CREATE_ACTION_MODE || actionMode === operationConstant.CLONE_ACTION_MODE) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(operationConstant.SET_CREATE_OPERATION_DETAILS_URL, operationDetailsObj).then(response => {
        dispatch(setAjaxCallStatus(createApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
    };
  }
  if (actionMode === operationConstant.EDIT_ACTION_MODE) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(operationConstant.SET_UPDATE_OPERATION_DETAILS_URL + "OPT-0001", operationDetailsObj).then(response => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
    };
  }
}

export function getOperationList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(operationConstant.GET_OPERATION_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: operationActionTypes.GET_OPERATION_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getOperationDetails(operationId) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(operationConstant.GET_OPERATION_DETAILS_URL + (operationId ? "?status=" + String(operationId) : "")).then(response => {
      if (response.status == 200) {
        dispatch({
          type: operationActionTypes.GET_OPERATION_DETAILS,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function updateOperationStatus(operationDetailsObj, additionalData) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(operationConstant.SET_UPDATE_OPERATION_STATUS_URL + "OPT-0001", operationDetailsObj).then(response => {
      dispatch(setAjaxCallStatus(updateApiResponse(response, additionalData)));
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  }
}

export function setBulkOperation(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(operationConstant.SET_CREATE_BULK_OPERATION_URL, params).then(response => {
      if (response.status == 200) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch({
          type: actionTypes.SET_UPLOAD_IMPORT_FILE_STATUS,
          payload: response.data.uploadDetails
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
      throw error;
    });
  };
}



