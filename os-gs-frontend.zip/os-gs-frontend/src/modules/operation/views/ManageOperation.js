import React, { Component } from "react";
import { Row, Col, Nav, NavDropdown, MenuItem } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import * as commonConstant from '../../common/constant/commonConstant';
import { setOperationDetails, getOperationDetails, setReducerInitMode, updateOperationStatus } from "../actions/operationActions";
import { getOperationList } from "../actions/operationActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as operationConstant from '../constant/operationConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import PopularTableUtil from '../../common/util/popularTableUtil.js';
import _ from 'lodash'
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";
import filter from 'assets/img/filter.svg';
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import isAuthorized from "auth-plugin";

class CreateOperation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            attributeList: null,
            attributeObj: null,
            submitted: false,
            deleteOpetaion: false,
            alert: null,
            operations: [],
            deletedOperations: [],
            selectedTab: "OPERATIONS",
            operationTableKey: "operations",
            selectedTabKey: "OPERATIONS",
        };
        this.handleSave = this.handleSave.bind(this);
        this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
        this.handlePopupCancel = this.handlePopupCancel.bind(this);
        this.handleDeleteAction = this.handleDeleteAction.bind(this);
    }

    componentDidMount = () => {
        mixpanel.track("Manage Operation loaded");
        if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
            this.props.getDataDictionaryDetails();
        }
        this.props.getOperationDetails();
        this.setSelectedTableDetails(this.state.selectedTab);
    }

    handleTableTextBoxChange = (event) => {
        PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    }

    handleTableDropDownChange = (event, obj) => {
        PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    }

    handleDeleteRowPopup = async (event) => {
        await this.setState({ eventId: event.target.id, deleteOpetaion: true });
        let popupActionButton = {};
        popupActionButton.onConfirmClick = this.handleTableRemove;
        popupActionButton.onCancelClick = this.handlePopupCancel;
        let popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handleTableRemove = async (event) => {
        this.setState({ alert: null });
        let tempevent = event ? event : this.state.eventId;
        let tempObj = {};
        tempObj.operationId = tempevent.split('_')[2];
        let additionalData = {};
        additionalData.deletedFlag = true;
        additionalData.module = "OPERATION";
        this.props.updateOperationStatus(tempObj, additionalData);
    }

    handleTableAddRow = (event) => {
        var tempAttributeDataList = [...this.state["operations"]];
        var tempObj = {};
        tempObj.operationId = "";
        tempObj.isNewRowAdded = true;
        tempAttributeDataList.push({ ...tempObj });
        this.setState({ "operations": tempAttributeDataList })
    }

    handlePopupContinue = () => {
        CommonUtil.handlePageRedirection(operationConstant.DASHBOARD_PAGE_URL, this);
    }

    getSelectedTablekey = () => {
        return this.state.operationTableKey;
    }

    handleDeleteAction = (event) => {
        var popupActionButton = {};
        popupActionButton.onConfirmClick = this.handleTableRemove(event);
        var popupConfig = CommonUtil.prepareDeactivatePopUpConfig(popupActionButton, operationConstant.MODULE_NAME);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handleTabClick = (label, event) => {
        var selectedTabKey = label.toUpperCase();
        this.setState({
            selectedTab: label.toUpperCase(),
            operationTableKey: label,
        }, function () {
            this.setSelectedTableDetails(selectedTabKey);
            this.props.getOperationDetails(selectedTabKey);
        })
    }

    setSelectedTableDetails = (selectedTab) => {
        const tableAttributeList = pagePropertyListConstant["CREATE_OPERATION_" +
            selectedTab.toUpperCase() + "_TABLE_LIST"](this);
        this.setState({
            tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
                tableAttributeList.attributeList, this.props.dataDictionaryList),
            tableColumnList: tableAttributeList.tableColumnList,
            tableConfig: tableAttributeList.tableConfig,
        })
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
            this.updateApiData(this.props.attributeObj);
        }

        if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
            this.handleAjaxResponse();
        }
    }

    updateApiData(attributeObj) {
        this.setState({
            attributeObj: {
                ...attributeObj,
            },
            operations: this.state.operationTableKey === "operations" ? [...attributeObj] : [],
            deletedOperations: this.state.operationTableKey === "deletedOperations" ? [...attributeObj] : [],
        })
    }

    componentWillUnmount() {
        this.props.setReducerInitMode(null);
    }

    handleSave(value) {
        this.setState({ submitted: true, alert: null });
        var tempObj = {};
        var actionMode = commonConstant.EDIT_ACTION_MODE;
        tempObj.operations = this.state.operations;
        tempObj.operations = ValidationUtil.removeAttributeFromArrayList(tempObj.operations,
            pagePropertyListConstant.CREATE_OPERATION_OPERATIONS_TABLE_LIST(this).tableColumnList,
            commonConstant.EDIT_ACTION_MODE);
        if (this.isValidRequestObj(tempObj)) {
            this.props.setOperationDetails(tempObj, actionMode);
        }
    }

    isValidRequestObj = (tempObj) => {
        if (tempObj.operations.length > 0) {
            if (!ValidationUtil.validateArrayListRequestObj(tempObj.operations,
                pagePropertyListConstant.CREATE_OPERATION_OPERATIONS_TABLE_LIST(this).tableColumnList)) {
                return false;
            }
        }
        return true;
    }

    isDuplicateValue = (value) => {
        let filteredList = [];
        if (CommonUtil.isNotNull(this.state.operations) && this.state.operations.length > 0) {
            filteredList = this.state.operations.filter(function (tempObj) {
                if (CommonUtil.isNotNull(tempObj["operationName"]) && CommonUtil.isNotNull(value)) {
                    return tempObj["operationName"].toLowerCase() == value.toLowerCase();
                }
            });
        }
        if (filteredList.length > 1) {
            return true;
        }
        return false;
    }
    handleDuplicateErrorPopup = function () {
        let popupActionButton = {};
        popupActionButton.onCancelClick = this.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, operationConstant.DUPLICATE_ERROR);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handleDeleteErrorPopup = function () {
        let popupActionButton = {};
        popupActionButton.onCancelClick = this.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, operationConstant.DELETE_ERROR);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handleValidationErrorPopup = function (err) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = this.handlePopupCancel;
        let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, err);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handleAjaxResponse = async () => {
        if (this.props.ajaxCallStatus.status == "SUCCESS") {
            this.props.setAjaxCallStatus(null);
            this.props.getOperationDetails();
            this.props.handleClick(CommonUtil.prepareDeleteSuccessPopUpConfig());
        }
        if (this.props.ajaxCallStatus.status == "FAILED") {
            let errorMessage = this.props.ajaxCallStatus.data &&
                this.props.ajaxCallStatus.data.response &&
                this.props.ajaxCallStatus.data.response.data;
            if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "409") {
                this.handleDuplicateErrorPopup();
            } else if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "405") {
                this.props.getOperationDetails();
                this.handleDeleteErrorPopup();
            } else if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "403") {
                this.handleValidationErrorPopup(errorMessage);
            } else {
                PopupUtil.popupErrorResponse(this);
            }
            await this.props.setAjaxCallStatus(null);
        }
    }

    handlePopupCancel() {
        this.setState({ alert: null, deleteOpetaion: false });
    }

    handleSelect = (key) => {
        this.setState({ key });
    };

    render() {
        const { tableColumnList, tableConfig, operationTableKey } = this.state;
        const actionMode = this.props.actionMode;
        const tableDataList = this.state[this.getSelectedTablekey()];

        return (
            <Row>
                {this.state.redirect === true ?
                    <Redirect push to={this.state.redirectUrl}></Redirect> : null
                }
                {this.state.alert}
                <Col md={12}>
                    <div className="header-section operation-filter">
                        <Nav pullRight>
                            <NavDropdown
                                title={<div className="filter"> <img src={filter} alt="" />  </div>}
                                noCaret id="status-filter" className="filter-status"
                                onSelect={this.handleTabClick}>
                                <MenuItem eventKey={"operations"}
                                    className={CommonUtil.isBothEqual(operationTableKey, "operations") ? 'active' : null}>
                                    {StatusUtil.getStatusLabel(statusConstant.ACTIVE_STATUS)}
                                </MenuItem>
                                <MenuItem eventKey={"deletedOperations"}
                                    className={CommonUtil.isBothEqual(operationTableKey, "deletedOperations") ? 'active' : null}>
                                    {StatusUtil.getStatusLabel(statusConstant.DELETE_STATUS)}
                                </MenuItem>
                            </NavDropdown>
                        </Nav>
                    </div>
                </Col>

                <Col md={12}>
                    <Card
                        content={
                            <Row>
                                {tableColumnList != null && tableColumnList.length > 0 ?
                                    <div>
                                        <Table columns={tableColumnList}
                                            data={tableDataList}
                                            config={tableConfig}
                                            getRowProps={this.getTdProps}
                                            that={this}
                                        />
                                        {isAuthorized("updateOperations") && operationTableKey != "deletedOperations" ?
                                            <div className="add-new-section">
                                                <Col md={12}>
                                                    <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                                        <i className=" fa fa-plus" />
                                                        Add Row
                                                    </div>
                                                </Col>
                                            </div>
                                            : null}
                                    </div>
                                    : <Col md={12}><div className="no-record">No Record Found</div></Col>
                                }
                            </Row>
                        }
                        ftTextRight
                        legend={
                            <div>
                                {isAuthorized("updateOperations") && operationTableKey != "deletedOperations" ?
                                    <Button className="btn-save btn-fill" onClick={this.handleSave}>
                                        Save
                                    </Button>
                                    : null}
                            </div>
                        }
                    />
                </Col>
            </Row>
        );
    }
}

function mapStateToProps(state, ownProps) {
    return {
        attributeObj: state.operation.operationDetails,
        actionMode: state.app.actionMode,
        ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
        dataDictionaryList: state.dataDictionary.dataDictionaryList,
        currencyCode: state.dataDictionary.currencyCode,
        operationList: state.operation.operationList
    };
}

const mapDispatchToProps = dispatch => ({
    setOperationDetails: (operationDetailsObj, actionMode) => dispatch(setOperationDetails(operationDetailsObj, actionMode)),
    getOperationDetails: operationId => dispatch(getOperationDetails(operationId)),
    setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
    setReducerInitMode: init => dispatch(setReducerInitMode(init)),
    getOperationList: () => dispatch(getOperationList()),
    updateOperationStatus: (operationDetailsObj, additionalData) => dispatch(updateOperationStatus(operationDetailsObj, additionalData)),
    getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateOperation);
