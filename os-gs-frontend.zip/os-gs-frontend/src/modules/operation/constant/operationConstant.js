export const OPERATION_DETAILS_HEADER_TITLE = "Create Operation";
export const OPERATION_DETAILS_HEADER_TITLE_EDIT = "Edit Operation";
export const MANAGE_OPERATION_PAGENAME = "Operations";
export const MODULE_NAME = "operation";

export const VIEW_ACTION_MODE = "viewMode";
export const CREATE_ACTION_MODE = "createMode";
export const MENU_ACTION_MODE = "menuMode";
export const CLONE_ACTION_MODE = "cloneMode";
export const EDIT_ACTION_MODE = "editMode";
export const DELETE_ACTION_MODE = "deleteMode";

export const CREATE_OPERATION = "createOperation";
export const DEATIVATE_OPERATION = "deactivateOperation";
export const DELETE_OPERATION = "deleteOperation";
export const ACTIVATE_OPERATION = "activateOperation";
export const DUPLICATE_ERROR = "Process name can not be duplicated.";
export const DELETE_ERROR = "Selected operation can not be deleted as it is used in any of the product. However, you can still modify it.";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_OPERATION_LIST_URL = `${BASE_URL}/operations`;
export const SET_UPDATE_OPERATION_STATUS_URL = `${BASE_URL}/operations/`;
export const SET_UPDATE_OPERATION_DETAILS_URL = `${BASE_URL}/operations/`;
export const GET_OPERATION_DETAILS_URL = `${BASE_URL}/operations/`;
export const SET_CREATE_OPERATION_DETAILS_URL = `${BASE_URL}/operations`;
export const SET_CREATE_BULK_OPERATION_URL = `${BASE_URL}/operationsbulkupload`;

export const MANAGE_OPERATION_PAGE_URL = '/admin/manage-operation';
export const CREATE_OPERATION_PAGE_URL = '/admin/create-operation';
export const DASHBOARD_PAGE_URL = '/admin/dashboard';
export const OPERATION_TABLE_NAME = 'OPERATIONS';
export const DELETEDOPERATION_TABLE_NAME = 'DELETEDOPERATIONS';
