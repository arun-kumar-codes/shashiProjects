import React from "react";
import Button from "components/CustomButton/CustomButton.jsx";
import * as commonConstant from '../../common/constant/commonConstant';
import { FormControl, InputGroup } from "react-bootstrap";
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import isAuthorized from "auth-plugin";

export const CREATE_OPERATION_OPERATIONS_TABLE_LIST = (that) => {
    return {
        tableData: [{
            operationId: '',
            operationName: '',
            duration: '',
            cost: '',
            action: '',
            operationId: ''

        }],
        tableColumnList: [
            {
                Header: "Process Name",
                id: "operationName",
                name: "operationName",
                accessor: "operationName",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                required: true,
                type: "text",
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let isDuplicateFlag = that.isDuplicateValue(value);
                    return (
                        <InputGroup
                            className={(that.state.submitted && isDuplicateFlag && original.isNewRowAdded) || (that.state.submitted && !original.operationName && original.isNewRowAdded)
                                ? 'required-error' : ''}>
                            <FormControl id={'operationName' + '_' + index} name={'operationName'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : false}
                                value={original.operationName} />
                        </InputGroup>

                    )
                }
            },
            {
                Header: "Duration (Hours)",
                id: "duration",
                name: "duration",
                accessor: "duration",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                type: "text",
                inputType: "number",
                required: false,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && !original.duration &&
                            original.operationName && original.duration < 0 ? 'required-error' : ''}>
                            <FormControl id={'duration' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'duration'}
                                onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : false}
                                value={value} />
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Cost",
                id: "cost",
                name: "cost",
                accessor: "cost",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                type: "text",
                inputType: "number",
                required: false,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && !original.cost &&
                            original.operationName && original.cost < 0 ? 'required-error' : ''}>
                            <FormControl id={'cost' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'cost'}
                                onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : false}
                                value={value} />
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
                id: "status",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(statusConstant.ACTIVE_STATUS)
                        }}>
                            {StatusUtil.getStatusLabel(statusConstant.ACTIVE_STATUS)}
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                className: "action justify-content-center",
                style: {
                    flex: '0 0 60px'
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                           {isAuthorized("updateOperations") && <Button bsStyle="default" simple icon >
                                <div className="circle"><i title="remove"
                                    id={commonConstant.EDIT_ACTION_MODE + "_" + index + '_' + original.operationId}
                                    className="fa fa-trash" onClick={(e) => that.handleDeleteRowPopup(e)} />
                                </div>
                            </Button>}
                        </div>
                    )
                }
            },
            {
                id: "operationId",
                name: "operationId",
                type: "TEMP",
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 100,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};
export const CREATE_OPERATION_DELETEDOPERATIONS_TABLE_LIST = (that) => {
    return {
        tableData: [{
            operationId: '',
            operationName: '',
            duration: '',
            cost: '',
            action: '',
            operationId: ''

        }],
        tableColumnList: [
            {
                Header: "Process",
                id: "operationName",
                name: "operationName",
                accessor: "operationName",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                required: true,
                type: "text",
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let isDuplicateFlag = that.isDuplicateValue(value);
                    return (
                        <InputGroup
                            className={that.state.submitted && isDuplicateFlag && original.isNewRowAdded
                                ? 'required-error' : ''}>
                            <FormControl id={'operationName' + '_' + index} name={'operationName'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={true}
                                value={original.operationName} />
                        </InputGroup>

                    )
                }
            },
            {
                Header: "Duration (Hours)",
                id: "duration",
                name: "duration",
                accessor: "duration",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                type: "text",
                inputType: "number",
                required: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl id={'duration' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'duration'}
                            onChange={that.handleTableTextBoxChange} disabled={true}
                            value={value} />
                    )
                }
            },
            {
                Header: "Cost",
                id: "cost",
                name: "cost",
                accessor: "cost",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                type: "text",
                inputType: "number",
                required: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup>
                            <FormControl id={'cost' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'cost'}
                                onChange={that.handleTableTextBoxChange} disabled={true}
                                value={value} />
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
                id: "status",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(statusConstant.DELETE_STATUS)
                        }}>
                            {StatusUtil.getStatusLabel(statusConstant.DELETE_STATUS)}
                        </div>
                    )
                }
            },
            {
                id: "operationId",
                name: "operationId",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 100,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};
