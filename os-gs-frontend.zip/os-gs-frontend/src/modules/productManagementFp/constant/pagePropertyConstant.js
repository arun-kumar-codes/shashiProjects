import * as productConstant from './productConstant';
import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import { FormControl, InputGroup } from "react-bootstrap";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import SuggestionUtil from '../../common/util/suggestionUtil';
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import isAuthorized from "auth-plugin";
import CommonUtil from '../../common/util/commonUtil';
import Select from "react-select";


export const CREATE_PRODUCT_PAGE_LIST = (that) => {
    return {
        attributeObj: {
            productId: '',
            productName: '',
            category: '',
            family: '',
            productUOM: '',
            productGTIN: '',
            productSKU: '',
            buyOrMake: '',
            source: "buy",
            // ingredientCost: '',
            kittingCost: '',
            // operationCost: '',
            salesPrice: '',
            transferPrice: '',
            // ingredients: [],
            // operations: [],
            bomKitComponents: [],
            status: statusConstant.ACTIVE_STATUS,
            // hsnCode: '',
            upcNumber: '',
            sourceChannel:commonConstant.ORIGINSCALE,
            shelflife: '',
            weight: '',
            length: '',
            height: '',
            width: '',
            palletqty: '',
            boxpack: '',
            serializedCombination: '',
        },
        attributeList: [
            {
                name: "productId",
                type: "UNIQUE_CODE",
                prefix: "PRO",
                label: "Product Code",
                required: false,
                createMode: 'disabled',
                cloneMode: 'disabled',
                editMode: 'disabled',
                viewMode: 'disabled',
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                createModeRemoveFlag: true,
                cloneModeRemoveFlag: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "productName",
                type: "TEXTBOX",
                label: "Product Name",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 100,
                minLength: 3,
                customMessage: "Product Name already exist.",
            },
            {
                name: "category",
                type: "DROPDOWN",
                label: "Category",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                placeholder: "Select",
                mandatoryMsgText: "Field can not be empty.",
                dataDictionaryFlag: true,
                dataDictionaryId: 'categoryList',
                options: []
            },
            {
                name: "family",
                type: "DROPDOWN",
                label: "Family",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                placeholder: "Select",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                mandatoryMsgText: "Field can not be empty.",
                MsgText: "View all products for selected family",
                MsgTextHref: "#",
                linkOnClickFun: that.handleLinkClick,
                dataDictionaryFlag: true,
                dataDictionaryId: 'familyList',
                options: []
            },
            {
                name: "productUOM",
                type: "DROPDOWN",
                label: "UoM",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                placeholder: "Select",
                mandatoryMsgText: "Field can not be empty.",
                dataDictionaryFlag: true,
                dataDictionaryId: 'unitofMesurementList',
                options: []
            },
            {
                name: "productGTIN",
                type: "TEXTBOX",
                label: "GTIN",
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 25,
                minLength: 3,
            },
            {
                name: "productSKU",
                type: "TEXTBOX",
                label: "SKU",
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 25,
                minLength: 3,
            },
            {
                name: "source",
                type: "CUSTOM_RADIO",
                checkList: [
                    {
                        name: 'buy',
                        label: 'Buy',
                        value: 'buy'
                    },
                    // {
                    //     name: 'make',
                    //     label: 'Make',
                    //     value: 'make'
                    // },
                    {
                        name: 'repack',
                        label: 'Repack',
                        value: 'repack'
                    }
                ],
                label: "How do i source the product?",
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty."
            },
            {
                name: "supplier",
                type: "DROPDOWN",
                label: "Default Supplier",
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                customAttribute: true,
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: false,
                numberOfRow: 0,
                placeholder: "Select",
                createSupplier: "Create New",
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "purchasePrice",
                type: "TEXTBOX",
                label: "Purchase Price",
                inputType: 'number',
                required: false,
                showCurrency: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'disabled',
                cloneMode: 'disabled',
                editMode: 'disabled',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: true,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: false,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 1,
                tooltipText: 'Please select a default supplier to enter the purchase price.',
            },
            {
                name: "ingredientCost",
                type: "TEXTBOX",
                label: "Ingredient Cost",
                inputType: 'number',
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'disabled',
                cloneMode: 'disabled',
                editMode: 'disabled',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: false,
                makeShowFlag: true,
                repackShowFlag: false,
                numberOfRow: 0,
                maxLength: 10,
                minLength: 1,
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "kittingCost",
                type: "TEXTBOX",
                label: "Repacking Cost",
                inputType: 'number',
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: false,
                makeShowFlag: false,
                repackShowFlag: true,
                numberOfRow: 0,
                maxLength: 10,
                minLength: 1,
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "operationCost",
                type: "TEXTBOX",
                label: "Operation Cost",
                inputType: 'number',
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'disabled',
                cloneMode: 'disabled',
                editMode: 'disabled',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: false,
                makeShowFlag: true,
                repackShowFlag: false,
                numberOfRow: 0,
                maxLength: 10,
                minLength: 1,
                mandatoryMsgText: "Field can not be empty.",
            },
            {
                name: "salesPrice",
                type: "TEXTBOX",
                label: "Sales Price",
                inputType: 'number',
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 1,
            },
            {
                name: "transferPrice",
                type: "TEXTBOX",
                label: "Transfer Price",
                inputType: 'number',
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 1,
            },
            {
                name: "leadTime",
                type: "TEXTBOX",
                label: "Lead Time",
                inputType: 'number',
                numberType: 'fixed',
                showCurrency: false,
                addonvalue: 'Days',
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: true,
                showField: false,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: false,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 1,
            },
            {
                name: "moq",
                type: "TEXTBOX",
                label: "MOQ",
                inputType: 'number',
                numberType: 'fixed',
                showCurrency: false,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                tooltipText: 'Mimimum Order Quantity',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: true,
                showField: false,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: false,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 1,
            },
            {
                name: "moa",
                type: "TEXTBOX",
                label: "MOA",
                inputType: 'number',
                showCurrency: true,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                tooltipText: 'Mimimum Order Amount',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: true,
                showField: false,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: false,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 1,
            },
            {
                name: "tax",
                type: "DROPDOWN",
                label: "Tax %",
                showCurrency: false,
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: true,
                showField: false,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: false,
                numberOfRow: 0,
                placeholder: "Select",
                mandatoryMsgText: "Field can not be empty.",
                dataDictionaryFlag: true,
                dataDictionaryId: 'taxList',
                options: []
            },
            // {
            //     name: "hsnCode",
            //     type: "TEXTBOX",
            //     label: "HSN Code",
            //     required: true,
            //     fieldWidth: 3,
            //     fieldWidthSmall: 4,
            //     createMode: 'enable',
            //     cloneMode: 'enable',
            //     editMode: 'enable',
            //     viewMode: 'disabled',
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     supplierfields: false,
            //     buyShowFlag: true,
            //     makeShowFlag: true,
            //     repackShowFlag: true,
            //     numberOfRow: 0,
            //     mandatoryMsgText: "Field can not be empty.",
            //     maxLength: 10,
            //     minLength: 3,
            // },
            {
                name: "upcNumber",
                type: "TEXTBOX",
                label: "UPC Number",
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 10,
                minLength: 3,
            },
            {
                name: "shelflife",
                type: "TEXTBOX",
                label: "Shelf Life",
                inputType: 'number',
                numberType: 'fixed',
                showCurrency: false,
                addonvalue: 'Days',
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 3,
                minLength: 1,
            },
            {
                name: "weight",
                type: "TEXTBOX",
                label: "Weight",
                inputType: 'number',
                showCurrency: false,
                addonvalue: 'KG',
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 5,
                minLength: 1,
            },
            {
                name: "length",
                type: "TEXTBOX",
                label: "Length",
                inputType: 'number',
                showCurrency: false,
                addonvalue: 'Inches',
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 5,
                minLength: 1,
            },
            {
                name: "width",
                type: "TEXTBOX",
                label: "Width",
                inputType: 'number',
                showCurrency: false,
                addonvalue: 'Inches',
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 5,
                minLength: 1,
            },
            {
                name: "height",
                type: "TEXTBOX",
                label: "Height",
                inputType: 'number',
                showCurrency: false,
                addonvalue: 'Inches',
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: false,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 5,
                minLength: 1,
            },
            {
                name: "palletqty",
                type: "TEXTBOX",
                label: "Pallet Qty",
                inputType: 'number',
                numberType: 'fixed',
                showCurrency: false,
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 5,
                minLength: 1,
            },
            {
                name: "boxpack",
                type: "TEXTBOX",
                label: "Box Pack",
                inputType: 'number',
                numberType: 'fixed',
                showCurrency: false,
                addonvalue: 'Pcs',
                required: true,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                numberOfRow: 0,
                mandatoryMsgText: "Field can not be empty.",
                maxLength: 5,
                minLength: 1,
            },
            {
                name: "serializedCombination",
                type: "DROPDOWN",
                label: "Serialized Combination",
                required: false,
                fieldWidth: 3,
                fieldWidthSmall: 4,
                createMode: 'enable',
                cloneMode: 'enable',
                editMode: 'enable',
                viewMode: 'disabled',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                supplierfields: false,
                showField: true,
                buyShowFlag: true,
                makeShowFlag: true,
                repackShowFlag: true,
                placeholder: "Select",
                mandatoryMsgText: "Field can not be empty.",
                dataDictionaryFlag: true,
                dataDictionaryId: 'serializedCombination',
                options: []
            },
            {
                name: "status",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
            },
            {
                name: "version",
                type: "TEMP",
                createModeShowFlag: false,
                cloneModeShowFlag: false,
                editModeShowFlag: true,
            },
            // {
            //     name: "ingredients",
            //     type: "TEMP",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            // },
            // {
            //     name: "operations",
            //     type: "TEMP",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            // },
            {
                name: 'bomKitComponents',
                type: 'TEMP',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true
            },
            {
                name: 'supplierId',
                type: 'TEMP',
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true
            },
            {
                name: "sourceChannel",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
            },
        ]
    }
};

export const CREATE_PRODUCT_INGREDIENT_TABLE_LIST = (that) => {
    return {
        tableData: [{
            ingredient: '',
            quantity: '',
            ingredientUOM: '',
            purchasePrice: '',
        }],
        tableColumnList: [
            {
                Header: "Ingredient",
                id: "ingredientId",
                name: "ingredientId",
                accessor: "ingredientId",
                style: {
                    flex: '0 0 35%'
                },
                required: true,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-width" title={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}>
                            <SuggestionUtil
                                className={that.state.submitted && !value ? 'required-error' : ''}
                                searchOptionList={["ingredientId", "ingredientName"]}
                                id={'ingredientId' + '_' + index}
                                options={that.state.ingredientList}
                                selectedListKeys={['ingredientId']}
                                selectedAttributeList={that.state.ingredients}
                                placeholder=""
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}
                                selectedValue={original.ingredientId ? original.ingredientId + "|" + original.ingredientName : ''}
                                onChange={(e) => that.handleTableSuggestionChange(e, 'ingredientId' + '_' + index,
                                    ["ingredientId", "ingredientName"])}
                                handleSuggestionChange={that.handleTableSuggestionChange}
                            />
                        </div>
                    )
                }
            },
            {
                Header: "Quantity",
                id: "quantity",
                accessor: "quantity",
                name: "quantity",
                required: true,
                type: "text",
                inputType: 'number',
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && !original.quantity
                            && original.ingredientId ? 'required-error' : ''}>
                            <FormControl id={'quantity' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                name={'quantity'} onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.quantity}
                                className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>{original.ingredientUOM}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Cost",
                id: "purchasePrice",
                accessor: "purchasePrice",
                name: "purchasePrice",
                required: true,
                type: "number",
                inputType: 'number',
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && original.ingredientId &&
                            !original.purchasePrice ? 'required-error' : ''}>
                            <FormControl id={'purchasePrice' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                name={'purchasePrice'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.purchasePrice}
                                className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            {/*<InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                style: {
                    flex: '0 0 60px'
                },
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                    className="fa fa-trash" onClick={(e) => that.handleDeleteRowPopup(e)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const CREATE_PRODUCT_OPERATION_TABLE_LIST = (that) => {
    return {
        tableData: [{
            process: '',
            duration: '',
            cost: '',
            processId: ''
        }],
        tableColumnList: [
            {
                Header: "Process",
                id: "process",
                name: "process",
                accessor: "process",
                required: true,
                type: "text",
                style: {
                    flex: '0 0 35%'
                },
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-width" title={original.process ? original.process : ''}>
                            <SuggestionUtil
                                className={that.state.submitted && !value ? 'required-error' : ''}
                                searchOptionList={["process"]}
                                id={'process' + '_' + index}
                                options={that.state.operationList}
                                selectedListKeys={['process']}
                                selectedAttributeList={that.state.operations}
                                placeholder=""
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.process ? original.process : ''}
                                selectedValue={original.process ? original.process : ''}
                                onChange={(e) => that.handleTableSuggestionChange(e, 'process' + '_' + index,
                                    ["process"])}
                                handleSuggestionChange={that.handleTableSuggestionChange}
                            />
                        </div>
                    )
                }
            },
            {
                Header: "Production Time",
                id: "duration",
                accessor: "duration",
                name: "duration",
                required: true,
                type: "text",
                inputType: 'number',
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && original.process &&
                            !original.duration ? 'required-error' : ''}>
                            <FormControl id={'duration' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                name={'duration'} onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.duration}
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>hrs</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Cost",
                id: "cost",
                accessor: "cost",
                name: "cost",
                required: true,
                type: "text",
                inputType: 'number',
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && original.process &&
                            !original.cost ? 'required-error' : ''}>
                            <FormControl id={'cost' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'cost'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={value} 
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1}/>
                            {/*<InputGroup.Addon>
                                {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>*/}
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                style: {
                    flex: '0 0 60px'
                },
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                    className="fa fa-trash" onClick={(e) => that.handleDeleteRowPopup(e)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            },
            {
                name: "processId",
                id: "processId",
                type: "TEMP",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
            },
        ],
        tableConfig: {
            defaultFilteredList: [

            ],
            defaultSortedList: [

            ],
            defaultPageSize: 50,
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const CREATE_PRODUCT_BOM_KIT_TABLE_LIST = (that) => {
    return {
        tableData: [{
            productId: '',
            quantity: '',
            productUOM: '',
            purchasePrice: '',
        }],
        tableColumnList: [
            {
                Header: "Components",
                id: "productId",
                name: "productId",
                accessor: "productId",
                required: true,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-width" title={original.productId ? original.productId + "|" + original.productName : ''}>
                            <SuggestionUtil
                                className={that.state.submitted && !value ? 'required-error' : ''}
                                searchOptionList={["productId", "productName"]}
                                id={'productId' + '_' + index}
                                options={that.state.productIngredientOptions}
                                selectedListKeys={['productId']}
                                selectedAttributeList={that.state.bomKitComponents}
                                placeholder=""
                                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.productId ? original.productId + "|" + original.productName : ''}
                                selectedValue={original.productId ? original.productId + "|" + original.productName : ''}
                                onChange={(e) => that.handleTableSuggestionChange(e, 'productId' + '_' + index,
                                    ["productId", "productName"])}
                                handleSuggestionChange={that.handleTableSuggestionChange}
                            />
                        </div>
                    )
                }
            },
            {
                Header: "Quantity",
                id: "quantity",
                accessor: "quantity",
                name: "quantity",
                required: true,
                type: "text",
                disableSortBy: true,
                disableFilters: true,
                inputType: 'number',
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && !value ? 'required-error' : ''}>
                            <FormControl id={'quantity' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                                name={'quantity'} onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={original.quantity}
                                className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            // {
            //     Header: "Cost",
            //     id: "purchasePrice",
            //     accessor: "purchasePrice",
            //     name: "purchasePrice",
            //     required: true,
            //     type: "number",
            //     inputType: 'number',
            //     disableSortBy: true,
            //     disableFilters: true,
            //     className: "input-field",
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (
            //             <InputGroup className={that.state.submitted && original.productId &&
            //                 !original.purchasePrice ? 'required-error' : ''}>
            //                 <FormControl id={'purchasePrice' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
            //                     name={'purchasePrice'}
            //                     onChange={that.handleTableTextBoxChange}
            //                     disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
            //                     value={original.purchasePrice}
            //                     className="center-align"
            //                     onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
            //                     onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
            //                     maxLength={10}
            //                     minLength={1} />
            //                 <InputGroup.Addon>
            //                     {that.props.currencyCode ? that.props.currencyCode.toUpperCase() : ''}</InputGroup.Addon>
            //             </InputGroup>
            //         )
            //     }
            // },
            // {
            //     Header: "Actions",
            //     id: "actions",
            //     accessor: "actions",
            //     sticky: "right",
            //     style: {
            //         flex: '0 0 60px'
            //     },
            //     className: "action justify-content-center",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (
            //             <div className="actions-left">
            //                 <Button bsStyle="default" simple icon disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
            //                     <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
            //                         className="fa fa-trash" onClick={(e) => that.handleDeleteRowPopup(e)} />
            //                     </div>
            //                 </Button>
            //             </div>
            //         )
            //     }
            // }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const MANAGE_PRODUCT_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product Code",
                id: "productId",
                style: {
                    flex: '0 0 120px'
                },
                accessor: "productId"
            },
            {
                Header: "Product Name",
                id: "productName",
                accessor: "productName"
            },
            {
                Header: "Category",
                id: "category",
                accessor: "category",
                style: {
                    flex: '0 0 120px'
                },
            },
            {
                Header: "Type",
                id: "source",
                style: {
                    flex: '0 0 100px'
                },
                accessor: "source"
            },
            {
                Header: "Family",
                id: "family",
                style: {
                    flex: '0 0 120px'
                },
                accessor: "family"
            },
            // {
            //     Header: "Product Origin",
            //     id: "sourceChannel",
            //     accessor: "sourceChannel",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     style: {
            //         flex: '0 0 150px'
            //     },
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         let productOrigin = original.sourceChannel ? original.sourceChannel : commonConstant.ORIGINSCALE;
            //         return (
            //             <div className="full-td label-black">
            //                 <span> {productOrigin}</span>
            //             </div>
            //         )
            //     }
            // },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: '0 0 120px'
                },
                disableSortBy: true,
                id: "status",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            {StatusUtil.getStatusLabel(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                sortable: false,
                style: {
                    flex: '0 0 110px'
                },
                className: "action",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            {isAuthorized("changeProductStatus") &&
                                <Nav pullRight>
                                    <NavDropdown id={original.productId + "_" + commonConstant.MENU_ACTION_MODE}
                                        title={<i className="fa fa-ellipsis-v" id={original.productId + "_" + commonConstant.MENU_ACTION_MODE} onClick={(e) => that.getTdProps(e)} />} noCaret >
                                        {original.status != statusConstant.ACTIVE_STATUS ?
                                            <MenuItem id={original.productId + "_" + commonConstant.MENU_ACTION_MODE + "_" + productConstant.ACTIVE_PRODUCT} onClick={(e) => that.getTdProps(e)}>Activate</MenuItem>
                                            : <MenuItem id={original.productId + "_" + commonConstant.MENU_ACTION_MODE + "_" + productConstant.DEATIVATE_PRODUCT} onClick={(e) => that.getTdProps(e)}>Deactivate</MenuItem>
                                        }
                                    </NavDropdown>
                                </Nav>
                            }
                            <Button bsStyle="default" simple icon>
                                {original.status == statusConstant.ACTIVE_STATUS && isAuthorized("editProduct") ?
                                    <div className="circle"><i title="edit" id={original.productId + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index} className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} /></div>
                                    : null}
                                {original.status == statusConstant.ACTIVE_STATUS && isAuthorized("cloneProduct") ?
                                    <div className="circle"><i title="clone" id={original.productId + "_" + commonConstant.CLONE_ACTION_MODE + '_' + index} className="fa fa-copy" onClick={(e) => that.getTdProps(e)} /></div>
                                    : null}
                                {isAuthorized("viewProduct") ?
                                    <div className="circle"><i title="view" id={original.productId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index} className="fa fa-eye" onClick={(e) => that.getTdProps(e)} /></div>
                                    : null}
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    };
}

export const CREATE_SUPPLIER_MODAL_LIST = (that) => ({
    attributeObj: {
        supplierName: "",
    },
    locationAttributeObj: {
        locationName: "",
        address: "",
        country: "",
        state: "",
        city: "",
        zipcode: "",
    },
    attributeList: [
        {
            name: "supplierName",
            type: "TEXTBOX",
            label: "supplier Name",
            required: true,
            fieldWidth: 12,
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 32,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
    ],
    attributeListLocation: [
        {
            name: "locationName",
            type: "TEXTBOX",
            label: "Location Name",
            inputType: "text",
            required: true,
            fieldWidth: 6,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            maxLength: 32,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "address",
            type: "TEXTBOX",
            label: "Address",
            inputType: "text",
            required: true,
            fieldWidth: 6,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            maxLength: 100,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "country",
            type: "DROPDOWN",
            label: "Country",
            required: true,
            isCountry: true,
            fieldWidth: 3,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: [],
        },
        {
            name: "state",
            type: "DROPDOWN",
            label: "State",
            required: true,
            fieldWidth: 3,
            isState: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: [],
        },
        {
            name: "city",
            type: "DROPDOWN",
            label: "City",
            required: true,
            fieldWidth: 3,
            isCity: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: [],
        },
        {
            name: "zipcode",
            type: "TEXTBOX",
            label: "Zip Code",
            minValue: 0,
            required: true,
            fieldWidth: 3,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            maxLength: 15,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
    ],
});

export const CREATE_SUPPLIER_PRODUCT_MODAL_TABLE_LIST = (that) => {
    return {
        tableData: [{
            leadTime: '',
            moq: '',
            moa: '',
            taxCode: '',
        }],
        tableColumnList: [
            {
                Header: "Lead Time(days)",
                id: "leadTime",
                name: "leadTime",
                accessor: "leadTime",
                type: "text",
                required: true,
                inputType: 'number',
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl
                            className={that.state.submitted && original.productId &&
                                !original.leadTime ? 'required-error center-align' : 'center-align'}
                            id={'leadTime' + '_' + index}
                            data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'leadTime'}
                            onChange={that.handleTableTextBoxChange}
                            disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={value}
                            onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                            onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                            maxLength={10}
                            minLength={1} />

                    )
                }
            },
            {
                Header: "MOQ",
                id: "moq",
                name: "moq",
                title: "Minimum Order Quantity",
                accessor: "moq",
                type: "text",
                required: true,
                inputType: 'number',
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted &&
                            original.productId &&
                            !original.moq ? 'required-error' : ''}>
                            <FormControl
                                id={'moq' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moq'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={value}
                                className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "MOA",
                id: "moa",
                name: "moa",
                title: "Minimum Order Amount",
                accessor: "moa",
                type: "text",
                required: true,
                inputType: 'number',
                submitted: that.state.submitted,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted &&
                            original.productId &&
                            !original.moa ? 'required-error' : ''}>
                            <FormControl
                                id={'moa' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moa'}
                                onChange={that.handleTableTextBoxChange}
                                disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={value}
                                className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Tax %",
                id: "taxCode",
                name: "taxCode",
                accessor: "taxCode",
                type: "text",
                dataDictionaryFlag: true,
                dataDictionaryId: 'taxList',
                required: true,
                submitted: that.state.submitted,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <Select
                            className={that.state.submitted && original.productId &&
                                !original.taxCode ? 'required-error center-align' : 'center-align'}
                            id={'taxCode' + '_' + index}
                            name={"taxCode" + '_' + index}
                            onChange={that.handleTableDropDownChange}
                            options={that.props.dataDictionaryList &&
                                that.props.dataDictionaryList.dataDictionaryList &&
                                that.props.dataDictionaryList.dataDictionaryList.taxList}
                            classNamePrefix="react-select"
                            isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={{ "label": original.taxCode }} />
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                className: "action justify-content-center",
                style: {
                    flex: '0 0 60px',
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                    className="fa fa-trash" onClick={(e) => that.handleTableRemove(e)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const CREATE_SUPPLIER_INGREDIENT_MODAL_TABLE_LIST = (that) => {
    return {
        tableData: [{
            leadTime: '',
            moq: '',
            moa: '',
            taxCode: '',
        }],
        tableColumnList: [
            {
                Header: "Lead Time(days)",
                id: "leadTime",
                name: "leadTime",
                accessor: "leadTime",
                type: "text",
                required: true,
                inputType: 'number',
                submitted: that.state.submitted,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <FormControl
                            className={that.state.submitted && original.ingredientId &&
                                !original.leadTime ? 'required-error center-align' : 'center-align'}
                            id={'leadTime' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'leadTime'}
                            onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={value} 
                            onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                            onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                            maxLength={10}
                            minLength={1}/>
                    )
                }
            },
            {
                Header: "MOQ",
                id: "moq",
                name: "moq",
                accessor: "moq",
                type: "text",
                required: true,
                inputType: 'number',
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && original.ingredientId &&
                            !original.moq ? 'required-error' : ''}>
                            <FormControl id={'moq' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moq'}
                                onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={value} className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>{original.ingredientUOM}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "MOA",
                id: "moa",
                name: "moa",
                accessor: "moa",
                type: "text",
                required: true,
                inputType: 'number',
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <InputGroup className={that.state.submitted && original.ingredientId &&
                            !original.moa ? 'required-error' : ''}>
                            <FormControl id={'moa' + '_' + index} data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }} name={'moa'}
                                onChange={that.handleTableTextBoxChange} disabled={that.props.actionMode == 'disabled' ? true : CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                                value={value} className="center-align"
                                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 10)}}
                                maxLength={10}
                                minLength={1} />
                            <InputGroup.Addon>{original.ingredientUOM}</InputGroup.Addon>
                        </InputGroup>
                    )
                }
            },
            {
                Header: "Tax %",
                id: "taxCode",
                name: "taxCode",
                accessor: "taxCode",
                type: "text",
                dataDictionaryFlag: true,
                dataDictionaryId: 'taxList',
                required: true,
                submitted: that.state.submitted,
                className: "input-field",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <Select
                            className={that.state.submitted && original.ingredientId &&
                                !original.taxCode ? 'required-error center-align' : 'center-align'}
                            id={'taxCode' + '_' + index}
                            name={"taxCode" + '_' + index}
                            onChange={that.handleTableDropDownChange}
                            options={that.props.dataDictionaryList &&
                                that.props.dataDictionaryList.dataDictionaryList &&
                                that.props.dataDictionaryList.dataDictionaryList.taxList}
                            classNamePrefix="react-select"
                            isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                            value={{ "label": original.taxCode }} />
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                className: "action justify-content-center",
                style: {
                    flex: '0 0 60px'
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}>
                                <div className="circle"><i title="remove" id={commonConstant.EDIT_ACTION_MODE + '_' + index}
                                    className="fa fa-trash" onClick={(e) => that.handleTableRemove(e)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const LOCATION_PAGE_LIST =
{
    attributeObj: {
        locationName: '',
        address: '',
        country: '',
        state: '',
        city: '',
        zipcode: '',
        isDefault: false
    },
    attributeList: [
        {
            name: "locationName",
            type: "TEXTBOX",
            label: "Location Name",
            required: true,
            fieldWidth: 4,
            numberOfRow: 0,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            maxLength: 32,
            lengthValidationMessage: "Max length of 32 chars exceeded",
            mandatoryMsgText: "Field can not be empty."
        },
        {
            name: "address",
            type: "TEXTBOX",
            label: "Address",
            inputType: "text",
            required: true,
            fieldWidth: 8,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            placeholder: "",
            numberOfRow: 0,
            maxLength: 100,
            lengthValidationMessage: "Max length of 100 chars exceeded",
            mandatoryMsgText: "Field can not be empty."
        },
        {
            name: "country",
            type: "DROPDOWN",
            label: "Country",
            required: true,
            isCountry: true,
            fieldWidth: 3,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "state",
            type: "DROPDOWN",
            label: "State",
            required: true,
            fieldWidth: 3,
            isState: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "city",
            type: "DROPDOWN",
            label: "City",
            required: true,
            fieldWidth: 3,
            isCity: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "zipcode",
            type: "TEXTBOX",
            label: "Zip Code",
            minValue: 0,
            required: true,
            fieldWidth: 3,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            placeholder: "",
            numberOfRow: 0,
            maxLength: 15,
            lengthValidationMessage: "Max length of 15 chars exceeded",
            mandatoryMsgText: "Field can not be empty."
        }
    ]

};

export const CREATE_SUPPLIER_PAGE_LIST =
{
    attributeObj: {
        supplierId: '',
        supplierName: '',
        status: statusConstant.ACTIVE_STATUS,
        locations: [],
        documents: []
    },
    attributeList: [
        {
            name: "supplierId",
            type: "UNIQUE_CODE",
            label: "Supplier Code",
            prefix: "SUP",
            required: false,
            fieldWidth: 6,
            inputType: "text",
            numberOfRow: 0,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "supplierName",
            type: "TEXTBOX",
            label: "Supplier Name",
            required: true,
            fieldWidth: 12,
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 32,
            lengthValidationMessage: "Max length of 32 chars exceeded",
            mandatoryMsgText: "Field can not be empty.",
            customMessage: "Supplier Name already exist."
        },
        {
            name: "status",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
        },
        {
            name: "version",
            type: "TEMP",
            createModeShowFlag: false,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "locations",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
        },
        {
            name: "documents",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
        },
    ]
};

export const ADVANCE_SEARCH_LIST = (that) => {
    return {
        attributeObj: {
            orderNumber: '',
        },
        attributeList: [
            {
                name: "orderNumber",
                type: "TEXTBOX",
                label: "",
                inputType: "text",
                fieldWidth: 12,
                numberOfRow: 0,
                placeholder: "Search by Product Code/Name",
            },
        ],
    }
};
