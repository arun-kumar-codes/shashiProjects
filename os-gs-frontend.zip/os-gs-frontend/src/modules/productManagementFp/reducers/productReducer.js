import * as productActionTypes from "../actions/productActionTypes";
import * as supplierActionTypes from "../../supplierManagement/actions/supplierActionTypes";

const initialState = {
  productDetails: null,
  productList: null,
  productGrossList: null,
  selectedProductCode: null,
};

const productReducer = (state = initialState, action) => {
  switch (action.type) {
    case productActionTypes.SET_REDUCER_INIT_MODE:
      return {
        ...initialState,
      };
    case productActionTypes.SET_PRODUCT_DETAILS:
      return {
        ...state,
        productDetails: action.payload
      };
    case productActionTypes.GET_PRODUCT_LIST:
      return {
        ...state,
        productList: action.payload
      };
    case productActionTypes.GET_PRODUCT_GROSS_LIST:
      return {
        ...state,
        productGrossList: action.payload
      };
    case productActionTypes.SET_SELECTED_PRODUCT_CODE:
      return {
        ...state,
        selectedProductCode: action.payload
      };
    case productActionTypes.GET_PRODUCT_DETAILS:
      return {
        ...state,
        productDetails: action.payload
      };
    case supplierActionTypes.GET_SUPPLIER_DETAILS:
      return {
        ...state,
        supplierDetails: action.payload
      };
    default:
      return state;
  }
};

export default productReducer;
