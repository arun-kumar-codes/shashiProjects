import axios from '../../../axios/axios';
import * as productActionTypes from './productActionTypes';
import * as actionTypes from '../../../actions/actionTypes';
import * as productConstant from '../constant/productConstant';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: productActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setProductDetails(productDetailsObj, actionMode) {

  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(productConstant.SET_CREATE_PRODUCT_DETAILS_URL,
        productDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }

  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(productConstant.SET_UPDATE_PRODUCT_DETAILS_URL +
        productDetailsObj.productId, productDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedProductCode(selectedProductCode) {
  return function (dispatch) {
    dispatch({
      type: productActionTypes.SET_SELECTED_PRODUCT_CODE,
      payload: selectedProductCode
    });
  }
}

export function getProductList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getProductGrossList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_GROSS_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getProductDetails(selectedProductCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_DETAILS_URL +
      selectedProductCode).then(response => {
        if (response.status == 200) {
          dispatch({
            type: productActionTypes.GET_PRODUCT_DETAILS,
            payload: response.data.Item
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}


export function updateProductStatus(productDetailsObj, additionalData) {
  let params = { limit: 15, page: 1, pageIndex: 1 };
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(productConstant.SET_UPDATE_PRODUCT_STATUS_URL +
      productDetailsObj.productId, productDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(productConstant.GET_PRODUCT_LIST_URL, { params: params }).then(response => {
            if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
              dispatch(setAjaxCallStatus(updateApiResponse(response, additionalData)));
              dispatch({
                type: productActionTypes.GET_PRODUCT_LIST,
                payload: response.data
              })
            }
            dispatch(endAjaxCall());
          })
        }
      }).catch(error => {
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
        dispatch(endAjaxCall());
      });
  }
}

export function setBulkProduct(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(productConstant.SET_CREATE_BULK_PRODUCT_URL, params).then(response => {
      if (response.status == 200) {
        dispatch({
          type: actionTypes.SET_UPLOAD_IMPORT_FILE_STATUS,
          payload: response.data.uploadDetails
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getProductSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(productConstant.GET_PRODUCT_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: productActionTypes.GET_PRODUCT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}
