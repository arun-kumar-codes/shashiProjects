import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, ControlLabel, Tabs, Tab } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { setProductDetails, getProductDetails, setReducerInitMode } from "../actions/productActions";
import { getSupplierList, getSupplierDetails } from "../../supplierManagement/actions/supplierActions";
// import { getIngredientList } from "../../ingredientManagement/actions/ingredientActions";
import { getProductList } from '../../productManagement/actions/productActions';
// import { getOperationDetails } from "../../operation/actions/operationActions";
import { setActionMode } from "../../../actions/appActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as productConstant from '../constant/productConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CustomRadio from "../../../components/CustomRadio/CustomRadio";
import CommonUtil from '../../common/util/commonUtil';
import PopularTableUtil from '../../common/util/popularTableUtil.js';
import PopupUtil from '../../common/util/popupUtil';
import LabelUtil from '../../common/util/labelUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import _ from 'lodash';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import product from "assets/img/product-page-icon.svg";
import CreateSupplierModalFp from '../../common/components/CreateSupplierModalFp';
import mixpanel from "../../analytics/mixpanel/mixpael";
import * as statusConstant from '../../common/constant/statusConstant';

let Modal = require('react-bootstrap-modal');
class CreateProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: {
        source: 'buy'
      },
      supplierDetails: null,
      showSupplierFields: false,
      submitted: false,
      alert: null,
      source: "buy",
      // ingredients: [],
      // operations: [],
      bomKitComponents: [],
      selectedTab: "INGREDIENT",
      ingredientTableKey: "ingredients",
      operationTableKey: "operations",
      bomKitComponentTableKey: 'bomKitComponents'
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.getCompleteDetails = this.getCompleteDetails.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }


  handleTableSuggestionChange = (event, eventId, searchOptions) => {
    PopularTableUtil.handleTableSuggestionChange(
      event,
      eventId,
      searchOptions,
      this,
      this.getSelectedTablekey()
    );
    var id = parseInt(eventId.split('_')[1]);

    if (this.state.selectedTab == 'INGREDIENT') {
      this.setIngredientDefaultRowData(id, this.getSelectedTablekey());
    } else if (this.state.selectedTab === 'BOM_KIT') {
      this.setBomKitComponentDefaultRowData(id, this.getSelectedTablekey());
    } else {
      this.setOperationDefaultRowData(id, this.getSelectedTablekey());
    }
    // this.handleTableCalculation(this.getSelectedTablekey());
  }

  setBomKitComponentDefaultRowData = (id, tableDataKeyName) => {
    var selectedData = '';
    var attributeDataList = [...this.state[tableDataKeyName]];
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (id == i) {
        this.state.productIngredientOptions && this.state.productIngredientOptions.filter(value => {
          if ((value.productId && String(value.productId).toLowerCase().indexOf(
            attributeDataList[i].productId &&
            attributeDataList[i].productId.toLowerCase()) !== -1)) {
            // || (value.ingredientId &&
            //   String(value.ingredientId).toLowerCase().indexOf(attributeDataList[i].ingredientId &&
            //     String(attributeDataList[i].ingredientId).toLowerCase()) !== -1)) {
            selectedData = value;
          }
        });
        if (selectedData && selectedData !== null) {
          // attributeDataList[i].ingredientId = undefined;
          // attributeDataList[i].ingredientName = undefined;
          attributeDataList[i].productId = selectedData.ingredientId || selectedData.productId;
          attributeDataList[i].productName = selectedData.ingredientName || selectedData.productName;
          attributeDataList[i].productUOM = selectedData.productUOM || selectedData.ingredientUOM;
          attributeDataList[i].purchasePrice = selectedData.price || selectedData.purchasePrice;
        }
      }
    }
    this.setState({ [tableDataKeyName]: attributeDataList });
  }

  setIngredientDefaultRowData = (id, tableDataKeyName) => {
    var selectedData = '';
    var attributeDataList = [...this.state[tableDataKeyName]];
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (id == i) {
        this.props && this.props.ingredientList && this.props.ingredientList.Items.filter(value => {
          if (value.ingredientId && String(value.ingredientId).toLowerCase().indexOf(
            attributeDataList[i].ingredientId &&
            String(attributeDataList[i].ingredientId).toLowerCase()) !== -1) {
            selectedData = value;
          }
        });
        if (selectedData && selectedData !== null) {
          attributeDataList[i].ingredientUOM = selectedData.ingredientUOM;
          attributeDataList[i].purchasePrice = selectedData.purchasePrice;
        }
      }
    }
    this.setState({ [tableDataKeyName]: attributeDataList });
  }

  setOperationDefaultRowData = (id, tableDataKeyName) => {
    var selectedData = '';
    var attributeDataList = [...this.state[tableDataKeyName]];
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (id == i) {
        this.props && this.props.operationList && this.props.operationList.operations.filter(value => {
          if (value.process && value.process.toLowerCase().indexOf(
            attributeDataList[i].process &&
            attributeDataList[i].process.toLowerCase()) !== -1) {
            selectedData = value;
          }
        });
        if (selectedData && selectedData !== null) {
          attributeDataList[i].duration = selectedData.duration;
          attributeDataList[i].cost = selectedData.cost;
          attributeDataList[i].processId = selectedData.processId;
        }
      }
    }
    this.setState({ [tableDataKeyName]: attributeDataList });
  }

  handleCustomDropDownChange = async (event, obj) => {
    if (obj.name == 'supplier') {
      const { attributeObj } = this.state;
      attributeObj.leadTime = "";
      attributeObj.moq = "";
      attributeObj.moa = "";
      attributeObj.tax = "0";
      attributeObj.purchasePrice = "";

      const { attributeList } = this.state;
      var newlist = attributeList.map((item) => {
        if (item.supplierfields) {
          item.showField = true;
          item.required = true;
          item.createMode = 'enable';
          item.cloneMode = 'enable';
          item.editMode = 'enable';
          if (item.name == "tax") {
            item.createMode = 'disabled';
            item.cloneMode = 'disabled';
            item.editMode = 'disabled';
          }
        }
        return item;
      });

      if (CommonUtil.isEditMode(this.props.actionMode)) {
        attributeObj.showSupplierFields = true;
      }
      await this.setState({
        attributeList: newlist,
        attributeObj: {
          ...attributeObj,
          [obj.name]: event.value,
          "supplierId": event.value
        },
      });
      this.props.getSupplierDetails(event.value);
    }
  }

  handleRadioButtonsChange = async (event) => {
    const { name, value } = event.target;
    const { attributeObj } = this.state;
    if (value === "make") {
      await this.setState({
        selectedTab: 'INGREDIENT'
      })
      this.setSelectedTableDetails('INGREDIENT');
    } else if (value === 'repack') {
      await this.setState({
        selectedTab: 'BOM_KIT',
        bomKitComponents: [{}],
      });
      this.setSelectedTableDetails('BOM_KIT');
    }
    const { attributeList } = this.state;
    attributeObj.ingredientCost = '';
    attributeObj.operationCost = '';
    attributeObj.kittingCost = '';
    this.setState({
      attributeObj: {
        ...attributeObj,
        source: value
      }
    })
  }

  // handleTableCalculation = (tableDataKeyName) => {
  //   if (CommonUtil.isBothEqual(tableDataKeyName, 'ingredients')) {
  //     this.handleIngredientTableCalulation(tableDataKeyName);
  //   }
  //   if (CommonUtil.isBothEqual(tableDataKeyName, 'operations')) {
  //     this.handleOperationTableCalulation(tableDataKeyName);
  //   }
  //   if (CommonUtil.isBothEqual(tableDataKeyName, 'bomKitComponents')) {
  //     this.handleKittingTableCalulation(tableDataKeyName);
  //   }
  // }

  handleIngredientTableCalulation = (tableDataKeyName) => {
    var attributeDataList = [...this.state[tableDataKeyName]];
    var grandTotal = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (attributeDataList[i].purchasePrice && attributeDataList[i].quantity) {
        var tempPurchasePrice = 0, tempQuantity = 0;
        tempPurchasePrice = parseFloat(attributeDataList[i].purchasePrice);
        tempQuantity = parseFloat(attributeDataList[i].quantity);
        tempPurchasePrice = parseFloat(tempPurchasePrice * tempQuantity);
        grandTotal = parseFloat(grandTotal + tempPurchasePrice);
      }
    }
    grandTotal = parseFloat(grandTotal).toFixed(2);
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        ingredientCost: grandTotal
      }
    })
  }

  handleKittingTableCalulation = (tableDataKeyName) => {
    var attributeDataList = [...this.state[tableDataKeyName]];
    var grandTotal = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (attributeDataList[i].purchasePrice && attributeDataList[i].quantity) {
        var tempPurchasePrice = 0, tempQuantity = 0;
        tempPurchasePrice = parseFloat(attributeDataList[i].purchasePrice);
        tempQuantity = parseFloat(attributeDataList[i].quantity);
        tempPurchasePrice = parseFloat(tempPurchasePrice * tempQuantity);
        grandTotal = parseFloat(grandTotal + tempPurchasePrice);
      }
    }
    grandTotal = parseFloat(grandTotal).toFixed(2);
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        kittingCost: grandTotal
      }
    })
  }

  handleOperationTableCalulation = (tableDataKeyName) => {
    var attributeDataList = [...this.state[tableDataKeyName]];
    var grandTotal = 0;
    for (var i = 0; i < this.state[tableDataKeyName].length; i++) {
      if (attributeDataList[i].cost && attributeDataList[i].duration) {
        var tempOperationCost = 0, tempDuration = 0;
        tempOperationCost = parseFloat(attributeDataList[i].cost);
        tempDuration = parseFloat(attributeDataList[i].duration);
        tempOperationCost = parseFloat(tempOperationCost * tempDuration);
        grandTotal = parseFloat(grandTotal + tempOperationCost);
      }
    }
    grandTotal = parseFloat(grandTotal).toFixed(2);
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        operationCost: grandTotal
      }
    })
  }

  getSelectedTablekey = (selectedTab) => {
    if (this.state.selectedTab == 'INGREDIENT' || selectedTab == 'INGREDIENT') {
      return this.state.ingredientTableKey;
    }
    if (this.state.selectedTab == 'OPERATION' || selectedTab == 'OPERATION') {
      return this.state.operationTableKey;
    }

    if (this.state.selectedTab == 'BOM_KIT' || selectedTab == 'BOM_KIT') {
      return this.state.bomKitComponentTableKey
    }
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    // this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
    // this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleDeleteRowPopup = (event) => {
    this.setState({ eventId: event.target.id });
    var popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleTableRemove;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    var popupConfig = CommonUtil.prepareDeleteRowPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleTableRemove = async (event) => {
    this.setState({ alert: null });
    var tempevent = event ? event : this.state.eventId;
    await PopularTableUtil.handleTableRemove(tempevent, this, this.getSelectedTablekey(), true);
    // this.handleTableCalculation(this.getSelectedTablekey());
  }

  handleLinkClick = (event) => {
    event.preventDefault();
    this.handleFamilyRedirection(productConstant.MANAGE_PRODUCT_PAGE_URL,
      this.getFamilyRequestParams(event));
  }

  handleFamilyRedirection = (redirectURL, params) => {
    this.setState({ redirect: true, redirectUrl: redirectURL, params }, () => {
    });
  }

  getFamilyRequestParams(event) {
    var tempParamas = {};
    tempParamas.family = this.state.attributeObj && this.state.attributeObj.family;
    return tempParamas;
  }

  componentDidMount = () => {
    mixpanel.track("Create product loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getProductDetails(this.props.selectedProductCode);
      }
    } else {
      CommonUtil.handlePageRedirection(productConstant.MANAGE_PRODUCT_PAGE_URL, this);
    }
    this.props.getProductList();
    // this.props.getIngredientList();
    // this.props.getOperationDetails();
    this.props.getSupplierList();
    this.setSelectedTableDetails(this.state.selectedTab);
    const commonAttributeList = pagePropertyListConstant.CREATE_PRODUCT_PAGE_LIST(this);
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      // operations: CommonUtil.isCreateMode(this.props.actionMode) ? [{}] : [],
      // ingredients: CommonUtil.isCreateMode(this.props.actionMode) ? [{}] : [],
      bomKitComponents: CommonUtil.isCreateMode(this.props.actionMode) ? [{}] : [],
      attributeObj: commonAttributeList.attributeObj
    });
  }

  handleTabClick = (label, event) => {
    var selectedTabKey = label.toUpperCase();
    this.setState({
      selectedTab: label.toUpperCase(),
    }, function () {
      this.setSelectedTableDetails(selectedTabKey);
    })
  }

  setSelectedTableDetails = (selectedTab) => {

    const tableAttributeList = pagePropertyListConstant["CREATE_PRODUCT_" +
      selectedTab.toUpperCase() + "_TABLE_LIST"](this);

    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.attributeList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    })
  }

  updateAttributeObj(supplierDetails) {
    const { attributeObj } = this.state;
    if (supplierDetails.products != null) {
      for (let i = 0; i < supplierDetails.products.length; i++) {
        if (supplierDetails.products[i].productId == attributeObj.productId) {
          attributeObj.leadTime = supplierDetails.products[i].leadTime;
          attributeObj.moq = supplierDetails.products[i].moq;
          attributeObj.moa = supplierDetails.products[i].moa;
          attributeObj.tax = supplierDetails.products[i].taxCode;
          attributeObj.purchasePrice = supplierDetails.products[i].purchasePrice;
          attributeObj.showSupplierFields = true;
          this.setState({
            attributeObj: {
              ...attributeObj
            }
          });
        }
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }

    if (this.props.supplierDetails != null && prevProps.supplierDetails != this.props.supplierDetails) {
      if (CommonUtil.isEditMode(this.props.actionMode) || CommonUtil.isViewMode(this.props.actionMode)) {
        this.updateAttributeObj(this.props.supplierDetails);
      }
    }

    if (this.props.supplierList != null && prevProps.supplierList != this.props.supplierList) {
      this.updateSupplierDropDownList();
    }
    if (this.props.operationList != null && prevProps.operationList != this.props.operationList) {
      this.updateOperationDropDownList();
    }
    if (this.props.ingredientList != null && prevProps.ingredientList != this.props.ingredientList) {
      this.updateIngredientDropDownList();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (prevProps.location.key !== this.props.location.key) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getProductDetails(this.props.selectedProductCode);
      } else {
        this.createNew();
      }
    }
  }

  async updateApiData(attributeObj) {
    const selectedTab = attributeObj.source == 'repack' ? 'BOM_KIT' : 'INGREDIENT';
    await this.setState({
      attributeObj: {
        ...attributeObj,
        productId: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productId,
        productName: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productName,
        source: attributeObj.source
      },
      selectedTab,
      // ingredients: [...attributeObj.ingredients],
      bomKitComponents: [...attributeObj.bomKitComponents],
      // operations: [...attributeObj.operations], function() {}
    });
    if (!CommonUtil.isCreateMode(this.props.actionMode)) {
      this.getDefaultSupplierPrice();
    }
    this.setSelectedTableDetails(selectedTab);
    // this.handleTableCalculation(this.getSelectedTablekey());
  }

  createNew = async () => {
    let tempObj = [];
    // tempObj.ingredients = [{}];
    // tempObj.operations = [{}];
    await this.setState({
      attributeObj: {
        ...tempObj,
        source: 'buy',
        productId: "",
        productName: "",
        productGTIN: "",
        productSKU: "",
        salesPrice: "",
        transferPrice: "",
        hsnCode: "",
        upcNumber: "",
        purchasePrice: "",
        height: "",
        width: "",
        length: "",
        shelflife: "",
        weight: "",
        palletqty: "",
        boxpack: "",
        serializedCombination: "",
        status: statusConstant.ACTIVE_STATUS,
      },
      // ingredients: [...tempObj.ingredients],
      // operations: [...tempObj.operations],
    });
    // this.handleTableCalculation(this.getSelectedTablekey());
  };

  updateSupplierDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.supplierList.Items,'supplierId', 'supplierName');
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({
        attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'supplierId')
    })
    if (!CommonUtil.isCreateMode(this.props.actionMode)) {
      this.getDefaultSupplierPrice();
    }
  }

  getDefaultSupplierPrice = async () => {
    if (this.props.supplierList != null && this.props.attributeObj != null) {
      let selectedSupplierObj = CommonUtil.getFilteredObjFromArray(
        this.props.supplierList.Items, 'supplierId', this.props.attributeObj.supplier);
      if (selectedSupplierObj != null) {
        let selectedProductObj = CommonUtil.getFilteredObjFromArray(
          selectedSupplierObj.products, 'productId', this.props.selectedProductCode);
        const { attributeObj } = this.state;
        if (CommonUtil.isEditMode(this.props.actionMode) || CommonUtil.isViewMode(this.props.actionMode)) {
          await this.setState({
            attributeObj: {
              ...attributeObj,
              purchasePrice: selectedProductObj.purchasePrice
            },
          })
        } else {
          await this.setState({
            attributeObj: {
              ...attributeObj,
              purchasePrice: '',
              supplier: ''
            },
          })
        }
      }
    }
  }

  updateOperationDropDownList = () => {
    this.setState({ operationList: this.props.operationList.operations })
  }

  updateIngredientDropDownList = () => {
    this.setState({ ingredientList: this.props.ingredientList.Items });
    this.mergeProductIngredientList();
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleStatusAction = (status) => {
    var tempObj = {};
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updateSaleOrderDeleteStatus(tempObj, this.state.attributeObj.saleOrderId);
  }

  handleSave = async (event) => {
    this.setState({ submitted: true, alert: null });

    var tempObj = this.state.attributeObj, actionMode = this.props.actionMode;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, actionMode);
    if (tempObj.source == 'make') {
      tempObj.ingredients = this.state.ingredients;
      tempObj.operations = this.state.operations;
      tempObj.supplier = '';
      tempObj.bomKitComponents = [];
      tempObj.kittingCost = '';
    } else if (tempObj.source == 'repack') {
      tempObj.bomKitComponents = this.state.bomKitComponents;
      // tempObj.ingredients = [];
      // tempObj.operations = [];
      // tempObj.operationCost = '';
      // tempObj.ingredientCost = '';
    } else {
      // tempObj.ingredients = [];
      // tempObj.operations = [];
      // tempObj.operationCost = '';
      // tempObj.ingredientCost = '';
      tempObj.bomKitComponents = [];
      tempObj.kittingCost = '';
    }
    if (this.isValidRequestObj(tempObj)) {
      this.props.setProductDetails(tempObj, actionMode);
    }
  }

  handleSubmit = () => {
    const { operations, ingredients, attributeObj, bomKitComponents } = this.state;
    if (attributeObj.source == 'make') {
      if ((operations != null && operations.length > 0 && operations[0].process) && (ingredients != null && ingredients.length > 0 && ingredients[0].ingredientId)) {
        this.handleSave();
      } else if (((operations.length == 0) || (operations != null && operations.length > 0 && !operations[0].process)) && (ingredients != null && ingredients.length > 0 && ingredients[0].ingredientId)) {
        PopupUtil.popupSaveProductMakeOperation(this);
      } else if ((operations != null && operations.length > 0 && operations[0].process) && ((ingredients.length == 0) || (ingredients != null && ingredients.length > 0 && !ingredients[0].ingredientId))) {
        PopupUtil.popupSaveProductMakeIngredients(this);
      } else {
        PopupUtil.popupSaveProductMake(this);
      }
    } else if (attributeObj.source == 'repack') {
      if (bomKitComponents != null && bomKitComponents.length > 0 && bomKitComponents[0].productId) {
        this.handleSave();
      } else {
        PopupUtil.popupSaveProductRepack(this);
      }
    } else {
      this.handleSave();
    }
  }

  isValidRequestObj = (tempObj) => {

    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }

    // if (tempObj.ingredients.length > 0 && tempObj.ingredients[0].ingredientId) {
    //   if (!ValidationUtil.validateArrayListRequestObj(tempObj.ingredients,
    //     pagePropertyListConstant.CREATE_PRODUCT_INGREDIENT_TABLE_LIST(this).tableColumnList)) {
    //     return false;
    //   }
    // } else {
    //   tempObj.ingredients = [];
    // }

    // if (tempObj.operations.length > 0 && tempObj.operations[0].process) {
    //   if (!ValidationUtil.validateArrayListRequestObj(tempObj.operations,
    //     pagePropertyListConstant.CREATE_PRODUCT_OPERATION_TABLE_LIST(this).tableColumnList)) {
    //     return false;
    //   }
    // } else {
    //   tempObj.operations = [];
    // }

    if (tempObj.bomKitComponents.length > 0 && tempObj.bomKitComponents[0].productId) {
      if (
        !ValidationUtil.validateArrayListRequestObj(
          tempObj.bomKitComponents,
          pagePropertyListConstant.CREATE_PRODUCT_BOM_KIT_TABLE_LIST(this).tableColumnList
        )) {
        return false;
      }
    } else {
      tempObj.bomKitComponents = [];
    }

    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      if (!this.state.isSupplierPopupFlag) {
        setTimeout(this.handlePopupContinue, 0);
      } else {
        this.setState({ openModal: false });
        this.closeModal();
        this.props.getSupplierList();
      }
    }
    if (this.props.ajaxCallStatus.status == "FAILED" && this.state.openModal == false) {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = this.state.attributeObj.status ? this.state.attributeObj.status : null;
    CommonUtil.handlePageRedirection(productConstant.MANAGE_PRODUCT_PAGE_URL, this, params);
  }

  handleTableAddRow = (event) => {
    if (this.state.attributeObj.source == 'make') {
      if (this.state.selectedTab == 'INGREDIENT') {
        if (this.state.ingredientList.length > this.state.ingredients.length) {
          PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
        }
      }
      if (this.state.selectedTab == 'OPERATION') {
        if (this.state.operationList.length > this.state.operations.length) {
          PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
        }
      }
    } else if (this.state.attributeObj.source == 'repack') {
      if (this.state.productIngredientOptions.length > this.state.bomKitComponents.length) {
        PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
      }
    }
  }

  updateProductDropDownList = () => {
    this.setState({ productList: this.props.productList });
    this.mergeProductIngredientList();
  }

  mergeProductIngredientList = () => {
    // if (CommonUtil.isNotNull(this.props.productList) && CommonUtil.isNotNull(this.props.ingredientList)
    //   && this.props.ingredientList.Items.length > 0 && this.props.productList.Items.length > 0) {

    //   let buyProductList = CommonUtil.getFilteredListFromArray(this.props.productList.Items, 'source', 'buy');
    //   let makeProductList = CommonUtil.getFilteredListFromArray(this.props.productList.Items, 'source', 'make');
    //   let allProductList = [];
    //   Array.prototype.push.apply(allProductList, buyProductList);
    //   Array.prototype.push.apply(allProductList, makeProductList);
    //   this.setState({ productIngredientOptions: [...allProductList, ...this.props.ingredientList.Items] })
    // }
    if (CommonUtil.isNotNull(this.props.productList) && this.props.productList.Items.length > 0) {

      let buyProductList = CommonUtil.getFilteredListFromArray(this.props.productList.Items, 'source', 'buy');
      let allProductList = [];
      Array.prototype.push.apply(allProductList, buyProductList);
      this.setState({ productIngredientOptions: [...allProductList] })
    }
  }

  showModal = () => {
    this.setState({ openModal: true, isSupplierPopupFlag: true });
  };

  closeModal = () => {
    this.setState({ openModal: false, isSupplierPopupFlag: false });
  };

  getCompleteDetails = (completeDetails) => {
    this.setState({ openModal: false, isSupplierPopupFlag: false });
  }

  render() {
    const { attributeList, attributeObj, submitted,
      tableColumnList, tableConfig, customErrorFlag, bomKitComponents } = this.state;
    const tableDataList = this.state[this.getSelectedTablekey()];
    const actionMode = this.props.actionMode;

    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={product} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    productConstant.EDIT_PRODUCT_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      productConstant.VIEW_PRODUCT_HEADER_TITLE
                      : productConstant.CREATE_PRODUCT_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSubmit}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <div>
                        <Row className="content-section">
                          {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                            tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true &&
                              tempAttributeListObj[[attributeObj.source] + 'ShowFlag'] == true ?
                              LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true &&
                                tempAttributeListObj[[attributeObj.source] + 'ShowFlag'] == true ?
                                attributeObj.source == 'buy' && tempAttributeListObj.supplierfields == true ?
                                  (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                    TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                    : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                      TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                      : null
                                  : TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true &&
                                  tempAttributeListObj[[attributeObj.source] + 'ShowFlag'] == true ?
                                  attributeObj.source == 'buy' && tempAttributeListObj.supplierfields == true ?
                                    (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                      DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                        DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                        : null
                                    : DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : tempAttributeListObj.type == "CUSTOM_RADIO" && tempAttributeListObj[actionMode + 'ShowFlag'] == true &&
                                    tempAttributeListObj[[attributeObj.source] + 'ShowFlag'] == true ?

                                    <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index} className="product-checkbox">
                                      <FormGroup style={{ width: '100%' }}>
                                        <div>
                                          <ControlLabel style={{ textTransform: 'none' }}>
                                            {tempAttributeListObj.label}
                                            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                          </ControlLabel>
                                        </div>
                                        <div className="source-btn">
                                          {tempAttributeListObj.checkList.map((check, Nestedindex) => {
                                            return (
                                              <Col md={4} key={Nestedindex}>
                                                <CustomRadio key={Nestedindex} name={check.name} number={check.name} label={check.label}
                                                  onChange={this.handleRadioButtonsChange} value={check.value}
                                                  disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                                  checked={attributeObj.source == check.value} />
                                              </Col>
                                            )
                                          })}
                                        </div>
                                      </FormGroup>
                                    </Col>
                                    : null))
                          }

                        </Row>

                      </div>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
          < Row >
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      {attributeObj && attributeObj.source == 'make' ?
                        <Tabs activeKey={this.state.selectedTab} onSelect={this.handleTabClick} id="table-tab">
                          <Tab eventKey={'INGREDIENT'} title={productConstant.INGREDIENT_TABLE_NAME}>
                            {tableDataList != null &&
                              <Row>
                                {tableColumnList != null && tableColumnList.length > 0 ?
                                  <div>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                    <div className="add-new-section">
                                      <Col md={12}>
                                        {!CommonUtil.isViewMode(this.props.actionMode) ?
                                          <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                            <i className=" fa fa-plus" />
                                            Add Row
                                        </div>
                                          : null}
                                      </Col>
                                    </div>
                                  </div>
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>}
                          </Tab>
                          <Tab eventKey={'OPERATION'} title={productConstant.OPERATION_TABLE_NAME}>
                            {tableDataList != null &&
                              <Row>
                                {tableColumnList != null && tableColumnList.length > 0 ?
                                  <div>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />
                                    <div className="add-new-section">
                                      <Col md={12}>
                                        {!CommonUtil.isViewMode(this.props.actionMode) ?
                                          <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                            <i className=" fa fa-plus" />
                                            Add Row
                                          </div>
                                          : null}
                                      </Col>
                                    </div>
                                  </div>
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>}
                          </Tab>
                        </Tabs>
                        : attributeObj && attributeObj.source == 'repack' ?
                          <Tabs id="table-tab" activeKey='BOM_KIT'>
                            <Tab eventKey={'BOM_KIT'} title={productConstant.BOM_KIT_TABLE_NAME}>
                              {tableDataList != null &&
                                <Row>
                                  {tableColumnList != null && tableColumnList.length > 0 ?
                                    <div>
                                      <Table columns={tableColumnList}
                                        data={tableDataList}
                                        config={tableConfig}
                                        getRowProps={this.getTdProps}
                                        that={this}
                                      />
                                      {/*{<div className="add-new-section">
                                        <Col md={12}>
                                          {!CommonUtil.isViewMode(this.props.actionMode) ?
                                            <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                              <i className=" fa fa-plus" />
                                              Add Row
                                            </div>
                                            : null}
                                        </Col>
                                      </div>}*/}
                                    </div>
                                    : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                </Row>}
                            </Tab>
                          </Tabs> : null}
                    </div>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSubmit}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row >
        </Grid >
        {this.state.openModal == true ?
          <CreateSupplierModalFp getCompleteDetails={this.getCompleteDetails} /> : null
        }
      </div >
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.product.productDetails,
    supplierDetails: state.supplier.supplierDetails,
    selectedProductCode: state.product.selectedProductCode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    productList: state.product.productList,
    // ingredientList: state.ingredient.ingredientList,
    supplierList: state.supplier.supplierList,
    // operationList: state.operation.operationDetails,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setProductDetails: (productDetailsObj, actionMode) => dispatch(setProductDetails(productDetailsObj, actionMode)),
  getProductDetails: selectedProductCode => dispatch(getProductDetails(selectedProductCode)),
  getSupplierDetails: selectedSupplierCode => dispatch(getSupplierDetails(selectedSupplierCode)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  // getIngredientList: (params) => dispatch(getIngredientList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  // getOperationDetails: (params) => dispatch(getOperationDetails(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateProduct);
