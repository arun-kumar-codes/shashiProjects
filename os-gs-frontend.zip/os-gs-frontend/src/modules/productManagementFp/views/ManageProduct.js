import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, FormGroup, ControlLabel, Form } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as productConstant from "../constant/productConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import { connect } from "react-redux";
import { setSelectedProductCode, getProductList, updateProductStatus, getProductSearchList } from "../actions/productActions";
import { setActionMode } from "../../../actions/appActions";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import PaginationUtil from "../../common/util/paginationUtil";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import filter from 'assets/img/filter.svg';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import StatusUtil from '../../common/util/statusUtil';
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import product from "assets/img/product-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import TextBoxUtil from '../../common/util/textBoxUtil';
import { stat } from "fs";
import check from "assets/img/check.svg";

class ManageProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: statusConstant.ACTIVE_STATUS,
      alert: null,
      redirect: false,
      redirectUrl: null,
      productId: null,
      status: null,
      activate: false,
      search: null,
      statusfilter: false,

      additionalParams: {},
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      propertiesInnitialized: false,
      userPermissions: [],
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage product loaded");
    let status = CommonUtil.getAdditonalPathParams(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.setSelectedTabDetails(status);
    this.setState({ status: status });
  }

  setSelectedTabDetails = async (status) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    var additionalParams = {};
    if (status == statusConstant.INACTIVE_STATUS) {
      this.setState({ selectedFilter: statusConstant.INACTIVE_STATUS });
      additionalParams.status = statusConstant.INACTIVE_STATUS;
    } else if (status && status.family != null) {
      additionalParams.family = status.family;
    } else if (status) {
      additionalParams.status = status;
    }
    const { location, history } = this.props;
    history.replace();
    const managePageList = pagePropertyListConstant.MANAGE_PRODUCT_PAGE_LIST(this);
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (prevProps.productList != this.props.productList && this.props.productList != null) {
      PaginationUtil.handlePagination(this.props.productList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleAjaxResponse() {
    let additionalData = this.props.ajaxCallStatus.additionalData;
    if (this.props.ajaxCallStatus.status == "SUCCESS" && additionalData.deactiveFlag) {
      this.props.setAjaxCallStatus(null);
      if (this.state.activate == true) {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      } else {
        this.props.handleClick(CommonUtil.prepareDeactivateSuccessPopUpConfig());
      }
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      PopupUtil.popupErrorResponse(this);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.productList.Items.filter((value) => {
      return (
        String(value.productId).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  };

  handleFIlter = (event) => {
    PaginationUtil.initPaginationParams(this);
    let status = event.toLowerCase();
    if (status == statusConstant.INACTIVE_STATUS) {
      this.setSelectedTabDetails(status);
    } else {
      this.setSelectedTabDetails();
    }
    this.setState({ selectedFilter: event, status: status, statusfilter: true });
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  advanceSearch = async () => {
    if(CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim()});
      this.setSelectedTabDetails(this.state.status);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  // closeSearchBox = () => {
  //   this.state.attributeObj.orderNumber = '';
  //   this.setState({ menuOpen: false });
  // }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedProductCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(productConstant.CREATE_PRODUCT_PAGE_URL, this);
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == productConstant.CREATE_PRODUCT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(
        productConstant.CREATE_PRODUCT_PAGE_URL,
        this
      );
    }

    if (tempId[2] == productConstant.ACTIVE_PRODUCT) {
      this.handleStatusAction(tempId[0], statusConstant.ACTIVE_STATUS);
      this.setState({ statusfilter: false,activate: true });
    }

    if (tempId[2] == productConstant.DEATIVATE_PRODUCT) {
      this.setState({
        productId: tempId[0],
        status: statusConstant.INACTIVE_STATUS,
        activate: false,
        statusfilter: false,
      });
      var popupActionButton = {};
      popupActionButton.onConfirmClick = this.handleStatusAction;
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeactivatePopUpConfig(
        popupActionButton,
        productConstant.MODULE_NAME
      );
      this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleStatusAction(productId, status) {
    var tempObj = {};
    tempObj.productId = productId ? productId : this.state.productId;
    tempObj.status = status ? status : this.state.status;
    let additionalData = {};
    additionalData.deactiveFlag = true;
    PaginationUtil.initPaginationParams(this);
    this.setState({ alert: null, filter: null, selectedFilter: statusConstant.ACTIVE_STATUS });
    this.props.updateProductStatus(tempObj, additionalData);
  }

  makeCustomAPICall(tempParamas) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getProductSearchList(tempParamas);
    } else {
      this.props.getProductList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      await this.setState({ search: null, searchInput: ""});
      await this.setSelectedTabDetails(this.state.status);
    }
    if (tempId[1] === "status") {
      await this.setState({ statusfilter: false, status: null, selectedFilter: statusConstant.ACTIVE_STATUS, lastEvaluatedKeyArray: []});
      await this.setSelectedTabDetails();
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter, attributeList, attributeObj, submitted, search, status, statusfilter } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ? (
          <Redirect push to={this.state.redirectUrl}></Redirect>
        ) : null}
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={product} alt="" className="page-icon" />
                  {productConstant.MANAGE_PRODUCT_HEADER_TITLE}
                </div>
              </Col>

              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl
                        type="text"
                        name="searchInput"
                        placeholder="Search By Product Code/Name"
                        value={this.state.searchInput}
                        onChange={this.handleChange}
                      />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? {cursor: 'default'} : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {/*<Nav pullRight className="advance-filter">
                    <NavDropdown title={<div className="filter"> <i className="fa fa-ellipsis-v"></i>  </div>}
                      noCaret id="search-filter" className="filter-search filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)
                                : null))
                            }
                          </Row>
                        </Form>
                      </MenuItem>
                      <div className="search-btns">
                        <Button className="btn-cancel" onClick={this.closeSearchBox}>
                          Cancel
                        </Button>
                        <Button className="btn-save btn-fill btn-wd" onClick={this.advanceSearch}>
                          Search
                        </Button>
                      </div>
                    </NavDropdown>
                  </Nav>*/}

                  <Nav pullRight>
                    <NavDropdown
                      title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status"
                      onSelect={this.handleFIlter}>
                      <MenuItem eventKey={statusConstant.ACTIVE_STATUS}
                        className={CommonUtil.isBothEqual(selectedFilter, statusConstant.ACTIVE_STATUS) ? 'active' : null}>
                        {StatusUtil.getStatusLabel(statusConstant.ACTIVE_STATUS)}
                      </MenuItem>
                      <MenuItem eventKey={statusConstant.INACTIVE_STATUS}
                        className={CommonUtil.isBothEqual(selectedFilter, statusConstant.INACTIVE_STATUS) ? 'active' : null}>
                        {StatusUtil.getStatusLabel(statusConstant.INACTIVE_STATUS)}
                      </MenuItem>
                    </NavDropdown>
                  </Nav>

                  {
                    isAuthorized("createProduct") &&
                    <Button id={"saleOrderId" + "_" + commonConstant.MENU_ACTION_MODE + "_" + productConstant.CREATE_PRODUCT}
                      fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                        </Button>
                  }



                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {statusfilter || search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ? 
                            <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                          {statusfilter ? 
                            <div className="filtertag">{StatusUtil.getStatusLabel(status)} <i id="filter-status" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                      </div>
                    : null }
                    {tableColumnList != null ? (
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                    ) : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    productList: state.product.productList,
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    productSearchList: state.product.productSearchList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setSelectedProductCode: (selectedProductCode) => dispatch(setSelectedProductCode(selectedProductCode)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getProductList: (id) => dispatch(getProductList(id)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  updateProductStatus: (productDetails, additionalData) => dispatch(updateProductStatus(productDetails, additionalData)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getProductSearchList: params => dispatch(getProductSearchList(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageProduct);
