import React, { useState, useCallback } from 'react';
import { Row, Col, FormGroup, ControlLabel, FormControl } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import * as constants from "../../constant/integrationConstant";
import axios from '../../../../axios/axios';

const StoreView = (props) => {

  const [address, setAddress] = useState('');
  const [errorMsg, setErrorMsg] = useState(false);

  const changeAddressHandler = useCallback((evt) => {
    setAddress(evt.target.value);
    evt.target.value == "" ?
      setErrorMsg(true) : setErrorMsg(false);
  }, []);

  const authorizeStore = useCallback((evt) => {
    const regex = /^[a-z\d_.-]+[.]amazon[.]com$/;
    let isValidStoreURL = false;
    if (address.match(regex)) {
      isValidStoreURL = true;
      setErrorMsg(false);
    } else {
      isValidStoreURL = false;
      setErrorMsg(true);
    }

    if (isValidStoreURL) {
      axios.post(constants.GET_SHOPIFY_API_KEY_URL).then(response => {
        props.updateStep(2);
        props.setShopAddress(address);
        props.setApiKey(response.data);
      }).catch(error => {
        console.log(error);
      });
    }
  }, [address, setErrorMsg]);

  return (
    <Row>
      <Col md={12}>
        <form>
          <Card
            content={
              <Row>
                <Col md={8}>
                  <div className="store-view-wrapper">
                    <FormGroup
                      controlId="storeAddress"
                    >
                      <ControlLabel>Enter your Amazon Store address to get started</ControlLabel>
                      <FormControl
                        type="text"
                        value={address}
                        placeholder="Your Store address"
                        onChange={changeAddressHandler}
                      />
                      {errorMsg ?
                        <small className="text-danger">
                          Please enter correct address.
                        </small> : null}
                    </FormGroup>
                  </div>
                </Col>
              </Row>
            }
            ftTextRight
            legend={
              <div>
                <Button className="btn-cancel" onClick={props.closeModal}>Cancel</Button>
                <Button className="btn-save btn-fill btn btn-default" onClick={authorizeStore}>Authorize</Button>
              </div>
            }
          />
        </form>
      </Col>
    </Row>
  );
};

export default StoreView;
