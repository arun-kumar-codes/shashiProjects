import React, { useEffect, useState, useRef } from 'react';

const createPopup = ({ url, title, height, width, }) => {
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2.5;
    const externalPopup = window.open(url, title, `width=${width},height=${height},left=${left},top=${top}`);
    return externalPopup;
};
const AmazonPopup = ({ title = '', width = 500, height = 500, url, children, onCode, onClose }) => {
    const [externalWindow, setExternalWindow] = useState();
    const intervalRef = useRef();

    const clearTimer = () => {
        window.clearInterval(intervalRef.current);
    };
    const onContainerClick = () => {
        setExternalWindow(createPopup({
            url, title, width, height,
        }));
    };

    useEffect(() => {
        if (externalWindow) {
            intervalRef.current = window.setInterval(() => {
                try {
                    const currentUrl = externalWindow.location.href;
                    const params = new URL(currentUrl).searchParams;
                    const code = params.get('spapi_oauth_code');
                    if (!code) {
                        return;
                    } else {
                        clearTimer();
                        externalWindow.close();
                    }
                    onCode(code, params);
                    clearTimer();
                }
                catch (error) {
                    // eslint-ignore-line
                }
                finally {
                    if (!externalWindow && externalWindow.closed) {
                        onClose();
                        clearTimer();
                    }
                }
            }, 700);
        }
        return () => {

            if (externalWindow) {
                externalWindow.close();
            }
            if (onClose)
                onClose();
        };
    });
    return (
        React.createElement("div", {
            onClick: () => {
                onContainerClick();
            }
        }, children));
};
export default AmazonPopup;