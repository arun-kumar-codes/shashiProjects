import React, { PureComponent } from "react";
import { SketchPicker } from "react-color";
import Button from "components/CustomButton/CustomButton.jsx";
// import "./ColorPicker.css";
// import { SwatchesPicker } from 'react-color'
// import { TwitterPicker } from "react-color";
import { Col } from "react-bootstrap";
class ColorPicker extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      showPicker: false,
    };

    this.toggleColor = this.toggleColor.bind(this);
    this.handleChangeComplete = this.handleChangeComplete.bind(this);
  }

  componentWillReceiveProps({ value }) {
    this.setState({ color: value });
  }

  toggleColor(e) {
    e.preventDefault();

    this.setState({
      showPicker: !this.state.showPicker,
    });
  }

  closeColorPallet = () => {
    this.setState({ showPicker: false });
  };

  handleChangeComplete(color) {
    const { onColorChange } = this.props;
    this.setState({ color: color.hex });
    onColorChange(color.hex);
    this.setState({ showPicker: false });
  }

  render() {
    return (
      <div className="color-picker__container">
        <Button onClick={this.toggleColor}>
          <div
            className="color-picker__color"
            style={{ backgroundColor: this.state.color }}
          ></div>
        </Button>
        {this.state.showPicker && (
          <div className="color-picker__picker" >
            <SketchPicker
              color={this.state.color}
              onChangeComplete={this.handleChangeComplete}
              disableAlpha={true}
              width={250}
            />
          </div>
        )}
      </div>
    );
  }
}

export default ColorPicker;
