import SvgColor from 'src/components/svg-color';

// ----------------------------------------------------------------------

const icon = (name) => (
  <SvgColor src={`/assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />
);

const navConfig = [
  {
    title: 'home',
    path: '/home',
    icon: icon('ic_analytics'),
  },
  {
    title: 'Sellers',
    path: '/home/user',
    icon: icon('ic_user'),
  },
  {
    title: 'Properties',
    path: '/home/products',
    icon: icon('ic_cart'),
  },
  {
    title: 'blog',
    path: '/home/blog',
    icon: icon('ic_blog'),
  },
  {
    title: 'Media',
    path: '/home/media',
    icon: icon('ic_lock'),
  },
  {
    title: 'Not found',
    path: '/404',
    icon: icon('ic_disabled'),
  },
];

export default navConfig;
