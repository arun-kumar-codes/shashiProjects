import { banner1, banner2, banner3} from "../assets/banners";
import { mobile1,mobile2,mobile3} from "../assets/banners/mobile";

export const BannerData = [
    {
        id : 1,
        img: banner1,
        smimg:mobile1
    },
    {
        id : 2,
        img: banner2,
        smimg:mobile2
    },
    {
        id : 3,
        img: banner3,
        smimg:mobile3
    },
    
    
]