import React from 'react';
import { Route, Redirect } from 'react-router-dom';

const PrivateRoute = ({ component: Component, authPage, ...rest }) => {
	const session = localStorage.getItem('user');

	if (authPage)
		return (
			<Route
				{...rest}
				render={(props) =>
					session ? <Component {...props} /> : <Redirect to={'/login'} />
				}
			/>
		);
	else
		return (
			<Route
				{...rest}
				render={(props) =>
					!session ? (
						<Component {...props} />
					) : (
						<Redirect to={'/app/homepage'} />
					)
				}
			/>
		);
};

export default PrivateRoute;
