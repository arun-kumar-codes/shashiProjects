import React from 'react';
import empty_page from '../../common/assets/images/Wefund.jpg';
// import empty_page from '../../common/assets/images/Webinar_Oct.jpg';

const HiddenPage1 = () => {
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				height: '100vh',
				margin: 0,
				padding: 0
			}}
		>
			<img
				src={empty_page}
				alt="Beautiful Picture xd"
				style={{ maxWidth: '100%', height: 'auto' }}
			/>
		</div>
	);
};

export default HiddenPage1;
