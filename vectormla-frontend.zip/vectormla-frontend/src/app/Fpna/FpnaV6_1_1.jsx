import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Divider, Grid, CircularProgress } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolioFPNA,
	downloadFPNATemplate,
	deletePortfolio,
	updatePortfolio,
	getScenarioFPNADetails,
	getPortfolioScenarios,
	getCalcStatus,
	runCalculate,
	downloadDataFile,
	downloadFpnaCustomReports,
	getSubPortofolios,
	getSegment,
	getPrepayment6_1_1Charts
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import Chart from 'app/components/Chart/Chart';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import {
	GET_FPNA6_TABLES_CLEAN,
	GET_CHARTS6_CLEAN,
	TASK_PROGRESS_FPNA6,
	STOP_FPNA6_TIMER
} from '../store/types/fpna.type';
import { dynamicHeaders } from './liabilityTableFileds';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import {
	requiredTablesFpnaV6_1_1,
	tableDataFpnaV6_1_1,
	tableDataFpnaV6_1_1_second
} from './fpna6Assets';
const FpnaV6_1_1 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios6,
		tables6,
		status6,
		scenarios6,
		staus6ScenarioID,
		subPortofolio6,
		prepayment_6_1_1_charts
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);
	// state to check first time status if success
	const [timerStarted, setTimerStarted] = useState(false);
	const [chartVisible, setChartVisible] = useState(false);
	const [chartVisible2, setChartVisible2] = useState(false);
	const [chartsData, setChartsData] = useState([]);
	const [chartsData2, setChartsData2] = useState([]);

	useEffect(() => {
		if (selectedSubPorofolio?.[0]?.id) {
			dispatch(getPrepayment6_1_1Charts(selectedSubPorofolio?.[0]?.id));
		}
	}, [selectedSubPorofolio]);
	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		// if (Object.keys(prepayment_6_1_1_charts || {}).length > 0)
		// 	fetchScenariosDetails(Object.keys(prepayment_6_1_1_charts));
		selectedScenario[0]?.id && fetchSubPorofolios4(selectedScenario[0]);
		// for charts data
	}, [selectedScenario]);

	const fetchSubPorofolios4 = () => {
		dispatch(
			getPrepayment6_1_1Charts(
				selectedScenario[0]?.id,
				(scenriosSubPortofolios) => {
					setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
					scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
				}
			)
		);
	};
	useEffect(() => {
		let chart1 = [];
		let chart2 = [];
		let chart3 = [];
		let chart4 = [];
		let chart5 = [];
		let chart6 = [];

		let tempChart1 = [];
		let tempChart2 = [];
		let tempChart3 = [];
		let tempChart4 = [];
		let tempChart5 = [];
		let tempChart6 = [];

		if (subPortofolio6?.parallel) {
			subPortofolio6?.parallel?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of parallel and exclude x-label
				for (let key in subPortofolio6?.parallel) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.parallel[key][i];
					}
				}

				tempChart1.push(tempObj);
			});
		}
		chart1.push(tempChart1);

		if (subPortofolio6?.non_parallel) {
			subPortofolio6?.non_parallel?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of non_parallel and exclude x-label
				for (let key in subPortofolio6?.non_parallel) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.non_parallel[key][i];
					}
				}

				tempChart2.push(tempObj);
			});
		}
		chart2.push(tempChart2);

		if (subPortofolio6?.short_term) {
			subPortofolio6?.short_term?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of short_term and exclude x-label
				for (let key in subPortofolio6?.short_term) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.short_term[key][i];
					}
				}

				tempChart3.push(tempObj);
			});
		}
		chart3.push(tempChart3);

		if (subPortofolio6?.long_term) {
			subPortofolio6?.long_term?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of long_term and exclude x-label
				for (let key in subPortofolio6?.long_term) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.long_term[key][i];
					}
				}

				tempChart4.push(tempObj);
			});
		}
		chart4.push(tempChart4);

		if (subPortofolio6?.swap) {
			subPortofolio6?.swap?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of swap and exclude x-label
				for (let key in subPortofolio6?.swap) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.swap[key][i];
					}
				}
				tempChart5.push(tempObj);
			});
		}
		chart5.push(tempChart5);

		if (subPortofolio6?.historical_swap_chart) {
			subPortofolio6?.historical_swap_chart?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of historical_swap_chart and exclude x-label
				for (let key in subPortofolio6?.historical_swap_chart) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.historical_swap_chart[key][i];
					}
				}
				tempChart6.push(tempObj);
			});
		}
		chart6.push(tempChart6);

		let updatedCharts = [
			{
				ch: chart1,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart2,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart3,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart4,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart5,
				xIndex: 'x-axis',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart6,
				xIndex: 'x-axis',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			}
		];
		setChartsData(updatedCharts);
	}, [chartVisible, chartVisible2, subPortofolio6]);

	useEffect(() => {
		//PREPAYMENT CHARTS
		let chart1 = [];
		let chart2 = [];

		let tempChart1 = [];
		let tempChart2 = [];

		if (prepayment_6_1_1_charts?.prepay_cpr) {
			prepayment_6_1_1_charts?.prepay_cpr?.['x-axis'].forEach((val1, i) => {
				let tempObj2 = { date: val1 };

				// Loop through keys of prepay_cpr and exclude x-label
				for (let key in prepayment_6_1_1_charts?.prepay_cpr) {
					if (key !== 'x-label') {
						// Check if the value is a string and contains a percent sign
						if (
							typeof prepayment_6_1_1_charts.prepay_cpr[key][i] === 'string' &&
							prepayment_6_1_1_charts.prepay_cpr[key][i].includes('%')
						) {
							// Remove the percent sign and convert to number
							tempObj2[key] = parseFloat(
								prepayment_6_1_1_charts.prepay_cpr[key][i].replace('%', '')
							);
						} else {
							// If no conversion is needed, use the value as is
							tempObj2[key] = prepayment_6_1_1_charts.prepay_cpr[key][i];
						}
					}
				}

				tempChart1.push(tempObj2);
			});
			chart1.push(tempChart1);
		}

		if (prepayment_6_1_1_charts?.prepay_smm) {
			prepayment_6_1_1_charts?.prepay_smm?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of prepay_smm and exclude x-label
				for (let key in prepayment_6_1_1_charts?.prepay_smm) {
					if (key !== 'x-label') {
						// Check if the value is a string and contains a percent sign
						if (
							typeof prepayment_6_1_1_charts.prepay_smm[key][i] === 'string' &&
							prepayment_6_1_1_charts.prepay_smm[key][i].includes('%')
						) {
							// Remove the percent sign and convert to number
							tempObj[key] = parseFloat(
								prepayment_6_1_1_charts.prepay_smm[key][i].replace('%', '')
							);
						} else {
							// If no conversion is needed, use the value as is
							tempObj[key] = prepayment_6_1_1_charts.prepay_smm[key][i];
						}
					}
				}

				tempChart2.push(tempObj);
			});
			chart2.push(tempChart2);
		}

		let updatedCharts2 = [
			{
				ch: chart1,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart2,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			}
		];
		setChartsData2(updatedCharts2);
	}, [chartVisible2, prepayment_6_1_1_charts]);

	useEffect(() => {
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
		selectedScenario[0]?.id && fetchSubPorofolios4(selectedScenario[0]);
	}, [selectedScenario]);

	useEffect(() => {
		if (!portfolios6 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		else setSelectedPortfolio(portfolios6?.[0]);
		if (staus6ScenarioID) {
			setRunningTaskId();
			stopTimerFunction();
			dispatch(stopTimer('cfm6', 'STOPPED', () => setTimerStarted(false)));
		}
	}, [portfolios6]);

	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		if (Object.keys(tables6 || {}).length > 0)
			fetchScenariosDetails(Object.keys(tables6));
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
		// for charts data
	}, [selectedScenario]);

	const dispatchClean = (/*unmount*/ callBack) => {
		dispatch({
			type: GET_FPNA6_TABLES_CLEAN
			// payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS6_CLEAN });
		stopTimerFunction();
		dispatch(
			stopTimer('cfm6', 'change', () => {
				setTimerStarted(false);
				callBack && callBack();
			})
		);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (selectedScenario[0] && status6 === 'SUCCESS') {
			fetchScenariosDetails();
			setTimerStarted(false);
		}
		selectedScenario[0] &&
			(status6 === 'STOPPED' ||
				status6 === 'FAILURE' ||
				status6 === 'stopped') &&
			calculateStatus(selectedScenario[0]?.id, true);
	}, [status6]);

	const fetchSubPorofolios = () => {
		dispatch(
			getSubPortofolios(
				'6',
				selectedScenario[0]?.id,
				(scenriosSubPortofolios) => {
					setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
					scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
				}
			)
		);
	};

	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('6', supPorofolioId));
	};

	const fetchScenarioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getScenarioFPNADetails('6', selectedScenario[0]?.id, type, (data) => {
				if (type === 'default-vintage') {
					const finalObject = {};
					Object.keys(data?.vintage_df?.category).forEach((item) => {
						finalObject[item] = data?.vintage_df?.category[item];
					});
				}
			})
		);
	};

	const fetchScenariosDetails = async (openedTables) => {
		const fetchPromises = (openedTables || requiredTablesFpnaV6_1_1).map(
			(table) => fetchScenarioDetails(selectedScenario[0]?.id, table + '/')
		);
		// this line is to wait for all the promises to resolve
		await Promise.all(fetchPromises);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('6', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};
	const uploadFunction = (formData) => {
		dispatchClean(() => {
			dispatch(
				updatePortfolio(
					'6',
					selectedPortfolio?.id,
					formData,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchScenarios(selectedPortfolio?.id, 'create');
					},
					'fpna6'
				)
			);
			dispatch({
				type: TASK_PROGRESS_FPNA6,
				payload: '0.0 %'
			});
		});
	};
	const setDataFunction = (val) => {
		setDataType(val);
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
		if (tables6) fetchScenarioDetails(selectedScenario[0]?.id, val);
	};
	const updateFunction = (name) => {
		dispatchClean(() =>
			dispatch(
				updatePortfolio('6', selectedPortfolio?.id, { name }, () => {
					fetchPortfolio();
				})
			)
		);
	};
	const createFunction = (name, file) => {
		dispatchClean(() =>
			dispatch(
				createPortfolioFPNA(
					'6',
					name,
					user?.company_id,
					file,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchPortfolio('create');
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: '0.0 %'
						});
					},
					'fpna6'
				)
			)
		);
	};
	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('6', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, create);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, create) => {
		dispatch(
			getPortfolioScenarios('6', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm6', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const calculateStatus = (supPorofolioId, checkInStart) => {
		getCalcStatus(
			'cfm6/portfolio',
			selectedSubPorofolio[0]?.id || selectedScenario?.[0]?.id,
			(res) => {
				if (checkInStart && res?.task_state === 'SUCCESS') {
					setTimerStarted(false);
					return;
				} else {
					dispatch(startTimer('cfm6', supPorofolioId, ''));
					setRunningTaskId(selectedPortfolio?.id);
					setTimerStarted(true);
					if (res.task_state !== 'SUCCESS' && res.task_state !== 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: res.task_progress
						});
					}
					if (res.task_state === 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: 'Failed'
						});
						dispatch(
							killTaskFunc('cfm6', selectedPortfolio?.id, () => {
								deleteFunction();
								setRunningTaskId();
								stopTimerFunction();
								dispatch(
									stopTimer('cfm6', 'STOPPED', () => setTimerStarted(false))
								);
							})
						);
					}
				}
			}
		);
	};
	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('6', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};
	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA6_TIMER,
			payload: { status6: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog, callBack) => {
		let id = selectedPortfolio?.id;
		if (('' + status6)?.toLowerCase() === 'pending') {
			let modelName = 'cfm6';
			dispatch(
				killTaskFunc(modelName, id, () => {
					deleteFunction();
					closeKillTaskDialog && closeKillTaskDialog();
					setRunningTaskId();
					stopTimerFunction();
					dispatch(
						stopTimer(modelName, 'STOPPED', () => {
							setTimerStarted(false);
							callBack && callBack();
						})
					);
				})
			);
		} else {
			setTimerStarted(false);
			callBack && callBack();
		}
	};
	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
	}, [collapsed]);
	useEffect(() => {
		if (collapsed >= 1) setChartVisible2(true);
		else if (collapsed === 0 && chartVisible2) setChartVisible2(false);
	}, [collapsed]);
	const typeHeaders = (tableName, category) => {
		if (tableName) return dynamicHeaders(category);
		else return null;
	};
	const renderChart = () => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
				>
					<p className={classes.contentHeader}>
						{'SOFR Projected Rates Charts'}
					</p>
				</div>
				{chartVisible &&
				subPortofolio6 &&
				Object.keys(subPortofolio6).length > 0 ? (
					<div className={classes.datechat__charts}>
						<br />
						{chartsData?.length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								{subPortofolio6?.parallel && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData?.[0]?.ch}
											nameLegend={`Parallel Shift`}
											brushID={`Parallel Shift`}
											sizeLegend="14px"
											dataX={`x-axis`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												subPortofolio6?.parallel || {}
											).filter((key) => key !== 'x-axis' && key !== 'period')}
											customTooltip
										/>
									</Grid>
								)}
								{subPortofolio6?.non_parallel && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData?.[1]?.ch}
											nameLegend={`Steepner/Flatner`}
											brushID={`Steepner/Flatner`}
											sizeLegend="14px"
											dataX={`x-axis`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												subPortofolio6?.non_parallel || {}
											).filter((key) => key !== 'x-axis' && key !== 'period')}
											customTooltip
										/>
									</Grid>
								)}
								{subPortofolio6?.short_term && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData?.[2]?.ch}
											nameLegend={`Short Term Up/Down`}
											brushID={`Short Term Up/Down`}
											sizeLegend="14px"
											dataX={`x-axis`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												subPortofolio6?.short_term || {}
											).filter((key) => key !== 'x-axis' && key !== 'period')}
											customTooltip
										/>
									</Grid>
								)}
								{subPortofolio6?.long_term && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData?.[3]?.ch}
											nameLegend={`Long Term Up/Down`}
											brushID={`Long Term Up/Down`}
											sizeLegend="14px"
											dataX={`x-axis`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												subPortofolio6?.long_term || {}
											).filter((key) => key !== 'x-axis' && key !== 'period')}
											customTooltip
										/>
									</Grid>
								)}
							</Grid>
						)}
					</div>
				) : chartVisible ? (
					<div className={classes.progressContainer}>
						<CircularProgress
							style={{
								color: '#266696',
								marginTop: 0,
								marginLeft: '49%'
							}}
							size={26}
						/>
					</div>
				) : null}
			</div>
		);
	};

	const renderChartPrepayment = () => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible2(!chartVisible2)}
				>
					<p className={classes.contentHeader}>{'Prepayment Charts'}</p>
				</div>
				{chartVisible2 &&
				prepayment_6_1_1_charts &&
				Object.keys(prepayment_6_1_1_charts).length > 0 ? (
					<div className={classes.datechat__charts}>
						<br />
						{chartsData2?.length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								{prepayment_6_1_1_charts?.prepay_cpr && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[0]?.ch}
											nameLegend={`Prepayment CPR`}
											brushID={`Prepayment CPR`}
											sizeLegend="14px"
											dataX={`period`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												prepayment_6_1_1_charts?.prepay_cpr
											).filter(
												(key) =>
													key !== 'x-axis' &&
													key !== 'x-label' &&
													key !== 'period'
											)}
											customTooltip
										/>
									</Grid>
								)}
								{prepayment_6_1_1_charts?.prepay_smm && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[1]?.ch}
											nameLegend={`Prepayment SMM`}
											brushID={`Prepayment SMM`}
											sizeLegend="14px"
											dataX={`period`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												prepayment_6_1_1_charts?.prepay_smm
											).filter(
												(key) =>
													key !== 'x-axis' &&
													key !== 'x-label' &&
													key !== 'period'
											)}
											customTooltip
										/>
									</Grid>
								)}
								{/*prepayment_6_1_1_charts?.prepay_smm && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6}
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData2?.[1]?.ch}
													nameLegend={`Prepayment SMM`}
													brushID={`Prepayment SMM`}
													sizeLegend="14px"
													dataX={`x-axis`}
													xDistance={400}
													format={'per'}
													noCharts={Object.keys(
														prepayment_6_1_1_charts?.prepay_smm
													).filter(
														(key) =>
															key !== 'x-axis' &&
															key !== 'x-label' &&
															key !== 'period'
													)}
													customTooltip
												/>
											</Grid>
										)*/}
								{/*prepayment_6_1_1_charts?.prepay_smm && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6}
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData2?.[1]?.ch}
													nameLegend={`Prepay SMM`}
													brushID={`Prepay SMM`}
													sizeLegend="14px"
													dataX={`x-axis`}
													xDistance={400}
													format={'per'}
													noCharts={Object.keys(
														prepayment_6_1_1_charts?.prepay_smm
													).filter(
														(key) => key !== 'x-axis' && key !== 'x-label'
													)}
													customTooltip
												/>
											</Grid>
										)*/}
							</Grid>
						)}
					</div>
				) : chartVisible2 ? (
					<div className={classes.progressContainer}>
						<CircularProgress
							style={{
								color: '#266696',
								marginTop: 0,
								marginLeft: '49%'
							}}
							size={26}
						/>
					</div>
				) : null}
			</div>
		);
	};

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator,
		extraMultiSeparator
	) => {
		let finalTableName =
			tableName === 'specialtable2' ? 'assetamort_table' : tableName;

		if (['Vintage', 'Portfolio'].includes(verboseTableName)) return null;

		const fetchData = () => {
			const tableKeys = Object.keys(tables6 || {});
			const isTableDataMissing = !tableKeys.includes(tableName);

			if (
				(['stopped', 'SUCCESS'].includes(('' + status6).toLowerCase()) &&
					isTableDataMissing) ||
				staus6ScenarioID !== selectedScenario?.[0]?.id
			) {
				fetchScenarioDetails(selectedScenario[0]?.id, tableName + '/');
			}
		};

		return (
			<div>
				{[
					'Historical SOFR Rates',
					'NI - Scenario Shocks',
					'PV and Duration',
					'Prepayment Curve Percent'
				].includes(verboseTableName) ? (
					<>
						<div
							style={{
								marginTop: verboseTableName === 'Balance Sheet ' ? 20 : 30
							}}
						></div>
						<hr />
						<div style={{ marginTop: 20 }}></div>
					</>
				) : (
					''
				)}
				<MainTable
					statusScenarioId={staus6ScenarioID}
					status={('' + status6).toLowerCase()}
					header={tableData && tableData[finalTableName]?.columns}
					data={tableData && tableData[finalTableName]}
					attributes={
						tableData &&
						tableData[finalTableName]?.data &&
						Object.keys(tableData[finalTableName]?.columns)
					}
					tableData={tableData}
					multiSeparator={multiSeparator}
					extraMultiSeparator={extraMultiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableDataName={finalTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					collapsed={collapsed}
					separator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								multiSeparator ? 'category' : 'category2'
							]
					)}
					nestedSeparator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							!multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								!multiSeparator ? 'category' : 'category2'
							]
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model="6"
					id={selectedScenario[0]?.id}
					modelName="fpna6"
					fetchData={fetchData}
				/>
			</div>
		);
	};

	const renderTables = () => {
		return tableDataFpnaV6_1_1.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				tables6,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};

	const renderTables2 = () => {
		return tableDataFpnaV6_1_1_second.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				tables6,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};

	if (
		!user?.allowed_pages?.includes(1) ||
		!user?.allowed_section1.includes(109)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />
			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							dispatchClean={() => dispatchClean()}
							model={'fpna6-1-1'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							timerStarted={timerStarted}
							loading={('' + status6).toLowerCase() === 'pending'}
							key={1006}
							portfolioList={portfolios6 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios6.filter((item) => item.id == val)[0]
								);
							}}
							// create={(name, file) => createFunction(name, file)}
							// update={(name) => updateFunction(name)}
							// deleteObj={() => deleteFunction()}
							upload={(formData) => uploadFunction(formData)}
							downloadFile={() => {
								dispatch(downloadDataFile('6', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('6'));
							}}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios6?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => setSelectedScenario([item])}
							setData={(val) => setDataFunction(val)}
							downloadCustomReports={(type) => {
								dispatch(
									downloadFpnaCustomReports('6', selectedScenario[0]?.id, type)
								);
							}}
							collapsed={collapsed}
							runCalculateFunction={runCalculateFunction}
							selectedData={dataType}
							seconds={0}
							status={status6}
							minutes={0}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<>{renderTables()}</>
						{renderChart()}
						<>{renderTables2()}</>
						{renderChartPrepayment()}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default FpnaV6_1_1;
