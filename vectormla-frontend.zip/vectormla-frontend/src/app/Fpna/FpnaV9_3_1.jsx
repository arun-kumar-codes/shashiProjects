import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Divider, Grid, CircularProgress } from '@material-ui/core';
import { useStyles } from './fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolioFPNA,
	downloadFPNATemplate,
	deletePortfolio,
	updatePortfolio,
	getScenarioFPNADetails,
	getPortfolioScenarios,
	getCalcStatus,
	runCalculate,
	downloadDataFile,
	downloadFpnaCustomReports,
	getSubPortofolios,
	getSegment
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import Chart from 'app/components/Chart/Chart';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import {
	GET_FPNA9_TABLES_CLEAN,
	GET_CHARTS9_CLEAN,
	TASK_PROGRESS_FPNA9,
	STOP_FPNA9_TIMER
} from '../store/types/fpna.type';
import { dynamicHeaders } from './liabilityTableFileds';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import { requiredTablesFpnaV9_3_1, tableDataFpnaV9_3_1 } from './fpna9Assets';
const FpnaV9_3_1 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios6,
		portfolios9,
		tables9,
		status9,
		scenarios9,
		staus9ScenarioID,
		subPortofolio9
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);
	// state to check first time status if success
	const [timerStarted, setTimerStarted] = useState(false);
	const [chartVisible, setChartVisible] = useState(false);
	const [chartVisible2, setChartVisible2] = useState(false);
	const [chartVisible3, setChartVisible3] = useState(false);
	const [chartsData, setChartsData] = useState([]);

	useEffect(() => {
		let chart1 = [];
		let chart2 = [];
		let chart3 = [];
		let chart4 = [];
		let chart5 = [];
		let chart6 = [];
		let tempChart1 = [];
		let tempChart2 = [];
		let tempChart3 = [];
		let tempChart4 = [];
		let tempChart5 = [];
		let tempChart6 = [];
		subPortofolio9?.chart_delinquency?.['date'].forEach((val1, i) => {
			tempChart1.push({
				date: val1,
				status_1a_del_prcnt:
					subPortofolio9?.chart_delinquency?.['status_1a_del_prcnt'][i],
				status_1b_del_prcnt:
					subPortofolio9?.chart_delinquency?.['status_1b_del_prcnt'][i],
				status_2_del_prcnt:
					subPortofolio9?.chart_delinquency?.['status_2_del_prcnt'][i],
				status_3_del_prcnt:
					subPortofolio9?.chart_delinquency?.['status_3_del_prcnt'][i],
				status_4_del_prcnt:
					subPortofolio9?.chart_delinquency?.['status_4_del_prcnt'][i]
			});
			chart1.push(tempChart1);
		});

		if (subPortofolio9?.chart_default) {
			subPortofolio9?.chart_default?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of chart_default and exclude x-label
				for (let key in subPortofolio9?.chart_default) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio9?.chart_default[key][i];
					}
				}

				tempChart2.push(tempObj);
			});
		}
		chart2.push(tempChart2);

		if (subPortofolio9?.chart_closing_balance_cpr_scenarios) {
			subPortofolio9?.chart_closing_balance_cpr_scenarios?.['Date'].forEach(
				(val1, i) => {
					let tempObj = { Date: val1 };

					// Loop through keys of chart_closing_balance_cpr_scenarios and exclude x-label
					for (let key in subPortofolio9?.chart_closing_balance_cpr_scenarios) {
						if (key !== 'Date') {
							tempObj[key] =
								subPortofolio9?.chart_closing_balance_cpr_scenarios[key][i];
						}
					}

					tempChart6.push(tempObj);
				}
			);
		}
		chart6.push(tempChart6);

		subPortofolio9?.chart_closing_balance?.['date'].forEach((val1, i) => {
			tempChart3.push({
				date: val1,
				closing_balance:
					subPortofolio9?.chart_closing_balance?.['closing_balance'][i]
			});
			chart3.push(tempChart3);
		});

		subPortofolio9?.timing_curve?.['period'].forEach((val1, i) => {
			tempChart4.push({
				period: val1,
				cumulative_curve: subPortofolio9?.timing_curve?.['cumulative_curve'][i]
			});
			chart4.push(tempChart4);
		});

		subPortofolio9?.timing_curve?.['period'].forEach((val1, i) => {
			tempChart5.push({
				period: val1,
				timing_curve: subPortofolio9?.timing_curve?.['timing_curve'][i]
			});
			chart5.push(tempChart5);
		});

		let updatedCharts = [
			{
				ch: chart1,
				xIndex: 'date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart2,
				xIndex: 'date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart3,
				xIndex: 'date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart4,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart5,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart6,
				xIndex: 'Date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			}
		];
		setChartsData(updatedCharts);
	}, [chartVisible, chartVisible2, chartVisible3, subPortofolio9]);

	useEffect(() => {
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
	}, [selectedScenario]);

	useEffect(() => {
		if (!portfolios9 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		else setSelectedPortfolio(portfolios9?.[0]);
		if (staus9ScenarioID) {
			setRunningTaskId();
			stopTimerFunction();
			dispatch(stopTimer('cfm9', 'STOPPED', () => setTimerStarted(false)));
		}
	}, [portfolios9]);

	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		if (Object.keys(tables9 || {}).length > 0)
			fetchScenariosDetails(Object.keys(tables9));
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
		// for charts data
	}, [selectedScenario]);

	const dispatchClean = (/*unmount*/ callBack) => {
		dispatch({
			type: GET_FPNA9_TABLES_CLEAN
			// payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS9_CLEAN });
		stopTimerFunction();
		dispatch(
			stopTimer('cfm9', 'change', () => {
				setTimerStarted(false);
				callBack && callBack();
			})
		);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (selectedScenario[0] && status9 === 'SUCCESS') {
			fetchScenariosDetails();
			setTimerStarted(false);
		}
		selectedScenario[0] &&
			(status9 === 'STOPPED' ||
				status9 === 'FAILURE' ||
				status9 === 'stopped') &&
			calculateStatus(selectedScenario[0]?.id, true);
	}, [status9]);

	const fetchSubPorofolios = () => {
		dispatch(
			getSubPortofolios(
				'9',
				selectedScenario[0]?.id,
				(scenriosSubPortofolios) => {
					setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
					scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
				}
			)
		);
	};

	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('9', supPorofolioId));
	};

	const fetchScenarioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getScenarioFPNADetails('9', selectedScenario[0]?.id, type, (data) => {
				if (type === 'default-vintage') {
					const finalObject = {};
					Object.keys(data?.vintage_df?.category).forEach((item) => {
						finalObject[item] = data?.vintage_df?.category[item];
					});
				}
			})
		);
	};

	const fetchScenariosDetails = async (openedTables) => {
		const fetchPromises = (openedTables || requiredTablesFpnaV9_3_1).map(
			(table) => fetchScenarioDetails(selectedScenario[0]?.id, table + '/')
		);
		// this line is to wait for all the promises to resolve
		await Promise.all(fetchPromises);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('9', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};
	const uploadFunction = (formData) => {
		dispatchClean(() => {
			dispatch(
				updatePortfolio(
					'9',
					selectedPortfolio?.id,
					formData,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchScenarios(selectedPortfolio?.id, 'create');
					},
					'fpna9'
				)
			);
			dispatch({
				type: TASK_PROGRESS_FPNA9,
				payload: '0.0 %'
			});
		});
	};
	const setDataFunction = (val) => {
		setDataType(val);
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
		if (tables9) fetchScenarioDetails(selectedScenario[0]?.id, val);
	};
	const updateFunction = (name) => {
		dispatchClean(() =>
			dispatch(
				updatePortfolio('9', selectedPortfolio?.id, { name }, () => {
					fetchPortfolio();
				})
			)
		);
	};
	const createFunction = (name, file) => {
		dispatchClean(() =>
			dispatch(
				createPortfolioFPNA(
					'9',
					name,
					user?.company_id,
					file,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchPortfolio('create');
						dispatch({
							type: TASK_PROGRESS_FPNA9,
							payload: '0.0 %'
						});
					},
					'fpna9'
				)
			)
		);
	};
	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('9', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, create);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, create) => {
		dispatch(
			getPortfolioScenarios('9', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm9', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const calculateStatus = (supPorofolioId, checkInStart) => {
		getCalcStatus(
			'cfm9/portfolio',
			selectedSubPorofolio[0]?.id || selectedScenario?.[0]?.id,
			(res) => {
				if (checkInStart && res?.task_state === 'SUCCESS') {
					setTimerStarted(false);
					return;
				} else {
					dispatch(startTimer('cfm9', supPorofolioId, ''));
					setRunningTaskId(selectedPortfolio?.id);
					setTimerStarted(true);
					if (res.task_state !== 'SUCCESS' && res.task_state !== 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA9,
							payload: res.task_progress
						});
					}
					if (res.task_state === 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA9,
							payload: 'Failed'
						});
						dispatch(
							killTaskFunc('cfm9', selectedPortfolio?.id, () => {
								deleteFunction();
								setRunningTaskId();
								stopTimerFunction();
								dispatch(
									stopTimer('cfm9', 'STOPPED', () => setTimerStarted(false))
								);
							})
						);
					}
				}
			}
		);
	};
	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('9', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};
	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA9_TIMER,
			payload: { status9: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog, callBack) => {
		let id = selectedPortfolio?.id;
		if (('' + status9)?.toLowerCase() === 'pending') {
			let modelName = 'cfm9';
			dispatch(
				killTaskFunc(modelName, id, () => {
					deleteFunction();
					closeKillTaskDialog && closeKillTaskDialog();
					setRunningTaskId();
					stopTimerFunction();
					dispatch(
						stopTimer(modelName, 'STOPPED', () => {
							setTimerStarted(false);
							callBack && callBack();
						})
					);
				})
			);
		} else {
			setTimerStarted(false);
			callBack && callBack();
		}
	};
	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
		if (collapsed >= 1) setChartVisible2(true);
		else if (collapsed === 0 && chartVisible2) setChartVisible2(false);
		if (collapsed >= 1) setChartVisible3(true);
		else if (collapsed === 0 && chartVisible) setChartVisible3(false);
	}, [collapsed]);
	const typeHeaders = (tableName, category) => {
		if (tableName) return dynamicHeaders(category);
		else return null;
	};
	const renderChart = () => {
		return (
			<div>
				<div style={{ marginTop: 50 }}></div>
				<p
					style={{
						fontFamiliy: 'Roboto',
						fontSize: '13px',
						marginTop: -8,
						color: '#313132',
						fontWeight: 'bold'
					}}
				>
					Portfolio Charts
				</p>
				{<hr style={{ marginTop: -10 }} />}
				<div style={{ marginTop: 20 }}></div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
					style={{ paddingBottom: !chartVisible ? 150 : 0 }}
				>
					<p className={classes.contentHeader}>{'Portfolio Charts'}</p>
				</div>
				{chartVisible &&
				subPortofolio9 &&
				Object.keys(subPortofolio9).length > 0 ? (
					<div className={classes.datechat__charts}>
						<br />
						{chartsData?.length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								{subPortofolio9?.chart_closing_balance && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6} // Changed from 4 to 6
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData?.[2]?.ch}
											nameLegend={`Historical Balance`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'per'}
											noCharts={['closing_balance']}
										/>
									</Grid>
								)}
								{subPortofolio9?.chart_closing_balance_cpr_scenarios && (
									<Grid
										item
										xs={12}
										sm={12}
										md={6} // Changed from 4 to 6
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData?.[5]?.ch}
											nameLegend={`Projected Balance`}
											brushID={`Projected Balance`}
											sizeLegend="14px"
											dataX={`Date`}
											xDistance={400}
											format={'per'}
											noCharts={Object.keys(
												subPortofolio9?.chart_closing_balance_cpr_scenarios ||
													{}
											).filter((key) => key !== 'Date')}
											customTooltip
										/>
									</Grid>
								)}
							</Grid>
						)}
					</div>
				) : chartVisible ? (
					<div
						className={classes.progressContainer}
						style={{ paddingBottom: 150 }}
					>
						<CircularProgress
							style={{
								color: '#266696',
								marginTop: 0,
								marginLeft: '49%'
							}}
							size={26}
						/>
					</div>
				) : null}
			</div>
		);
	};
	const renderChart2 = () => {
		return (
			subPortofolio9 && (
				<div>
					<div
						className={classes.contentHeaderContainer}
						onClick={() => setChartVisible2(!chartVisible2)}
					>
						<p className={classes.contentHeader}>{'Credit Charts'}</p>
					</div>
					{chartVisible2 &&
						subPortofolio9 &&
						Object.keys(subPortofolio9).length > 0 && (
							<div className={classes.datechat__charts}>
								<br />
								{chartsData?.length > 0 && (
									<Grid
										container
										spacing={1}
										justify="flex-start"
										alignItems="center"
										direction="row"
									>
										{subPortofolio9?.chart_default && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[1]?.ch}
													nameLegend={`Default`}
													brushID={`Default`}
													sizeLegend="14px"
													dataX={`x-axis`}
													xDistance={400}
													format={'per'}
													noCharts={Object.keys(
														subPortofolio9?.chart_default || {}
													).filter((key) => key !== 'x-axis')}
													customTooltip
												/>
											</Grid>
										)}
										{subPortofolio9?.chart_delinquency && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[0]?.ch}
													nameLegend={`Delinquency`}
													brushID={`delinquency`}
													sizeLegend="14px"
													dataX={`date`}
													xDistance={400}
													format={'per'}
													noCharts={[
														'status_1a_del_prcnt',
														'status_1b_del_prcnt',
														'status_2_del_prcnt',
														'status_3_del_prcnt',
														'status_4_del_prcnt'
													]}
												/>
											</Grid>
										)}
									</Grid>
								)}
							</div>
						)}
					{chartVisible2 &&
						!subPortofolio9?.chart_closing_balance &&
						!subPortofolio9.chart_default &&
						!subPortofolio9.chart_delinquency && (
							<div className={classes.progressContainer}>
								<CircularProgress
									style={{
										color: '#266696',
										marginTop: 0,
										marginLeft: '49%'
									}}
									size={26}
								/>
							</div>
						)}
				</div>
			)
		);
	};
	const renderChart3 = () => {
		return (
			subPortofolio9 && (
				<div>
					<div
						className={classes.contentHeaderContainer}
						onClick={() => setChartVisible3(!chartVisible3)}
					>
						<p className={classes.contentHeader}>{'Timing Charts'}</p>
					</div>
					{chartVisible3 &&
						subPortofolio9 &&
						Object.keys(subPortofolio9).length > 0 && (
							<div className={classes.datechat__charts}>
								<br />
								{chartsData?.length > 0 && (
									<Grid
										container
										spacing={1}
										justify="flex-start"
										alignItems="center"
										direction="row"
									>
										{subPortofolio9?.timing_curve?.cumulative_curve && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[3]?.ch}
													nameLegend={`Cumulative Curve`}
													sizeLegend="14px"
													dataX={`period`}
													xDistance={400}
													format={'per'}
													noCharts={['cumulative_curve']}
												/>
											</Grid>
										)}
										{subPortofolio9?.timing_curve?.timing_curve && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[4]?.ch}
													nameLegend={`Timing Curve`}
													sizeLegend="14px"
													dataX={`period`}
													xDistance={400}
													format={'per'}
													noCharts={['timing_curve']}
												/>
											</Grid>
										)}
									</Grid>
								)}
							</div>
						)}
					{chartVisible3 &&
						!subPortofolio9?.chart_closing_balance &&
						!subPortofolio9.chart_default &&
						!subPortofolio9.chart_delinquency && (
							<div className={classes.progressContainer}>
								<CircularProgress
									style={{
										color: '#266696',
										marginTop: 0,
										marginLeft: '49%'
									}}
									size={26}
								/>
							</div>
						)}
				</div>
			)
		);
	};

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator,
		extraMultiSeparator
	) => {
		let finalTableName =
			tableName === 'specialtable2' ? 'assetamort_table' : tableName;

		if (['Vintage', 'Portfolio'].includes(verboseTableName)) return null;

		const fetchData = () => {
			const tableKeys = Object.keys(tables9 || {});
			const isTableDataMissing = !tableKeys.includes(tableName);

			if (
				(['stopped', 'SUCCESS'].includes(('' + status9).toLowerCase()) &&
					isTableDataMissing) ||
				staus9ScenarioID !== selectedScenario?.[0]?.id
			) {
				fetchScenarioDetails(selectedScenario[0]?.id, tableName + '/');
			}
		};

		return (
			<div>
				{[
					'Balance Sheet ',
					'Historical Portfolio Daily',
					'Projected Portfolio Daily',
					'Projected Portfolio Run-off',
					'Borrowing Base Daily',
					'Ineligible Receivables Daily',
					'Interest Paid by Borrower Daily',
					'Excess Concentration Limits',
					'Available Cash Daily',
					'Bad Debt Support Schedule',
					'Loan Pricing  '
				].includes(verboseTableName) ? (
					<>
						<div
							style={{
								marginTop: verboseTableName === 'Balance Sheet ' ? 20 : 50
							}}
						></div>
						<p
							style={{
								fontFamiliy: 'Roboto',
								fontSize: '13px',
								marginTop: -8,
								color: '#313132',
								fontWeight: 'bold'
							}}
						>
							{verboseTableName === 'Balance Sheet '
								? 'Financials'
								: verboseTableName === 'Loan Pricing  '
								? 'Loan Pricing'
								: verboseTableName === 'Historical Portfolio Daily'
								? 'Historical Portfolio'
								: verboseTableName === 'Projected Portfolio Daily'
								? 'Projected portfolio'
								: verboseTableName === 'Borrowing Base Daily'
								? 'Borrowing Base'
								: verboseTableName === 'Ineligible Receivables Daily'
								? 'Ineligibles and Excess'
								: verboseTableName === 'Interest Paid by Borrower Daily'
								? 'Supporting Schedules'
								: ''}
						</p>
						{![
							'Projected Portfolio Run-off',
							'Excess Concentration Limits',
							'Available Cash Daily',
							'Bad Debt Support Schedule'
						].includes(verboseTableName) && <hr style={{ marginTop: -10 }} />}
						<div style={{ marginTop: 20 }}></div>
					</>
				) : (
					''
				)}
				<MainTable
					statusScenarioId={staus9ScenarioID}
					status={('' + status9).toLowerCase()}
					header={tableData && tableData[finalTableName]?.columns}
					data={tableData && tableData[finalTableName]}
					attributes={
						tableData &&
						tableData[finalTableName]?.data &&
						Object.keys(tableData[finalTableName]?.columns)
					}
					tableData={tableData}
					multiSeparator={multiSeparator}
					extraMultiSeparator={extraMultiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableDataName={finalTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					collapsed={collapsed}
					separator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								multiSeparator ? 'category' : 'category2'
							]
					)}
					nestedSeparator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							!multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								!multiSeparator ? 'category' : 'category2'
							]
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model="9"
					id={selectedScenario[0]?.id}
					modelName="fpna9"
					fetchData={fetchData}
				/>
			</div>
		);
	};

	const renderTables = () => {
		return tableDataFpnaV9_3_1.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				tables9,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(311)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							dispatchClean={() => dispatchClean()}
							model={'fpna9-3-1'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							timerStarted={timerStarted}
							loading={('' + status9).toLowerCase() === 'pending'}
							key={2012}
							portfolioList={portfolios9 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios9.filter((item) => item.id == val)[0]
								);
							}}
							upload={(formData) => uploadFunction(formData)}
							downloadFile={() => {
								dispatch(downloadDataFile('9', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('9'));
							}}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios9?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => setSelectedScenario([item])}
							setData={(val) => setDataFunction(val)}
							downloadCustomReports={(type) => {
								dispatch(
									downloadFpnaCustomReports('9', selectedScenario[0]?.id, type)
								);
							}}
							collapsed={collapsed}
							runCalculateFunction={runCalculateFunction}
							selectedData={dataType}
							seconds={0}
							status={status9}
							minutes={0}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<>{renderTables()}</>
						{renderChart()}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default FpnaV9_3_1;
