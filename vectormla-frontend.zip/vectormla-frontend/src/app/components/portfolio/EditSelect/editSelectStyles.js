import { fade, makeStyles } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import { Checkbox } from '@material-ui/core';
import { primaryColor } from '../../../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	root: {
		width: 135,
		fontSize: '11px'
	},
	button: {
		width: 135,
		fontSize: '11px',
		textAlign: 'left',
		margin: '10px 0px',
		height: '25px',
		borderRadius: 0,
		textTransform: 'capitalize',
		backgroundColor: '#f7f8fa',
		border: '1px solid rgb(25, 71, 117)',
		color: primaryColor,
		'& span': {
			width: '100%',
			marginLeft: 3,
			fontSize: '11px',
			color: '#000'
		},
		'& svg': {
			width: 16,
			height: 16
		}
	},
	tag: {
		marginTop: 3,
		height: 20,
		padding: '.15em 4px',
		fontWeight: 600,
		lineHeight: '15px',
		borderRadius: 2
	},
	popper: {
		border: '1px solid rgba(27,31,35,.15)',
		boxShadow: '0 3px 12px rgba(27,31,35,.15)',
		borderRadius: 3,
		width: '250px',
		zIndex: 1100,
		fontSize: 13,
		color: '#586069',
		backgroundColor: '#f6f8fa'
	},
	header: {
		borderBottom: '1px solid #e1e4e8',
		padding: '8px 10px',
		fontWeight: 600
	},
	inputBase: {
		padding: 10,
		width: '250px',
		borderBottom: '1px solid #dfe2e5',
		'& input': {
			borderRadius: 4,
			backgroundColor: theme.palette.common.white,
			padding: 8,
			transition: theme.transitions.create(['border-color', 'box-shadow']),
			border: '1px solid #ced4da',
			fontSize: '11px',
			'&:focus': {
				boxShadow: `${fade(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
				borderColor: theme.palette.primary.main
			},
			'&::placeholder': {
				color: 'red',
				opacity: 1
			}
		}
	},
	paper: {
		boxShadow: 'none',
		margin: 0,
		color: '#586069',
		width: '250px',
		fontSize: '11px'
	},
	option: {
		minHeight: 'auto',
		alignItems: 'flex-start',
		padding: 8,
		'&[aria-selected="true"]': {
			backgroundColor: 'transparent'
		},
		'&[data-focus="true"]': {
			backgroundColor: theme.palette.action.hover
		}
	},
	popperDisablePortal: {
		position: 'relative'
	},
	iconSelected: {
		width: 17,
		height: 17,
		marginRight: 5,
		marginLeft: -2
	},
	color: {
		width: 14,
		height: 14,
		flexShrink: 0,
		borderRadius: 3,
		marginRight: 8,
		marginTop: 2
	},
	text: {
		flexGrow: 1
	},
	close: {
		opacity: 0.6,
		width: 18,
		height: 18
	},
	divButtonEdit: {
		display: 'flex',
		justifyContent: 'space-around',
		margin: '10px 0px',
		width: '250px'
	},
	buttonEdit: {
		textTransform: 'capitalize',
		height: 31,
		width: 60,
		color: '#fff',
		borderRadius: 0,
		backgroundColor: '#7991aa',
		'&:hover': {
			backgroundColor: '#99a8b7'
		},
		'&:disabled': {
			backgroundColor: '#fff',
			color: '#000'
		}
	},
	checkbox_icon: {
		flex: 1,
		marginRight: 8
	},
	checkbox_typo: {
		width: 170,
		maxWidth: 190,
		height: 30,
		fontSize: '11px',
		marginTop: '10px',
		overflow: 'hidden',
		'&:hover': {
			cursor: 'pointer'
		}
	},
	editPen: {
		color: 'green',
		'&:hover': {
			cursor: 'pointer'
		},
		marginTop: 10,
		flex: 1
	},
	closeIcon: {
		color: 'red',
		'&:hover': {
			cursor: 'pointer'
		},
		marginTop: 10,
		flex: 1
	},
	checkbox_input: {
		width: '80%',
		zIndex: 99,
		margin: '7px 0px auto',
		'& .MuiInputLabel-formControl': {
			top: -5
		},
		'& .MuiOutlinedInput-input': {
			padding: '12px 14px'
		}
	}
}));

export const DarkCheckbox = withStyles({
	root: {
		color: 'grey',
		'&$checked': {
			color: primaryColor
		}
	},
	checked: {}
	// eslint-disable-next-line react/react-in-jsx-scope
})((props) => <Checkbox color="default" {...props} />);
