import SvgIcon from '@material-ui/core/SvgIcon';
import React from 'react';

export const MinusSquare = (props) => {
	return (
		<SvgIcon
			fontSize="inherit"
			style={{
				width: 14,
				height: 14,
				marginLeft: props.extra
					? 8
					: props.secondextra
					? 16
					: props.thirdExtra
					? 24
					: 0
			}}
			{...props}
		>
			<path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 11.023h-11.826q-.375 0-.669.281t-.294.682v0q0 .401.294 .682t.669.281h11.826q.375 0 .669-.281t.294-.682v0q0-.401-.294-.682t-.669-.281z" />
		</SvgIcon>
	);
};

export const PlusSquare = (props) => {
	return (
		<SvgIcon
			fontSize="inherit"
			style={{
				width: 14,
				height: 14,
				marginLeft: props.extra
					? 8
					: props.secondextra
					? 16
					: props.thirdExtra
					? 24
					: 0
			}}
			{...props}
		>
			<path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 12.977h-4.923v4.896q0 .401-.281.682t-.682.281v0q-.375 0-.669-.281t-.294-.682v-4.896h-4.923q-.401 0-.682-.294t-.281-.669v0q0-.401.281-.682t.682-.281h4.923v-4.896q0-.401.294-.682t.669-.281v0q.401 0 .682.281t.281.682v4.896h4.923q.401 0 .682.281t.281.682v0q0 .375-.281.669t-.682.294z" />
		</SvgIcon>
	);
};
export const PlusSquareTotal = (props) => {
	return (
		<SvgIcon
			fontSize="inherit"
			style={{ width: 14, height: 14, marginLeft: -5 }}
			{...props}
		>
			<path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 12.977h-4.923v4.896q0 .401-.281.682t-.682.281v0q-.375 0-.669-.281t-.294-.682v-4.896h-4.923q-.401 0-.682-.294t-.281-.669v0q0-.401.281-.682t.682-.281h4.923v-4.896q0-.401.294-.682t.669-.281v0q.401 0 .682.281t.281.682v4.896h4.923q.401 0 .682.281t.281.682v0q0 .375-.281.669t-.682.294z" />
		</SvgIcon>
	);
};
export const MinusSquareTotal = (props) => {
	return (
		<SvgIcon
			fontSize="inherit"
			style={{ width: 14, height: 14, marginLeft: -5 }}
			{...props}
		>
			<path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 11.023h-11.826q-.375 0-.669.281t-.294.682v0q0 .401.294 .682t.669.281h11.826q.375 0 .669-.281t.294-.682v0q0-.401-.294-.682t-.669-.281z" />
		</SvgIcon>
	);
};
export const rendersideBar = (currentCell, cashFlowSize) => {
	let height = Math.floor(cashFlowSize / 20);
	let nums = [];

	for (let i = 0; i < height; i++) {
		nums.push(i + 1);
	}

	return nums.map((num, index) => (
		<div
			key={index}
			style={{
				width: 25,
				height: 20,
				border: '1px solid #DBE0E5',
				borderTop: 0,
				fontSize: 11,
				boxSizing: 'border-box',
				backgroundColor: '#fff',
				textAlign: 'center'
			}}
			className={`num_cell num_cell`}
		>
			{num}
		</div>
	));
};
