import React from 'react';
import { fade, makeStyles } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import { Checkbox } from '@material-ui/core';
import { primaryColor } from '../../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	root: {
		width: 221,
		fontSize: 13
	},
	button: {
		width: 135,
		height: 25,
		textAlign: 'left',
		borderRadius: 0,
		backgroundColor: '#f7f8fa !important',
		border: '1px solid rgb(25, 71, 117) !important',
		color: `${primaryColor} !important`,
		'& span': {
			width: '100%',
			fontSize: '11px'
		},
		'& svg': {
			width: 16,
			height: 16
		}
	},
	tag: {
		marginTop: 3,
		height: 20,
		padding: '.15em 4px',
		fontWeight: 600,
		lineHeight: '15px',
		borderRadius: 2
	},
	popper: {
		border: '1px solid rgba(27,31,35,.15) !important',
		boxShadow: '0 3px 12px rgba(27,31,35,.15) !important',
		borderRadius: 3,
		width: 250,
		zIndex: 1100,
		fontSize: 13,
		color: '#586069 !important',
		backgroundColor: '#f6f8fa !important'
	},
	header: {
		borderBottom: '1px solid #e1e4e8 !important',
		padding: '8px 10px',
		fontWeight: 600
	},
	inputBase: {
		padding: 10,
		width: 250,
		borderBottom: '1px solid #dfe2e5 !important',
		'& input': {
			borderRadius: 4,
			backgroundColor: theme.palette.common.white,
			padding: 8,
			transition: theme.transitions.create(['border-color', 'box-shadow']),
			border: '1px solid #ced4da',
			fontSize: 14,
			'&:focus': {
				boxShadow: `${fade(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
				borderColor: theme.palette.primary.main
			}
		}
	},
	paper: {
		boxShadow: 'none',
		margin: 0,
		color: '#586069 !important',
		fontSize: 13
	},
	option: {
		minHeight: 'auto',
		alignItems: 'flex-start',
		padding: 8,
		'&[aria-selected="true"]': {
			backgroundColor: 'transparent'
		},
		'&[data-focus="true"]': {
			backgroundColor: theme.palette.action.hover
		}
	},
	popperDisablePortal: {
		position: 'relative'
	},
	iconSelected: {
		width: 17,
		height: 17,
		marginRight: 5,
		marginLeft: -2
	},
	color: {
		width: 14,
		height: 14,
		flexShrink: 0,
		borderRadius: 3,
		marginRight: 8,
		marginTop: 2
	},
	text: {
		flexGrow: 1
	},
	close: {
		opacity: 0.6,
		width: 18,
		height: 18
	}
}));

export const DarkCheckbox = withStyles({
	root: {
		color: 'grey',
		'&$checked': {
			color: primaryColor
		}
	},
	checked: {}
})((props) => <Checkbox color="default" {...props} />);
